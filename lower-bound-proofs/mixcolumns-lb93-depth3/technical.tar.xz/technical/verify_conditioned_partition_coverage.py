"""Independent complete regeneration after certified weight-six exclusions."""
from pathlib import Path
from functools import lru_cache
from itertools import combinations
from collections import Counter
import json,time,argparse,hashlib
from verify_pair26 import canonical,inverse
from verify_cluster_results import aes_rows
HERE=Path(__file__).resolve().parent
ALL32=(1<<32)-1;ALL64=(1<<64)-1

def regenerate_short(rows,maximum):
    def apply(rs,u):return sum(((r&u).bit_count()%2)<<i for i,r in enumerate(rs))
    inv=inverse(rows);cols=[apply(rows,1<<i) for i in range(32)];icols=[apply(inv,1<<i) for i in range(32)]
    assert all(apply(inv,cols[i])==1<<i for i in range(32))
    words=set()
    for k in range(1,maximum//2+1):
        for ii in combinations(range(32),k):
            u=sum(1<<i for i in ii);v=z=0
            for i in ii:v^=cols[i];z^=icols[i]
            if k+v.bit_count()<=maximum:words.add(u|(v<<32))
            if k+z.bit_count()<=maximum:words.add(z|(u<<32))
    expected={6:84,8:276,10:1300,12:8112,14:46040}
    assert Counter(w.bit_count() for w in words)=={k:v for k,v in expected.items() if k<=maximum}
    return words

def enumerate_partitions(rows,all_words,bad,excluded,blocks,budget,destination):
    @lru_cache(None)
    def tax(u):
        components=[];cycles=0
        for e in sorted({u&r for r in rows if r.bit_count()==7 and (u&r).bit_count()==2}):
            hits=[j for j,c in enumerate(components) if c&e]
            if len(hits)==1 and components[hits[0]]&e==e:cycles+=1
            merged=e
            for j in reversed(hits):merged|=components.pop(j)
            components.append(merged)
        return max(cycles,int(canonical(u) in bad))
    maxweight={6:14,7:12,8:10}[blocks]
    words=sorted((w for w in all_words if w.bit_count()<=maxweight and canonical(w&ALL32) not in excluded and tax(w&ALL32)<=budget),key=lambda w:(w.bit_count(),w))
    n=len(words);weights=[w.bit_count() for w in words];taxes=[tax(w&ALL32) for w in words]
    incidence=[0]*64
    for j,w in enumerate(words):
        v=w
        while v:
            b=v&-v;v-=b;incidence[b.bit_length()-1]|=1<<j
    compat=[];all_indices=(1<<n)-1
    for j,w in enumerate(words):
        conflicts=0;v=w
        while v:
            b=v&-v;v-=b;conflicts|=incidence[b.bit_length()-1]
        compat.append((all_indices^((1<<(j+1))-1))&~conflicts)
    weightmask={k:sum(1<<j for j,w in enumerate(weights) if w<=k) for k in range(6,maxweight+1)}
    taxmask={k:sum(1<<j for j,t in enumerate(taxes) if t<=k) for k in range(budget+1)}
    @lru_cache(None)
    def splits(rem):
        inp=rem&ALL32;out=rem>>32
        eq=[r&inp for i,r in enumerate(rows) if not out>>i&1];piv=[];rank=0
        for i in range(32):
            if not inp>>i&1:continue
            j=next((j for j in range(rank,len(eq)) if eq[j]>>i&1),None)
            if j is None:continue
            eq[rank],eq[j]=eq[j],eq[rank]
            for j in range(len(eq)):
                if j!=rank and eq[j]>>i&1:eq[j]^=eq[rank]
            piv.append(i);rank+=1
        basis=[]
        for i in range(32):
            if inp>>i&1 and i not in piv:
                u=(1<<i)|sum(1<<p for p,r in zip(piv,eq) if r>>i&1)
                v=sum(((r&u).bit_count()&1)<<j for j,r in enumerate(rows))
                assert not v&~out;basis.append(u|(v<<32))
        code=[0]
        for b in basis:code += [w^b for w in code]
        result=[]
        for a in code[1:]:
            b=rem^a;ka=(a.bit_count(),a);kb=(b.bit_count(),b)
            if not b or ka>=kb:continue
            if canonical(a&ALL32) in excluded or canonical(b&ALL32) in excluded:continue
            cost=tax(a&ALL32)+tax(b&ALL32)
            if cost<=budget:result.append((ka,a,b,cost))
        return result
    nodes=leaves=survivors=0;chosen=[]
    with destination.open('w') as f:
        def dfs(candidates,used,depth,spent):
            nonlocal nodes,leaves,survivors
            nodes+=1
            if depth==blocks-2:
                leaves+=1;last=(weights[chosen[-1]],words[chosen[-1]])
                for key,a,b,cost in splits(ALL64^used):
                    if key>last and spent+cost<=budget:
                        survivors+=1;print(*(words[j]&ALL32 for j in chosen),a&ALL32,b&ALL32,file=f)
                return
            mw=min(maxweight,(64-used.bit_count())//(blocks-depth))
            if mw<6:return
            # Only the NEXT chosen word is bounded by this average weight.
            # Later words may be heavier, so retain the unfiltered candidates
            # for recursion. Cycle budgets only decrease, unlike this bound.
            eligible = candidates & weightmask[mw] & taxmask[budget-spent]
            while eligible:
                bit=eligible&-eligible;eligible-=bit;j=bit.bit_length()-1
                chosen.append(j);dfs(candidates&compat[j],used|words[j],depth+1,spent+taxes[j]);chosen.pop()
        dfs((1<<n)-1,0,0,0)
    result={'blocks':blocks,'cycle_budget':budget,'short_words':n,'nodes':nodes,'leaves':leaves,'surviving_partitions':survivors,'distinct_remainders':splits.cache_info().currsize}
    print('PARITY ENUMERATION',json.dumps(result),flush=True);return result

def run(blocks):
    start=time.monotonic();rows=aes_rows();maximum={6:14,7:12}[blocks]
    words=regenerate_short(rows,maximum);print('SHORT WORDS PASS',blocks,len(words),flush=True)
    given=list(map(int,(HERE/('six_partition_data.txt' if blocks==6 else 'seven_partition_data.txt')).read_text().split()))
    assert given[:32]==rows and given[32]==len(words) and set(given[33:])==words
    badfile=HERE/('pair26_extended_forest_obstructions.txt' if blocks==6 else 'forest_obstruction_cover.txt')
    bad=set(map(int,badfile.read_text().split()));excluded=set(map(int,(HERE/'excluded_components_92_weight6.txt').read_text().split()))
    checks=json.loads((HERE/'component_conditional_checks.json').read_text());assert checks['status']=='PASS'
    assert excluded=={x['component'] for x in checks['records']}
    target=HERE/f'conditioned_c{blocks}_python.txt';info=enumerate_partitions(rows,words,bad,excluded,blocks,blocks-6,target)
    def readset(path):
        lines=path.read_text().splitlines();result={tuple(sorted(map(int,line.split()))) for line in lines}
        assert len(result)==len(lines);return result
    a=readset(target);b=readset(HERE/f'conditioned_c{blocks}_parts.txt');assert a==b
    result={'status':'PASS','components':blocks,'cycle_budget':blocks-6,'enumeration':info,'cpp_set_matches':True,'canonical_sha256':hashlib.sha256(json.dumps(sorted(a),separators=(',',':')).encode()).hexdigest(),'seconds':time.monotonic()-start,'scope':'Complete parity-partition coverage after previously verified component exclusions; partitions are not yet all excluded.'}
    (HERE/f'conditioned_c{blocks}_coverage_checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('components',type=int,choices=[6,7]);a=p.parse_args();run(a.components)
