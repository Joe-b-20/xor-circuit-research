#include <array>
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
struct R {array<int,5> h; int base;};
vector<int>w,cnt;array<vector<R>,4>r;array<int,4>choice,bestchoice;uint64_t nodes=0,leaves=0;int best=1000000000;bool stopped=false;double limit;auto start=chrono::steady_clock::now();
int delta(const R &a){return w[a.h[0]]*(cnt[a.h[0]]==0)+w[a.h[1]]*(cnt[a.h[1]]==0)+w[a.h[2]]*(cnt[a.h[2]]==0)+w[a.h[3]]*(cnt[a.h[3]]==0)+w[a.h[4]]*(cnt[a.h[4]]==0);}
void dfs(int d,int cost){
 if(stopped || cost>=best)return;
 if(d==3){
  for(int j=0;j<(int)r[d].size();j++){leaves++;int total=cost+delta(r[d][j]);if(total<best){best=total;choice[d]=j;bestchoice=choice;cout<<"best "<<best<<" nodes "<<nodes<<" leaves "<<leaves<<endl;}}
  return;
 }
 if(d==2){for(int k=d;k<4;k++){int mn=1000000000;for(auto &a:r[k])mn=min(mn,delta(a));if(cost+mn>=best)return;}}
 for(int j=0;j<(int)r[d].size();j++){
  nodes++;
  if((nodes&65535)==0 && chrono::duration<double>(chrono::steady_clock::now()-start).count()>limit){stopped=true;return;}
  auto &a=r[d][j];int dc=delta(a);if(cost+dc>=best)continue;
  choice[d]=j;for(int h:a.h)cnt[h]++;dfs(d+1,cost+dc);for(int h:a.h)cnt[h]--;
 }
}
int main(int argc,char**argv){
 if(argc<2)return 2;ifstream in(argv[1]);int n;in>>n;w.resize(n);cnt.resize(n);for(int &v:w)in>>v;
 for(auto &rr:r){int m;in>>m;rr.resize(m);for(auto &a:rr){a.base=0;for(int &h:a.h){in>>h;a.base+=w[h];}}stable_sort(rr.begin(),rr.end(),[](const R&a,const R&b){return a.base<b.base;});}
 if(!in)return 3;limit=argc>2?stod(argv[2]):120;start=chrono::steady_clock::now();dfs(0,0);
 cout<<(stopped?"INCOMPLETE":"COMPLETE")<<" minimum "<<best<<" nodes "<<nodes<<" leaves "<<leaves<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<endl;
 cout<<"recipes";for(int i=0;i<4;i++)for(int h:r[i][bestchoice[i]].h)cout<<' '<<h;cout<<endl;
}

