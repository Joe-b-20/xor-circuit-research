"""Independent exact check: P=26,c=8 implies T+Q>=38.

Regenerates every parity partition; covers it by either exact pair-recipe
infeasibility or a directly checked parent-forest price. No optimizer is
imported. Parent eligibility is regenerated from component intersections,
without importing the discovery helper or recipe model.
"""
from pathlib import Path
from itertools import combinations
from collections import defaultdict
from fractions import Fraction
import json,re,subprocess,tempfile,time,hashlib,argparse
from verify_cluster_results import aes_rows
from verify_pair26 import short_words,enumerate_partitions,pair_recipes,write_recipe_data
from independent_parent_rows import all_trees
HERE=Path(__file__).resolve().parent

def rot(h,r):return ((h<<(8*r))&0xffffffff)|(h>>(32-8*r)) if r else h

def regenerate_parent_edges(O):
    odd=[1<<i for i in range(32)]+[sum(1<<i for i in ii) for ii in combinations(range(32),3)]
    E=sorted((a,a^y,o) for o,y in enumerate(O) for a in odd if (a^y).bit_count() in (2,4))
    assert len(E)==6120
    return E

def check_prices(cuts,O):
    full=regenerate_parent_edges(O);V={h for a,b,o in full for h in (a,b)}
    cache={};coverage={};minimum=None;total_trees=0
    for ci,cut in enumerate(cuts):
        blocks=cut['partition'];D=cut['price_denominator'];prices=cut['prices']
        assert type(D) is int and D>0 and len(prices)==32 and all(type(p) is int for p in prices)
        union=0;outputs=0
        for b in blocks:
            assert type(b) is int and 0<b<2**32 and not union&b;union|=b
            out=sum(((y&b).bit_count()%2)<<i for i,y in enumerate(O))
            assert out and not outputs&out;outputs|=out
        assert len(blocks)==8 and union==outputs==2**32-1
        allowed=set()
        for h in V:
            w=h.bit_count();counts=[(h&b).bit_count() for b in blocks]
            if w==1 or (w==2 and 2 in counts) or (w==3 and max(counts)>=2) or (w==4 and all(v%2==0 for v in counts)):allowed.add(h)
        E=[e for e in full if e[0] in allowed and e[1] in allowed]
        assert len(E)==cut['edges']
        adj=defaultdict(set)
        for a,b,o in E:adj[a].add(b);adj[b].add(a)
        seen=set();tree_count=0
        for root in sorted(adj):
            if root in seen:continue
            S={root};seen.add(root);todo=[root]
            for a in todo:
                for b in adj[a]:
                    if b not in seen:seen.add(b);S.add(b);todo.append(b)
            ee=tuple(e for e in E if e[0] in S)
            if ee not in cache:
                trees=all_trees(S,ee)
                cache[ee]=[(tuple(sorted(labels)),sum(h.bit_count()>2 for h in vertices)) for vertices,labels in trees]
            tt=cache[ee];tree_count+=len(tt)
            assert all(sum(prices[o] for o in labels)<=D*cost for labels,cost in tt),(ci,'invalid tree price')
        assert tree_count==cut['trees'];total_trees+=tree_count
        bound=Fraction(sum(prices),D);assert bound>37
        minimum=bound if minimum is None else min(minimum,bound)
        for r in range(4):
            key=tuple(sorted(rot(b,r) for b in blocks))
            if key in coverage:assert coverage[key]==ci
            coverage[key]=ci
        if (ci+1)%50==0:print('PARENT PRICE PASS',ci+1,'minimum',minimum,'cached components',len(cache),flush=True)
    assert len(cuts)==388 and len(coverage)==1552
    return coverage,{'representatives':len(cuts),'covered_partitions':len(coverage),'minimum_exact_parent_bound':str(minimum),'integer_parent_lower_bound':38,'trees_checked_with_multiplicity':total_trees,'distinct_component_graphs':len(cache)}

def run(reuse_forest=False):
    start=time.monotonic();O=aes_rows();basis={}
    for row in O:
        while row:
            k=row.bit_length()-1
            if k in basis:row^=basis[k]
            else:basis[k]=row;break
    assert len(basis)==32
    assert all(rot(O[8*b+k],1)==O[8*((b+1)%4)+k] for b in range(4) for k in range(8))
    cuts=json.loads((HERE/'partition_parent_prices.json').read_text());coverage,price_checks=check_prices(cuts,O)
    print('ALL PARENT PRICES PASS',json.dumps(price_checks),flush=True)
    with tempfile.TemporaryDirectory(prefix='aes-eight-component-proof-') as td:
        td=Path(td);badfile=HERE/'forest_obstruction_cover.txt';bad=set(map(int,badfile.read_text().split()))
        recipes=pair_recipes(O);write_recipe_data(td/'recipes.txt',recipes)
        if not reuse_forest:
            exe=td/'component_check';subprocess.run(['g++','-O3','-std=c++17',str(HERE/'check_component_forests.cpp'),'-o',str(exe)],check=True)
            out=subprocess.check_output([str(exe),str(td/'recipes.txt'),str(badfile),str(td/'bad_verified.txt'),'20000000','600'],text=True)
            assert re.search(r'^COMPLETE components 4082 rejected 4082 unknown 0 feasible 0 ',out,re.M)
            assert set(map(int,(td/'bad_verified.txt').read_text().split()))==bad
        words=short_words(O)
        enum=enumerate_partitions(O,words,bad,8,2,td/'all_parts.txt')
        assert enum['surviving_partitions']==110712
        covered=set();left=0
        with (td/'reject_parts.txt').open('w') as out:
            for line in (td/'all_parts.txt').read_text().splitlines():
                key=tuple(sorted(map(int,line.split())))
                if key in coverage:covered.add(key)
                else:out.write(line+'\n');left+=1
        assert covered==set(coverage) and left==109160
        exe=td/'pair_check';subprocess.run(['g++','-O3','-std=c++17',str(HERE/'check_partition_pairs.cpp'),'-o',str(exe)],check=True)
        out=subprocess.check_output([str(exe),str(td/'recipes.txt'),str(td/'reject_parts.txt'),'8','2','1000000','600'],text=True)
        m=re.search(r'^COMPLETE partitions (\d+) rejected (\d+) unknown 0 nodes (\d+) seconds (\S+)',out,re.M)
        assert m and int(m[1])==int(m[2])==left,'Incomplete pair exclusion is not a proof.\n'+out[-1000:]
        pair_check={'rejected_partitions':left,'nodes':int(m[3]),'seconds':float(m[4])}
    result={'status':'PASS','theorem':'Every normalized depth-three circuit with P=26 and c=8 has T+Q>=38, hence G>=96.',
            'parent_prices':price_checks,'independent_parity_enumeration':enum,'pair_recipe_exclusions':pair_check,'seconds':time.monotonic()-start,
            'forest_obstruction_sha256':hashlib.sha256(badfile.read_bytes()).hexdigest(),'forest_premise_reused':reuse_forest,
            'scope':'This excludes the c=8 branch of the 92-gate case. The c=6 and c=7 branches are not excluded by this theorem.'}
    (HERE/'eight_component_tradeoff_checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--reuse-forest-premise',action='store_true');a=ap.parse_args();run(a.reuse_forest_premise)
