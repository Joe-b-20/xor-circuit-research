"""Regenerate and compare full corrected Python/C++ c=8 partition sets.

This cross-check audits enumeration coverage. The separate theorem checkers
establish that the obstruction file is valid and classify all generated cases.
"""
from pathlib import Path
import json,hashlib,subprocess,tempfile
from verify_pair26 import short_words,enumerate_partitions
from verify_cluster_results import aes_rows
HERE=Path(__file__).resolve().parent

def readset(path):
    lines=path.read_text().splitlines()
    values={tuple(sorted(map(int,line.split()))) for line in lines}
    assert len(values)==len(lines)
    return values

def run():
    rows=aes_rows();words=short_words(rows)
    bad=set(map(int,(HERE/'forest_obstruction_cover.txt').read_text().split()))
    with tempfile.TemporaryDirectory(prefix='aes-partition-crosscheck-') as td:
        td=Path(td)
        enumerate_partitions(rows,words,bad,8,2,td/'python.txt')
        ww=sorted(w for w in words if w.bit_count()<=10)
        (td/'input.txt').write_text(' '.join(map(str,rows))+'\n'+str(len(ww))+'\n'+'\n'.join(map(str,ww))+'\n')
        exe=td/'cpp';subprocess.run(['g++','-O3','-std=c++17',str(HERE/'enumerate_obstructed_partitions.cpp'),'-o',str(exe)],check=True)
        log=subprocess.check_output([str(exe),str(td/'input.txt'),str(td/'cpp.txt'),'8','2','600',str(HERE/'forest_obstruction_cover.txt')],text=True)
        assert log.startswith('COMPLETE '),log
        a=readset(td/'python.txt');b=readset(td/'cpp.txt')
        assert a==b and len(a)==110712
        digest=hashlib.sha256(json.dumps(sorted(a),separators=(',',':')).encode()).hexdigest()
        result={'status':'PASS','python_partitions':len(a),'cpp_partitions':len(b),'python_only':0,'cpp_only':0,'canonical_sha256':digest}
    (HERE/'corrected_partition_crosscheck.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

if __name__=='__main__':run()
