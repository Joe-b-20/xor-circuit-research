"""Independent exact Farkas checks for fixed actual pair partitions."""
from pathlib import Path
from itertools import combinations
import json,hashlib,argparse
from independent_check import rebuild
from independent_check_86 import new_rows
from compact_joint_certificate import assemble
from verify_cluster_results import aes_rows
from verify_component_conditionals import SOURCE_SHA
HERE=Path(__file__).resolve().parent

def run(components=None):
    source=HERE/'certificate_depth3_linked_92.json';assert hashlib.sha256(source.read_bytes()).hexdigest()==SOURCE_SHA
    src=json.loads(source.read_text());base,c,H,opts=rebuild();base+=new_rows(H,opts);base,_=assemble(base,H,opts,src)
    base.append(([(j,-1) for j,h in enumerate(H) if h.bit_count()==2],-26))
    base.append(([(j,-1) for j,h in enumerate(H)],-60))
    O=aes_rows();results=[]
    pair_endpoints={h:tuple(i for i in range(32) if h>>i&1) for h in H if h.bit_count()==2}
    forms={}
    for h in H:
        if h.bit_count()==2:forms[h]=[(h,)];continue
        bits=[1<<i for i in range(32) if h>>i&1];ff=set()
        for a,b in combinations(bits,2):
            p=a|b;q=h^p;ff.add((p,) if q.bit_count()==1 else tuple(sorted((p,q))))
        assert len(ff)==3;forms[h]=sorted(ff)
    index={h:j for j,h in enumerate(H)}
    recipe_indices=[tuple(index[h] for h in r) for rr in opts for r in rr]
    for path in sorted(HERE.glob('partition_cut_c*.json' if components is None else f'partition_cut_c{components}_*.json')):
        cert=json.loads(path.read_text());blocks=cert['partition'];assert len(blocks)==cert['components'] in (6,7)
        union=0;outunion=0;color={}
        for k,C in enumerate(blocks):
            assert type(C) is int and 0<C<2**32 and not union&C;union|=C
            v=sum(((y&C).bit_count()%2)<<i for i,y in enumerate(O));assert v and not outunion&v;outunion|=v
            for i in range(32):
                if C>>i&1:color[i]=k
        assert union==outunion==2**32-1
        pair_ok={h:color[a]==color[b] for h,(a,b) in pair_endpoints.items()}
        helper_ok=[any(all(pair_ok[p] for p in ff) for ff in forms[h]) for h in H]
        ok=helper_ok+[all(helper_ok[j] for j in rr) for rr in recipe_indices]
        local=[]
        for C in blocks:
            if C.bit_count()>1:local.append(([(j,1) for j,h in enumerate(H) if h.bit_count()==2 and h&C==h],C.bit_count()-1))
        assert json.loads(json.dumps(local))==cert['connectivity_rows'];rows=base+local
        acc=[0]*len(c);raw=0;seen=set();D=cert['denominator'];assert type(D) is int and D>0
        for i,u in cert['u_nonzero']:
            assert type(i) is int and 0<=i<len(rows) and i not in seen;seen.add(i)
            assert type(u) is int and u>=0
            ts,b=rows[i];raw+=u*b
            for j,a in ts:acc[j]+=u*a
        repair=sum(max(0,acc[j]) for j in range(len(c)) if ok[j]);num=raw-repair
        assert (raw,repair,num)==(cert['raw_numerator'],cert['repair_numerator'],cert['contradiction_numerator']) and num>0
        results.append({'file':path.name,'partition':blocks,'components':len(blocks),'contradiction_numerator':num,'denominator':D})
        if len(results)%20==0:print('PARTITION FARKAS PASS',len(results),flush=True)
    result={'status':'PASS','verified_certificates':len(results),'source_sha256':SOURCE_SHA,'scope':'Each listed actual component partition is impossible at P=26,H<=60. Unlisted partitions are not excluded by these checks.','records':results}
    (HERE/('partition_conditional_checks.json' if components is None else f'partition_conditional_checks_c{components}.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='records'},indent=2),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--components',type=int,choices=[6,7]);a=p.parse_args();run(a.components)
