"""Exact finite proof that a depth-three AES MixColumns circuit needs P>=26.

Regenerates pair recipes by a separate matching/path argument, verifies a
finite list of forest obstructions, and independently enumerates all remaining
parity partitions. No numerical optimizer or saved partition list is used.
"""
from pathlib import Path
from itertools import combinations
from collections import Counter
from functools import lru_cache
import json,re,subprocess,tempfile,time,argparse
from verify_cluster_results import aes_rows
from verify_pair_rank import inverse,verify as verify_component_bound
HERE=Path(__file__).resolve().parent
ALL32=(1<<32)-1; ALL64=(1<<64)-1

def rotate(x):return ((x<<8)&ALL32)|(x>>24)
def canonical(x):
    orbit=[]
    for _ in range(4):orbit.append(x);x=rotate(x)
    return min(orbit)

def matchings(bits):
    if not bits:yield ();return
    a=bits[0]
    for j in range(1,len(bits)):
        b=bits[j]
        for rest in matchings(bits[1:j]+bits[j+1:]):yield tuple(sorted((a|b,)+rest))

def pair_recipes(rows):
    result=[]
    for y in rows:
        bs=[1<<i for i in range(32) if y>>i&1];rs=set()
        for anchor in bs:
            rest=[b for b in bs if b!=anchor]
            rs.update(matchings(rest))
            if len(bs)==5:
                for a,b in combinations(rest,2):
                    other=sum(t for t in rest if t not in (a,b))
                    for i in range(32):
                        z=1<<i
                        if not y&z:rs.add(tuple(sorted((a|z,b|z,other))))
        assert len(rs)==(105 if len(bs)==7 else 825)
        result.append(sorted(rs))
    return result

def write_recipe_data(path,recipes):
    pairs=sorted(sum(1<<i for i in ij) for ij in combinations(range(32),2));ix={p:i for i,p in enumerate(pairs)}
    with path.open('w') as f:
        print(len(pairs),file=f);print(*pairs,file=f);print(32,file=f)
        for rr in recipes:
            print(len(rr),file=f)
            for r in rr:print(len(r),*(ix[p] for p in r),file=f)

def positive_control(rows,recipes):
    control=json.loads((HERE/'control_97.json').read_text());sig=[1<<i for i in range(32)];depth=[0]*32
    for a,b in control['gates']:
        assert 0<=a<len(sig) and 0<=b<len(sig)
        sig.append(sig[a]^sig[b]);depth.append(1+max(depth[a],depth[b]))
    assert len(control['gates'])==97 and max(depth)==3
    assert [sig[i] for i in control['outputSignals']]==rows
    pairs={v for v in sig[32:] if v.bit_count()==2}
    assert len(pairs)==27 and all(any(set(r)<=pairs for r in rr) for rr in recipes)
    # Check the byte rotation used to transport component obstructions.
    assert all(rotate(rows[8*b+k])==rows[8*((b+1)%4)+k] for b in range(4) for k in range(8))

def short_words(rows):
    def apply(rs,u):return sum(((r&u).bit_count()&1)<<i for i,r in enumerate(rs))
    inv=inverse(rows);cols=[apply(rows,1<<i) for i in range(32)];icols=[apply(inv,1<<i) for i in range(32)]
    assert all(apply(inv,cols[i])==1<<i for i in range(32))
    assert apply(rows,ALL32)==ALL32
    assert all(sum(r>>i&1 for r in rows)%2 for i in range(32))
    words=set()
    for k in range(1,7):
        for ii in combinations(range(32),k):
            u=sum(1<<i for i in ii);v=z=0
            for i in ii:v^=cols[i];z^=icols[i]
            if k+v.bit_count()<=12:words.add(u|(v<<32))
            if k+z.bit_count()<=12:words.add(z|(u<<32))
    assert Counter(w.bit_count() for w in words)=={6:84,8:276,10:1300,12:8112}
    return words

def enumerate_partitions(rows,all_words,bad,blocks,budget,destination):
    @lru_cache(None)
    def tax(u):
        components=[];cycles=0
        for e in sorted({u&r for r in rows if r.bit_count()==7 and (u&r).bit_count()==2}):
            hits=[j for j,c in enumerate(components) if c&e]
            if len(hits)==1 and components[hits[0]]&e==e:cycles+=1
            merged=e
            for j in reversed(hits):merged|=components.pop(j)
            components.append(merged)
        return max(cycles,int(canonical(u) in bad))
    maxweight=12 if blocks==7 else 10
    words=sorted((w for w in all_words if w.bit_count()<=maxweight and tax(w&ALL32)<=budget),key=lambda w:(w.bit_count(),w))
    n=len(words);weights=[w.bit_count() for w in words];taxes=[tax(w&ALL32) for w in words]
    compat=[sum(1<<j for j in range(i+1,n) if not words[i]&words[j]) for i in range(n)]
    weightmask={k:sum(1<<j for j,w in enumerate(weights) if w<=k) for k in range(6,maxweight+1)}
    taxmask={k:sum(1<<j for j,t in enumerate(taxes) if t<=k) for k in range(budget+1)}
    @lru_cache(None)
    def splits(rem):
        inp=rem&ALL32;out=rem>>32
        eq=[r&inp for i,r in enumerate(rows) if not out>>i&1];piv=[];rank=0
        for i in range(32):
            if not inp>>i&1:continue
            j=next((j for j in range(rank,len(eq)) if eq[j]>>i&1),None)
            if j is None:continue
            eq[rank],eq[j]=eq[j],eq[rank]
            for j in range(len(eq)):
                if j!=rank and eq[j]>>i&1:eq[j]^=eq[rank]
            piv.append(i);rank+=1
        basis=[]
        for i in range(32):
            if inp>>i&1 and i not in piv:
                u=(1<<i)|sum(1<<p for p,r in zip(piv,eq) if r>>i&1)
                v=sum(((r&u).bit_count()&1)<<j for j,r in enumerate(rows))
                assert not v&~out;basis.append(u|(v<<32))
        code=[0]
        for b in basis:code += [w^b for w in code]
        result=[]
        for a in code[1:]:
            b=rem^a;ka=(a.bit_count(),a);kb=(b.bit_count(),b)
            if not b or ka>=kb:continue
            cost=tax(a&ALL32)+tax(b&ALL32)
            if cost<=budget:result.append((ka,a,b,cost))
        return result
    nodes=leaves=survivors=0;chosen=[]
    with destination.open('w') as f:
        def dfs(candidates,used,depth,spent):
            nonlocal nodes,leaves,survivors
            nodes+=1
            if depth==blocks-2:
                leaves+=1;last=(weights[chosen[-1]],words[chosen[-1]])
                for key,a,b,cost in splits(ALL64^used):
                    if key>last and spent+cost<=budget:
                        survivors+=1;print(*(words[j]&ALL32 for j in chosen),a&ALL32,b&ALL32,file=f)
                return
            mw=min(maxweight,(64-used.bit_count())//(blocks-depth))
            if mw<6:return
            # Only the NEXT chosen word is bounded by this average weight.
            # Later words may be heavier, so retain the unfiltered candidates
            # for recursion. Cycle budgets only decrease, unlike this bound.
            eligible = candidates & weightmask[mw] & taxmask[budget-spent]
            while eligible:
                bit=eligible&-eligible;eligible-=bit;j=bit.bit_length()-1
                chosen.append(j);dfs(candidates&compat[j],used|words[j],depth+1,spent+taxes[j]);chosen.pop()
        dfs((1<<n)-1,0,0,0)
    result={'blocks':blocks,'cycle_budget':budget,'short_words':n,'nodes':nodes,'leaves':leaves,'surviving_partitions':survivors,'distinct_remainders':splits.cache_info().currsize}
    print('PARITY ENUMERATION',json.dumps(result),flush=True);return result

def check(full=True):
    start=time.monotonic();rows=aes_rows();recipes=pair_recipes(rows);positive_control(rows,recipes)
    premise=verify_component_bound() if full else None
    badlist=list(map(int,(HERE/'forest_obstruction_cover.txt').read_text().split()))
    assert len(badlist)==len(set(badlist)) and all(v and v<=ALL32 and canonical(v)==v for v in badlist)
    with tempfile.TemporaryDirectory(prefix='aes-pair26-proof-') as td:
        td=Path(td);data=td/'pair_recipes.txt';write_recipe_data(data,recipes)
        exe=td/'components';subprocess.run(['g++','-O3','-std=c++17',str(HERE/'check_component_forests.cpp'),'-o',str(exe)],check=True)
        out=subprocess.check_output([str(exe),str(data),str(HERE/'forest_obstruction_cover.txt'),str(td/'proved_bad.txt'),'20000000','180'],text=True)
        m=re.search(r'^COMPLETE components (\d+) rejected (\d+) unknown 0 feasible 0 nodes (\d+)',out,re.M)
        assert m and int(m[1])==int(m[2])==len(badlist),'Component exclusion incomplete.\n'+out[-1000:]
        assert set(map(int,(td/'proved_bad.txt').read_text().split()))==set(badlist)
        component_result={'rejected_orbits':len(badlist),'nodes':int(m[3])}
        print('FOREST OBSTRUCTIONS PASS',json.dumps(component_result),flush=True)
        words=short_words(rows);part7=enumerate_partitions(rows,words,set(badlist),7,0,td/'seven.txt')
        assert part7['surviving_partitions']==0
        part8=enumerate_partitions(rows,words,set(badlist),8,1,td/'eight.txt')
        exe=td/'pairs';subprocess.run(['g++','-O3','-std=c++17',str(HERE/'check_partition_pairs.cpp'),'-o',str(exe)],check=True)
        out=subprocess.check_output([str(exe),str(data),str(td/'eight.txt'),'8','1','20000000','180'],text=True)
        m=re.search(r'^COMPLETE partitions (\d+) rejected (\d+) unknown 0 nodes (\d+)',out,re.M)
        assert m and int(m[1])==int(m[2])==part8['surviving_partitions'],'Unicyclic exclusion incomplete.\n'+out[-1000:]
        unicyclic={'rejected_partitions':int(m[1]),'nodes':int(m[3])}
        print('UNICYCLIC EXCLUSION PASS',json.dumps(unicyclic),flush=True)
    result={'status':'PASS','pair_lower_bound':26,'component_bound_checked':bool(premise),'component_bound':premise,
            'independent_pair_recipe_counts':dict(Counter(map(len,recipes))),
            'known97_pair_control':True,'byte_rotation_symmetry_checked':True,'forest_obstructions':component_result,
            'seven_component_enumeration':part7,'eight_component_enumeration':part8,'unicyclic_exclusion':unicyclic,
            'seconds':time.monotonic()-start}
    print(json.dumps(result,indent=2),flush=True);return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--skip-component-bound',action='store_true');a=ap.parse_args()
    result=check(not a.skip_component_bound)
    (HERE/'pair26_checks.json').write_text(json.dumps(result,indent=2)+'\n')
