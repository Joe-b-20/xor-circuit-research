"""Independent exact parent prices for remaining six/seven-component cases."""
from pathlib import Path
from itertools import combinations
from collections import defaultdict
from fractions import Fraction
import json,argparse,time
from verify_cluster_results import aes_rows
from independent_parent_rows import all_trees
HERE=Path(__file__).resolve().parent
def rot(h,r):return ((h<<(8*r))&0xffffffff)|(h>>(32-8*r)) if r else h

def regenerate_parent_edges(O):
    odd=[1<<i for i in range(32)]+[sum(1<<i for i in ii) for ii in combinations(range(32),3)]
    E=sorted((a,a^y,o) for o,y in enumerate(O) for a in odd if (a^y).bit_count() in (2,4))
    assert len(E)==6120
    return E

def check_prices(cuts,O,components):
    full=regenerate_parent_edges(O);V={h for a,b,o in full for h in (a,b)}
    cache={};coverage={};minimum=None;total_trees=0
    for ci,cut in enumerate(cuts):
        blocks=cut['partition'];D=cut['price_denominator'];prices=cut['prices']
        assert type(D) is int and D>0 and len(prices)==32 and all(type(p) is int for p in prices)
        union=0;outputs=0
        for b in blocks:
            assert type(b) is int and 0<b<2**32 and not union&b;union|=b
            out=sum(((y&b).bit_count()%2)<<i for i,y in enumerate(O))
            assert out and not outputs&out;outputs|=out
        assert len(blocks)==components and union==outputs==2**32-1
        allowed=set()
        for h in V:
            w=h.bit_count();counts=[(h&b).bit_count() for b in blocks]
            if w==1 or (w==2 and 2 in counts) or (w==3 and max(counts)>=2) or (w==4 and all(v%2==0 for v in counts)):allowed.add(h)
        E=[e for e in full if e[0] in allowed and e[1] in allowed]
        assert len(E)==cut['edges']
        adj=defaultdict(set)
        for a,b,o in E:adj[a].add(b);adj[b].add(a)
        seen=set();tree_count=0
        for root in sorted(adj):
            if root in seen:continue
            S={root};seen.add(root);todo=[root]
            for a in todo:
                for b in adj[a]:
                    if b not in seen:seen.add(b);S.add(b);todo.append(b)
            ee=tuple(e for e in E if e[0] in S)
            if ee not in cache:
                trees=all_trees(S,ee)
                cache[ee]=[(tuple(sorted(labels)),sum(h.bit_count()>2 for h in vertices)) for vertices,labels in trees]
            tt=cache[ee];tree_count+=len(tt)
            assert all(sum(prices[o] for o in labels)<=D*cost for labels,cost in tt),(ci,'invalid tree price')
        assert tree_count==cut['trees'];total_trees+=tree_count
        bound=Fraction(sum(prices),D);assert bound>34
        minimum=bound if minimum is None else min(minimum,bound)
        for r in range(4):
            key=tuple(sorted(rot(b,r) for b in blocks))
            if key in coverage:assert coverage[key]==ci
            coverage[key]=ci
        if (ci+1)%500==0:print('PARENT PRICE PASS',ci+1,'minimum',minimum,'cached components',len(cache),flush=True)
    assert len(cuts)>0
    return coverage,{'representatives':len(cuts),'covered_partitions':len(coverage),'minimum_exact_parent_bound':str(minimum),'integer_parent_lower_bound':35,'trees_checked_with_multiplicity':total_trees,'distinct_component_graphs':len(cache)}

def run(components):
    start=time.monotonic();O=aes_rows();basis={}
    for row in O:
        while row:
            k=row.bit_length()-1
            if k in basis:row^=basis[k]
            else:basis[k]=row;break
    assert len(basis)==32
    assert all(rot(O[8*b+k],1)==O[8*((b+1)%4)+k] for b in range(4) for k in range(8))
    data=json.loads((HERE/f'conditioned_c{components}_parent_prices.json').read_text());assert data['complete']
    cuts=[{'partition':r['partition'],'price_denominator':r['price']['denominator'],'prices':r['price']['prices'],'edges':r['price']['edges'],'trees':r['price']['trees']} for r in data['strong']]
    coverage,result=check_prices(cuts,O,components)
    allparts={tuple(sorted(map(int,line.split()))) for line in (HERE/f'conditioned_c{components}_parts.txt').read_text().splitlines()}
    assert set(coverage)<=allparts
    result.update(status='PASS',components=components,seconds=time.monotonic()-start,scope='Every covered partition needs T+Q>=35, hence at least 93 gates when P=26. Other partitions are unresolved by these prices.')
    (HERE/f'conditioned_c{components}_parent_price_checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('components',type=int,choices=[6,7]);a=p.parse_args();run(a.components)
