"""Standard-library verification of a 100-gate depth-three circuit with P=26."""
from pathlib import Path
from collections import Counter
import json
from verify_cluster_results import aes_rows
HERE=Path(__file__).resolve().parent

def check():
    c=json.loads((HERE/'pair26_actual_circuit.json').read_text());s=[1<<i for i in range(32)];d=[0]*32
    for a,b in c['gates']:
        assert type(a) is int and type(b) is int and 0<=a<len(s) and 0<=b<len(s)
        s.append(s[a]^s[b]);d.append(1+max(d[a],d[b]))
    assert len(s)==len(set(s)) and 0 not in s
    assert len(c['gates'])==c['gateCount']==100 and c['depth']==max(d)==3
    assert [s[i] for i in c['outputSignals']]==aes_rows()
    assert all(d[i]==3 for i in c['outputSignals'])
    counts=Counter(h.bit_count() for h in s[32:]);assert counts[2]==26 and counts[3]+counts[4]==42
    parent=list(range(32))
    def root(i):
        while parent[i]!=i:i=parent[i]
        return i
    for h in s[32:]:
        if h.bit_count()!=2:continue
        a,b=[i for i in range(32) if h>>i&1];a=root(a);b=root(b)
        if a!=b:parent[a]=b
    components=len({root(i) for i in range(32)});assert components==8
    result={'status':'PASS','gates':100,'depth':3,'pairs':26,'triples':counts[3],'quartets':counts[4],
            'outputs':32,'pair_graph_components':components,'pair_graph_cycle_rank':26-32+components,
            'conclusion':'Together with the independently checked P>=26 theorem, this proves the exact normalized pair minimum is 26. The full gate optimum remains unresolved.'}
    print(json.dumps(result,indent=2));return result

if __name__=='__main__':
    result=check();(HERE/'pair26_witness_checks.json').write_text(json.dumps(result,indent=2)+'\n')
