"""Independent reconstruction and exact checking of parent graph cuts.

No numerical solver, discovery code, or saved parent graph is imported.
"""
from collections import defaultdict
from functools import lru_cache
from itertools import combinations
from verify_cluster_results import aes_rows

def data(H,opts):
    O=aes_rows();basis={}
    for row in O:
        v=row
        while v:
            k=v.bit_length()-1
            if k in basis:v^=basis[k]
            else:basis[k]=v;break
    assert len(basis)==32
    uses=defaultdict(list);j=len(H)
    for o,rr in enumerate(opts):
        for r in rr:
            choices=[]
            for a in list(r)+[1<<i for i in range(32)]:
                if a.bit_count() not in (1,3):continue
                b=a^O[o]
                if b in r and b.bit_count() in (2,4):choices.append((a,b))
            assert len(choices)==1
            a,b=choices[0];uses[a,b,o].append(j);j+=1
    assert len(uses)==6120
    return uses

def all_trees(S,ee):
    # Independent frozenset search: root is the smallest vertex. Grow by a
    # boundary edge carrying a new output label, considering every such edge.
    adj=defaultdict(list)
    for a,b,o in ee:adj[a].append((b,o));adj[b].append((a,o))
    result={}
    for root in sorted(S):
        empty=frozenset();todo=[(frozenset([root]),empty)];seen={todo[0]}
        for vertices,labels in todo:
            if labels:
                if vertices in result:assert result[vertices]==labels
                result[vertices]=labels
            for u in vertices:
                for v,o in adj[u]:
                    if v<=root or v in vertices or o in labels:continue
                    state=(vertices|{v},labels|{o})
                    if state not in seen:seen.add(state);todo.append(state)
    # A second exhaustive check on small components enumerates vertex subsets
    # and recognizes connected induced trees with pairwise distinct labels.
    if len(S)<=12:
        brute={};ss=sorted(S)
        for size in range(2,len(ss)+1):
            for vv in combinations(ss,size):
                vv=frozenset(vv);edges=[(a,b,o) for a,b,o in ee if a in vv and b in vv]
                labels=frozenset(o for _,_,o in edges)
                if len(edges)!=size-1 or len(labels)!=size-1:continue
                reach={next(iter(vv))}
                for _ in range(size):
                    for a,b,o in edges:
                        if a in reach or b in reach:reach.update((a,b))
                if reach==vv:brute[vv]=labels
        assert brute==result
    return list(result.items())

def additional_rows(H,opts,cert,verify_prices=True):
    uses=data(H,opts);ix={h:i for i,h in enumerate(H)};V={v for a,b,o in uses for v in (a,b)}
    rows=[];checks=[];cache={}
    for cut in cert.get('parent_forest_cuts',[]):
        S=set(cut['vertices']);o=cut['output']
        assert len(S)==len(cut['vertices']) and S<=V and type(o) is int and 0<=o<32
        acc=defaultdict(int);free=0
        for h in S:
            if h.bit_count()==1:free+=1
            else:acc[ix[h]]+=1
        for (a,b,k),jj in uses.items():
            if a in S and b in S:
                for j in jj:acc[j]-=1+int(k==o)
        rows.append((sorted((j,a) for j,a in acc.items() if a),-free))
    for ci,cut in enumerate(cert.get('parent_tree_cuts',[])):
        S=frozenset(cut['vertices']);w=dict(cut['prices']);p=dict(cut['rewards'])
        assert len(S)==len(cut['vertices']) and S<=V
        assert len(w)==len(cut['prices']) and len(p)==len(cut['rewards'])
        assert all(h in S and type(a) is int and a>0 for h,a in w.items())
        assert all(type(o) is int and 0<=o<32 and type(a) is int and a!=0 for o,a in p.items())
        ee=[e for e in uses if e[0] in S and e[1] in S]
        assert set(p)<={e[2] for e in ee}
        if verify_prices:
            if S not in cache:cache[S]=all_trees(S,ee)
            tt=cache[S]
            assert all(sum(w.get(v,0) for v in vv)>=sum(p.get(o,0) for o in oo) for vv,oo in tt)
            checks.append({'cut':ci,'vertices':len(S),'edges':len(ee),'connected_trees_checked':len(tt)})
        acc=defaultdict(int);free=0
        for h,a in w.items():
            if h.bit_count()==1:free+=a
            else:acc[ix[h]]+=a
        for a,b,o in ee:
            for j in uses[a,b,o]:acc[j]-=p.get(o,0)
        rows.append((sorted((j,a) for j,a in acc.items() if a),-free))
    return rows,checks
