"""Independent regeneration and integer checking of recipe-linked cluster cuts."""
from pathlib import Path
from collections import defaultdict
import tempfile,subprocess,re
from check_local_oracles import independent_data
from verify_cluster_results import aes_rows
HERE=Path(__file__).resolve().parent

def rotate(h,r):
    r%=4
    return ((h<<(8*r))&0xffffffff)|(h>>(32-8*r)) if r else h

def additional_rows(H,opts,cert,verify_prices=True):
    cuts=cert.get('linked_cluster_cuts',[])
    if not cuts:return [],[]
    ix={h:i for i,h in enumerate(H)};O=aes_rows();cache={};rows=[];checks=[]
    with tempfile.TemporaryDirectory(prefix='aes-independent-linked-') as td:
        tmp=Path(td);exe=tmp/'verify'
        if verify_prices:subprocess.run(['g++','-O3','-std=c++17',str(HERE/'check_linked_prices.cpp'),'-o',str(exe)],check=True)
        for ci,cut in enumerate(cuts):
            kind,bit=cut['kind'],cut['cluster'];assert kind in ('w5','w7')
            assert bit in ((0,2,5,6,7) if kind=='w5' else (1,3,4))
            canonical=6 if kind=='w5' else 3
            if kind not in cache:
                HH,oo=independent_data(canonical)
                local=[[tuple(HH[j] for j in r if j<len(HH)) for r in rr] for rr in oo]
                assert all(rr==sorted(rr) for rr in local)
                orb={};groups=[]
                for h in HH:
                    if h in orb:continue
                    group={rotate(h,r) for r in range(4)}
                    for v in group:orb[v]=len(groups)
                    groups.append(sorted(group))
                ri={r:i for i,r in enumerate(local[0])}
                which=[[ri[tuple(sorted(rotate(h,-b) for h in r))] for r in rr] for b,rr in enumerate(local)]
                cache[kind]=HH,local,orb,groups,which
            HH,local,orb,groups,which=cache[kind];hp=cut['helper_prices'];rp=cut['recipe_prices'];minimum=cut['minimum']
            assert len(hp)==len(groups) and len(rp)==315 and type(minimum) is int
            assert all(type(p) is int and 0<=p<=10**9 for p in hp)
            assert all(type(p) is int and abs(p)<=10**9 for p in rp)
            if verify_prices:
                hi={h:i for i,h in enumerate(HH)};lines=[str(len(HH)),' '.join(str(hp[orb[h]]) for h in HH)]
                for b,rr in enumerate(local):
                    lines.append(str(len(rr)))
                    for k,r in enumerate(rr):lines.append(' '.join(map(str,[rp[which[b][k]],len(r),*(hi[h] for h in r)])))
                inp=tmp/'prices';inp.write_text('\n'.join(lines)+'\n')
                out=subprocess.check_output([str(exe),str(inp),str(minimum),'180'],text=True)
                m=re.fullmatch(r'VERIFIED nodes (\d+) seconds (\S+)\s*',out);assert m,out
                checks.append({'cut':ci,'kind':kind,'cluster':bit,'minimum':minimum,'nodes':int(m.group(1)),'seconds':float(m.group(2))})
                print('LINKED EXACT PASS',ci,kind,bit,minimum,flush=True)
            sourcefamilies=(3,2,7) if kind=='w7' else (6,5)
            targetfamilies=(bit,bit-1,7) if kind=='w7' else (bit,(bit-1)%8)
            def move(h):
                v=0
                for j in range(32):
                    if h>>j&1:v|=1<<(8*(j//8)+targetfamilies[sourcefamilies.index(j%8)])
                return v
            forward={h:move(h) for h in HH};inverse={v:h for h,v in forward.items()};acc=defaultdict(int)
            support=0
            for b in range(4):support|=O[8*b+bit]
            if kind=='w7':
                for h in HH:acc[ix[forward[h]]]+=hp[orb[h]]
            else:
                possible={h for o,rr in enumerate(opts) if o%8==bit for r in rr for h in r}
                for h in possible:
                    image=h&support
                    if image.bit_count()>1:acc[ix[h]]+=hp[orb[inverse[image]]]
            j=len(H)
            for o,rr in enumerate(opts):
                if o%8!=bit:j+=len(rr);continue
                b=o//8;index={r:k for k,r in enumerate(local[b])}
                for r in rr:
                    projected=tuple(sorted({inverse[h&support] for h in r if (h&support).bit_count()>1}))
                    k=index[projected];acc[j]+=rp[which[b][k]];j+=1
            rows.append(([(j,a) for j,a in sorted(acc.items()) if a],minimum))
    return rows,checks
