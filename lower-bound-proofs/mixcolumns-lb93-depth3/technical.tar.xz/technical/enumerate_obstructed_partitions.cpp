// Includes exact forest-obstruction tax, with full byte-rotation orbits.
// Enumerate parity partitions subject to a forced-cycle-rank budget.
// For c blocks, the first c-2 words have weight at most
// floor_even((64-6*(c-3))/3). The last two are exact kernel splits.
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <unordered_map>
#include <unordered_set>
#include <vector>
using namespace std;
vector<uint64_t> words;vector<int> weights,taxes;array<uint32_t,32> rows;
array<uint64_t,8> chosen;uint64_t nodes=0,leaves=0,partitions=0;
int blocks,budget;bool stopped=false;double limit;auto start=chrono::steady_clock::now();ofstream out;
unordered_map<uint32_t,int> taxcache;unordered_set<uint32_t> forest_bad;
int pc(uint64_t x){return __builtin_popcountll(x);}
bool lessword(uint64_t a,uint64_t b){return pc(a)!=pc(b)?pc(a)<pc(b):a<b;}
uint32_t apply(uint32_t u){uint32_t v=0;for(int i=0;i<32;i++)if(pc(rows[i]&u)&1)v|=uint32_t(1)<<i;return v;}
int tax(uint32_t u){
 auto it=taxcache.find(u);if(it!=taxcache.end())return it->second;
 array<int,32>uf;for(int i=0;i<32;i++)uf[i]=i;
 auto find=[&uf](int a){while(uf[a]!=a)a=uf[a];return a;};
 array<uint32_t,12>seen{};int ns=0,cyc=0;
 for(auto r:rows)if(pc(r)==7){
  uint32_t s=r&u;if(pc(s)!=2||std::find(seen.begin(),seen.begin()+ns,s)!=seen.begin()+ns)continue;
  seen[ns++]=s;int a=__builtin_ctz(s);s&=s-1;int b=__builtin_ctz(s),x=find(a),y=find(b);
  if(x==y)cyc++;else uf[x]=y;
 }
 cyc=max(cyc,int(forest_bad.count(u)));taxcache[u]=cyc;return cyc;
}
void finish(uint64_t used,int spent){
 leaves++;uint64_t rem=~used;uint32_t inp=rem,outs=rem>>32;
 vector<uint32_t>a;for(int i=0;i<32;i++)if(!(outs>>i&1))a.push_back(rows[i]&inp);
 int rank=0;vector<int>piv;
 for(int c=0;c<32;c++)if(inp>>c&1){
  int p=rank;while(p<(int)a.size()&&!(a[p]>>c&1))p++;
  if(p==(int)a.size())continue;swap(a[p],a[rank]);
  for(int j=0;j<(int)a.size();j++)if(j!=rank&&(a[j]>>c&1))a[j]^=a[rank];
  piv.push_back(c);rank++;
 }
 uint32_t pm=0;for(int c:piv)pm|=uint32_t(1)<<c;vector<uint32_t>basis;
 for(int c=0;c<32;c++)if((inp>>c&1)&&!(pm>>c&1)){
  uint32_t v=uint32_t(1)<<c;for(int j=0;j<rank;j++)if(a[j]>>c&1)v|=uint32_t(1)<<piv[j];basis.push_back(v);
 }
 if(basis.size()<2)return;
 for(uint64_t s=1;s<(uint64_t(1)<<basis.size());s++){
  uint32_t u=0;for(int j=0;j<(int)basis.size();j++)if(s>>j&1)u^=basis[j];
  uint64_t w=u|(uint64_t(apply(u))<<32),other=rem^w;
  if(!other||!lessword(chosen[blocks-3],w)||!lessword(w,other))continue;
  if(spent+tax(uint32_t(w))+tax(uint32_t(other))>budget)continue;
  chosen[blocks-2]=w;chosen[blocks-1]=other;partitions++;
  for(int j=0;j<blocks;j++)out<<uint32_t(chosen[j])<<(j==blocks-1?'\n':' ');
 }
}
void dfs(int begin,uint64_t used,int depth,int spent){
 if(stopped)return;nodes++;
 if((nodes&65535)==0&&chrono::duration<double>(chrono::steady_clock::now()-start).count()>limit){stopped=true;return;}
 if(depth==blocks-2){finish(used,spent);return;}
 int rem=64-pc(used),count=blocks-depth;
 for(int j=begin;j<(int)words.size();j++){
  if(weights[j]*count>rem)break;
  if((words[j]&used)||spent+taxes[j]>budget)continue;
  chosen[depth]=words[j];dfs(j+1,used|words[j],depth+1,spent+taxes[j]);if(stopped)return;
 }
}
int main(int argc,char**argv){
 if(argc!=7)return 2;ifstream in(argv[1]);for(auto&r:rows)in>>r;
 int n;in>>n;vector<uint64_t>all(n);for(auto&w:all)in>>w;if(!in)return 3;
 ifstream badin(argv[6]);uint32_t bad;while(badin>>bad){for(int r=0;r<4;r++){forest_bad.insert(bad);bad=(bad<<8)|(bad>>24);}}
 blocks=stoi(argv[3]);budget=stoi(argv[4]);if(blocks<3||blocks>8)return 4;
 for(auto w:all)if(tax(uint32_t(w))<=budget)words.push_back(w);
 sort(words.begin(),words.end(),lessword);for(auto w:words){weights.push_back(pc(w));taxes.push_back(tax(uint32_t(w)));}
 out.open(argv[2]);limit=stod(argv[5]);start=chrono::steady_clock::now();dfs(0,0,0,0);
 cout<<(stopped?"INCOMPLETE":"COMPLETE")<<" blocks "<<blocks<<" budget "<<budget<<" short_words "<<words.size()<<" nodes "<<nodes<<" leaves "<<leaves<<" partitions "<<partitions<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<endl;
}
