"""Enumerate all optimal local helper-mask sets; no optimization solver.

This counts helper sets, not all possible wire-level realizations.
Completeness uses P>=6, H>=5 and the proved local optimum P+H=12.
"""
from itertools import combinations,product
from collections import Counter
from pathlib import Path
import json
from verify_boundary_tax import Y,pairs_for_parent
HERE=Path(__file__).resolve().parent

def check():
    options=[]
    for y in Y:
        bits=[1<<i for i in range(12) if y>>i&1]
        options.append([(sum(t),y^sum(t)) for t in combinations(bits,3)])
    parents=set();decomposition_count=0
    for dd in product(*options):
        decomposition_count+=1
        hs=tuple(sorted({h for d in dd for h in d}))
        if len(hs)<=6:parents.add(hs)
    assert decomposition_count==35**4
    assert Counter(map(len,parents))=={5:4,6:318}
    optima=set();assignments=0
    for hs in parents:
        for constructions in product(*(pairs_for_parent(h) for h in hs)):
            assignments+=1
            pp=set().union(*constructions)
            if len(pp)+len(hs)==12:optima.add(tuple(sorted(pp|set(hs))))
    assert assignments==4*3**5+318*3**6
    assert len(optima)==126
    types=Counter((sum(h.bit_count()==2 for h in r),sum(h.bit_count()==3 for h in r),
                   sum(h.bit_count()==4 for h in r)) for r in optima)
    assert types=={(7,2,3):108,(6,4,2):18}
    def lift(row,b):
        mapping=[8*i+b for i in range(4)]+[8*i+b-1 for i in range(4)]+[8*i+7 for i in range(4)]
        return frozenset(sum(1<<mapping[i] for i in range(12) if h>>i&1) for h in row)
    o3=[lift(r,3) for r in optima];o4=[lift(r,4) for r in optima]
    for a,b in product(o3,o4):assert not a&b
    result={'status':'PASS','optimal_helper_sets':126,'parent_selections':decomposition_count,
            'parent_sets_with_at_most_six_helpers':len(parents),'construction_assignments':assignments,
            'helper_type_counts':[{'P':p,'T':t,'Q':q,'count':v} for (p,t,q),v in sorted(types.items())],
            'cluster3_cluster4_optimal_pairs_checked':126**2,
            'maximum_shared_helpers_between_two_local_optima':0,
            'qualification':'Counts distinct helper-mask sets, not wire-level circuits; does not exclude joint savings from nonoptimal local ancestries.'}
    print(json.dumps(result,indent=2))
    return result

if __name__=='__main__':
    result=check();(HERE/'local_optima_checks.json').write_text(json.dumps(result,indent=2)+'\n')
