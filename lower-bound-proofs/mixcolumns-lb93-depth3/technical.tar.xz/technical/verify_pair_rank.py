"""Recompute the finite premise of P>=24, independently of an LP solver.
See PROOF.md for why the exhaustive test suffices.
"""
from itertools import combinations
from collections import Counter
import json,time
from pathlib import Path
from verify_structure import aes_rows,rank

def apply(rows,u):return sum(((r&u).bit_count()%2)<<i for i,r in enumerate(rows))
def inverse(rows):
 a=[r|(1<<(32+i)) for i,r in enumerate(rows)]
 for c in range(32):
  p=next(i for i in range(c,32) if a[i]>>c&1);a[c],a[p]=a[p],a[c]
  for i in range(32):
   if i!=c and a[i]>>c&1:a[i]^=a[c]
 return [r>>32 for r in a]

def verify():
 start=time.monotonic();rows=aes_rows();inv=inverse(rows);all32=(1<<32)-1;all64=(1<<64)-1
 assert apply(rows,all32)==all32
 assert all(sum((r>>c)&1 for r in rows)%2 for c in range(32))
 assert all(apply(inv,apply(rows,1<<i))==1<<i for i in range(32))
 words=set()
 for k in range(1,5):
  for inds in combinations(range(32),k):
   u=sum(1<<i for i in inds);v=apply(rows,u)
   if k+v.bit_count()<=8:words.add(u|(v<<32))
   v=apply(inv,u)
   if k+v.bit_count()<=8:words.add(v|(u<<32))
 assert Counter(w.bit_count() for w in words)=={6:84,8:276}
 words=sorted(words,key=lambda w:(w.bit_count(),w));weights=[w.bit_count() for w in words]
 nodes=leaves=splits=0
 def dfs(start,used,depth):
  nonlocal nodes,leaves,splits
  nodes+=1
  if depth==7:
   leaves+=1;rem=all64^used;inp=rem&all32;out=rem>>32
   nullity=inp.bit_count()-rank([r&inp for i,r in enumerate(rows) if not(out>>i&1)])
   if nullity>=2:splits+=1
   return
  remaining=64-used.bit_count();k=9-depth
  for j in range(start,len(words)):
   if weights[j]*k>remaining:break
   w=words[j]
   if not w&used:dfs(j+1,used|w,depth+1)
 dfs(0,0,0)
 assert (nodes,leaves,splits)==(1485213,62112,0)
 assert all(apply(rows,0x01010101<<j)==0x01010101<<j for j in range(8))
 result={'short_word_weights':{6:84,8:276},'nodes':nodes,'leaves':leaves,'nine_part_partitions':splits,'pair_lower_bound':24,'seconds':time.monotonic()-start}
 print('PASS parity partition premise',json.dumps(result),flush=True)
 return result
if __name__=='__main__':
 result=verify();json.dump(result,open(Path(__file__).resolve().parent/'pair_rank_result.json','w'),indent=2)
