"""Independent integer verification of single-component exclusion certificates.

No optimizer or conditional discovery module is imported. The source finite
premises are the previously verified linked-92 rows. This verifies the new
conditional restrictions, connectivity rows, and exact dual arithmetic.
"""
from pathlib import Path
from itertools import combinations
from fractions import Fraction
import json,hashlib
from independent_check import rebuild
from independent_check_86 import new_rows
from compact_joint_certificate import assemble
from verify_cluster_results import aes_rows
HERE=Path(__file__).resolve().parent
SOURCE_SHA='47c5b0fcdbcffb085be518103d357cb64c383f0363cba48712f2089394be6bdf'

def connectivity(C,H):
    pairs=[(j,h) for j,h in enumerate(H) if h.bit_count()==2 and h&C==h]
    rows=[]
    if C.bit_count()>1:
        rows.append(([(j,1) for j,h in pairs],C.bit_count()-1))
        anchor=C&-C;S=(C-1)&C
        while S:
            if S&anchor:rows.append(([(j,1) for j,h in pairs if (h&S).bit_count()==1],1))
            S=(S-1)&C
    return rows

def allowed_columns(C,H,opts):
    def internal_pair(h):return (h&C).bit_count()!=1
    allowed=set()
    for h in H:
        size=h.bit_count()
        if size==2:
            if internal_pair(h):allowed.add(h)
        else:
            bs=[1<<i for i in range(32) if h>>i&1]
            for a,b in combinations(bs,2):
                p=a|b;q=h^p
                if internal_pair(p) and (q.bit_count()==1 or internal_pair(q)):
                    allowed.add(h);break
    result=[h in allowed for h in H]
    for rr in opts:
        for recipe in rr:result.append(all(h in allowed for h in recipe))
    return result

def verify():
    source=HERE/'certificate_depth3_linked_92.json';assert hashlib.sha256(source.read_bytes()).hexdigest()==SOURCE_SHA
    cert=json.loads(source.read_text());base,c,H,opts=rebuild();base+=new_rows(H,opts);base,_=assemble(base,H,opts,cert)
    assert len(base)==cert['rows'];base.append(([(j,-1) for j,h in enumerate(H) if h.bit_count()==2],-26))
    O=aes_rows()
    def rotate(x):return ((x<<8)&0xffffffff)|(x>>24)
    assert all(rotate(O[8*b+k])==O[8*((b+1)%4)+k] for b in range(4) for k in range(8))
    records=[];excluded=set()
    for path in sorted(HERE.glob('component_cut_*.json'),key=lambda p:int(p.stem.split('_')[-1])):
        cut=json.loads(path.read_text());C=cut['component'];assert type(C) is int and 0<C<2**32-1
        local=connectivity(C,H);assert json.loads(json.dumps(local))==cut.get('connectivity_rows',[])
        rows=base+local;ok=allowed_columns(C,H,opts);assert len(ok)==len(c)
        D=cut['denominator'];assert type(D) is int and D>0
        acc=[0]*len(c);raw=0;seen=set()
        for i,u in cut['u_nonzero']:
            assert type(i) is int and 0<=i<len(rows) and i not in seen;seen.add(i)
            assert type(u) is int and u>=0
            ts,b=rows[i];raw+=u*b
            for j,a in ts:acc[j]+=u*a
        repair=sum(max(0,acc[j]-D*c[j]) for j in range(len(c)) if ok[j]);num=raw-repair
        assert (raw,repair,num)==(cut['raw_numerator'],cut['repair_numerator'],cut['helper_numerator'])
        assert num>60*D
        orbit=[];u=C
        for _ in range(4):orbit.append(u);excluded.add(u);u=rotate(u)
        row={'file':path.name,'component':C,'component_word_weight':C.bit_count()+sum((r&C).bit_count()%2 for r in O),'helper_lower_bound':str(Fraction(num,D)),'gate_lower_bound':32+(num+D-1)//D,'rotations':sorted(set(orbit))}
        records.append(row);print('CONDITIONAL PASS',json.dumps(row),flush=True)
    result={'status':'PASS','source_sha256':SOURCE_SHA,'verified_representatives':len(records),'excluded_components_including_rotations':len(excluded),'scope':'If P=26 and any listed set is an actual pair-graph component, the circuit has at least 93 gates. This does not cover all possible component cases.','records':records}
    (HERE/'component_conditional_checks.json').write_text(json.dumps(result,indent=2)+'\n');return result

if __name__=='__main__':print(json.dumps(verify(),indent=2))
