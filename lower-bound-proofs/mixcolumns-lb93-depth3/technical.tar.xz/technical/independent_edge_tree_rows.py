"""Exact independent validation of edge-specific parent-tree inequalities."""
from collections import defaultdict
from independent_parent_rows import data,all_trees

def additional_rows(H,opts,cert,verify_prices=True):
    cuts=cert.get('parent_edge_tree_cuts',[])
    if not cuts:return [],[]
    uses=data(H,opts);ix={h:i for i,h in enumerate(H)};V={h for a,b,o in uses for h in (a,b)}
    rr=[];checks=[];cache={}
    for ci,cut in enumerate(cuts):
        S=frozenset(cut['vertices']);assert len(S)==len(cut['vertices']) and S<=V
        w=dict(cut['prices']);assert len(w)==len(cut['prices'])
        assert all(h in S and type(v) is int and v>0 for h,v in w.items())
        rewards={tuple(row[:3]):row[3] for row in cut['edge_rewards']};assert len(rewards)==len(cut['edge_rewards'])
        assert all(e in uses and e[0] in S and e[1] in S and type(v) is int and v!=0 for e,v in rewards.items())
        ee=[e for e in uses if e[0] in S and e[1] in S]
        if verify_prices:
            if S not in cache:cache[S]=all_trees(S,ee)
            trees=cache[S]
            for vertices,labels in trees:
                internal=[e for e in ee if e[0] in vertices and e[1] in vertices]
                assert len(internal)==len(vertices)-1==len(labels)
                assert {e[2] for e in internal}==set(labels)
                assert sum(w.get(h,0) for h in vertices)>=sum(rewards.get(e,0) for e in internal)
            checks.append({'cut':ci,'vertices':len(S),'edges':len(ee),'connected_trees_checked':len(trees)})
            print('EDGE TREE EXACT PASS',ci,len(S),len(trees),flush=True)
        acc=defaultdict(int);free=0
        for h,v in w.items():
            if h.bit_count()==1:free+=v
            else:acc[ix[h]]+=v
        for e,v in rewards.items():
            for j in uses[e]:acc[j]-=v
        rr.append(([(j,a) for j,a in sorted(acc.items()) if a],-free))
    return rr,checks
