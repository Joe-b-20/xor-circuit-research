"""Exact reweighting of the already verified linked 92-gate certificate.

No new finite-enumeration premise is introduced. --full first rechecks all
old finite premises; the default regenerates every row and checks the new
integer arithmetic independently of floating-point optimization.
"""
from pathlib import Path
from fractions import Fraction
import argparse,hashlib,json,subprocess,sys
from independent_check import rebuild
from independent_check_86 import new_rows
from compact_joint_certificate import assemble
HERE=Path(__file__).resolve().parent

def verify(full=False):
    source=HERE/'certificate_depth3_linked_92.json'
    if full:subprocess.run([sys.executable,str(HERE/'independent_check_consistent.py'),str(source),'--result',str(HERE/'tradeoff_full_premise_checks.json')],check=True)
    cert=json.loads(source.read_text());D=cert['denominator']
    base,c,H,opts=rebuild();base+=new_rows(H,opts);rows,starts=assemble(base,H,opts,cert)
    assert len(rows)==cert['rows'] and len(c)==cert['variables']
    pairrow=starts['consistency_cuts']-1
    assert rows[pairrow]==([(j,1) for j,h in enumerate(H) if h.bit_count()==2],26)
    u=dict(cert['u_nonzero']);assert all(type(v) is int and v>=0 for v in u.values())
    acc=[0]*len(c);raw=0
    for i,v in u.items():
        ts,b=rows[i];raw+=v*b
        for j,a in ts:acc[j]+=v*a
    repair=sum(max(0,a-D*w) for a,w in zip(acc,c));num=raw-repair
    assert (raw,repair,num)==(cert['raw_numerator'],cert['repair_numerator'],cert['certified_numerator'])
    lam=u[pairrow]
    # H >= num/D + lam/D*(P-26), with precisely the same bounded-variable
    # coefficient correction. The removed row now contributes its actual P.
    assert num+lam>60*D
    # Reweight the objective to 3P+4T+4Q, remove the pair >=26 row, and
    # recompute the correction against this new objective, exactly.
    newacc=[4*a for a in acc];newc=[4*w for w in c]
    for j,h in enumerate(H):
        if h.bit_count()==2:newacc[j]-=4*lam;newc[j]=3
    newraw=4*raw-4*26*lam
    newrepair=sum(max(0,a-D*w) for a,w in zip(newacc,newc));newnum=newraw-newrepair
    assert 213*D<newnum<=214*D
    result={'status':'PASS','source':source.name,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
            'rows':len(rows),'variables':len(c),'denominator':D,'pair_row':pairrow,
            'helper_numerator':num,'pair_multiplier_numerator':lam,
            'helper_lower_bound_when_P_at_least_27':str(Fraction(num+lam,D)),
            'reweighted_raw_numerator':newraw,'reweighted_repair_numerator':newrepair,
            'reweighted_lower_numerator':newnum,'rounded_inequality':'3*P + 4*T + 4*Q >= 214',
            'consequence':'A 92-gate normalized circuit must have P=26 and T+Q=34.',
            'scope':'Finite row-validity premises are exactly those of the previous verified linked certificate; --full rechecks them.'}
    (HERE/'pair_tradeoff_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--full',action='store_true');a=ap.parse_args();verify(a.full)
