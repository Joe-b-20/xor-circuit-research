"""Independent standard-library verification excluding 24 depth-one pairs.

P=24 would give an eight-component forest. Its component graph-code words
partition 64 coordinates. A weight-seven output meeting a component in
exactly two inputs forces that edge. Every component's forced-edge graph
must therefore be a forest. No eight-word partition satisfies this condition.
"""
from itertools import combinations
from collections import Counter
from functools import lru_cache
from pathlib import Path
import json,time
from verify_cluster_results import aes_rows
HERE=Path(__file__).resolve().parent
ALL32=(1<<32)-1;ALL64=(1<<64)-1

def inverse(rows):
    work=[r|(1<<(32+i)) for i,r in enumerate(rows)]
    for i in range(32):
        j=next(j for j in range(i,32) if work[j]>>i&1)
        work[i],work[j]=work[j],work[i]
        for j in range(32):
            if j!=i and work[j]>>i&1:work[j]^=work[i]
    return [r>>32 for r in work]

def check():
    start=time.monotonic();rows=aes_rows();w7=[r for r in rows if r.bit_count()==7]
    def apply(rs,u):return sum(((r&u).bit_count()&1)<<i for i,r in enumerate(rs))
    assert apply(rows,ALL32)==ALL32
    inv=inverse(rows)
    assert all(apply(inv,apply(rows,1<<i))==1<<i for i in range(32))
    assert all(sum(r>>i&1 for r in rows)%2 for i in range(32))
    @lru_cache(None)
    def forest(u):
        edges={u&r for r in w7 if (u&r).bit_count()==2};components=[]
        for e in edges:
            hits=[i for i,c in enumerate(components) if c&e]
            if len(hits)==1 and e&components[hits[0]]==e:return False
            union=e
            for i in reversed(hits):union|=components.pop(i)
            components.append(union)
        return True
    cols=[apply(rows,1<<i) for i in range(32)];icols=[apply(inv,1<<i) for i in range(32)]
    short=set()
    for k in range(1,6):
        for ii in combinations(range(32),k):
            u=sum(1<<i for i in ii);v=z=0
            for i in ii:v^=cols[i];z^=icols[i]
            if k+v.bit_count()<=10:short.add(u|(v<<32))
            if k+z.bit_count()<=10:short.add(z|(u<<32))
    hist=dict(Counter(w.bit_count() for w in short));assert hist=={6:84,8:276,10:1300}
    words=sorted((w for w in short if forest(w&ALL32)),key=lambda w:(w.bit_count(),w))
    goodhist=dict(Counter(w.bit_count() for w in words));assert goodhist=={6:72,8:194,10:868}
    n=len(words);compat=[]
    for i,w in enumerate(words):compat.append(sum(1<<j for j in range(i+1,n) if not w&words[j]))
    max_weight_masks={k:sum(1<<j for j,w in enumerate(words) if w.bit_count()<=k) for k in range(6,11)}
    @lru_cache(None)
    def last_pair(rem):
        inp=rem&ALL32;out=rem>>32
        eq=[r&inp for i,r in enumerate(rows) if not(out>>i&1)]
        piv=[];rank=0
        for i in range(32):
            if not(inp>>i&1):continue
            j=next((j for j in range(rank,len(eq)) if eq[j]>>i&1),None)
            if j is None:continue
            eq[rank],eq[j]=eq[j],eq[rank]
            for j in range(len(eq)):
                if j!=rank and eq[j]>>i&1:eq[j]^=eq[rank]
            piv.append(i);rank+=1
        free=[i for i in range(32) if inp>>i&1 and i not in piv]
        if len(free)<2:return (-1,0)
        basis=[]
        for i in free:
            u=(1<<i)|sum(1<<p for p,r in zip(piv,eq) if r>>i&1)
            v=apply(rows,u);assert v&~out==0
            basis.append(u|(v<<32))
        best=(-1,0);code=[0]
        for b in basis:code += [w^b for w in code]
        for a in code[1:]:
            b=rem^a
            if not b:continue
            ka=(a.bit_count(),a);kb=(b.bit_count(),b)
            if ka>=kb:continue
            if forest(a&ALL32) and forest(b&ALL32):best=max(best,ka)
        return best
    nodes=leaves=survivors=0
    def dfs(candidates,used,depth,last):
        nonlocal nodes,leaves,survivors
        nodes+=1
        if depth==6:
            leaves+=1
            if last_pair(ALL64^used)>(words[last].bit_count(),words[last]):survivors+=1
            return
        maxweight=min(10,(64-used.bit_count())//(8-depth))
        if maxweight<6:return
        eligible=candidates&max_weight_masks[maxweight]
        while eligible:
            bit=eligible&-eligible;eligible-=bit;i=bit.bit_length()-1
            dfs(candidates&compat[i],used|words[i],depth+1,i)
    print('PAIR25 start',{'short_words':hist,'forest_compatible_short_words':goodhist},flush=True)
    dfs((1<<n)-1,0,0,-1)
    assert survivors==0
    result={'status':'PASS','pair_lower_bound':25,'short_word_weights':hist,
            'forest_compatible_short_words':goodhist,'nodes':nodes,'six_word_leaves':leaves,
            'distinct_remainders':last_pair.cache_info().currsize,'eight_forest_partitions':survivors,
            'seconds':time.monotonic()-start,
            'premise':'The already proved parity partition bound limits the pair graph to at most eight components.'}
    print(json.dumps(result,indent=2),flush=True);return result

if __name__=='__main__':
    result=check();(HERE/'pair25_checks.json').write_text(json.dumps(result,indent=2)+'\n')
