"""Independent standard-library checks of the matrix, control, and W7 lemma."""
from itertools import combinations
from collections import Counter,defaultdict
from pathlib import Path
import json,sys
HERE=Path(__file__).resolve().parent

def aes_rows():
 def mul(c,x):
  z=((x<<1)^(0x11b if x&128 else 0))
  return x if c==1 else z if c==2 else x^z
 matrix=((2,3,1,1),(1,2,3,1),(1,1,2,3),(3,1,1,2))
 return [sum(1<<(8*j+k) for j in range(4) for k in range(8) if (mul(matrix[r][j],1<<k)>>b)&1) for r in range(4) for b in range(8)]

def rank(vs):
 basis={}
 for v in vs:
  while v:
   p=v.bit_length()-1
   if p in basis:v^=basis[p]
   else:basis[p]=v;break
 return len(basis)

def control():
 O=aes_rows();c=json.load(open(HERE/'control_97.json'));signals=[1<<i for i in range(32)];depth=[0]*32
 for a,b in c['gates']:
  assert 0<=a<len(signals) and 0<=b<len(signals)
  signals.append(signals[a]^signals[b]);depth.append(1+max(depth[a],depth[b]))
 assert [signals[i] for i in c['outputSignals']]==O
 assert len(c['gates'])==97 and max(depth)==3
 assert len(set(signals))==len(signals) and 0 not in signals
 matrix=[sum(int(v)<<i for i,v in enumerate(line.strip())) for line in open(HERE/'matrix.txt') if line.strip()]
 assert matrix==O and rank(O)==32
 assert Counter(v.bit_count() for v in O)=={5:20,7:12}
 counts=Counter(v.bit_count() for v in signals[32:])
 assert counts=={2:27,3:20,4:18,5:20,7:12}
 sys.path.insert(0,str(HERE/'inherited'))
 from build_lp import build
 from model3 import buildings
 rows,cost,meta=build();p=[0]*len(cost)
 for h,j in meta['xi'].items():p[j]=int(h in signals)
 for h,j in meta['yi'].items():p[j]=int(h in signals)
 # One actual final recipe per output, and one actual recipe per quartet.
 for idx in c['outputSignals']:
  a,b=[signals[j] for j in c['gates'][idx-32]];t=signals[idx]
  k=next(k for k,ds in enumerate(meta['decomp'][t]) if set(ds)=={a,b})
  p[meta['zi'][t,k]]=1
 for h,j in meta['yi'].items():
  if h not in signals or h.bit_count()!=4:continue
  idx=signals.index(h);a,b=[signals[j] for j in c['gates'][idx-32]]
  k=next(k for k,ds in enumerate(buildings(h)) if set(ds)=={a,b})
  p[meta['wi'][h,k]]=1
 assert all(sum(p[j]*v for j,v in ts)>=rhs for ts,rhs,tag in rows)
 assert sum(a*b for a,b in zip(p,cost))==65
 assert sum(p[j] for j in meta['xi'].values())>=24
 print('PASS matrix, depth-3 control: P=27,T=20,Q=18; all inherited LP rows satisfied')
 return signals,depth

def w7_lemma():
 O=aes_rows();outs=[i for i,o in enumerate(O) if o.bit_count()==7]
 uses=defaultdict(set);decomp={}
 for i in outs:
  bits=[1<<j for j in range(32) if O[i]>>j&1]
  decomp[i]=[(sum(c),O[i]^sum(c)) for c in combinations(bits,3)]
  for a,b in decomp[i]:uses[a].add(i);uses[b].add(i)
 assert max(map(len,uses.values()))==2
 doubles=[]
 for i in outs:
  for a,b in decomp[i]:
   if len(uses[a])==2 and len(uses[b])==2:
    j=next(iter(uses[a]-{i}));k=next(iter(uses[b]-{i}))
    assert len({i,j,k})==3 and i%8==j%8==k%8
    doubles.append((i,j,k))
 assert len(doubles)==24
 # Hence a cross-cluster sharing edge is an isolated edge. Every other
 # connected component stays among the four outputs of one cluster.
 # Independence forbids cycles. With 12 outputs and components of <=4,
 # the output-parent forest has >=3 components and >=12+3 parents.
 w=json.load(open(HERE/'weight7_parent_result.json'));selected=w['selected']
 assert len(selected)==12 and {i for i,a,b in selected}==set(outs)
 hs=set()
 for i,a,b in selected:
  a=int(a,16);b=int(b,16)
  assert a^b==O[i] and a&b==0 and sorted([a.bit_count(),b.bit_count()])==[3,4]
  hs.update((a,b))
 assert len(hs)==15
 print('PASS weight-7 lemma: all helper fanouts <=2, 24 double-sharing cases internal to clusters, sharp parent count 15')

if __name__=='__main__':control();w7_lemma()
