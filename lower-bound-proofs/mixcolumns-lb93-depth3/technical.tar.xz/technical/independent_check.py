"""Second certificate checker: independent recipe and row enumeration.
Python standard library only. No imports from the LP or recipe generator.
"""
import json,itertools
from collections import defaultdict
from pathlib import Path
from verify_structure import aes_rows
HERE=Path(__file__).resolve().parent

def rebuild():
 O=aes_rows();parents=[];L=set();P={sum(1<<i for i in c) for c in itertools.combinations(range(32),2)}
 odd=[1<<i for i in range(32)]+[sum(1<<i for i in c) for c in itertools.combinations(range(32),3)]
 for o in O:
  ds=[]
  for a in odd:
   b=a^o
   if b.bit_count() in (2,4):
    ds.append((a,b));L.update(v for v in (a,b) if v.bit_count()>2)
  parents.append(ds)
 assert len(L)==7897 and len(P)==496 and sum(map(len,parents))==6120
 H=sorted(P)+sorted(L);idx={h:i for i,h in enumerate(H)}
 def ways(h):
  if h.bit_count()==1:return [frozenset()]
  if h.bit_count()==2:return [frozenset([h])]
  bits=[1<<i for i in range(32) if h>>i&1]
  result=set()
  for two in itertools.combinations(bits,2):
   e=sum(two);f=h^e
   result.add(frozenset([h,e]+([f] if f.bit_count()==2 else [])))
  return result
 opts=[]
 for ds in parents:
  opts.append(sorted({tuple(sorted(x|y)) for a,b in ds for x in ways(a) for y in ways(b)}))
 assert [len(rs) for rs in opts]==[315 if o.bit_count()==7 else 2475 for o in O]
 rows=[];n=len(H)
 for rs in opts:
  uses=defaultdict(list);begin=n
  for recipe in rs:
   for h in recipe:uses[h].append(n)
   n+=1
  rows.append(([(j,1) for j in range(begin,n)],1))
  for h,js in sorted(uses.items()):rows.append(([(idx[h],1)]+[(j,-1) for j in js],0))
 rows.append(([(idx[p],1) for p in sorted(P)],24))
 W7={h for o,ds in zip(O,parents) if o.bit_count()==7 for pair in ds for h in pair}
 rows.append(([(idx[h],1) for h in sorted(W7)],15))
 return rows,[1]*len(H)+[0]*(n-len(H)),H,opts

def check():
 rows,c,H,opts=rebuild();cert=json.load(open(HERE/'certificate_85.json'));D=cert['denominator']
 assert type(D) is int and D>0
 assert (len(rows),len(c))==(cert['rows'],cert['variables'])==(15126,61673)
 multipliers={}
 for i,a in cert['u_nonzero']:
  assert type(i) is int and type(a) is int and 0<=i<len(rows) and a>=0 and i not in multipliers
  multipliers[i]=a
 # The W7 lemma is included in the search model but has multiplier ZERO:
 # this 85 proof does not rely on that additional lemma.
 assert multipliers.get(len(rows)-1,0)==0
 acc=[0]*len(c);rhs=0
 for i,a in multipliers.items():
  terms,b=rows[i];rhs+=a*b
  for j,v in terms:acc[j]+=a*v
 penalty=sum(max(0,a-D*w) for a,w in zip(acc,c));num=rhs-penalty
 assert num==cert['certified_numerator']==52682563822048
 assert rhs==cert['raw_numerator'] and penalty==cert['repair_numerator']==2762
 assert num>52*D and 32+(num+D-1)//D==85
 control=json.load(open(HERE/'control_97.json'));signals=[1<<i for i in range(32)]
 for a,b in control['gates']:signals.append(signals[a]^signals[b])
 p=[int(h in signals) for h in H]+[0]*(len(c)-len(H));j=len(H)
 for rs in opts:
  k=next(k for k,recipe in enumerate(rs) if all(h in signals for h in recipe));p[j+k]=1;j+=len(rs)
 assert sum(w*v for w,v in zip(c,p))==65
 assert all(sum(p[j]*a for j,a in terms)>=b for terms,b in rows)
 print('INDEPENDENT PASS: regenerated all 53,280 recipes, all rows, exact 85 bound, and positive control')
 if (HERE/'fractional_witness.json').exists():
  f=json.load(open(HERE/'fractional_witness.json'));d=f['denominator'];assert type(d) is int and d>0
  v=[0]*len(c);seen=set()
  for j,a in f['nonzero']:
   assert type(j) is int and type(a) is int and 0<=j<len(c) and j not in seen and 0<=a<=d
   seen.add(j);v[j]=a
  assert all(sum(v[j]*a for j,a in terms)>=b*d for terms,b in rows)
  value=sum(a*w for a,w in zip(v,c));assert value==f['helper_numerator'] and value<53*d
  print('EXACT FRACTIONAL WITNESS PASS:',str(value)+'/'+str(d),'helpers; this is NOT a circuit')

if __name__=='__main__':check()
