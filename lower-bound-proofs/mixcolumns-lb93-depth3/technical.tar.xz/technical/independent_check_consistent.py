"""Independent exact verification of pair25 and construction-consistency cuts.

No numerical optimizer or discovery/model code is imported. Local recipe
pricing and the new pair25 finite premise are rechecked by default.
"""
from pathlib import Path
from itertools import combinations
from functools import lru_cache
import json,argparse
from independent_check import rebuild
from independent_check_86 import new_rows
from independent_check_local import additional_rows
from check_local_oracles import verify_oracles
from verify_pair25 import check as check_pair25
from verify_pair26 import check as check_pair26
from independent_parent_rows import additional_rows as parent_rows
from verify_cluster_results import aes_rows
HERE=Path(__file__).resolve().parent

def consistency_rows(H,opts,cuts):
    index={h:i for i,h in enumerate(H)};starts=[];j=len(H)
    for rs in opts:starts.append(j);j+=len(rs)
    @lru_cache(None)
    def builds(h):
        bits=[1<<i for i in range(32) if h>>i&1];forms=set()
        for a,b in combinations(bits,2):
            p=a|b;other=h^p
            forms.add((p,) if other.bit_count()==1 else tuple(sorted((p,other))))
        assert len(forms)==3;return sorted(forms)
    @lru_cache(None)
    def uses(h,o):
        forms=builds(h);result=[[],[],[]]
        for i,rec in enumerate(opts[o]):
            if h not in rec:continue
            pairs=tuple(sorted(v for v in rec if v.bit_count()==2 and v&h==v))
            result[forms.index(pairs)].append(starts[o]+i)
        return result
    rows=[]
    for cut in cuts:
        h=cut['helper'];os=cut['outputs']
        assert type(h) is int and h in index and h.bit_count() in (3,4)
        assert len(os)==3 and all(type(o) is int and 0<=o<32 for o in os)
        vs=[]
        for k,o in enumerate(os):
            chosen=uses(h,o)[k];assert chosen;vs.extend(chosen)
        assert len(vs)==len(set(vs))
        rows.append(([(index[h],1)]+[(j,-1) for j in sorted(vs)],0))
    return rows

def positive_control(rows,H,opts,filename='control_97.json',expected_gates=97):
    control=json.loads((HERE/filename).read_text());signals=[1<<i for i in range(32)];depth=[0]*32
    ancestors=[frozenset() for i in range(32)]
    for a,b in control['gates']:
        assert 0<=a<len(signals) and 0<=b<len(signals)
        h=signals[a]^signals[b];signals.append(h);depth.append(1+max(depth[a],depth[b]))
        ancestors.append(ancestors[a]|ancestors[b]|{h})
    assert len(control['gates'])==expected_gates and max(depth)==3
    assert [signals[i] for i in control['outputSignals']]==aes_rows()
    p=[int(h in signals) for h in H]
    for i,rs in zip(control['outputSignals'],opts):
        actual=tuple(sorted(h for h in ancestors[i] if 1<h.bit_count()<5))
        chosen=rs.index(actual);p.extend(int(k==chosen) for k in range(len(rs)))
    assert all(sum(p[j]*a for j,a in ts)>=rhs for ts,rhs in rows)

def check(path,full=True):
    cert=json.loads(path.read_text());pair_bound=cert['pair_lower_bound'];assert pair_bound in (25,26)
    pair_result=(check_pair25() if pair_bound==25 else check_pair26()) if full else None
    local=verify_oracles(cert) if full else []
    rows,c,H,opts=rebuild();rows+=new_rows(H,opts);assert len(rows)==cert['base_rows']==15169
    rows+=additional_rows(H,opts,cert)
    rows.append(([(j,1) for j,h in enumerate(H) if h.bit_count()==2],pair_bound))
    rows+=consistency_rows(H,opts,cert['consistency_cuts'])
    parent,tree_checks=parent_rows(H,opts,cert,verify_prices=full)
    rows+=parent
    linked_checks=[];edge_checks=[]
    if cert.get('linked_cluster_cuts'):
        from independent_linked_rows import additional_rows as linked_rows
        linked,linked_checks=linked_rows(H,opts,cert,verify_prices=full);rows+=linked
    if cert.get('parent_edge_tree_cuts'):
        from independent_edge_tree_rows import additional_rows as edge_rows
        edges,edge_checks=edge_rows(H,opts,cert,verify_prices=full);rows+=edges
    assert (len(rows),len(c))==(cert['rows'],cert['variables'])
    D=cert['denominator'];assert type(D) is int and D>0
    acc=[0]*len(c);raw=0;seen=set()
    for i,u in cert['u_nonzero']:
        assert type(i) is int and 0<=i<len(rows) and i not in seen
        assert type(u) is int and u>=0;seen.add(i)
        terms,rhs=rows[i];raw+=u*rhs
        for j,a in terms:acc[j]+=u*a
    repair=sum(max(0,a-D*w) for a,w in zip(acc,c));num=raw-repair;bound=32+(num+D-1)//D
    assert (raw,repair,num,bound)==(cert['raw_numerator'],cert['repair_numerator'],cert['certified_numerator'],cert['gate_lower_bound'])
    positive_control(rows,H,opts)
    check26=(HERE/'pair26_actual_circuit.json').exists()
    if check26:positive_control(rows,H,opts,'pair26_actual_circuit.json',100)
    result={'status':'PASS','certificate':path.name,'rows':len(rows),'variables':len(c),
            'certified_helper_numerator':num,'denominator':D,'rounding_repair_numerator':repair,
            'gate_lower_bound':bound,'pair_lower_bound':pair_bound,'pair_bound_checked':bool(pair_result),'local_oracles_checked':len(local),
            'consistency_inequalities':len(cert['consistency_cuts']),'known97_satisfies_all_rows':True,
            'parent_forest_inequalities':len(cert.get('parent_forest_cuts',[])),
            'parent_tree_inequalities':len(cert.get('parent_tree_cuts',[])),
            'known26pair_witness_satisfies_all_rows':check26,
            'pair_bound_result':pair_result,'local_checks':local,'parent_tree_checks':tree_checks,
            'linked_cluster_checks':linked_checks,'parent_edge_tree_checks':edge_checks}
    print(json.dumps({k:v for k,v in result.items() if k not in ('pair_bound_result','local_checks','parent_tree_checks','linked_cluster_checks','parent_edge_tree_checks')},indent=2),flush=True)
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('certificate',type=Path);ap.add_argument('--skip-finite-checks',action='store_true');ap.add_argument('--result',type=Path);a=ap.parse_args()
    result=check(a.certificate,not a.skip_finite_checks)
    target=a.result if a.result else HERE/f'independent_consistent_{result["gate_lower_bound"]}_checks.json'
    target.write_text(json.dumps(result,indent=2)+'\n')
