// Independent threshold verifier for a four-output priced construction cut.
// Uses bitset copies, reverses output order, and proves that no selection is
// strictly cheaper than the proposed RHS. No optimizer or discovery importer.
#include <algorithm>
#include <array>
#include <chrono>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;using I=long long;
struct Recipe{vector<int> ids;I fixed;};
array<vector<Recipe>,4>options;vector<I>price;I threshold;uint64_t nodes=0;
bool bad=false,timed=false;double seconds;auto begun=chrono::steady_clock::now();
I extra(const Recipe&r,const vector<uint64_t>&set){I x=r.fixed;for(int j:r.ids)if(!(set[j/64]>>(j%64)&1))x+=price[j];return x;}
void visit(int remaining,I paid,const vector<uint64_t>&set){
 if(bad||timed||paid>=threshold)return;
 if(!remaining){bad=true;return;}
 I largest=0,fixedsum=0;
 for(int k=0;k<remaining;k++){
  I least=(1LL<<61),leastfixed=(1LL<<61);
  for(const auto&r:options[k]){least=min(least,extra(r,set));leastfixed=min(leastfixed,r.fixed);}
  largest=max(largest,least);fixedsum+=leastfixed;
 }
 if(paid+max(largest,fixedsum)>=threshold)return;
 for(const auto&r:options[remaining-1]){
  if((++nodes&16383)==0&&chrono::duration<double>(chrono::steady_clock::now()-begun).count()>seconds){timed=true;return;}
  I value=paid+extra(r,set);if(value>=threshold)continue;
  if(remaining==1){bad=true;return;}
  vector<uint64_t>updated(set);for(int j:r.ids)updated[j/64]|=1ULL<<(j%64);
  visit(remaining-1,value,updated);if(bad||timed)return;
 }
}
int main(int argc,char**argv){
 if(argc!=4)return 2;ifstream in(argv[1]);int n;in>>n;price.resize(n);for(auto&p:price){in>>p;if(p<0)return 3;}
 threshold=stoll(argv[2]);seconds=stod(argv[3]);
 for(auto&list:options){int count;in>>count;list.resize(count);I smallest=(1LL<<61);
  for(auto&r:list){int size;in>>r.fixed>>size;r.ids.resize(size);for(auto&j:r.ids){in>>j;if(j<0||j>=n)return 4;}smallest=min(smallest,r.fixed);}
  threshold-=smallest;for(auto&r:list)r.fixed-=smallest;
  stable_sort(list.begin(),list.end(),[](const auto&a,const auto&b){return a.fixed<b.fixed;});
 }
 if(!in)return 5;begun=chrono::steady_clock::now();visit(4,0,vector<uint64_t>((n+63)/64));
 cout<<(timed?"INCOMPLETE":bad?"COUNTEREXAMPLE":"VERIFIED")<<" nodes "<<nodes<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-begun).count()<<'\n';
 return timed?6:bad?7:0;
}
