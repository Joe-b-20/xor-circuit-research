"""Combine all independently checked case exclusions into D3>=93.

Default reruns every new check and both C++ exclusions. --full also rechecks
all earlier finite premises. --reuse-checked-results trusts the recorded
checks already completed in this run and only recomputes coverage.
"""
from pathlib import Path
import json,hashlib,argparse,subprocess,sys,tempfile,re
from verify_pair26 import pair_recipes,write_recipe_data,canonical
from verify_cluster_results import aes_rows
HERE=Path(__file__).resolve().parent

def run_python(*args):subprocess.run([sys.executable,*map(str,args)],cwd=HERE,check=True)
def orbit(bb):
    def rot(h,r):return ((h<<(8*r))&0xffffffff)|(h>>(32-8*r)) if r else h
    return {tuple(sorted(rot(C,r) for C in bb)) for r in range(4)}
def readparts(path):return {tuple(sorted(map(int,line.split()))) for line in path.read_text().splitlines() if line.strip()}
def digest(parts):return hashlib.sha256(json.dumps(sorted(parts),separators=(',',':')).encode()).hexdigest()

def cpp_checks():
    with tempfile.TemporaryDirectory(prefix='aes-93-cpp-checks-') as td:
        td=Path(td);write_recipe_data(td/'recipes.txt',pair_recipes(aes_rows()))
        exe=td/'components';subprocess.run(['g++','-O3','-std=c++17',str(HERE/'check_component_forests.cpp'),'-o',str(exe)],check=True)
        bad=set(map(int,(HERE/'conditioned_c6_used_bad.txt').read_text().split()))|set(map(int,(HERE/'pair26_extended_forest_obstructions.txt').read_text().split()))
        assert len(bad)==20933
        (td/'all_bad.txt').write_text('\n'.join(map(str,sorted(bad)))+'\n')
        out=subprocess.check_output([str(exe),str(td/'recipes.txt'),str(td/'all_bad.txt'),str(td/'bad.txt'),'20000000','600'],text=True)
        assert re.search(r'^COMPLETE components 20933 rejected 20933 unknown 0 feasible 0 ',out,re.M),out[-1000:]
        assert set(map(int,(td/'bad.txt').read_text().split()))==bad
        exe=td/'pairs';subprocess.run(['g++','-O3','-std=c++17',str(HERE/'check_partition_pairs.cpp'),'-o',str(exe)],check=True)
        out2=subprocess.check_output([str(exe),str(td/'recipes.txt'),str(HERE/'conditioned_c7_pair_rejected.txt'),'7','1','2000','180'],text=True)
        assert re.search(r'^COMPLETE partitions 710 rejected 710 unknown 0 ',out2,re.M),out2[-1000:]
    return {'status':'PASS','forest_obstructions':20933,'seven_component_pair_orbits_rejected':710}

def combine(reuse=False,full=False):
    if full:
        for script in ('verify_structure.py','verify_boundary_tax.py','verify_cluster_results.py','weighted_cluster_certificate.py'):
            run_python(script)
        run_python('verify_pair_tradeoff.py','--full');run_python('verify_eight_component_tradeoff.py')
    if not reuse:
        run_python('verify_component_conditionals.py')
        for c in (6,7):run_python('verify_conditioned_partition_coverage.py',c);run_python('verify_reduced_parent_prices.py',c)
        run_python('verify_partition_conditionals.py')
        (HERE/'complete_92_cpp_checks.json').write_text(json.dumps(cpp_checks(),indent=2)+'\n')
    for name in ['pair_tradeoff_checks.json','eight_component_tradeoff_checks.json','component_conditional_checks.json','partition_conditional_checks.json','complete_92_cpp_checks.json']:
        assert json.loads((HERE/name).read_text())['status']=='PASS',name
    cutchecks=json.loads((HERE/'partition_conditional_checks.json').read_text());stats={}
    bad=set(map(int,(HERE/'conditioned_c6_used_bad.txt').read_text().split()))
    for c in (6,7):
        allparts=readparts(HERE/f'conditioned_c{c}_parts.txt')
        enumeration=json.loads((HERE/f'conditioned_c{c}_coverage_checks.json').read_text());assert enumeration['status']=='PASS' and digest(allparts)==enumeration['canonical_sha256']
        prices=json.loads((HERE/f'conditioned_c{c}_parent_prices.json').read_text());pricecheck=json.loads((HERE/f'conditioned_c{c}_parent_price_checks.json').read_text());assert prices['complete'] and pricecheck['status']=='PASS'
        covered_forest={p for p in allparts if c==6 and any(canonical(C) in bad for C in p)}
        covered_prices=set()
        for r in prices['strong']:covered_prices.update(orbit(r['partition']))
        assert len(covered_prices)==pricecheck['covered_partitions']
        covered_duals=set()
        for r in cutchecks['records']:
            if r['components']==c:covered_duals.update(orbit(r['partition']))
        covered_pairs=set()
        if c==7:
            for p in readparts(HERE/'conditioned_c7_pair_rejected.txt'):covered_pairs.update(orbit(p))
        for group in (covered_forest,covered_prices,covered_duals,covered_pairs):assert group<=allparts
        left=allparts-covered_forest-covered_prices-covered_duals-covered_pairs
        stats[c]={'total_partitions':len(allparts),'forest_component_exclusions':len(covered_forest),'parent_price_exclusions':len(covered_prices),'farkas_exclusions':len(covered_duals),'pair_recipe_exclusions':len(covered_pairs),'uncovered':len(left)}
        assert not left,(c,'uncovered partitions',len(left),list(left)[:3])
    control=json.loads((HERE/'control_97.json').read_text());sig=[1<<i for i in range(32)];dep=[0]*32
    for a,b in control['gates']:
        assert type(a) is int and type(b) is int and 0<=a<len(sig) and 0<=b<len(sig)
        sig.append(sig[a]^sig[b]);dep.append(1+max(dep[a],dep[b]))
    assert len(control['gates'])==97 and max(dep)==3 and [sig[i] for i in control['outputSignals']]==aes_rows()
    result={'status':'PASS','verified_gate_interval':[93,97],'new_lower_bound':93,'case_coverage':stats,'eight_component_case':'Previously verified: P=26,c=8 requires at least 96 gates.','premise':'Previously verified P>=26 and 3P+4T+4Q>=214 reduce any <=92-gate circuit to P=26,H=60,c in {6,7,8}.','known97_rechecked':True,'reused_completed_checks':reuse,'source_certificate_checker_rerun':full,'exact_optimum':'UNRESOLVED'}
    (HERE/'depth3_93_checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--reuse-checked-results',action='store_true');p.add_argument('--full',action='store_true');a=p.parse_args();combine(a.reuse_checked_results,a.full)
