"""Exact, solver-free checks for the weight-seven cluster boundary tax.

The proof is in BOUNDARY_TAX_PROOF.txt. The only construction table has
five cases, each with 3^6 = 729 pair-construction assignments.
"""
from itertools import combinations,product
from functools import reduce
from operator import xor
from collections import defaultdict
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
A=[1<<i for i in range(4)];B=[1<<(4+i) for i in range(4)];C=[1<<(8+i) for i in range(4)]
am=sum(A);bm=sum(B);cm=sum(C)
Y=[(am^A[r])^B[r]^B[(r+1)%4]^C[r]^C[(r+1)%4] for r in range(4)]

def pairs_for_parent(h):
 bits=[1<<i for i in range(12) if h>>i&1]
 if len(bits)==3:return [frozenset([h^b]) for b in bits]
 assert len(bits)==4
 return [frozenset([bits[0]|bits[i],h^(bits[0]|bits[i])]) for i in range(1,4)]

def free_pair(e):return e&~cm==0

def check():
 assert {reduce(xor,z,0).bit_count() for z in combinations(Y,2)}=={6,10}
 assert {reduce(xor,z,0).bit_count() for z in combinations(Y,3)}=={5}
 assert reduce(xor,Y,0).bit_count()==4
 assert {(x&y&z).bit_count() for x,y,z in combinations(Y,3)}=={1}
 for i,j in combinations(range(12),2):
  e=(1<<i)|(1<<j)
  assert sum(e&~y==0 for y in Y)<=2
  if free_pair(e):assert sum(e&~y==0 for y in Y)<=1

 # Verify the structural rule for every output decomposition: if a selected
 # parent contains a C-family pair, it is private. Its other parent is either
 # private, or a shared triple omitting C; in the latter case every adjacent
 # quartet is private. This assertion is about possible masks, not a solver.
 parents=set()
 ds=[]
 for r,y in enumerate(Y):
  bits=[1<<i for i in range(12) if y>>i&1]
  for bs in combinations(bits,3):
   t=sum(bs);q=y^t;parents.update([t,q]);ds.append((r,t,q))
 fanout={h:sum(h&~y==0 for y in Y) for h in parents}
 local_cases=0
 for r,t,q in ds:
  for h,other in [(t,q),(q,t)]:
   if (h&cm).bit_count()!=2:continue
   assert fanout[h]==1
   if fanout[other]>1:
    assert other.bit_count()==3 and other&cm==0
    for s,y in enumerate(Y):
     if other&~y==0:assert fanout[y^other]==1
   local_cases+=1

 # In the only nontrivial H=6 case, a component carrying a free C-pair
 # has the two outputs 0,1 and shared triple T=A2+A3+B1.
 t=A[2]|A[3]|B[1]
 first=[t,Y[0]^t,Y[1]^t]
 assert [h.bit_count() for h in first]==[3,4,4]
 intersection=Y[2]&Y[3]
 assert intersection.bit_count()==4
 cases=[('shared_quartet',[intersection,Y[2]^intersection,Y[3]^intersection])]
 for bit in [1<<i for i in range(12) if intersection>>i&1]:
  tt=intersection^bit
  cases.append(('shared_triple_omits_'+('A' if bit&am else 'B' if bit&bm else 'C')+str(bit.bit_length()-1),[tt,Y[2]^tt,Y[3]^tt]))
 table=[];assignments=0
 for name,second in cases:
  hs=first+second;assert len(set(hs))==6
  best=defaultdict(lambda:100)
  for recipes in product(*(pairs_for_parent(h) for h in hs)):
   pp=set().union(*recipes);k=sum(free_pair(e) for e in pp)
   paid=len(pp)-k
   assignments+=1
   if k:
    assert paid>=6,(name,k,paid,pp)
    best[k]=min(best[k],paid)
  table.append({'second_component':name,'minimum_non_C_pairs_by_k':dict(sorted(best.items()))})
 assert assignments==5*3**6
 result={'status':'PASS','decomposition_checks':local_cases,'construction_assignments':assignments,'table':table,
  'claim':'For one W7 cluster, gate count >=16 + number of C-family pair gates in its ancestry.',
  'qualification':'The table checks the finite H=6 case; the other cases are justified in the written proof.'}
 print(json.dumps(result,indent=2))
 return result

if __name__=='__main__':
 result=check();(HERE/'boundary_tax_checks.json').write_text(json.dumps(result,indent=2)+'\n')
