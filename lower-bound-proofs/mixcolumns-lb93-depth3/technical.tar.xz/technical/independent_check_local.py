"""Independent exact verification of the full depth-three construction bound.

No import from a numerical model, separation code, NumPy, or SciPy.
Default operation also exhaustively verifies every additional local cut.
"""
from pathlib import Path
import json,argparse
from independent_check import rebuild
from independent_check_86 import new_rows as base86_extra
from verify_cluster_results import aes_rows
from check_local_oracles import verify_oracles
HERE=Path(__file__).resolve().parent

def additional_rows(H,opts,cert):
    index={h:i for i,h in enumerate(H)};rows=[];seen=set()
    # Directly build input-bit permutations, independently of discovery code.
    for cut in cert['w7_cuts']:
        for b in (1,3,4):
            for mirror in (False,True):
                for swap in (False,True):
                    perm={}
                    for family,oldbit in enumerate((3,2,7)):
                        for r in range(4):
                            rr=(4-r)%4 if mirror and family==0 else (5-r)%4 if mirror else r
                            ff=3-family if swap and family else family
                            perm[1<<(8*r+oldbit)]=1<<(8*rr+(b,b-1,7)[ff])
                    terms=[]
                    for h,w in cut['prices']:
                        out=0
                        while h:
                            t=h&-h;h-=t;out|=perm[t]
                        terms.append((index[out],w))
                    key=(tuple(sorted(terms)),cut['minimum'])
                    if key not in seen:seen.add(key);rows.append((list(key[0]),key[1]))
    seen=set();O=aes_rows()
    for cut in cert['w5_projection_cuts']:
        for b in (0,2,5,6,7):
            U=sorted({h for i,rs in enumerate(opts) if i%8==b for r in rs for h in r})
            support=0
            for r in range(4):support|=O[8*r+b]
            for mirror in (False,True):
                perm={}
                for family,oldbit in enumerate((6,5)):
                    for r in range(4):
                        rr=(4-r)%4 if mirror and family==0 else (5-r)%4 if mirror else r
                        perm[1<<(8*r+oldbit)]=1<<(8*rr+(b,(b-1)%8)[family])
                prices={}
                for h,w in cut['prices']:
                    out=0
                    while h:
                        t=h&-h;h-=t;out|=perm[t]
                    prices[out]=w
                terms=tuple((index[h],prices[h&support]) for h in U if h&support in prices)
                key=(terms,cut['minimum'])
                if key not in seen:seen.add(key);rows.append((list(terms),key[1]))
    return rows

def check(path,oracles=True):
    cert=json.loads(path.read_text())
    local_checks=verify_oracles(cert) if oracles else []
    rows,c,H,opts=rebuild();rows.extend(base86_extra(H,opts));assert len(rows)==cert['base_rows']==15169
    rows.extend(additional_rows(H,opts,cert));assert (len(rows),len(c))==(cert['rows'],cert['variables'])
    D=cert['denominator'];assert type(D) is int and D>0
    acc=[0]*len(c);raw=0;seen=set()
    for i,u in cert['u_nonzero']:
        assert type(i) is int and 0<=i<len(rows) and i not in seen
        assert type(u) is int and u>=0;seen.add(i)
        terms,rhs=rows[i];raw+=u*rhs
        for j,a in terms:acc[j]+=u*a
    repair=sum(max(0,a-D*w) for a,w in zip(acc,c));num=raw-repair
    assert (raw,repair,num)==(cert['raw_numerator'],cert['repair_numerator'],cert['certified_numerator'])
    bound=32+(num+D-1)//D;assert bound==cert['gate_lower_bound']
    # The known97 circuit must remain legal under every newly checked row.
    control=json.loads((HERE/'control_97.json').read_text());signals=[1<<i for i in range(32)];depth=[0]*32
    for a,b in control['gates']:
        assert 0<=a<len(signals) and 0<=b<len(signals)
        signals.append(signals[a]^signals[b]);depth.append(1+max(depth[a],depth[b]))
    assert len(control['gates'])==97 and max(depth)==3
    assert [signals[i] for i in control['outputSignals']]==aes_rows()
    present=set(signals);p=[int(h in present) for h in H]+[0]*(len(c)-len(H));j=len(H)
    for rs in opts:
        k=next(k for k,r in enumerate(rs) if all(h in present for h in r));p[j+k]=1;j+=len(rs)
    assert all(sum(p[j]*a for j,a in ts)>=rhs for ts,rhs in rows)
    result={'status':'PASS','certificate':path.name,'rows':len(rows),'variables':len(c),
            'certified_helper_numerator':num,'denominator':D,'rounding_repair_numerator':repair,
            'gate_lower_bound':bound,'known97_satisfies_all_rows':True,'local_oracles_checked':len(local_checks),
            'local_checks':local_checks}
    print(json.dumps({k:v for k,v in result.items() if k!='local_checks'},indent=2),flush=True)
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('certificate',type=Path);ap.add_argument('--skip-oracles',action='store_true');a=ap.parse_args()
    result=check(a.certificate,not a.skip_oracles)
    (HERE/f'independent_depth3_{result["gate_lower_bound"]}_checks.json').write_text(json.dumps(result,indent=2)+'\n')
