"""Independent local recipe regeneration and exact checking of priced cuts."""
from itertools import combinations
from pathlib import Path
import re,subprocess,tempfile
from verify_cluster_results import aes_rows
HERE=Path(__file__).resolve().parent

def independent_data(bit):
    O=aes_rows();outputs=[O[8*r+bit] for r in range(4)]
    inputs=sorted({1<<i for y in outputs for i in range(32) if y>>i&1})
    odd=([a for a in inputs] if bit==6 else [])+[sum(c) for c in combinations(inputs,3)]
    def ways(h):
        if h.bit_count()==1:return [frozenset()]
        if h.bit_count()==2:return [frozenset([h])]
        result=set();bs=[a for a in inputs if h&a]
        for two in combinations(bs,2):
            p=sum(two);q=h^p
            if q.bit_count() in (1,2):result.add(frozenset([h,p]+([q] if q.bit_count()==2 else [])))
        assert len(result)==3
        return result
    options=[]
    for y in outputs:
        rs=set()
        for a in odd:
            b=a^y
            if b.bit_count() not in ((2,4) if bit==6 else (4,)):continue
            for x in ways(a):
                for z in ways(b):rs.add(tuple(sorted(x|z)))
        assert len(rs)==315
        assert all(len(r) in ((3,5) if bit==6 else (5,)) for r in rs)
        options.append(sorted(rs))
    H=sorted({h for rs in options for r in rs for h in r});idx={h:i for i,h in enumerate(H)}
    padded=[[tuple(idx[h] for h in r)+((len(H),len(H)+1) if len(r)==3 else ()) for r in rs] for rs in options]
    return H,padded

def verify_oracles(cert):
    results=[]
    with tempfile.TemporaryDirectory(prefix='aes-construction-proof-') as tmp:
        tmp=Path(tmp);exe=tmp/'enum'
        subprocess.run(['g++','-O3','-std=c++17',str(HERE/'exact_weighted_enum.cpp'),'-o',str(exe)],check=True)
        for kind,bit,cuts in (('w7',3,cert['w7_cuts']),('w5_projection',6,cert['w5_projection_cuts'])):
            H,options=independent_data(bit)
            for k,cut in enumerate(cuts):
                prices={}
                for h,w in cut['prices']:
                    assert type(h) is int and h in H and h not in prices
                    assert type(w) is int and 0<w<=10**6;prices[h]=w
                assert type(cut['minimum']) is int and cut['minimum']>=0
                weights=[prices.get(h,0) for h in H]+([0,0] if bit==6 else [])
                inp=tmp/'data.txt'
                with inp.open('w') as f:
                    print(len(weights),file=f);print(*weights,file=f)
                    for rs in options:
                        print(len(rs),file=f)
                        for r in rs:print(*r,file=f)
                out=subprocess.check_output([str(exe),str(inp),'120'],text=True)
                m=re.search(r'^COMPLETE minimum (\d+) nodes (\d+) leaves (\d+)',out,re.M)
                assert m,'Incomplete enumeration does not prove a cut.'
                value=int(m.group(1));assert value==cut['minimum'],(kind,k,value,cut['minimum'])
                ids=list(map(int,re.search(r'^recipes (.*)',out,re.M).group(1).split()))
                assert len(ids)==20
                for i in range(4):assert tuple(ids[5*i:5*i+5]) in options[i]
                assert sum(weights[i] for i in set(ids))==value
                results.append({'kind':kind,'cut':k,'minimum':value,'nodes':int(m.group(2)),
                                'last_output_candidates':int(m.group(3))})
                print('EXACT LOCAL PASS',kind,k,'minimum',value,flush=True)
    return results
