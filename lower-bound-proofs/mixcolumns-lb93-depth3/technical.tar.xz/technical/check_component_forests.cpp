// Component-wise necessary forest feasibility. Global recipes cannot use
// an edge crossing a true graph component. Project each complete recipe to
// edges inside this component; every projected output must be supported.
#define main partition_main
#include "check_partition_pairs.cpp"
#undef main
#include <set>
int main(int argc,char**argv){
 if(argc!=6)return 2;ifstream in(argv[1]),components(argv[2]);ofstream bad(argv[3]);int n;in>>n;if(n!=496)return 3;
 masks.resize(n);for(auto&m:masks){in>>m;int a=__builtin_ctz(m);uint32_t t=m&(m-1);edges.push_back({a,__builtin_ctz(t)});}
 int no;in>>no;if(no!=32)return 4;
 for(auto&rr:original){int m;in>>m;for(int j=0;j<m;j++){R r;in>>r.n;for(int k=0;k<r.n;k++)in>>r.e[k];rr.push_back(r);}}
 cap=stoull(argv[4]);double seconds=stod(argv[5]);budget=0;
 auto start=chrono::steady_clock::now();uint64_t total=0,rejected=0,unknown=0,sats=0,totalnodes=0;uint32_t component;bool timed=false;
 while(components>>component){
  if(chrono::duration<double>(chrono::steady_clock::now()-start).count()>seconds){timed=true;break;}
  array<int,496>type;for(int e=0;e<496;e++)type[e]=(masks[e]&component)==0?0:(masks[e]&component)==masks[e]?1:2;
  bool impossible=false;
  for(int o=0;o<32;o++){
   set<vector<int>> projected;
   for(auto&r:original[o]){
    bool ok=true;vector<int>es;for(int k=0;k<r.n;k++){if(type[r.e[k]]==2)ok=false;if(type[r.e[k]]==1)es.push_back(r.e[k]);}
    if(ok)projected.insert(es);
   }
   options[o].clear();vector<vector<int>> vv(projected.begin(),projected.end());
   sort(vv.begin(),vv.end(),[](auto&a,auto&b){return a.size()!=b.size()?a.size()<b.size():a<b;});
   vector<vector<int>>keep;
   for(auto&es:vv){
    bool redundant=false;for(auto&ss:keep)if(includes(es.begin(),es.end(),ss.begin(),ss.end())){redundant=true;break;}
    if(redundant)continue;keep.push_back(es);R r;r.n=es.size();for(int k=0;k<r.n;k++)r.e[k]=es[k];options[o].push_back(r);
   }
   if(options[o].empty())impossible=true;
  }
  total++;nodes=0;incomplete=false;dead.clear();bool sat=false;
  if(!impossible){State s;for(int i=0;i<32;i++)s.uf[i]=i;sat=dfs(s);}
  totalnodes+=nodes;if(sat)sats++;else if(incomplete)unknown++;else{rejected++;bad<<component<<'\n';}
  if(total%1000==0)cout<<"PROGRESS components "<<total<<" rejected "<<rejected<<" unknown "<<unknown<<" feasible "<<sats<<" nodes "<<totalnodes<<endl;
 }
 cout<<(timed?"INCOMPLETE":"COMPLETE")<<" components "<<total<<" rejected "<<rejected<<" unknown "<<unknown<<" feasible "<<sats<<" nodes "<<totalnodes<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<endl;
}
