"""Solver-free verification of cluster constructions and separation premises."""
from pathlib import Path
from itertools import combinations
from collections import defaultdict
import json
HERE=Path(__file__).resolve().parent

def aes_rows():
    coefficients=((2,3,1,1),(1,2,3,1),(1,1,2,3),(3,1,1,2))
    def multiply(c,x):
        double=(x<<1)^(0x11b if x&128 else 0)
        return x if c==1 else double if c==2 else x^double
    return [sum(1<<(8*j+k) for j in range(4) for k in range(8)
                if multiply(coefficients[r][j],1<<k)>>b&1)
            for r in range(4) for b in range(8)]

def local_sixteen(bit):
    signals=[1<<i for i in range(32)];depth=[0]*32;gates=[]
    A=[8*r+bit for r in range(4)]
    B=[8*r+bit-1 for r in range(4)];C=[8*r+7 for r in range(4)]
    def gate(a,b):
        gates.append([a,b]);signals.append(signals[a]^signals[b])
        depth.append(1+max(depth[a],depth[b]));return len(signals)-1
    p=[gate(b,c) for b,c in zip(B,C)]
    u=gate(A[0],A[1]);v=gate(A[2],A[3])
    q0=gate(v,p[1]);q1=gate(u,p[3])
    t=[gate(A[1],p[0]),gate(A[0],p[2]),gate(A[3],p[2]),gate(A[2],p[0])]
    out=[gate(q0,t[0]),gate(q0,t[1]),gate(q1,t[2]),gate(q1,t[3])]
    assert [signals[i] for i in out]==[aes_rows()[8*r+bit] for r in range(4)]
    assert len(gates)==16 and max(depth)==3
    return signals,gates,out

def check_saved(name):
    obj=json.loads((HERE/name).read_text());O=aes_rows()
    signals=[1<<i for i in range(32)];depth=[0]*32
    for a,b in obj['gates']:
        assert 0<=a<len(signals) and 0<=b<len(signals)
        signals.append(signals[a]^signals[b]);depth.append(1+max(depth[a],depth[b]))
    assert len(set(signals))==len(signals) and 0 not in signals
    assert len(obj['gates'])==obj['gateCount'] and max(depth)==3
    assert [signals[i] for i in obj['outputSignals']]==[O[i] for i in obj['outputIndices']]
    return {'file':name,'gates':len(obj['gates']),'outputs':obj['outputIndices'],'depth':max(depth)}

def check():
    O=aes_rows();families={b:sum(1<<(8*r+b) for r in range(4)) for b in range(8)}
    for b in (1,3,4):
        for r in range(4):
            a=families[b]^(1<<(8*r+b))
            side=sum(1<<(8*j+k) for j in (r,(r+1)%4) for k in (b-1,7))
            assert O[8*r+b]==a^side
        signals,gates,out=local_sixteen(b)
        assert len(gates)==16
        if b==1:assert all(h&~families[7] for h in signals[32:])
    support1=0;support34=0
    for i,o in enumerate(O):
        if i%8==1:support1|=o
        if i%8 in (3,4):support34|=o
    assert support1&support34==families[7]
    assert all((O[i]&families[7]).bit_count()==2 for i in range(32) if i%8 in (1,3,4))

    # Independently check the cross-parent isolation premise used by the
    # exploratory strengthened search. It is not needed for boundary tax.
    uses=defaultdict(set);decomps={}
    for i,o in enumerate(O):
        if i%8 not in (3,4):continue
        bits=[1<<j for j in range(32) if o>>j&1]
        decomps[i]=[(sum(c),o^sum(c)) for c in combinations(bits,3)]
        for a,b in decomps[i]:uses[a].add(i);uses[b].add(i)
    assert max(map(len,uses.values()))==2
    for i,ds in decomps.items():
        for a,b in ds:
            if len(uses[a])==2 and len(uses[b])==2:
                assert all(j%8==i%8 for j in uses[a]|uses[b])

    # Check the warning against adding both boundary taxes.
    from verify_boundary_tax import A,B,C,Y
    pairs={A[0]|A[1],A[2]|A[3]}
    pairs.update(B[r]|B[(r+1)%4] for r in range(4))
    pairs.update(C[r]|C[(r+1)%4] for r in range(4))
    triples=[sum(A)^a for a in A]
    quartets=[B[r]|B[(r+1)%4]|C[r]|C[(r+1)%4] for r in range(4)]
    assert [t^q for t,q in zip(triples,quartets)]==Y
    for t in triples:assert any(p&~t==0 and (t^p).bit_count()==1 for p in pairs)
    for q in quartets:assert any(p&~q==0 and q^p in pairs for p in pairs)
    assert len(pairs)+len(triples)+len(quartets)+len(Y)==22

    checked=[check_saved(name) for name in ('cluster1_free7_circuit.json','cluster34_circuit.json','cluster134_circuit.json')]
    result={'status':'PASS','local_gate_count':16,'separation':'D3({1,3,4}) = 16 + D3({3,4})',
            'saved_circuits':checked,'qualification':'Partial circuits are upper bounds only.'}
    print(json.dumps(result,indent=2));return result

if __name__=='__main__':
    result=check();(HERE/'cluster_results_checks.json').write_text(json.dumps(result,indent=2)+'\n')
