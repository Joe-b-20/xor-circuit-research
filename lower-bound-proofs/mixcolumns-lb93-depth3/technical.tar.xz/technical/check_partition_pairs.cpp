// Exact pair-only construction search inside specified parity components.
// Every output chooses a complete allowed two/three-pair recipe. Union
// cycle rank is bounded by P-32+c. Unit propagation uses intersections
// of all currently viable recipes; branching exhausts one output's choices.
#include <algorithm>
#include <array>
#include <bitset>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <sstream>
#include <unordered_set>
#include <vector>
using namespace std;
using Bits=bitset<496>;
struct R{array<int,3> e;int n;};
struct State{array<int,32>uf;Bits selected;int cycles=0;};
vector<uint32_t> masks;vector<pair<int,int>>edges;array<vector<R>,32>original,options;
int budget;uint64_t nodes,cap;bool incomplete;State witness;
unordered_set<Bits> dead;
int find(const State&s,int a){while(s.uf[a]!=a)a=s.uf[a];return a;}
bool add(State&s,int e){
 if(s.selected[e])return true;s.selected.set(e);auto[a,b]=edges[e];int x=find(s,a),y=find(s,b);
 if(x==y)s.cycles++;else s.uf[x]=y;return s.cycles<=budget;
}
bool add_recipe(State&s,const R&r){for(int k=0;k<r.n;k++)if(!add(s,r.e[k]))return false;return true;}
bool contains(const State&s,const R&r){for(int k=0;k<r.n;k++)if(!s.selected[r.e[k]])return false;return true;}
bool dfs(State state){
 if(dead.find(state.selected)!=dead.end())return false;
 if(++nodes>cap){incomplete=true;return false;}
 while(true){
  bool changed=false;int branch=-1;vector<R>best;
  for(int o=0;o<32;o++){
   bool done=false;for(auto&r:options[o])if(contains(state,r)){done=true;break;}if(done)continue;
   vector<R>viable;Bits common;common.set();
   for(auto&r:options[o]){
    State next=state;if(!add_recipe(next,r))continue;viable.push_back(r);
    Bits set;for(int k=0;k<r.n;k++)set.set(r.e[k]);common&=set;
   }
   if(viable.empty()){dead.insert(state.selected);return false;}
   common&=~state.selected;
   if(common.any()){
    for(int e=0;e<496;e++)if(common[e]){if(!add(state,e))return false;changed=true;}
   }
   if(branch<0||viable.size()<best.size()){branch=o;best=move(viable);}
  }
  if(changed)continue;
  if(dead.find(state.selected)!=dead.end())return false;
  if(branch<0){witness=state;return true;}
  stable_sort(best.begin(),best.end(),[&state](const R&a,const R&b){
   int ca=0,cb=0;for(int k=0;k<a.n;k++)ca+=!state.selected[a.e[k]];for(int k=0;k<b.n;k++)cb+=!state.selected[b.e[k]];return ca<cb;});
  for(auto&r:best){State next=state;if(add_recipe(next,r)&&dfs(next))return true;if(incomplete)return false;}
  dead.insert(state.selected);return false;
 }
}
int main(int argc,char**argv){
 if(argc!=7)return 2;ifstream in(argv[1]),parts(argv[2]);int n;in>>n;if(n!=496)return 3;
 masks.resize(n);for(auto&m:masks){in>>m;int a=__builtin_ctz(m);uint32_t t=m&(m-1);edges.push_back({a,__builtin_ctz(t)});}
 int no;in>>no;if(no!=32)return 4;
 for(auto&rr:original){int m;in>>m;for(int j=0;j<m;j++){R r;in>>r.n;if(r.n<2||r.n>3)return 5;for(int k=0;k<r.n;k++)in>>r.e[k];rr.push_back(r);}}
 int count=stoi(argv[3]);budget=stoi(argv[4]);cap=stoull(argv[5]);double seconds=stod(argv[6]);
 auto start=chrono::steady_clock::now();uint64_t total=0,rejected=0,unknown=0,totalnodes=0;string line;bool timed=false;
 while(getline(parts,line)){
  if(chrono::duration<double>(chrono::steady_clock::now()-start).count()>seconds){timed=true;break;}
  istringstream is(line);vector<uint32_t>blocks(count);for(auto&b:blocks)is>>b;if(!is)return 6;
  uint32_t cover=0;array<int,32>color;
  for(int j=0;j<count;j++){if(cover&blocks[j])return 7;cover|=blocks[j];for(int i=0;i<32;i++)if(blocks[j]>>i&1)color[i]=j;}if(cover!=uint32_t(-1))return 8;
  array<bool,496>allowed;for(int e=0;e<496;e++)allowed[e]=color[edges[e].first]==color[edges[e].second];
  bool impossible=false;
  for(int o=0;o<32;o++){
   options[o].clear();for(auto&r:original[o]){bool ok=true;for(int k=0;k<r.n;k++)if(!allowed[r.e[k]])ok=false;if(ok)options[o].push_back(r);}
   if(options[o].empty())impossible=true;
  }
  total++;nodes=0;incomplete=false;dead.clear();bool sat=false;
  if(!impossible){State s;for(int i=0;i<32;i++)s.uf[i]=i;sat=dfs(s);}
  totalnodes+=nodes;
  if(sat){
   // Complete each prescribed component with arbitrary connecting edges.
   for(int e=0;e<496;e++)if(allowed[e]&&find(witness,edges[e].first)!=find(witness,edges[e].second))add(witness,e);
   cout<<"SAT partition "<<total<<" nodes "<<nodes<<" pairs "<<witness.selected.count()<<" cycles "<<witness.cycles<<endl;
   cout<<"blocks";for(auto b:blocks)cout<<' '<<b;cout<<endl;
   cout<<"pairs";for(int e=0;e<496;e++)if(witness.selected[e])cout<<' '<<masks[e];cout<<endl;return 0;
  }
  if(incomplete)unknown++;else rejected++;
  if(total%10000==0)cout<<"PROGRESS partitions "<<total<<" rejected "<<rejected<<" unknown "<<unknown<<" nodes "<<totalnodes<<endl;
 }
 cout<<((timed||unknown)?"INCOMPLETE":"COMPLETE")<<" partitions "<<total<<" rejected "<<rejected<<" unknown "<<unknown<<" nodes "<<totalnodes<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<endl;
 return 0;
}
