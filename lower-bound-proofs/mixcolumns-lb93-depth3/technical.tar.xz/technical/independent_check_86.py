"""Independent regeneration and exact integer checking of the new 86 bound.

Does not import the strengthened model or its cut-generation code.
The validity of its structural premises is proved in the accompanying notes
and checked by the boundary/weighted/partition verifiers.
"""
from itertools import combinations
from pathlib import Path
import json
from independent_check import rebuild
HERE=Path(__file__).resolve().parent

def new_rows(H,opts):
    ix={h:i for i,h in enumerate(H)}
    U={b:{h for i,rs in enumerate(opts) if i%8==b for r in rs for h in r} for b in (1,3,4)}
    rows=[]
    for b in (1,3,4):
        rows.append(([(ix[h],1) for h in sorted(U[b])],12))
        rows.append(([(ix[h],1) for h in sorted(U[b]) if h.bit_count()==2],6))
        rows.append(([(ix[h],1) for h in sorted(U[b]) if h.bit_count()>2],5))
        for side in (b-1,7):
            family=sum(1<<(8*j+side) for j in range(4))
            rows.append(([(ix[h],1) for h in sorted(U[b]) if h.bit_count()!=2 or h&~family],12))
    for a,b in combinations((1,3,4),2):rows.append(([(ix[h],1) for h in sorted(U[a]|U[b])],24))
    rows.append(([(ix[h],1) for h in sorted(U[1]|U[3]|U[4])],36))
    seen=set()
    for b in (1,3,4):
        families=([1<<(8*i+b) for i in range(4)],
                  [1<<(8*i+b-1) for i in range(4)],
                  [1<<(8*i+7) for i in range(4)])
        for pattern,rhs in ((3,115),(4,116)):
            aa=families[0 if pattern==3 else 1];cc=families[2];special={}
            for i in range(4):
                j=(i+1)%4
                for h,w in ((aa[i]|aa[j],9),(aa[j]|cc[i],8),(aa[i]|cc[i],1),
                            (aa[i]|cc[j],8),(cc[i]|cc[j],1),
                            (aa[i]|aa[j]|cc[i],2),(aa[j]|cc[i]|cc[j],8)):
                    special[h]=w if pattern==3 else 10-w
            assert set(special)<=U[b]
            weights={h:special.get(h,10) for h in U[b]}
            for mirror in (False,True):
                for swap in (False,True):
                    permutation={}
                    for f in range(3):
                        for r in range(4):
                            target_r=(4-r)%4 if mirror and f==0 else (5-r)%4 if mirror else r
                            target_f=3-f if swap and f else f
                            permutation[families[f][r]]=families[target_f][target_r]
                    terms=[]
                    for h,w in weights.items():
                        image=0;remaining=h
                        while remaining:
                            bit=remaining&-remaining;remaining-=bit;image|=permutation[bit]
                        assert image in U[b];terms.append((ix[image],w))
                    key=(tuple(sorted(terms)),rhs)
                    if key not in seen:
                        seen.add(key);rows.append((list(key[0]),rhs))
    assert len(rows)==43
    return rows

def check():
    rows,c,H,opts=rebuild();rows.extend(new_rows(H,opts))
    cert=json.loads((HERE/'certificate_86.json').read_text());D=cert['denominator']
    assert type(D) is int and D>0
    assert (len(rows),len(c))==(cert['rows'],cert['variables'])==(15169,61673)
    acc=[0]*len(c);raw=0;seen=set()
    for i,u in cert['u_nonzero']:
        assert type(i) is int and 0<=i<len(rows) and i not in seen
        assert type(u) is int and u>=0;seen.add(i)
        terms,b=rows[i];raw+=u*b
        for j,a in terms:acc[j]+=u*a
    repair=sum(max(0,a-D*w) for a,w in zip(acc,c));num=raw-repair
    assert raw==cert['raw_numerator'] and repair==cert['repair_numerator']
    assert num==cert['certified_numerator'] and num>53*D
    bound=32+(num+D-1)//D;assert bound==86==cert['gate_lower_bound']
    # Recheck the known97 positive control against every new valid inequality.
    control=json.loads((HERE/'control_97.json').read_text());signals=[1<<i for i in range(32)]
    depth=[0]*32
    for a,b in control['gates']:
        signals.append(signals[a]^signals[b]);depth.append(1+max(depth[a],depth[b]))
    assert len(control['gates'])==97 and max(depth)==3
    present=set(signals);p=[int(h in present) for h in H]+[0]*(len(c)-len(H));j=len(H)
    for rs in opts:
        k=next(k for k,r in enumerate(rs) if all(h in present for h in r));p[j+k]=1;j+=len(rs)
    assert all(sum(p[j]*a for j,a in terms)>=b for terms,b in rows)
    result={'status':'PASS','rows':len(rows),'variables':len(c),'certified_helper_numerator':num,
            'denominator':D,'rounding_repair_numerator':repair,'gate_lower_bound':bound,
            'known97_satisfies_all_rows':True}
    print(json.dumps(result,indent=2));return result

if __name__=='__main__':
    result=check();(HERE/'independent_86_checks.json').write_text(json.dumps(result,indent=2)+'\n')
