"""Compact active old and new inequalities without changing the exact dual."""
from pathlib import Path
from collections import defaultdict
import json,argparse
from independent_check import rebuild
from independent_check_86 import new_rows
from independent_check_local import additional_rows
from independent_check_consistent import consistency_rows
from independent_parent_rows import additional_rows as parent_rows
from independent_linked_rows import additional_rows as linked_rows
from independent_edge_tree_rows import additional_rows as edge_rows
HERE=Path(__file__).resolve().parent

def key(row):
    acc=defaultdict(int)
    for j,a in row[0]:acc[j]+=a
    return tuple(sorted((j,a) for j,a in acc.items() if a)),row[1]

def assemble(base,H,opts,info):
    rows=list(base)+additional_rows(H,opts,info)
    rows.append(([(j,1) for j,h in enumerate(H) if h.bit_count()==2],info['pair_lower_bound']))
    starts={'consistency_cuts':len(rows)};rows+=consistency_rows(H,opts,info['consistency_cuts'])
    starts['parent_forest_cuts']=len(rows);starts['parent_tree_cuts']=len(rows)+len(info.get('parent_forest_cuts',[]))
    rr,_=parent_rows(H,opts,info,False);rows+=rr
    starts['linked_cluster_cuts']=len(rows);rr,_=linked_rows(H,opts,info,False);rows+=rr
    starts['parent_edge_tree_cuts']=len(rows);rr,_=edge_rows(H,opts,info,False);rows+=rr
    return rows,starts

def export(source,target):
    old=json.loads(source.read_text());base,c,H,opts=rebuild();base+=new_rows(H,opts);rr,starts=assemble(base,H,opts,old)
    assert len(rr)==old['rows'];u=dict(old['u_nonzero']);active={key(rr[i]) for i,v in u.items() if v}
    info={'pair_lower_bound':old['pair_lower_bound'],'w7_cuts':[],'w5_projection_cuts':[]}
    for kind in ('w7_cuts','w5_projection_cuts'):
        for cut in old[kind]:
            probe={'w7_cuts':[],'w5_projection_cuts':[]};probe[kind]=[cut]
            if any(key(row) in active for row in additional_rows(H,opts,probe)):info[kind].append({'minimum':cut['minimum'],'prices':cut['prices']})
    for kind,start in starts.items():info[kind]=[cut for i,cut in enumerate(old.get(kind,[])) if u.get(start+i,0)]
    rows,_=assemble(base,H,opts,info);ix={key(row):i for i,row in enumerate(rows)};uu=[0]*len(rows)
    for i,v in u.items():
        if v:uu[ix[key(rr[i])]]+=v
    D=old['denominator'];acc=[0]*len(c);raw=0
    for v,(ts,b) in zip(uu,rows):
        raw+=v*b
        for j,a in ts:acc[j]+=v*a
    repair=sum(max(0,a-D*w) for a,w in zip(acc,c));num=raw-repair;bound=32+(num+D-1)//D
    assert (raw,repair,num)==(old['raw_numerator'],old['repair_numerator'],old['certified_numerator'])
    cert=dict(info,model='complete depth-three model with linked cluster and edge-specific parent-tree prices',base_rows=len(base),rows=len(rows),variables=len(c),
              denominator=D,u_nonzero=[[i,v] for i,v in enumerate(uu) if v],raw_numerator=raw,repair_numerator=repair,certified_numerator=num,gate_lower_bound=bound)
    target.write_text(json.dumps(cert,separators=(',',':'))+'\n')
    print(json.dumps({'file':str(target),'rows':len(rows),'gate_lower_bound_unverified':bound,'helper_numerator':num,'denominator':D,'cuts':{k:len(v) for k,v in info.items() if isinstance(v,list)}},indent=2))
    return cert

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('source',type=Path);ap.add_argument('target',type=Path);a=ap.parse_args();export(a.source,a.target)
