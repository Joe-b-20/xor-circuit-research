"""Rebuild and exhaustively verify the rational certificate D3({3,4})>=32.

Python standard library plus a C++17 compiler; no optimization solver.
The certificate prices are integers in tenths. The tiny C++ enumerator
checks all four-output recipes, with only nonnegative-cost pruning.
"""
from itertools import combinations,product
from pathlib import Path
import json,re,subprocess,tempfile
from verify_cluster_results import aes_rows
HERE=Path(__file__).resolve().parent
PRICES=(9,8,1,8,1,2,8)
SCALE=10

def shared_prices():
    A=[1<<(8*i+3) for i in range(4)]
    C=[1<<(8*i+7) for i in range(4)]
    prices={}
    for i in range(4):
        masks=(A[i]|A[(i+1)%4],A[(i+1)%4]|C[i],A[i]|C[i],
               A[i]|C[(i+1)%4],C[i]|C[(i+1)%4],
               A[i]|A[(i+1)%4]|C[i],A[(i+1)%4]|C[i]|C[(i+1)%4])
        for h,w in zip(masks,PRICES):prices[h]=w
    assert len(prices)==28
    return prices

def recipes(bit):
    # Independently generate every 3+4 decomposition and every construction
    # of its two parents. A weight-seven output cannot have cancellation.
    def constructions(h):
        bs=[1<<i for i in range(32) if h>>i&1]
        if len(bs)==3:return [{h,h^a} for a in bs]
        assert len(bs)==4
        return [{h,bs[0]|bs[i],h^(bs[0]|bs[i])} for i in (1,2,3)]
    options=[]
    for row,o in enumerate(aes_rows()):
        if row%8!=bit:continue
        assert o.bit_count()==7
        bs=[1<<i for i in range(32) if o>>i&1]
        rs=set()
        for triple in combinations(bs,3):
            t=sum(triple);q=o^t
            for a,b in product(constructions(t),constructions(q)):
                rs.add(tuple(sorted(a|b)))
        assert len(rs)==315 and all(len(r)==5 for r in rs)
        options.append(sorted(rs))
    assert len(options)==4
    return options

def data(bit):
    options=recipes(bit);H=sorted({h for rs in options for r in rs for h in r})
    index={h:i for i,h in enumerate(H)};prices=shared_prices()
    weights=[(prices[h] if bit==3 else SCALE-prices[h]) if h in prices else SCALE for h in H]
    return H,weights,[[tuple(index[h] for h in r) for r in rs] for rs in options]

def write_data(path,weights,options):
    with path.open('w') as f:
        print(len(weights),file=f);print(*weights,file=f)
        for rs in options:
            print(len(rs),file=f)
            for r in rs:print(*r,file=f)

def check():
    H3,_,_=data(3);H4,_,_=data(4)
    assert set(H3)&set(H4)==set(shared_prices())
    results=[]
    with tempfile.TemporaryDirectory(prefix='aes-weighted-proof-') as temp:
        temp=Path(temp);exe=temp/'enumerator'
        subprocess.run(['g++','-O3','-std=c++17',str(HERE/'exact_weighted_enum.cpp'),'-o',str(exe)],check=True)
        for bit,expected in ((3,115),(4,116)):
            H,weights,options=data(bit);inp=temp/f'cluster{bit}.txt'
            write_data(inp,weights,options)
            out=subprocess.check_output([str(exe),str(inp),'120'],text=True)
            match=re.search(r'^COMPLETE minimum (\d+) nodes (\d+) leaves (\d+) seconds (\S+)',out,re.M)
            assert match,'Enumerator did not complete: no lower bound certified.'
            value=int(match.group(1));assert value==expected
            ids=list(map(int,re.search(r'^recipes (.*)',out,re.M).group(1).split()))
            assert len(ids)==20
            for i in range(4):assert tuple(ids[5*i:5*i+5]) in options[i]
            helper_ids=set(ids);assert sum(weights[i] for i in helper_ids)==value
            results.append({'cluster':bit,'weighted_helper_minimum':value,'denominator':SCALE,
                            'nodes':int(match.group(2)),'last_output_candidates':int(match.group(3)),
                            'attaining_helper_masks':[H[i] for i in sorted(helper_ids)]})
    numerator=8*SCALE+sum(r['weighted_helper_minimum'] for r in results)
    assert numerator==311 and (numerator+SCALE-1)//SCALE==32
    result={'status':'PASS','common_helper_count':28,'price_numerators':PRICES,
            'denominator':SCALE,'local_enumerations':results,
            'joint_gate_lower_bound_rational':[numerator,SCALE],
            'joint_gate_lower_bound_integer':32,
            'qualification':'The rational bound is verified by complete enumeration, not by an optimizer status.'}
    print(json.dumps(result,indent=2));return result

if __name__=='__main__':
    result=check();(HERE/'weighted_cluster_checks.json').write_text(json.dumps(result,indent=2)+'\n')
