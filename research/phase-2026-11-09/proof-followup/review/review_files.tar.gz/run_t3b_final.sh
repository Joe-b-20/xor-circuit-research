#!/bin/bash
# own exhaustive search on the pass-2 (results_final) newly excluded skeletons: 4 shards in parallel, nice 10, 8 GB each.
cd ~/xs-campaigns/2026-11-10-proof/review
ulimit -v 8000000
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
mkdir -p t3b_final
for s in 0 1 2 3; do
  nice -n 10 timeout 1800 python3 t3b_final.py $s 4 300 > t3b_final/shard$s.log 2>&1 &
done
wait
echo ALLDONE > t3b_final/done.flag
