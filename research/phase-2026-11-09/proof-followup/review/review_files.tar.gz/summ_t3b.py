#!/usr/bin/env python3
"""summarize t3b logs: per leaf, per skeleton: own result, nodes, cpu; pilot status."""
import json, glob, sys
from pathlib import Path
d = Path(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).parent / 't3b')
for fn in sorted(glob.glob(str(d / 'leaf_*.log'))):
    lines = open(fn).read().splitlines()
    print('==', Path(fn).name, lines[0][:160] if lines else '(empty)')
    for l in lines[1:]:
        if l.startswith('{'):
            x = json.loads(l)
            extra = ''
            if x['own'] == 'FOUND': extra = ' CHECK=' + str(x.get('check'))
            print('   ', x['own'], 'nodes', x['nodes'], 'cpu', x['cpu'], 'kept', x['kept_roles'], 'pilot', x['pilot_status'], x['pilot_survivors'], x['roles'], extra)
        else:
            print('   ', l[:300])
