#!/usr/bin/env python3
"""Unguided cross-check of the planted test: for planted objects with a small constrained part, run the pilot's step G
(current file) WITHOUT a guide, store every survivor (cap 200,000, 30 s), and check that the object's constrained part
appears among them under some rotation (only when the run is complete, i.e. not capped / timed out)."""
import sys, json, time
from collections import Counter
import t3c_planted as T
recs = [json.loads(l) for l in open(sys.argv[1])]
lim = int(sys.argv[2]) if len(sys.argv) > 2 else 40
st = Counter(); n = 0
for r in recs:
    if n >= lim: break
    obj = r['obj']; status = ['F'] * r['a'] + ['B'] * (3 - r['a'] - r['d']) + ['D'] * r['d']
    skel = dict(roles=r['roles'], status=status, W=r['W'])
    pl = T.enum_cur.plan(skel)
    nroles = sum(len(seg['order']) for seg in pl['segments']) + len(pl['riders2'])
    if not pl['constrained'] or nroles > 4: continue
    n += 1
    cap = 200_000
    res = T.enum_cur.run_skeleton(T.PG, pl, cap, cap, time.process_time() + 30)
    if res['mode'] != 'single':
        st['inconclusive (segments: product stops at its first combination)'] += 1; continue
    if res['status'] != 'done' or res['survivors'] >= cap or len(res['snaps']) < res['survivors']:
        st['inconclusive (' + res['status'] + ')'] += 1; continue
    hit = False
    for j in range(4):
        o2 = T.rot_obj(obj, j); cs, keep = T.constrained_part(o2, pl)
        if any(T.match(sn, o2, cs, keep) for sn in res['snaps']): hit = True; break
    st['found' if hit else 'MISSED'] += 1
    st['survivors_total'] += res['survivors']
print(dict(st))
