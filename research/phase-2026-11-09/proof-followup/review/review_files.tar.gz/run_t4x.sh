#!/bin/bash
# Task 4 batch: 11 leaves excluded by "step S (LP)", sequential, one process.
cd ~/xs-campaigns/2026-11-10-proof/review
ulimit -v 8000000
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
mkdir -p t4
{
nice -n 10 timeout 600 python3 t4_exact.py "(13, 6, 0, 'Mt', 3, 1)" 0 0
nice -n 10 timeout 600 python3 t4_exact.py "(14, 5, 0, 'Mt', 3, 1)" 0 0
nice -n 10 timeout 600 python3 t4_exact.py "(16, 1, 0, 'Mt', 3, 2)" 0 0
nice -n 10 timeout 600 python3 t4_exact.py "(16, 2, 4, 'Mt', 3, 1)" 0 0
nice -n 10 timeout 600 python3 t4_exact.py "(12, 7, 0, 'Mt', 3, 1)" 2 0
nice -n 10 timeout 600 python3 t4_exact.py "(13, 6, 0, 'Mt', 3, 1)" 1 0
nice -n 10 timeout 600 python3 t4_exact.py "(15, 3, 1, 'Mt', 3, 1)" 0 0
nice -n 10 timeout 600 python3 t4_exact.py "(13, 5, 0, 'Mt', 3, 2)" 0 1
nice -n 10 timeout 600 python3 t4_exact.py "(15, 4, 3, 'Mt', 3, 1)" 1 1
nice -n 10 timeout 600 python3 t4_exact.py "(12, 5, 3, 'Mt', 3, 3)" 0 1
nice -n 10 timeout 600 python3 t4_exact.py "(12, 6, 4, 'Mt', 3, 2)" 2 1
nice -n 10 timeout 600 python3 t4_exact.py "(15, 4, 0, 'Mt', 3, 1)" 1 0
} > t4/t4_exact.jsonl 2> t4/t4_exact_err.log
echo ALLDONE > t4/done_exact.flag
