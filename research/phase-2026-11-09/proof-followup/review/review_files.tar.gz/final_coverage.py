#!/usr/bin/env python3
"""Coverage of the pilot's pass-2 results (results_final) by the reviewer's independent checks:
 - every EXCLUDED-by-step-G leaf: each skeleton of its accepted list and each MILP-killed skeleton is one the reviewer's own
   exhaustive search found NONE for (t3b*, t3b_final, t_milp, pilotskel NONE);
 - skeleton completeness (t4b_skeletons.py) on every EXCLUDED leaf of results_final (subprocess);
 - witness re-verification (rcheck R1-R7, own LP, own MILP) for results_final witnesses."""
import json, glob, os, subprocess, sys
from collections import Counter
from pathlib import Path
P = Path.home() / 'xs-campaigns/2026-11-10-proof'; H = Path(__file__).resolve().parent
none = set()
for f in glob.glob(str(H / 't3b/leaf_*.log')) + glob.glob(str(H / 't3b_norot/leaf_*.log')):
    lines = open(f).read().splitlines(); hdr = lines[0].split()
    a = int(hdr[hdr.index('A') + 1]); d = int(hdr[hdr.index('qD') + 1])
    for l in lines[1:]:
        if l.startswith('{'):
            x = json.loads(l)
            if x['own'] == 'NONE': none.add((a, d, json.dumps(x['roles'])))
for f in glob.glob(str(H / 't3b_final/shard*.jsonl')):
    for l in open(f):
        x = json.loads(l)
        if x['own'] == 'NONE': none.add((x['a'], x['d'], json.dumps(x['roles'])))
for l in open(H / 't3c/pilotskel.jsonl'):
    x = json.loads(l)
    if x['own'] == 'NONE': none.add((x['a'], x['d'], json.dumps(x['roles'])))
for l in open(H / 't_milp.log'):
    x = json.loads(l)
    lf = x['leaf']; a = int(lf.split('_a')[1][0]); d = int(lf.split('_d')[1][0])
    if x['own_geometry'] == 'NONE': none.add((a, d, json.dumps(x['roles'])))
st = Counter(); uncovered = []; milp_lb = []
excl = []
for f in sorted(glob.glob(str(P / 'pilot/results_final/leaf_*.json'))):
    D = json.load(open(f)); n = os.path.basename(f)
    if D.get('result') != 'EXCLUDED': continue
    excl.append(f)
    st[D.get('excluded_by')] += 1
    if D.get('excluded_by') == 'step S (LP)': continue
    for e in D['skeleton_list']:
        k = (D['A'], D['qD'], json.dumps(e['roles']))
        if k not in none: uncovered.append((n, e['roles']))
    for ks in D.get('skeletons_milp_killed') or []:
        k = (D['A'], D['qD'], json.dumps(ks))
        if k not in none: milp_lb.append((n, ks))
print('results_final EXCLUDED leaves by class', dict(st))
print('accepted skeletons of step-G / LP+MILP leaves NOT covered by an own NONE:', len(uncovered), uncovered[:5])
print('MILP-killed skeletons of excluded leaves without own geometric NONE (MILP load-bearing):', len(milp_lb), milp_lb[:5])
# skeleton completeness on every EXCLUDED leaf of results_final
bad = []; certs = [0, 0]; nlv = 0
for f in excl:
    p = subprocess.run([sys.executable, str(H / 't4b_skeletons.py'), f], capture_output=True, text=True, timeout=900)
    lines = p.stdout.strip().splitlines()
    if len(lines) < 2: bad.append((f, 'error', p.stderr[-300:])); continue
    c = json.loads(lines[0]); s = json.loads(lines[1]); nlv += 1
    certs[0] += c['lp_infeasible_decisions']; certs[1] += c['exactly_certified']
    if s['n_missed'] or s['own_skeletons'] != s['pilot_lp_skeletons'] or s['extra_in_pilot']: bad.append((os.path.basename(f), s))
print('skeleton completeness on', nlv, 'EXCLUDED leaves of results_final: discrepancies', len(bad), bad[:5], 'LP decisions', certs[0], 'exactly certified', certs[1])
