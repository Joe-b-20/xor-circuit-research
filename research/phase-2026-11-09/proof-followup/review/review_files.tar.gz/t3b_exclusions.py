#!/usr/bin/env python3
"""Task 3(b): for leaves the pilot marks EXCLUDED by step G, re-derive with the reviewer's own exhaustive search
(rsearch.Search, mode 'exclude') that no skeleton of the leaf's accepted list (after the pilot's MILP filter) has a
realization satisfying R1-R7.  usage: t3b_exclusions.py leaf_file.json [node_cap] [time_cap_s] [norot]"""
import json, sys, time
from pathlib import Path
import rgeo, rsearch, rcheck

fn = sys.argv[1]
node_cap = int(float(sys.argv[2])) if len(sys.argv) > 2 else None
time_cap = float(sys.argv[3]) if len(sys.argv) > 3 else None
norot = len(sys.argv) > 4 and sys.argv[4] == 'norot'
D = json.load(open(fn))
G = rgeo.Geo()
status = ['F'] * D['A'] + ['B'] * (3 - D['A'] - D['qD']) + ['D'] * D['qD']
print(Path(fn).name, D['key'], 'A', D['A'], 'qD', D['qD'], 'pilot', D['result'], D.get('excluded_by'), 'norot' if norot else 'rot', flush=True)
summary = []
for e in D['skeleton_list']:
    roles = [(r, tuple(L)) for r, L in e['roles']]
    t0 = time.process_time()
    S = rsearch.Search(G, roles, status, mode='exclude', use_rot=not norot, node_cap=node_cap, time_cap=time_cap).run()
    res = 'FOUND' if S.found else ('ABORTED' if S.aborted else 'NONE')
    line = dict(roles=e['roles'], pilot_status=e.get('status'), pilot_survivors=e.get('survivors'), own=res, nodes=S.nodes,
                kept_roles=len(S.roles), order=[(k, S.roles[i], s) for k, i, s, _ in S.order], cpu=round(time.process_time() - t0, 1))
    if S.found:
        obj = S.found[0]
        line['found'] = obj
        line['check'] = rcheck.check(obj, G)
    print(json.dumps(line), flush=True)
    summary.append(res)
print('SUMMARY', Path(fn).name, summary, flush=True)
