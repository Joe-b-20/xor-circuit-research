#!/usr/bin/env python3
"""Task 3(b, surviving part) and 3(c, second set): realize skeletons from the pilot's accepted lists with the reviewer's
OWN search (rsearch, mode 'full': every helper explicit, riders and free components included, no rotation), verify the
complete object (rcheck R1-R7 with the leaf's a, d; own LP R8 and own MILP on the leaf's rows), then plant it into the
pilot's step G (current file and pass-1 variant), guided, and check that it is reported.
usage: t3c2_pilotskel.py out.jsonl time_cap_per_skeleton max_skeletons seed"""
import sys, json, glob, random, time
from collections import Counter, defaultdict
from pathlib import Path
import t3c_planted as T
import rgeo, rcheck, rsearch

outp = sys.argv[1]; tcap = float(sys.argv[2]); maxsk = int(sys.argv[3]); rng = random.Random(int(sys.argv[4]))
G = T.G
by = defaultdict(list)
for fn in sorted(glob.glob(str(T.PILOT / 'results/leaf_*.json'))):
    D = json.load(open(fn))
    if not (str(D['result']).startswith('SURVIVING') or D['result'] == 'UNRESOLVED'): continue
    for e in D['skeleton_list']:
        by[(D['A'], D['qD'], tuple((r, tuple(L)) for r, L in e['roles']))].append((tuple(D['key']), e.get('status'), e.get('survivors')))
items = list(by.items()); rng.shuffle(items)
# put skeletons of SURVIVING leaves first (so that at least two surviving leaves get an own realization)
items.sort(key=lambda kv: 0 if any(s and s > 0 for _, _, s in kv[1]) else 1)
stats = Counter(); out = open(outp, 'w'); t0 = time.time()
for (a, d, roles), leaves in items[:maxsk]:
    status = ['F'] * a + ['B'] * (3 - a - d) + ['D'] * d
    S = rsearch.Search(G, list(roles), status, mode='full', use_rot=False, time_cap=tcap, max_found=1)
    for k in list(S.rootcache): pass
    S.run()
    rec = dict(a=a, d=d, roles=[[r, list(L)] for r, L in roles], leaves=[list(x) for x in leaves[:6]], nodes=S.nodes, aborted=S.aborted)
    if not S.found:
        rec['own'] = 'ABORTED' if S.aborted else 'NONE'; stats['own_' + rec['own']] += 1
        out.write(json.dumps(rec) + '\n'); out.flush(); continue
    obj = S.found[0]
    for s in range(3):
        if obj['labels'][s]['value'] is None:
            v = 6
            while v in [l['value'] for l in obj['labels']]: v += 6
            obj['labels'][s]['value'] = v if bin(v).count('1') % 2 == 0 else v + 1 + 1
    chk = rcheck.check(obj, G, a, d)
    rec['own'] = 'FOUND'; rec['check'] = {k: v for k, v in chk.items()}; rec['obj'] = obj
    stats['own_FOUND'] += 1
    if not chk['all_R1_R7']: stats['own_found_but_check_failed'] += 1; out.write(json.dumps(rec) + '\n'); continue
    cnt = dict(rcheck.counts_of(obj))
    lpres = {}
    for key, st, sv in leaves[:3]:
        rows = rcheck.Rows(key, a, d)
        lpres[str(key)] = dict(lp=rows.lp(cnt, True), milp=rows.milp(cnt, 30.0), pilot_status=st, pilot_survivors=sv)
    rec['rows'] = lpres
    skel = dict(roles=[[r, list(L)] for r, L in roles], status=status, W=[sum(r for r, L in roles if s in L) for s in range(3)])
    for name, mod in (('cur', T.enum_cur), ('p1', T.enum_p1h)):
        try:
            pl, hit, rj = T.pilot_step_G(mod, obj, skel)
            rec[name] = dict(hit=hit, runs=rj, segments=len(pl['segments']), riders2=len(pl['riders2']))
            stats[f'{name}_hit' if hit else f'{name}_MISS'] += 1
        except Exception as ex:
            rec[name] = dict(error=repr(ex)[:300]); stats[f'{name}_ERROR'] += 1
    out.write(json.dumps(rec) + '\n'); out.flush()
    print(len(rec['roles']), rec['own'], dict(stats), f'{time.time()-t0:.0f}s', flush=True)
print('FINAL', dict(stats), f'{time.time()-t0:.0f}s')
