#!/usr/bin/env python3
"""List the distinct skeletons (roles, a, d) of leaves that results_final marks EXCLUDED by step G but that were not
EXCLUDED in results/ (pass 1), excluding skeletons already checked by the reviewer (t3b logs, t_milp, pilotskel NONE).
Writes final_newskels.json: [(a, d, roles, [leaves], pilot_nodes)]."""
import json, glob, os
from pathlib import Path
from collections import defaultdict
P = Path.home() / 'xs-campaigns/2026-11-10-proof'; H = Path(__file__).resolve().parent
old = {os.path.basename(f): json.load(open(f)).get('result') for f in glob.glob(str(P / 'pilot/results/leaf_*.json'))}
checked = set()
for f in glob.glob(str(H / 't3b*/leaf_*.log')):
    lines = open(f).read().splitlines()
    if not lines: continue
    hdr = lines[0].split()
    a = int(hdr[hdr.index('A') + 1]); d = int(hdr[hdr.index('qD') + 1])
    for l in lines[1:]:
        if l.startswith('{'):
            x = json.loads(l)
            if x['own'] == 'NONE': checked.add((a, d, json.dumps(x['roles'])))
for l in open(H / 't3c/pilotskel.jsonl'):
    x = json.loads(l)
    if x['own'] == 'NONE': checked.add((x['a'], x['d'], json.dumps(x['roles'])))
new = defaultdict(list); nodes = {}
for f in sorted(glob.glob(str(P / 'pilot/results_final/leaf_*.json'))):
    D = json.load(open(f)); n = os.path.basename(f)
    if D.get('excluded_by') != 'step G (geometry)' or old.get(n) == 'EXCLUDED': continue
    for e in D['skeleton_list']:
        k = (D['A'], D['qD'], json.dumps(e['roles']))
        new[k].append(n)
        nodes[k] = (e.get('geo_stats') or {}).get('nodes', e.get('nodes'))
todo = [(a, d, json.loads(r), lv, nodes[(a, d, r)]) for (a, d, r), lv in new.items() if (a, d, r) not in checked]
done = [(a, d, json.loads(r), lv) for (a, d, r), lv in new.items() if (a, d, r) in checked]
json.dump(dict(todo=todo, already=done), open(H / 'final_newskels.json', 'w'))
print('distinct skeletons in newly excluded leaves', len(new), 'already checked NONE by reviewer', len(done), 'to do', len(todo))
for t in sorted(todo, key=lambda t: (t[4] or 0)): print(t[0], t[1], t[4], len(t[3]), t[2])
