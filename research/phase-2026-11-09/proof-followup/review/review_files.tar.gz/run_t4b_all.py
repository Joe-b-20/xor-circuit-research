#!/usr/bin/env python3
"""run t4b_skeletons.py on every leaf with result EXCLUDED by step G, by step S (LP + MILP), and on the SURVIVING leaves."""
import json, glob, subprocess, sys
from pathlib import Path
RES = Path.home() / 'xs-campaigns/2026-11-10-proof/pilot/results'
HERE = Path(__file__).resolve().parent
out = open(HERE / 't4/t4b_all.jsonl', 'w')
for fn in sorted(glob.glob(str(RES / 'leaf_*.json'))):
    D = json.load(open(fn))
    if D.get('excluded_by') == 'step S (LP)': continue
    p = subprocess.run([sys.executable, str(HERE / 't4b_skeletons.py'), fn], capture_output=True, text=True, timeout=900)
    lines = p.stdout.strip().splitlines()
    out.write((lines[0] + '\n' + lines[-1] + '\n') if len(lines) >= 2 else json.dumps(dict(leaf=fn, error=p.stderr[-800:])) + '\n'); out.flush()
