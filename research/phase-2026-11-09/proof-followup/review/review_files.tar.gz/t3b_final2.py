#!/usr/bin/env python3
"""Task 3(b) on the pilot's pass-2 results (results_final): own exhaustive search (rsearch, mode 'exclude', rotation on)
on every distinct skeleton of the leaves newly EXCLUDED by step G that the reviewer had not yet checked.
usage: t3b_final.py shard nshards time_cap"""
import sys, json, time
from pathlib import Path
import rgeo, rsearch
H = Path(__file__).resolve().parent
shard, nsh, tcap = int(sys.argv[1]), int(sys.argv[2]), float(sys.argv[3])
todo = json.load(open(H / 'final_newskels2.json'))
todo.sort(key=lambda t: -(t[4] or 0))
G = rgeo.Geo()
out = open(H / f't3b_final/new2_shard{shard}.jsonl', 'w')
for j, (a, d, roles, leaves, pn) in enumerate(todo):
    if j % nsh != shard: continue
    status = ['F'] * a + ['B'] * (3 - a - d) + ['D'] * d
    t0 = time.process_time()
    S = rsearch.Search(G, [(r, tuple(L)) for r, L in roles], status, mode='exclude', use_rot=True, time_cap=tcap).run()
    res = 'FOUND' if S.found else ('ABORTED' if S.aborted else 'NONE')
    out.write(json.dumps(dict(a=a, d=d, roles=roles, leaves=leaves, pilot_nodes=pn, own=res, nodes=S.nodes, cpu=round(time.process_time() - t0, 1),
                              found=S.found[:1])) + '\n'); out.flush()
