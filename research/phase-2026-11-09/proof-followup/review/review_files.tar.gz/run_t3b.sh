#!/bin/bash
# Task 3(b) batch: own exhaustive search on step-G-excluded leaves, 4 in parallel, nice 10, 8 GB virtual each.
cd ~/xs-campaigns/2026-11-10-proof/review
ulimit -v 8000000
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
LEAVES="leaf_10_9_0_3_a2_d0 leaf_15_2_2_2_a1_d0 leaf_15_3_0_2_a0_d1 leaf_16_3_0_1_a0_d1 leaf_16_3_1_1_a0_d1 leaf_16_2_0_2_a0_d1 leaf_15_1_1_3_a2_d0 leaf_16_0_0_3_a0_d0 leaf_16_0_1_3_a2_d0 leaf_16_0_0_3_a1_d0 leaf_15_4_2_1_a2_d0 leaf_15_1_1_3_a1_d0"
for L in $LEAVES; do echo $L; done | xargs -P 4 -I{} sh -c 'nice -n 10 timeout 1500 python3 t3b_exclusions.py ../pilot/results/{}.json 3e7 240 > t3b/{}.log 2>&1'
echo ALLDONE > t3b/done.flag
