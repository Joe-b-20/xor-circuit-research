#!/usr/bin/env python3
"""Task 3(a): re-verify every stored witness of the pilot's results against R1-R7 (own code), R8 (own LP, exact count
rows, checker matrix) and the MILP status (own MILP, no upper bounds)."""
import json, glob, sys
from collections import Counter
from pathlib import Path
import rgeo, rcheck

RES = Path.home() / 'xs-campaigns/2026-11-10-proof/pilot/results_final'
G = rgeo.Geo(with_ranks=False)
tot = Counter(); bad = []; lines = []
for fn in sorted(glob.glob(str(RES / 'leaf_*.json'))):
    D = json.load(open(fn))
    ws = D.get('witnesses') or []
    if not ws: continue
    key, a, d = D['key'], D['A'], D['qD']
    rows = rcheck.Rows(key, a, d)
    for w in ws:
        obj = w['object']
        tot['witnesses'] += 1
        if obj.get('incomplete'):
            tot['incomplete'] += 1; bad.append((fn, 'incomplete object')); continue
        c = rcheck.check(obj, G, a, d)
        cnt = dict(rcheck.counts_of(obj))
        lp = rows.lp(cnt, True)
        ms, viol = rows.milp(cnt)
        pm = (w.get('milp') or {}).get('status')
        tot['R1-R7 ok' if c['all_R1_R7'] else 'R1-R7 FAIL'] += 1
        tot[f'lp status {lp}'] += 1
        tot[f'milp own {ms} pilot {pm}'] += 1
        if not c['all_R1_R7'] or lp != 0:
            bad.append((Path(fn).name, {k: v for k, v in c.items()}, lp))
        lines.append(f"{Path(fn).name} skel={w['skeleton']} counts={cnt} R1-7={c['all_R1_R7']} |F|={c['R7_size']} LP={lp} MILP(own)={ms} viol={viol} MILP(pilot)={pm}")
print('\n'.join(lines))
print(dict(tot))
print('bad', bad)
