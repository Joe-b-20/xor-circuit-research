#!/usr/bin/env python3
"""Step-S completeness for ANY leaf: the reviewer's own list of complete skeletons (R4, R5, R6, (B-1), exact LP not
status 2), built from the count DFS of t4_stepS (count vectors) and an own label-set enumeration per count vector,
canonicalized under status-preserving slot permutations (own code); compared with the pilot's skeleton_list plus
skeletons_milp_killed.  Also: exact Farkas certificates for every LP 'status 2' decision of the count DFS.
usage: t4b_skeletons.py leaf.json"""
import sys, json, itertools, time
from collections import Counter
from pathlib import Path
import rcheck
sys.argv_saved = list(sys.argv)
fn = sys.argv[1]
D = json.load(open(fn))
key, a, d = tuple(D['key']), D['A'], D['qD']
sys.argv = [sys.argv[0], repr(key), str(a), str(d)]
import t4_exact as X          # runs the count DFS + certificates for this leaf at import (prints one JSON line)
status = ['F'] * a + ['B'] * (3 - a - d) + ['D'] * d
F = {s for s in range(3) if status[s] == 'F'}; Dk = {s for s in range(3) if status[s] == 'D'}


def canon(roles):
    best = None
    for p in itertools.permutations(range(3)):
        if any(status[p[s]] != status[s] for s in range(3)): continue
        img = tuple(sorted((r, tuple(sorted(p[s] for s in L))) for r, L in roles))
        if best is None or img < best: best = img
    return best


def skeletons_of(c):
    helpers = sorted([(r, u) for (r, u), v in c.items() for _ in range(v)], key=lambda x: (-x[0], -x[1]))
    sets = {u: [tuple(L) for L in itertools.combinations(range(3), u)] for u in (1, 2, 3)}
    out = set()

    def rec(i, chosen):
        if i == len(helpers):
            for s in range(3):
                full = sum(1 for r, L in chosen if r == 3 and s in L); anch = any(r >= 1 and s in L for r, L in chosen)
                if status[s] == 'F' and full != 1: return
                if status[s] != 'F' and full: return
                if status[s] == 'B' and not anch: return
                if status[s] == 'D' and anch: return
            W = [sum(r for r, L in chosen if s in L) for s in range(3)]
            if max(W) > 7: return
            out.add(canon(chosen)); return
        r, u = helpers[i]
        for L in sets[u]:
            if r == 3 and not set(L) <= F: continue
            if r >= 1 and set(L) & Dk: continue
            if any(len(set(L) & set(L2)) >= 2 for _, L2 in chosen): continue
            if i > 0 and helpers[i - 1] == (r, u) and L < chosen[-1][1]: continue
            rec(i + 1, chosen + [(r, L)])
    rec(0, [])
    return out


mine = set()
for c in X.feas:
    mine |= skeletons_of(c)
pilot = {tuple((r, tuple(L)) for r, L in e['roles']) for e in D['skeleton_list']}
pilot_k = {tuple((r, tuple(L)) for r, L in ks) for ks in (D.get('skeletons_milp_killed') or [])}
print(json.dumps(dict(leaf=Path(fn).name, result=D['result'], excluded_by=D.get('excluded_by'), own_skeletons=len(mine),
                      pilot_lp_skeletons=D['skeletons_lp'], pilot_listed=len(pilot), pilot_milp_killed=len(pilot_k),
                      missed_by_pilot=[list(map(list, s)) for s in sorted(mine - pilot - pilot_k)][:5], n_missed=len(mine - pilot - pilot_k),
                      extra_in_pilot=len((pilot | pilot_k) - mine))), flush=True)
