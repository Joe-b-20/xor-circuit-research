#!/usr/bin/env python3
"""R8-int check: for every EXCLUDED leaf where the pilot's MILP (status 2) removed skeletons, recompute (own MILP, no
upper bounds, 120 s) the status of each removed skeleton's counts, and run the reviewer's own exhaustive geometric search
on it (mode 'exclude'): if no realization exists, the MILP decision is not load-bearing for that skeleton."""
import json, glob, time
from collections import Counter
from pathlib import Path
import rgeo, rcheck, rsearch

RES = Path.home() / 'xs-campaigns/2026-11-10-proof/pilot/results'
G = rgeo.Geo()
for fn in sorted(glob.glob(str(RES / 'leaf_*.json'))):
    D = json.load(open(fn))
    if D['result'] != 'EXCLUDED' or not D.get('skeletons_milp_killed'): continue
    key, a, d = D['key'], D['A'], D['qD']
    rows = rcheck.Rows(key, a, d)
    status = ['F'] * a + ['B'] * (3 - a - d) + ['D'] * d
    for roles in D['skeletons_milp_killed']:
        cnt = Counter((r, len(L)) for r, L in roles)
        lp = rows.lp(dict(cnt), True); ms = rows.milp(dict(cnt), 120.0)
        t0 = time.process_time()
        S = rsearch.Search(G, [(r, tuple(L)) for r, L in roles], status, mode='exclude', use_rot=True, time_cap=120).run()
        geo = 'FOUND' if S.found else ('ABORTED' if S.aborted else 'NONE')
        print(json.dumps(dict(leaf=Path(fn).name, excluded_by=D.get('excluded_by'), roles=roles, counts={f'{r},{u}': v for (r, u), v in cnt.items()},
                              own_lp=lp, own_milp=ms, own_geometry=geo, nodes=S.nodes, cpu=round(time.process_time() - t0, 1))), flush=True)
