#!/bin/bash
# Task 3(b) second batch: the two A=2 15-skeleton groups, and two no-rotation re-runs.
cd ~/xs-campaigns/2026-11-10-proof/review
ulimit -v 8000000
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
mkdir -p t3b_norot
nice -n 10 timeout 900 python3 t3b_exclusions.py ../pilot/results/leaf_15_4_3_1_a2_d0.json 3e7 120 > t3b/leaf_15_4_3_1_a2_d0.log 2>&1 &
nice -n 10 timeout 900 python3 t3b_exclusions.py ../pilot/results/leaf_16_0_2_3_a2_d0.json 3e7 120 > t3b/leaf_16_0_2_3_a2_d0.log 2>&1 &
nice -n 10 timeout 900 python3 t3b_exclusions.py ../pilot/results/leaf_12_5_1_3_a0_d0.json 3e7 300 norot > t3b_norot/leaf_12_5_1_3_a0_d0.log 2>&1 &
nice -n 10 timeout 900 python3 t3b_exclusions.py ../pilot/results/leaf_15_3_0_2_a0_d1.json 3e7 300 norot > t3b_norot/leaf_15_3_0_2_a0_d1.log 2>&1 &
wait
echo ALLDONE > t3b/done2.flag
