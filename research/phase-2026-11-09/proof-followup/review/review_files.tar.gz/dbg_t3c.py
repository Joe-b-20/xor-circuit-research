#!/usr/bin/env python3
"""debug a planted-test record: re-run the pilot's guided step G and print the snapshot next to the target."""
import sys, json, time
from pathlib import Path
PILOT = Path.home() / 'xs-campaigns/2026-11-10-proof/pilot'
sys.path.insert(1, str(PILOT))
sys.argv = [sys.argv[0], '0', '0', '/dev/null'] + sys.argv[1:]
recs = [json.loads(l) for l in open(sys.argv[4])]
idx = int(sys.argv[5])
import importlib
T = importlib.import_module('t3c_planted')
r = recs[idx]
obj = r['obj']
skel = dict(roles=r['roles'], status=['F'] * r['a'] + ['B'] * (3 - r['a'] - r['d']) + ['D'] * r['d'], W=r['W'])
pl = T.enum_cur.plan(skel)
cs, keep = T.constrained_part(obj, pl)
print('order', pl['order']); print('cslots', cs)
for j in range(4):
    o2 = T.rot_obj(obj, j)
    res = T.enum_cur.run_skeleton(T.PG, pl, 10, 10, time.process_time() + 60, guide=T.Guide(o2))
    print('j', j, res['status'], res['survivors'])
    _, keep2 = T.constrained_part(o2, pl)
    print('  target labels', [hex(l['value']) for l in o2['labels']], 'helpers', [(hex(x['mask']), [hex(t) for t in x['triples']], x['labels']) for x in keep2])
    for sn in res['snaps']:
        print('  snap labels', [None if l is None else hex(l) for l in sn['labels']], 'helpers', [(hex(h), [hex(t) for t in R], i) for h, R, e, i in sn['helpers']])
        print('  match', T.match(sn, o2, cs, keep2))
