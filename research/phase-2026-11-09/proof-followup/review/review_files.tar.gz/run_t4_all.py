#!/usr/bin/env python3
"""run t4_stepS.py and t4_exact.py on EVERY leaf the pilot marks 'step S (LP)' (sequential subprocesses)."""
import json, glob, subprocess, sys
from pathlib import Path
RES = Path.home() / 'xs-campaigns/2026-11-10-proof/pilot/results'
HERE = Path(__file__).resolve().parent
out1 = open(HERE / 't4/all_stepS.jsonl', 'w'); out2 = open(HERE / 't4/all_exact.jsonl', 'w')
n = 0
for fn in sorted(glob.glob(str(RES / 'leaf_*.json'))):
    D = json.load(open(fn))
    if D.get('excluded_by') != 'step S (LP)': continue
    k = repr(tuple(D['key'])); a = str(D['A']); d = str(D['qD'])
    for script, out in (('t4_stepS.py', out1), ('t4_exact.py', out2)):
        p = subprocess.run([sys.executable, str(HERE / script), k, a, d], capture_output=True, text=True, timeout=600)
        out.write(p.stdout.strip().splitlines()[-1] + '\n' if p.stdout.strip() else json.dumps(dict(key=k, a=a, d=d, error=p.stderr[-500:])) + '\n'); out.flush()
    n += 1
print('leaves', n)
