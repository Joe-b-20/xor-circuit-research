#!/usr/bin/env python3
"""Key-level completeness: for each of the 66 keys of the block (scope/hypo_kill_Mt3.json) and each of the 16 leaves
(A = a, q_D = d), a, d in 0..3, that the pilot did NOT treat as open (lp_bounds.json open_leaves), check that the plain
leaf system check_combined75.matrix(key, ('eq', a), d) is infeasible, with an exact Farkas certificate (own code).
Also check that every open leaf of lp_bounds.json has a result file."""
import json, sys
from fractions import Fraction
from math import lcm
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
import rcheck
P = Path.home() / 'xs-campaigns/2026-11-10-proof'
keys = [tuple(k) for k in json.load(open(P / 'scope/hypo_kill_Mt3.json'))['killed_keys_list']]
ob = json.load(open(P / 'pilot/lp_bounds.json'))
res_files = {p.name for p in (P / 'pilot/results').glob('leaf_*.json')}
tot = 0; cert = 0; feasible = []; failed = []; missing_files = []
for key in keys:
    openl = {tuple(x) for x in ob[str(key)]['open_leaves']}
    for a, d in openl:
        fn = 'leaf_%d_%d_%d_%d_a%d_d%d.json' % (key[0], key[1], key[2], key[5], a, d)
        if fn not in res_files: missing_files.append(fn)
    for a in range(4):
        for d in range(4):
            if (a, d) in openl: continue
            tot += 1
            b, cols, *_ = rcheck.CC.matrix(key, ('eq', a), d)
            A = np.array([c for _, c in cols], float).T; bb = np.array(b, float); m, n = A.shape
            r = linprog(np.zeros(n), A_ub=A, b_ub=bb, bounds=[(0, None)] * n, method='highs')
            if r.status != 2: feasible.append((key, a, d, int(r.status))); continue
            du = linprog(np.ones(m), A_ub=np.vstack([-A.T, bb[None, :]]), b_ub=np.concatenate([np.zeros(n), [-1.0]]), bounds=[(0, None)] * m, method='highs')
            ok = False
            if du.status == 0:
                Ai = [[int(x) for x in row] for row in A.astype(int)]; bi = [int(x) for x in b]
                for den in (10**4, 10**6, 10**9):
                    lam = [max(Fraction(0), Fraction(x).limit_denominator(den)) for x in du.x]
                    L = 1
                    for f in lam: L = lcm(L, f.denominator)
                    li = [int(f * L) for f in lam]
                    if all(sum(li[i] * Ai[i][j] for i in range(m) if li[i]) >= 0 for j in range(n)) and sum(li[i] * bi[i] for i in range(m) if li[i]) < 0:
                        ok = True; break
            if ok: cert += 1
            else: failed.append((key, a, d))
print(json.dumps(dict(keys=len(keys), nonopen_leaves=tot, exactly_certified_infeasible=cert, lp_feasible_nonopen=feasible[:10], n_lp_feasible_nonopen=len(feasible),
                      cert_failed=failed[:10], open_leaves=sum(len(ob[str(k)]['open_leaves']) for k in keys), open_leaves_without_result_file=missing_files)))
