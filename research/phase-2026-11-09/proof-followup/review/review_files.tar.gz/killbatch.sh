#!/bin/bash
# kill the reviewer's own batch processes (only those started from the review folder scripts)
PAT="$1"
for p in $(pgrep -f "$PAT"); do
  if [ "$p" != "$$" ] && [ "$p" != "$PPID" ]; then kill "$p" 2>/dev/null; fi
done
sleep 1
echo "remaining: $(pgrep -fc "$PAT")"
