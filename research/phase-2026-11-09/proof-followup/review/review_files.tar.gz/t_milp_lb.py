#!/usr/bin/env python3
"""The MILP-load-bearing skeletons of leaf (15,4,1,'Mt',3,1) A=1 qD=0 (results_final EXCLUDED 'step G'): build a complete
object (own search, mode 'full'), verify it (R1-R7, own LP exact counts), and record the own MILP status (300 s); run the
skeleton that aborted at 120 s with a longer cap."""
import json, time
import rgeo, rsearch, rcheck
G = rgeo.Geo()
key = (15, 4, 1, 'Mt', 3, 1); a, d = 1, 0
status = ['F', 'B', 'B']
rows = rcheck.Rows(key, a, d)
S1 = [[1, [0, 1]], [1, [0, 2]], [2, [1]], [2, [1]], [2, [2]], [2, [2]], [3, [0]]]
S2 = [[1, [0, 1, 2]], [1, [1]], [2, [1]], [2, [1]], [2, [2]], [2, [2]], [3, [0]]]
for roles, cap in ((S1, 120), (S2, 480)):
    t0 = time.process_time()
    S = rsearch.Search(G, [(r, tuple(L)) for r, L in roles], status, mode='full', use_rot=False, time_cap=cap).run()
    rec = dict(roles=roles, own=('FOUND' if S.found else ('ABORTED' if S.aborted else 'NONE')), nodes=S.nodes, cpu=round(time.process_time() - t0, 1))
    if S.found:
        obj = S.found[0]
        rec['check'] = rcheck.check(obj, G, a, d)
        cnt = dict(rcheck.counts_of(obj))
        rec['counts'] = {f'{r},{u}': v for (r, u), v in cnt.items()}
        rec['lp_exact'] = rows.lp(cnt, True)
        rec['milp_own_300s'] = rows.milp(cnt, 300.0)
        rec['object'] = obj
    print(json.dumps(rec), flush=True)
