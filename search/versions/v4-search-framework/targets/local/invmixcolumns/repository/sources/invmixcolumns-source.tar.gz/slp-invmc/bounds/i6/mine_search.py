#!/usr/bin/env python3
"""mine_search.py -- the ported minE DFS (NOTEBOOK sec. 2b), with node counts.

Decides minE_K(V_K) by iterative deepening up to --kmax, for every keep-set in
a layer or for keep-sets given on the command line.  Emits the Theorem-B bound
    L(M) >= (32 - |K|) + 32 + minE_K
and the PHASE2_PLAN sec.4 P5 acceptance tests, for every keep-set where minE
is certified (i.e. where the search returned "> kmax" or an exact value).

Usage:
  python3 mine_search.py --target invmc --K 6,9,12,24,27,29,30,31 --kmax 3
  python3 mine_search.py --target invmc --layer L.txt --select jam32 --kmax 2
"""
import argparse
import os
import sys
import time
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import i6_core as i6                                    # noqa: E402
core = i6.core


def one(rows, K, kmax, prune_last=True, memo=True, say=print):
    c = len(K)
    V = i6.restrict(rows, K)
    assert len(set(V)) == 32 and min(i6.popcount(v) for v in V) >= 2
    s = i6.Search(c, V, prune_last=prune_last, memo=memo)
    av0, todo0 = i6.closure(set(s.I), s.V)
    t0 = time.process_time()
    k, wit = s.run(kmax)
    dt = time.process_time() - t0
    rec = {
        'K': list(K), 'c': c, 'jam': len(todo0), 'avail0': len(av0),
        'pairsums0': len(i6.pairsums(av0)),
        'exact': wit is not None, 'minE': k, 'witness': wit,
        'nodes': s.nodes, 'level_nodes': dict(s.level_nodes), 'cpu_s': dt,
    }
    if say:
        flag = '=' if wit is not None else '>='
        say("K=%-26s jam=%-3d |avail0|=%-3d |pairsums0|=%-4d  minE %s %d   "
            "nodes=%-9d levels=%s  %.3f CPU-s"
            % (','.join(str(x) for x in K), rec['jam'], rec['avail0'],
               rec['pairsums0'], flag, k, s.nodes,
               dict(sorted(s.level_nodes.items())), dt))
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--target', default='invmc')
    ap.add_argument('--K', default=None)
    ap.add_argument('--layer', default=None)
    ap.add_argument('--select', default='jam32')
    ap.add_argument('--minjam', type=int, default=None)
    ap.add_argument('--kmax', type=int, default=2)
    ap.add_argument('--no-prune-last', action='store_true')
    ap.add_argument('--no-memo', action='store_true')
    a = ap.parse_args()

    t0 = time.process_time()
    t = core.load(a.target)
    core.rederive_and_compare(t)
    core.selfcheck(t)
    rows = t.rows

    if a.K:
        Ks = [[int(x) for x in a.K.split(',')]]
    else:
        layer = [[int(x) for x in l.split(',')] for l in open(a.layer) if l.strip()]
        Ks = []
        for K in layer:
            V = set(i6.restrict(rows, K))
            _, todo = i6.closure(set(1 << i for i in range(len(K))), V)
            j = len(todo)
            if a.minjam is not None:
                if j >= a.minjam:
                    Ks.append(K)
            elif a.select == 'jam32':
                if j == 32:
                    Ks.append(K)
            elif a.select == 'jampos':
                if j > 0:
                    Ks.append(K)
            else:
                Ks.append(K)
    print("\n%d keep-set(s), kmax=%d, prune_last=%s memo=%s"
          % (len(Ks), a.kmax, not a.no_prune_last, not a.no_memo))

    for K in Ks:
        assert i6.admissible(rows, K), 'non-admissible keep-set %s' % K

    recs = []
    for K in Ks:
        recs.append(one(rows, K, a.kmax,
                        prune_last=not a.no_prune_last, memo=not a.no_memo))

    best = max(recs, key=lambda r: (r['minE'], -len(r['K'])))
    print("\nminE distribution : %s"
          % dict(sorted(Counter(('=' if r['exact'] else '>=') + str(r['minE'])
                                for r in recs).items())))
    print("total nodes %d   total %.3f CPU-s (search only)"
          % (sum(r['nodes'] for r in recs), sum(r['cpu_s'] for r in recs)))

    b = i6.theorem_b_bound(best['K'], best['minE'])
    print("\nBEST keep-set K = %s" % best['K'])
    print("  base (32-|K|)+32 = %d ;  minE %s %d"
          % (64 - len(best['K']), '=' if best['exact'] else '>=', best['minE']))
    print("  THEOREM B:  L(%s) >= %d + %d = %d"
          % (t.name, 64 - len(best['K']), best['minE'], b))
    core.acceptance(t, b)
    print("\ncpu_seconds total %.3f" % (time.process_time() - t0))
    return 0


if __name__ == '__main__':
    sys.exit(main())
