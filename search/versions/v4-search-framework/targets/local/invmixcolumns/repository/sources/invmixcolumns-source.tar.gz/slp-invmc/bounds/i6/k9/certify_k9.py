#!/usr/bin/env python3
"""certify_k9.py -- the |K| = 9 Theorem-B certificate at minE = 5, checked from
the definitions only.

For each keep-set given, this script
  1. re-derives M_inv from spec/invmc_matrix.json's own mds_column over
     GF(2^8)/0x11B and compares entrywise (i5_core.rederive_and_compare);
  2. checks ALL THREE Theorem-A hypotheses that Theorem B inherits;
  3. recomputes V_K;
  4. replays the claimed witness E: |E| = m, elements distinct, weight >= 2,
     disjoint from V, and V u E realizable by the greedy fixpoint.  By Lemma B1
     of PRUNING.md that proves minE_K <= m -- with no search theory at all;
  5. prints the Theorem-B bound (32-|K|) + 32 + minE and the P5 acceptance tests.

The matching LOWER half (minE_K >= m) is NOT done here: it is an exhaustion,
and it lives in runs/brute_c_*_d4.txt (the author's full-pool C, every extra-set
of size <= 4 over the 470-mask pool) and runs/ref_i6_dfs_k9_minE5.txt (the I6
referee's independent C DFS).

  python3 certify_k9.py --K 2,4,8,15,17,25,27,29,30 --E 3,20,172,417,496
"""
import argparse, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.abspath(os.path.join(HERE, '..')))
import i6_core as i6
core = i6.core

UB = 88            # circuits/invmc_walk_88_depth33.json, oracle-VALID

def realizable(c, G):
    avail = set(1 << i for i in range(c)); todo = set(G) - avail
    ch = True
    while ch and todo:
        ch = False
        for g in list(todo):
            for a in avail:
                if (g ^ a) in avail:
                    avail.add(g); todo.discard(g); ch = True; break
    return not todo

ap = argparse.ArgumentParser()
ap.add_argument('--K', required=True)
ap.add_argument('--E', required=True)
a = ap.parse_args()

t = core.load('invmc')
core.rederive_and_compare(t)
core.selfcheck(t)
rows = t.rows

K = [int(x) for x in a.K.split(',')]
E = [int(x) for x in a.E.split(',')]
c = len(K)
print("\nkeep-set K = %s   |K| = %d" % (K, c))
ok = i6.admissible(rows, K, say=print)
assert ok, 'NOT Theorem-A admissible'

V = list(i6.restrict(rows, K))
print("  V_K = %s" % ' '.join(str(v) for v in V))
assert len(set(V)) == 32 and min(i6.popcount(v) for v in V) >= 2

print("\nwitness E = %s   (|E| = %d)" % (E, len(E)))
c1 = len(set(E)) == len(E);                       print("  elements distinct                 : %s" % c1)
c2 = all(i6.popcount(x) >= 2 for x in E);         print("  every element of weight >= 2      : %s" % c2)
c3 = not (set(E) & set(V));                       print("  disjoint from V_K                 : %s" % c3)
c4 = all(0 < x < (1 << c) for x in E);            print("  inside the ambient F2^%d           : %s" % (c, c4))
c5 = realizable(c, set(V) | set(E));              print("  V u E realizable (greedy fixpoint): %s" % c5)
assert c1 and c2 and c3 and c4 and c5, 'WITNESS REPLAY FAILED'
m = len(E)
print("  => minE_K <= %d   (Lemma B1, PRUNING.md sec.2.2 -- no search theory)" % m)

b = i6.theorem_b_bound(K, m)
print("\nTheorem B with minE_K = %d : L(M_inv) >= (32 - %d) + 32 + %d = %d" % (m, c, m, b))
print("P5 acceptance: bound <= upper bound in hand (%d <= %d) : %s" % (b, UB, b <= UB))
print("P5 acceptance: bound >= 32 (%d >= 32)                  : %s" % (b, b >= 32))
assert b <= UB and b >= 32
print("PASS")
