#!/usr/bin/env python3
"""i6_core.py -- Theorem-B / minE primitives for the InvMixColumns programme.

PORTED FROM (read-only reference, never modified; OLD = ~/xor_ui/slp-plateau-search):
    OLD/beat88/understanding/u3_lowerbound/scratch/extras.py:30-79
        closure() and min_extras() -- the iterative-deepening DFS over extras
    OLD/beat88/understanding/u3_lowerbound/scratch/deep_extras.py:14-77
        closure_fast(), pairsums(), Search.rec() -- the same search with the
        three prunings P1 (greedy closure), P2 (last-level restriction),
        P3 (memoisation on the committed extra set)
    OLD/atlas/thinktank/proofside_code/mine.c:50-137
        the referee's independent C re-implementation (commit/undo/search),
        plus its -o canonical-order pruning
    OLD/atlas/thinktank/proofside_code/mc.py:73-85
        jam() -- the free-closure jam count
  The theory is OLD/beat88/understanding/u3_lowerbound/NOTEBOOK.md sec. 2b
  (Lemma 3, Lemma 3', Theorem B, "Computing minE -- the search and why it is
  complete") and PROOFCHECK.md sec. 4 (the referee's Lemma 3').

WHAT CHANGED IN THE PORT
  * The matrix is never typed in: it is loaded through i5_core.load(), which
    re-derives it from NEW/spec/*.json's own declared mds_column over
    GF(2^8)/0x11B and compares entrywise + sha256.  Same discipline as I5.
  * Every routine here takes an explicit keep-set K and re-checks Theorem-A
    admissibility before doing anything (i5_core.keepset_ok +
    i5_core.cols_outside_nonzero -- the referee's hypothesis, REFEREE_REPORT
    sec. 2.6, which Theorem B inherits from Theorem A).
  * The searcher reports a BRANCH PROFILE (per-level candidate counts), which
    the forward code does not, because pricing is what this directory is for.

CONVENTION.  For a keep-set K of size c, restrict() re-indexes the 32 rows onto
c coordinates: bit i of the restricted mask is column K[i] of M.  Masks are
python ints in [0, 2^c).  The c inputs are 1<<0 .. 1<<(c-1).
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.abspath(os.path.join(HERE, '..', 'i5')))

import i5_core as core  # noqa: E402

restrict = core.restrict
popcount = core.popcount


# ---------------------------------------------------------------- the closure
def closure(avail, targets):
    """P1 -- greedy maximal target closure.

    Port of extras.py:30-44 / deep_extras.py:14-24.  Repeatedly adjoin any
    still-undone target v with v = a ^ b for a, b already available.  Returns
    (avail, todo).  Monotone in the seed, so taking it before every branch is
    sound (NOTEBOOK sec. 2b, completeness argument step 1).
    """
    avail = set(avail)
    todo = set(targets) - avail
    changed = True
    while changed and todo:
        changed = False
        for v in list(todo):
            for a in avail:
                if (v ^ a) in avail:
                    avail.add(v)
                    todo.discard(v)
                    changed = True
                    break
    return avail, todo


def pairsums(av):
    """The level's branching set: {a ^ b : a != b in avail} \\ avail, 0 removed.

    Port of deep_extras.py:27-36.  This is the complete candidate set for the
    NEXT extra (NOTEBOOK sec. 2b, completeness argument step 2): in any build
    order of a realizable G, the first element of G \\ V is a XOR of two things
    built before it, and everything built before it lies in V hence in avail.

    Note two facts that make the set exactly "the legal extras":
      * every weight-1 mask is an input, hence already in avail, hence excluded;
        so no candidate violates Lemma 3's weight->=2 requirement;
      * no candidate is an undone target, since a target that were a pairsum of
        avail would already have been taken by the closure.
    """
    avl = list(av)
    out = set()
    for i in range(len(avl)):
        ai = avl[i]
        for j in range(i + 1, len(avl)):
            e = ai ^ avl[j]
            if e:
                out.add(e)
    return out - set(av)


def enabling(av, todo):
    """P2 -- the last-level restriction (deep_extras.py:59-64).

    With one extra of budget left, that extra must start the cascade that
    finishes every remaining target.  The first target to become derivable is
    v = a ^ b with a, b in avail u {e}; a, b both in avail is impossible (v
    would already be closed) and a = b = e gives 0.  So e = v ^ a for some
    v in todo, a in avail.
    """
    out = set()
    for v in todo:
        for a in av:
            out.add(v ^ a)
    return out


# --------------------------------------------------------------- the searcher
class Search(object):
    """Iterative-deepening DFS proving minE_K(V) >= k, with a branch profile.

    Node convention (stated because the forward's two implementations differ):
    a NODE is one state expansion = one closure() call on a committed extra
    set.  self.nodes counts them, root included.  self.level_nodes[d] counts
    the expansions made at depth d (root = depth 0).
    """

    def __init__(self, c, V, prune_last=True, memo=True):
        self.c = c
        self.V = set(V)
        self.I = [1 << i for i in range(c)]
        self.prune_last = prune_last
        self.memo = memo
        self.seen = set()
        self.nodes = 0
        self.level_nodes = {}
        self.branch = {}          # depth -> list of candidate-set sizes seen

    def _cands(self, av, todo, budget):
        c = pairsums(av)
        if self.prune_last and budget == 1:
            c &= enabling(av, todo)
        return c

    def rec(self, avail, extras, budget):
        d = len(extras)
        self.nodes += 1
        self.level_nodes[d] = self.level_nodes.get(d, 0) + 1
        av, todo = closure(avail, self.V)
        if not todo:
            return list(extras)
        if budget == 0:
            return None
        if self.memo:
            key = frozenset(extras)
            if key in self.seen:
                return None
            self.seen.add(key)
        cands = self._cands(av, todo, budget)
        self.branch.setdefault(d, []).append(len(cands))
        for e in sorted(cands):
            r = self.rec(av | {e}, extras + [e], budget - 1)
            if r is not None:
                return r
        return None

    def run(self, kmax):
        """Returns (k, witness).  witness is None iff minE > kmax, in which
        case k = kmax + 1 and the claim proved is minE >= kmax + 1."""
        for k in range(kmax + 1):
            self.seen.clear()
            r = self.rec(set(self.I), [], k)
            if r is not None:
                return k, r
        return kmax + 1, None


# ------------------------------------------------------------------- pricing
def profile(rows, K, depth):
    """Measure the branching structure of the minE DFS to `depth` levels,
    WITHOUT the last-level P2 pruning (so the numbers are the honest raw
    branching factors, an upper bound on what a certification explores).

    Returns a dict with, per level d = 1..depth: the list of candidate-set
    sizes at that level and the level's node count (= sum of the parents'
    candidate counts).
    """
    c = len(K)
    V = set(restrict(rows, K))
    I = set(1 << i for i in range(c))
    av0, todo0 = closure(I, V)
    out = {'c': c, 'jam': len(todo0), 'avail0': len(av0), 'levels': {}}
    frontier = [(av0, todo0)]
    for d in range(1, depth + 1):
        sizes = []
        nxt = []
        for av, todo in frontier:
            if not todo:
                sizes.append(0)
                continue
            cs = pairsums(av)
            sizes.append(len(cs))
            if d == depth:
                continue        # last level: sizes only, do not expand further
            for e in sorted(cs):
                nxt.append(closure(av | {e}, V))
        out['levels'][d] = {
            'parents': len(frontier),
            'sizes': sizes,
            'nodes': sum(sizes),
        }
        frontier = nxt
        if not frontier:
            break
    return out


def theorem_b_bound(K, minE):
    """(32 - |K|) + 32 + minE  -- NOTEBOOK sec. 2b, Theorem B."""
    return (32 - len(K)) + 32 + minE


def admissible(rows, K, say=None):
    """All THREE hypotheses Theorem B inherits from Theorem A."""
    ok_rows = core.keepset_ok(rows, K)
    ok_cols, nout, minw = core.cols_outside_nonzero(rows, K)
    if say:
        say("  rows of M|_K distinct and weight >= 2 : %s" % ok_rows)
        say("  every column outside K nonzero        : %s "
            "(%d columns outside K, min weight %d)" % (ok_cols, nout, minw))
    return ok_rows and ok_cols
