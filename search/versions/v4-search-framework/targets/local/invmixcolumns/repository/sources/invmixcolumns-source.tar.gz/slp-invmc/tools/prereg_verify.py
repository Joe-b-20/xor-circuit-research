#!/usr/bin/env python3
"""Re-verify the PREREG.jsonl hash chain: each row's row_sha256 must equal
sha256(prev_row_sha256 || json(row without row_sha256)) and prev_sha256 must
equal the previous row's row_sha256.  Exit 0 iff the chain is intact."""
import json, hashlib, sys
path = sys.argv[1] if len(sys.argv) > 1 else 'PREREG.jsonl'
prev = ''
ok = True
for i, line in enumerate(open(path)):
    rec = json.loads(line)
    h = rec.pop('row_sha256')
    body = json.dumps(rec, sort_keys=True, ensure_ascii=False)
    exp = hashlib.sha256((prev + body).encode()).hexdigest()
    good = (h == exp) and (rec['prev_sha256'] == prev)
    print(f"{rec['id']:>4}  {'OK ' if good else 'BAD'}  {h[:16]}")
    ok &= good
    prev = h
print("CHAIN INTACT" if ok else "CHAIN BROKEN")
sys.exit(0 if ok else 1)
