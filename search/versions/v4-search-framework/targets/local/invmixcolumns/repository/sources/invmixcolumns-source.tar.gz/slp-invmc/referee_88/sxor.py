#!/usr/bin/env python3
"""Item 3: exact in-place (s-XOR) realisability of the 88, on 32 registers.
Model: an s-XOR program is a list of  x[d] ^= x[o]  instructions on 32 registers.
Unrolled to SSA, instruction k reads two live signals and DESTROYS one of them
(the destination register d).  So, for a g-XOR circuit with 32 inputs, q gates and
32 signals surviving as outputs:
  * the 32+q-32 = q non-output signals must each be destroyed exactly once;
  * signal s can only be destroyed by a gate that READS s (one of its two operands);
  * the destroying gate must be the LAST consumer of s in the execution order.
=> a perfect matching gates <-> non-output signals in the 'reads' bipartite graph,
   plus an acyclic precedence order.  Necessary and sufficient."""
import json, itertools, random, sys
sys.setrecursionlimit(10000)

REPO="~/xor_ui/slp-invmc"
E=json.load(open(REPO+"/referee_88/eval.json"))
G=json.load(open(REPO+"/circuits/invmc_walk_88_depth33.json"))["gates"]
outs=E["outs"]

def analyse(G,outs,nin=32,name=""):
    q=len(G); NS=nin+q; outset=set(outs)
    nonout=[s for s in range(NS) if s not in outset]
    print("[%s] signals=%d gates=%d outputs=%d non-output signals=%d"%(name,NS,q,len(outset),len(nonout)))
    if len(nonout)!=q:
        print("  -> #non-output signals != #gates: cannot be in-place on %d registers"%nin); return False
    # bipartite: gate index g -> candidate kill victims among its operands
    cand=[]
    dead_gate=[]
    for i,(a,b) in enumerate(G):
        c=[x for x in (a,b) if x not in outset]
        cand.append(c)
        if not c: dead_gate.append((nin+i,a,b))
    if dead_gate:
        print("  BLOCKING gates (both operands are outputs, so nothing may be destroyed):")
        for s,a,b in dead_gate:
            print("    gate signal %d = %d XOR %d ; %d is output bit %s, %d is output bit %s"
                  %(s,a,b,a,outs.index(a),b,outs.index(b)))
        print("  -> NO kill-assignment exists (0 perfect matchings). NOT s-XOR realisable.")
        return False
    # Hopcroft-Karp-ish augmenting path matching
    idx={s:k for k,s in enumerate(nonout)}
    matchS=[-1]*len(nonout)   # signal-slot -> gate
    matchG=[-1]*q
    def try_k(g,vis):
        for s in cand[g]:
            k=idx[s]
            if vis[k]: continue
            vis[k]=True
            if matchS[k]==-1 or try_k(matchS[k],vis):
                matchS[k]=g; matchG[g]=k; return True
        return False
    m=0
    for g in range(q):
        if try_k(g,[False]*len(nonout)): m+=1
    print("  maximum matching size %d / %d"%(m,q))
    if m<q:
        un=[nin+g for g in range(q) if matchG[g]==-1]
        print("  -> no perfect matching; unmatched gates:",un); return False
    # acyclicity: gate k kills s => every other consumer of s precedes k
    cons={}
    for i,(a,b) in enumerate(G):
        cons.setdefault(a,[]).append(nin+i); cons.setdefault(b,[]).append(nin+i)
    edges=set()
    for i,(a,b) in enumerate(G):
        for x in (a,b):
            if x>=nin: edges.add((x,nin+i))
    for g in range(q):
        s=nonout[matchG[g]]
        for k in cons.get(s,[]):
            if k!=nin+g: edges.add((k,nin+g))
    # topological sort over gate nodes
    nodes=set(range(nin,NS))
    indeg={n:0 for n in nodes}
    adj={n:[] for n in nodes}
    for u,v in edges:
        if u in nodes and v in nodes: adj[u].append(v); indeg[v]+=1
    st=[n for n in nodes if indeg[n]==0]; seen=0
    while st:
        u=st.pop(); seen+=1
        for v in adj[u]:
            indeg[v]-=1
            if indeg[v]==0: st.append(v)
    print("  one perfect matching found; its precedence order is %s"%("ACYCLIC -> s-XOR realisable" if seen==len(nodes) else "CYCLIC (this matching only)"))
    return seen==len(nodes)

print("="*78); print("H. in-place (s-XOR) realisability of the 88"); print("="*78)
r=analyse(G,outs,32,"invmc_walk_88_depth33")
print("RESULT: the 88 is %s an s-XOR program on 32 registers"%("" if r else "NOT"))

print()
print("="*78); print("H2. positive control: a synthetic in-place program, unrolled"); print("="*78)
# build a random in-place program on 32 registers, unroll to SSA, feed it back in
rng=random.Random(7)
for trial in range(3):
    reg=list(range(32)); gates=[]; nxt=32
    for _ in range(88):
        d,o=rng.sample(range(32),2)
        gates.append([reg[d],reg[o]]); reg[d]=nxt; nxt+=1
    # strip: keep as-is (may have dead gates); outputs = final register contents
    outs2=sorted(reg)
    if len(set(outs2))!=32 or any(o<32 for o in outs2):
        print("  trial %d skipped (an input survived unchanged)"%trial); continue
    ok=analyse(gates,reg,32,"synthetic in-place #%d"%trial)
    print("  control expects True ->",ok)
