// Bi-generation scan over masks.bin (88 x uint32 per record).
// For each MC value set U (S = I u U, 120 points), compute the triangle closure of the
// OUTPUT basis O inside S. Prints the record index and |<O>| - 32 for every record in which
// <O> reaches all 32 inputs (then <O> = S: the same point set is an SLP for M^{-1}).
// Also prints a histogram of the number of inputs reached.
// build: gcc -O2 -o bigen_scan bigen_scan.c ; run: ./bigen_scan masks.bin targets.txt
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

static int cmp(const void *a, const void *b) {
    uint32_t x = *(const uint32_t *)a, y = *(const uint32_t *)b;
    return x < y ? -1 : x > y;
}

int main(int argc, char **argv) {
    FILE *f = fopen(argv[1], "rb");
    FILE *t = fopen(argv[2], "r");
    uint32_t T[32];
    for (int i = 0; i < 32; i++) if (fscanf(t, "%u", &T[i]) != 1) return 2;
    fclose(t);
    fseek(f, 0, SEEK_END); long sz = ftell(f); fseek(f, 0, SEEK_SET);
    long n = sz / (88 * 4);
    uint32_t rec[88];
    long hist[33]; memset(hist, 0, sizeof hist);
    long full = 0;
    for (long r = 0; r < n; r++) {
        if (fread(rec, 4, 88, f) != 88) return 3;
        uint32_t S[120]; int m = 0;
        for (int i = 0; i < 32; i++) S[m++] = 1u << i;
        for (int i = 0; i < 88; i++) S[m++] = rec[i];
        qsort(S, m, 4, cmp);
        char in[120]; memset(in, 0, sizeof in);
        // mark O
        for (int i = 0; i < m; i++)
            for (int k = 0; k < 32; k++) if (S[i] == T[k]) in[i] = 1;
        int changed = 1;
        while (changed) {
            changed = 0;
            for (int i = 0; i < m; i++) {
                if (in[i]) continue;
                for (int j = 0; j < m && !in[i]; j++) {
                    if (!in[j]) continue;
                    uint32_t w = S[i] ^ S[j];
                    // binary search w
                    int lo = 0, hi = m - 1;
                    while (lo <= hi) {
                        int md = (lo + hi) / 2;
                        if (S[md] == w) { if (in[md]) { in[i] = 1; changed = 1; } break; }
                        if (S[md] < w) lo = md + 1; else hi = md - 1;
                    }
                }
            }
        }
        int ninp = 0, tot = 0;
        for (int i = 0; i < m; i++) if (in[i]) { tot++; if ((S[i] & (S[i] - 1)) == 0) ninp++; }
        hist[ninp]++;
        if (ninp == 32) { full++; printf("FULL %ld %d\n", r, tot - 32); }
    }
    fprintf(stderr, "records %ld full %ld\nhist:", n, full);
    for (int i = 0; i <= 32; i++) if (hist[i]) fprintf(stderr, " %d:%ld", i, hist[i]);
    fprintf(stderr, "\n");
    return 0;
}
