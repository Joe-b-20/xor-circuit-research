#!/bin/bash
# R2 pipeline smoke test, part (a): invmc_core self-test + two-verifier agreement
set -u
cd ~/xor_ui/slp-invmc
echo "=================================================================="
echo "R2 PIPELINE SMOKE TEST (a) -- invmc_core self-test + oracle agreement"
echo "date_utc: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "host: $(hostname)   python: $(python3 -V 2>&1)"
echo "repo: $(pwd)   git: $(git rev-parse --short HEAD)"
echo "=================================================================="
echo
echo "--- A1. invmc_core self-test -------------------------------------"
echo "\$ nice -n 19 python3 pipeline/invmc_core.py"
nice -n 19 python3 pipeline/invmc_core.py
echo "  exit=$?"
echo
echo "--- A2. the 32 masks EQUAL spec/invmc_target_masks.json ----------"
echo "\$ nice -n 19 python3 -c '<compare invmc_core.TARGETS with the spec file>'"
nice -n 19 python3 - <<'PY'
import sys, json
sys.path.insert(0, "pipeline")
import invmc_core as core
spec = json.load(open(core.SPEC_MASKS))
tm = [int(x) for x in spec["target_masks"]]
print("  spec file      :", core.SPEC_MASKS)
print("  spec n_targets :", spec["n_targets"])
print("  core TARGETS   :", len(core.TARGETS))
print("  identical      :", tm == core.TARGETS)
print("  first 4 (core) :", [hex(m) for m in core.TARGETS[:4]])
print("  first 4 (spec) :", [hex(m) for m in tm[:4]])
prof = {}
for m in core.TARGETS: prof[bin(m).count("1")] = prof.get(bin(m).count("1"),0)+1
print("  weight profile :", dict(sorted(prof.items())), "expected", core.WEIGHT_PROFILE)
print("  MIN_DEPTH      :", core.MIN_DEPTH, "= ceil(log2", core.MAX_TARGET_WEIGHT, ")")
assert tm == core.TARGETS and prof == core.WEIGHT_PROFILE and core.MIN_DEPTH == 5
print("  A2: PASS")
PY
echo "  exit=$?"
echo
echo "--- A3. built-in verifier AND generic oracle on all five seeds ---"
for f in pipeline/seeds/invmc_bp5ub2_106_depth21.json \
         pipeline/seeds/invmc_bp5ub2_113_depth17.json \
         pipeline/seeds/invmc_bp5ub2_121_depth16.json \
         pipeline/seeds/invmc_yuan91.json \
         pipeline/seeds/invmc_paar1.json ; do
  echo
  echo "  >>> $f"
  echo "  \$ nice -n 19 python3 -c 'invmc_core.verify(gates)'"
  nice -n 19 python3 - "$f" <<'PY'
import sys, json
sys.path.insert(0, "pipeline")
import invmc_core as core
g = json.load(open(sys.argv[1]))["gates"]
v = core.verify(g)
print("      built-in : gates=%d depth=%d outputs=%d/32 ok=%s"
      % (v["gates"], v["depth"], v["outputs"], v["ok"]))
sys.exit(0 if v["ok"] else 1)
PY
  echo "      built-in exit=$?"
  echo "  \$ nice -n 19 python3 tools/verify_slp_generic.py --target spec/invmc_matrix.json $f"
  nice -n 19 python3 tools/verify_slp_generic.py --target spec/invmc_matrix.json "$f" | sed 's/^/      /'
  echo "      oracle exit=${PIPESTATUS[0]}"
done
echo
echo "--- A4. NEGATIVE CONTROL: mutate one gate input in each seed -----"
echo "    (flip gate 40's first input to input 0; both verifiers must say INVALID)"
for f in pipeline/seeds/invmc_bp5ub2_106_depth21.json \
         pipeline/seeds/invmc_bp5ub2_113_depth17.json \
         pipeline/seeds/invmc_bp5ub2_121_depth16.json \
         pipeline/seeds/invmc_yuan91.json \
         pipeline/seeds/invmc_paar1.json ; do
  echo
  echo "  >>> mutated $f"
  MUT=/tmp/mut_$(basename $f)
  nice -n 19 python3 - "$f" "$MUT" <<'PY'
import sys, json
d = json.load(open(sys.argv[1]))
g = [list(x) for x in d["gates"]]
i = 40
old = list(g[i])
g[i][0] = 0 if old[0] != 0 else 1
print("      mutation : gate %d %s -> %s" % (i, old, g[i]))
json.dump({"gateCount": len(g), "gates": g}, open(sys.argv[2], "w"))
PY
  nice -n 19 python3 - "$MUT" <<'PY'
import sys, json
sys.path.insert(0, "pipeline")
import invmc_core as core
g = json.load(open(sys.argv[1]))["gates"]
v = core.verify(g)
print("      built-in : gates=%d depth=%d outputs=%d/32 ok=%s  -> %s"
      % (v["gates"], v["depth"], v["outputs"], v["ok"],
         "VALID (CONTROL FAILED)" if v["ok"] else "INVALID (control fired)"))
sys.exit(1 if v["ok"] else 0)
PY
  echo "      built-in control exit=$?  (0 = correctly rejected)"
  nice -n 19 python3 tools/verify_slp_generic.py --target spec/invmc_matrix.json "$MUT" | sed 's/^/      /'
  echo "      oracle exit=${PIPESTATUS[0]}  (1 = correctly rejected)"
done
echo
echo "--- A5. the retired engine and the infeasible depth caps ---------"
echo "\$ nice -n 19 python3 -c 'engines.run_engine(\"anneal3\", ...)' and check_cap(3/4/5)"
nice -n 19 python3 - <<'PY'
import sys
sys.path.insert(0, "pipeline")
import engines, invmc_core as core
for cap in (2, 3, 4):
    try:
        engines.check_cap(cap)
        print("  cap %d: ACCEPTED -- CONTROL FAILED" % cap)
    except SystemExit as e:
        print("  cap %d: REFUSED  -- %s" % (cap, str(e).split(".")[0]))
for cap in (5, 6, None):
    engines.check_cap(cap); print("  cap %s: accepted (>= MIN_DEPTH %d)" % (cap, core.MIN_DEPTH))
try:
    engines.run_engine("anneal3", None, 5, None, 1, [1], {}, None)
    print("  anneal3: RAN -- CONTROL FAILED")
except SystemExit as e:
    print("  anneal3: REFUSED --", str(e)[:90], "...")
print("  A5: PASS")
PY
echo "  exit=$?"
echo
echo "=================================================================="
echo "END smoke (a)"
echo "=================================================================="
