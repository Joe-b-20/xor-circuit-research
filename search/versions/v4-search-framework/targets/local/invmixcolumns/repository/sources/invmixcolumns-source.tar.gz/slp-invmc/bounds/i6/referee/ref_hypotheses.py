#!/usr/bin/env python3
"""All THREE Theorem-A/B hypotheses, checked explicitly on the certificate keep-sets."""
import json
rows=json.load(open('ref_matrix.json'))['rows']
def check(K):
    r=[''.join(row[c] for c in K) for row in rows]
    d=len(set(r))==32
    w=min(x.count('1') for x in r)
    outside=[c for c in range(32) if c not in K]
    colw=[sum(1 for row in rows if row[c]=='1') for c in outside]
    print("K=%-32s |K|=%d  (1) 32 distinct restricted rows: %s  (2) min restricted weight: %d (>=2: %s)  (3) columns outside K all nonzero: %s (min col weight %d over %d columns)"
          %(str(K),len(K),d,w,w>=2,all(x>0 for x in colw),min(colw),len(outside)))
for K in ([0,3,4,5,6,7,14,17],[0,2,3,4,5,6,7,25],
          [0,1,3,7,14,16,17,28,29],[0,3,4,5,6,7,13,14,17],
          [0,1,2,3,5,9,22,23,29]):
    check(K)
