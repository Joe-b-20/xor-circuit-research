#!/bin/bash
# ladder.sh WHICH J KFROM KTO PERLEVEL_TIMEOUT [DEPTH]
# walk the k-ladder of one record-free sector block, one subprocess per level,
# hard-bounded by `timeout`.  Stops at the first SAT or the first timeout.
export PYTHONDONTWRITEBYTECODE=1
cd "$(dirname "$0")"
W=$1; J=$2; A=$3; B=$4; TO=$5; D=${6:-None}
for ((k=A; k<=B; k++)); do
  out=$(timeout "$TO" nice -n 19 python3 one_level.py "$W" "$J" "$k" "$D")
  rc=$?
  if [ $rc -ne 0 ]; then
    echo "{\"which\":\"$W\",\"j\":$J,\"k\":$k,\"depth\":\"$D\",\"result\":\"TIMEOUT_${TO}s\"}"
    break
  fi
  echo "$out"
  case "$out" in *'"SAT"'*) break;; esac
done
