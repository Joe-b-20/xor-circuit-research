import json,sys,os
sizes={}
for line in open(sys.argv[1]):
    p,s=line.rsplit(" ",1); sizes[p.strip()]=int(s)
byfile={}; order=[]; allsets={}
for p,size in sizes.items():
    if not any(k in p for k in ("a1_lns_106","a3_walk_106","h3_alt_from88")): continue
    s=set(); nb=0
    with open(p,"rb") as f:
        for line in f:
            if nb+len(line)>size: break
            nb+=len(line)
            if not line.endswith(b"\n"): break
            t=line.strip()
            if not t: continue
            ms=json.loads(t)
            if len(ms)!=88: continue
            key=t.decode()
            s.add(key)
            if key not in allsets:
                allsets[key]=ms; order.append(key)
    byfile[os.path.basename(p)]=s
    print(p,"distinct88",len(s))
ks=list(byfile)
print("union",len(allsets))
for a in ks:
    for b in ks:
        if a!=b: print("  %s subset of %s: %s (|A|=%d |A&B|=%d)"%(a,b,byfile[a]<=byfile[b],len(byfile[a]),len(byfile[a]&byfile[b])))
json.dump([allsets[k] for k in order], open(sys.argv[2],"w"))
