#!/usr/bin/env python3
"""verify_k9.py -- independent verification of the banked |K| = 9 census.

It re-does, from the definitions only:

  COVERAGE.  The union of the shard banks covers every line of the canonical
    layer exactly once; the canonical layer is exactly the Z/4-canonical subset
    of the admissible layer; the admissible layer is re-derived here from the
    matrix and is closed under Z/4.  With PRUNING.md Lemmas A1/A2 that turns a
    statement about 261,136 keep-sets into a statement about all 1,044,544.

  UPPER HALF (which is the whole "no keep-set does better" claim).  For every
    banked record with a witness, replay it: |E| = minE, distinct, weight >= 2,
    disjoint from V_K, and V_K u E realizable by the greedy fixpoint.  By
    Lemma B1 that proves minE_K <= the banked value USING NO SEARCH THEORY.
    Records with minE = 0 are checked by realizability of V_K itself.

  It does NOT re-do the lower half (minE_K >= e), which is an exhaustion; the
  lower half of the load-bearing keep-sets lives in runs/brute_c_*_d4.txt and
  runs/ref_i6_dfs_k9_minE5.txt.

  python3 verify_k9.py --canon runs/canon_k9.txt --banks runs/census_sh*.txt
"""
import argparse, glob, os, sys, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.abspath(os.path.join(HERE, '..')))
import i6_core as i6
core = i6.core

ap = argparse.ArgumentParser()
ap.add_argument('--canon', required=True)
ap.add_argument('--banks', nargs='+', required=True)
ap.add_argument('--admis', default=None, help='the full admissible layer, for the coverage check')
a = ap.parse_args()

t = core.load('invmc'); core.rederive_and_compare(t); core.selfcheck(t)
rows = t.rows

def realizable(c, G):
    avail = set(1 << i for i in range(c)); todo = set(G) - avail
    ch = True
    while ch and todo:
        ch = False
        for g in list(todo):
            for x in avail:
                if (g ^ x) in avail:
                    avail.add(g); todo.discard(g); ch = True; break
    return not todo

def rot(km, s):
    o = 0
    for c in range(32):
        if (km >> c) & 1:
            b, i = divmod(c, 8); o |= 1 << (8 * ((b + s) % 4) + i)
    return o

canon = [l.strip() for l in open(a.canon) if l.strip()]
print("canonical layer          : %d lines (%s)" % (len(canon), a.canon))

if a.admis:
    S = set()
    for l in open(a.admis):
        km = 0
        for x in l.split(','): km |= 1 << int(x)
        S.add(km)
    closed = all(rot(k, s) in S for k in S for s in (1, 2, 3))
    cset = set()
    for l in canon:
        km = 0
        for x in l.split(','): km |= 1 << int(x)
        cset.add(km)
    want = set(k for k in S if all(rot(k, s) >= k for s in (1, 2, 3)))
    print("admissible layer         : %d, closed under Z/4 : %s" % (len(S), closed))
    print("canon == Z/4-canonical   : %s   (orbits all free: %s)"
          % (cset == want, all(rot(k, s) != k for k in S for s in (1, 2, 3))))
    assert closed and cset == want

files = []
for g in a.banks: files += sorted(glob.glob(g))
recs = {}
dup = 0
for f in files:
    for line in open(f):
        p = line.split()
        if len(p) < 6: print("SHORT LINE in %s: %r" % (f, line)); sys.exit(1)
        idx = int(p[0])
        if idx in recs: dup += 1
        recs[idx] = p
print("bank files               : %d, records %d, duplicates %d" % (len(files), len(recs), dup))
missing = [i for i in range(len(canon)) if i not in recs]
print("coverage                 : %d missing, indices %s"
      % (len(missing), missing[:10] if missing else 'none'))
assert dup == 0 and not missing

t0 = time.process_time()
hist = {}
bad = 0; nowit = []
maxE = -1
for i in range(len(canon)):
    p = recs[i]
    K = [int(x) for x in p[1].split(',')]
    assert p[1] == canon[i], 'keep-set mismatch at index %d' % i
    minE = int(p[3]); hist[minE] = hist.get(minE, 0) + 1
    maxE = max(maxE, minE)
    V = list(i6.restrict(rows, K))
    if len(set(V)) != 32 or min(i6.popcount(v) for v in V) < 2: bad += 1; print("BAD V at", i); continue
    if 'W' in p:
        E = [int(x) for x in p[p.index('W') + 1:]]
        ok = (len(set(E)) == len(E) == minE and all(i6.popcount(x) >= 2 for x in E)
              and not (set(E) & set(V)) and realizable(9, set(V) | set(E)))
    elif minE == 0:
        ok = realizable(9, set(V))
    else:
        ok = None; nowit.append((i, minE))
    if ok is False:
        bad += 1
        print("WITNESS REPLAY FAILED at index %d  K=%s minE=%d" % (i, p[1], minE))
t1 = time.process_time()

print("\nminE histogram over the %d canonical representatives:" % len(canon))
for k in sorted(hist): print("   minE = %-3d : %d" % (k, hist[k]))
print("max_K minE_K (canonical, hence over all %d admissible 9-sets) = %d"
      % (4 * len(canon), maxE))
print("witness replays failed   : %d" % bad)
print("records with no witness  : %d  %s" % (len(nowit), nowit[:20]))
print("verification CPU         : %.2f s" % (t1 - t0))
print("\nTheorem B: L(M_inv) >= (32-9) + 32 + max_K minE_K = %d" % (23 + 32 + maxE))
sys.exit(1 if bad else 0)
