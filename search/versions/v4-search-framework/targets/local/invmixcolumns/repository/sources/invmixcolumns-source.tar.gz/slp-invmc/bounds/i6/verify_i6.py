#!/usr/bin/env python3
"""verify_i6.py -- independent verification of the I6 / Theorem-B result at |K|=8,
using NOTHING but the definition of `realizable`.

The searcher in `mine_search.py` / `sweep.py` is only complete because of the
five-step argument in OLD NOTEBOOK sec. 2b (greedy closure WLOG, next extra is
a pairsum, last-level restriction, memoisation, weight->=1 exclusion).  This
script never uses any of it.  It re-decides both halves of the result directly:

  UPPER half -- `minE_K <= m` for every keep-set in the bank.
      Replay the banked witness E: check |E| = m, elements distinct, of weight
      >= 2, not already targets, and that V u E is realizable.  A witness needs
      no search theory at all.

  LOWER half -- `minE_K >= 2` for every keep-set the bank claims minE = 2.
      Brute-force EVERY extra-set of size <= 1 drawn from the whole ambient
      pool W \\ V, where W = all 2^|K| - 1 - |K| masks of weight >= 2.  At
      |K| = 8 that pool has 247 - 32 = 215 elements, so the exhaustion is 216
      realizability tests per keep-set.  This decides minE >= 2 by definition.

Together they certify max_K minE_K exactly, and therefore both the bound
    L(M_inv) >= (32-|K|) + 32 + max_K minE_K
and the statement that no admissible keep-set of this size does better.

Usage:
  python3 verify_i6.py --target invmc --layer ../i5/runs/admissible_invmc_k8.txt \
      --bank runs/sweep_k8_full.jsonl
"""
import argparse
import json
import os
import sys
import time
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import i6_core as i6                                    # noqa: E402
core = i6.core


def realizable(c, G):
    """True iff G can be ordered so each element is the XOR of two strictly
    earlier available masks (the c inputs are available from the start).

    Greedy is exact: if the greedy fixpoint misses some g in G, then in any
    legal ordering the first missed element would have both its operands in the
    fixpoint (they are earlier and either inputs or unmissed), so it would have
    been taken.  Deliberately a separate 12-line function from i6_core.closure,
    so that a bug in the searcher's closure cannot hide here too.
    """
    avail = set(1 << i for i in range(c))
    todo = set(G) - avail
    changed = True
    while changed and todo:
        changed = False
        for g in list(todo):
            for a in avail:
                if (g ^ a) in avail:
                    avail.add(g)
                    todo.discard(g)
                    changed = True
                    break
    return not todo


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--target', default='invmc')
    ap.add_argument('--layer', required=True)
    ap.add_argument('--bank', required=True)
    ap.add_argument('--exhaust-below', type=int, default=None,
                    help='brute-force minE >= m for every record with minE = m '
                         '(default: the maximum minE in the bank)')
    a = ap.parse_args()

    t = core.load(a.target)
    core.rederive_and_compare(t)
    core.selfcheck(t)
    rows = t.rows

    layer = [[int(x) for x in l.split(',')] for l in open(a.layer) if l.strip()]
    recs = [json.loads(l) for l in open(a.bank) if l.strip()]
    print("\nlayer %s : %d keep-sets of size %d"
          % (os.path.basename(a.layer), len(layer), len(layer[0])))
    print("bank  %s : %d records" % (os.path.basename(a.bank), len(recs)))

    t0 = time.process_time()
    seen = set()
    for r in recs:
        assert layer[r['i']] == r['K'], 'bank index %d does not match layer' % r['i']
        seen.add(r['i'])
    assert len(seen) == len(layer), \
        'bank covers %d of %d keep-sets -- NOT a complete census' % (len(seen), len(layer))
    print("  [OK] the bank covers every keep-set of the layer, exactly once")

    hist = Counter()
    mx = max(r['minE'] for r in recs)
    target_m = a.exhaust_below if a.exhaust_below is not None else mx

    # ---- UPPER half: replay every witness -----------------------------------
    t1 = time.process_time()
    nwit = 0
    for r in recs:
        K = r['K']
        c = len(K)
        assert i6.admissible(rows, K), 'non-admissible keep-set %s' % K
        V = i6.restrict(rows, K)
        assert len(set(V)) == 32 and min(i6.popcount(v) for v in V) >= 2
        Vs = set(V)
        hist[r['minE']] += 1
        E = r['witness']
        assert E is not None, \
            'record %d has no witness: minE > kmax, the sweep did not decide it' % r['i']
        assert len(set(E)) == len(E) == r['minE'], 'witness size mismatch at %d' % r['i']
        assert all(0 < e < (1 << c) for e in E), 'witness mask out of range at %d' % r['i']
        assert all(i6.popcount(e) >= 2 for e in E), 'witness mask of weight < 2 at %d' % r['i']
        assert not (set(E) & Vs), 'witness mask is a target at %d' % r['i']
        assert realizable(c, Vs | set(E)), 'witness NOT realizable at %d' % r['i']
        nwit += 1
    t_wit = time.process_time() - t1
    print("  [OK] %d witnesses replayed: every keep-set has minE <= its banked value"
          % nwit)
    print("       minE histogram over the whole layer : %s" % dict(sorted(hist.items())))
    print("       %.3f CPU-s" % t_wit)

    # ---- LOWER half: brute-force exhaustion ---------------------------------
    t2 = time.process_time()
    tight = [r for r in recs if r['minE'] == target_m]
    tested = 0
    print("\n  brute-forcing minE >= %d on the %d keep-sets the bank calls minE = %d"
          % (target_m, len(tight), target_m))
    for r in tight:
        K = r['K']
        c = len(K)
        Vs = set(i6.restrict(rows, K))
        pool = [m for m in range(1, 1 << c) if i6.popcount(m) >= 2 and m not in Vs]
        assert not realizable(c, Vs), 'minE = 0 at %d, contradicts bank' % r['i']
        tested += 1
        for e in pool:
            tested += 1
            assert not realizable(c, Vs | {e}), \
                'ONE extra %d completes K=%s -- bank says minE = %d' % (e, K, r['minE'])
    t_ex = time.process_time() - t2
    print("  [OK] %d extra-sets of size <= %d exhausted over the FULL ambient pool "
          "(%d masks of weight >= 2 outside V, per keep-set)"
          % (tested, target_m - 1, len(pool) if tight else 0))
    print("       no keep-set completes with fewer than %d extras : minE >= %d confirmed"
          % (target_m, target_m))
    print("       %.3f CPU-s" % t_ex)

    # ---- the bound ----------------------------------------------------------
    k = len(layer[0])
    b = (32 - k) + 32 + mx
    print("\n  max_K minE_K = %d over all %d admissible %d-sets" % (mx, len(recs), k))
    print("  THEOREM B:  L(%s) >= (32-%d) + 32 + %d = %d" % (t.name, k, mx, b))
    print("  and no admissible keep-set of size %d gives more than %d." % (k, b))
    ex = [r['K'] for r in recs if r['minE'] == mx]
    print("  attained by %d keep-sets, e.g. K = %s  (witness extras %s)"
          % (len(ex), ex[0], [r for r in recs if r['minE'] == mx][0]['witness']))
    core.acceptance(t, b)
    print("\ncpu_seconds %.3f" % (time.process_time() - t0))
    return 0


if __name__ == '__main__':
    sys.exit(main())
