| h1_d20_from88 | 2390260 | lns | 20 | seeds/invmc_walk_88_depth33.json |
| h2_d16_from88 | 2390261 | lns | 16 | seeds/invmc_walk_88_depth33.json |
| h3_alt_from88 | 2390262 | alt | none | seeds/invmc_walk_88_depth33.json |
