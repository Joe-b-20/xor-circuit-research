#!/bin/bash
# I5 forward positive control.
# Runs the ORIGINAL verifier in the OLD repo (read-only; nothing is written
# there) and the PORT on spec/mixcolumns_matrix.json, and diffs them.
# Then reproduces, with the port's own tools, every published forward number of
# METHOD_CATALOG entry I5 / NOTEBOOK.md sec.3.
set -u
OLD=~/xor_ui/slp-plateau-search
NEW=~/xor_ui/slp-invmc
I5=$NEW/bounds/i5
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

hdr(){ echo; echo "=============================================================================="; echo "$*"; echo "=============================================================================="; }

echo "I5 FORWARD POSITIVE CONTROL"
echo "date_utc  $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "host      $(uname -srm)   cores $(nproc)"
echo "OLD (read-only reference) $OLD"
echo "NEW                       $NEW"
echo "git OLD   $(cd $OLD && git rev-parse HEAD)   dirty-lines $(cd $OLD && git status --porcelain | wc -l)"
echo "git NEW   $(cd $NEW && git rev-parse HEAD)"

hdr "1  ORIGINAL, run in OLD, read-only"
echo "\$ cd $OLD/beat88/understanding/u3_lowerbound && nice -n 19 python3 verify_bound.py"
( cd $OLD/beat88/understanding/u3_lowerbound && nice -n 19 python3 verify_bound.py ) | tee $TMP/orig.out
echo "[exit $?]"
echo "OLD dirty-lines after the run: $(cd $OLD && git status --porcelain | wc -l)  (must be 0)"

hdr "2  PORT, --emulate-original, matrix LOADED from NEW/spec/mixcolumns_matrix.json"
echo "\$ cd $I5 && nice -n 19 python3 verify_bound.py --target mixcolumns --emulate-original"
( cd $I5 && nice -n 19 python3 verify_bound.py --target mixcolumns --emulate-original ) | tee $TMP/port.out
echo "[exit $?]"

hdr "3  DIFF  (original stdout  vs  port stdout)"
echo "\$ diff orig.out port.out"
if diff $TMP/orig.out $TMP/port.out; then
  echo "*** NO DIFFERENCE: the port reproduces the original byte for byte. ***"
else
  echo "*** DIFFERENCES ABOVE -- CONTROL FAILED ***"
fi

hdr "4  PORT, native mode on the forward matrix (self-check + acceptance tests)"
echo "\$ cd $I5 && nice -n 19 python3 verify_bound.py --target mixcolumns"
( cd $I5 && nice -n 19 python3 verify_bound.py --target mixcolumns )
echo "[exit $?]"

hdr "5  PORT, certificate search on the forward matrix (must find |K| = 13 -> 51, M^T -> 49)"
echo "\$ cd $I5 && nice -n 19 python3 search_cert.py --target mixcolumns"
( cd $I5 && nice -n 19 python3 search_cert.py --target mixcolumns --out $TMP/certs_mixcolumns.json )
echo "[exit $?]"
echo "PUBLISHED (OLD NOTEBOOK.md sec.3):  minimum admissible |K| = 13 -> L(M) >= 51;  M^T gives only 49."

hdr "6  PORT, solver-free exhaustive ceiling on the forward matrix"
echo "(banked at $I5/runs/ceiling_mixcolumns_k13.txt)"
cat $I5/runs/ceiling_mixcolumns_k13.txt
echo
echo "PUBLISHED (OLD NOTEBOOK.md sec.3 table / METHOD_CATALOG I5):"
echo "  |K|      4  5  6  7  8  9 10 11 12 13"
echo "  max q    8 12 16 20 22 24 26 28 30 32"
echo "  bound   36 39 42 45 46 47 48 49 50 51"
echo "  'all 462,411,532 subsets of [32] of size <= 12 enumerated in C'"
echo "  sum C(32,k) for k=1..12 = 462,411,532;  this run covers sizes 0..13 = 809,785,133."
echo "  'exactly 72 admissible 13-sets' (OLD METHOD_CATALOG I8)."

hdr "7  PORT, jam census on the complete |K| = 13 layer (I7 pricing)"
cat $I5/runs/jam_mixcolumns_k13.txt
echo "PUBLISHED (OLD NOTEBOOK.md sec.4.1): 'minE = 0 for every one of the 72'."

hdr "8  PORT, maxq.c cross-validation against an independent Python reference"
cat $I5/runs/xcheck_maxq.txt

hdr "9  the published Tier-1 certificate is inside the enumerated layer"
echo "\$ grep -c '^2,8,10,13,15,18,20,21,22,23,24,29,31\$' runs/admissible_mixcolumns_k13.txt"
grep -c '^2,8,10,13,15,18,20,21,22,23,24,29,31$' $I5/runs/admissible_mixcolumns_k13.txt
echo "(1 = the certificate hardcoded at OLD verify_bound.py:22 is one of the 72 this port found independently)"

hdr "CONTROL SUMMARY"
echo "OLD dirty-lines: $(cd $OLD && git status --porcelain | wc -l)  (0 = nothing written in the read-only repo)"
