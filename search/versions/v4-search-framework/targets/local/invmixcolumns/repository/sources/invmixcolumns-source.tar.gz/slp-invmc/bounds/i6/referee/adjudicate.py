import itertools,sys
c=6; N=1<<c
V=[47,13,56,50,42,11,55,19,35,46,44,41]
def closure(S):
    A=set(1<<i for i in range(c)); todo=set(S)
    ch=True
    while ch:
        ch=False
        for s in list(todo):
            for a in A:
                if (s^a) in A and (s^a)!=a:
                    A.add(s); todo.discard(s); ch=True; break
            if s in A: continue
    return A
W=[m for m in range(N) if bin(m).count('1')>=2]
for b in range(0,4):
    found=None
    for E in itertools.combinations(W,b):
        A=closure(list(V)+list(E))
        if all(v in A for v in V): found=E;break
    print("b=",b,"witness",found)
    if found is not None: break
