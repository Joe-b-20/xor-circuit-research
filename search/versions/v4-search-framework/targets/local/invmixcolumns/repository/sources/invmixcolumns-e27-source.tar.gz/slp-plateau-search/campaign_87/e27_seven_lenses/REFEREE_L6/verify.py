"""Referee L6 -- independent mechanical verification (own code only).

Claim 1: in-place (x[t] ^= x[c]) AES MixColumns programs, 89 instructions.
Claim 2: 88-gate InvMixColumns SLPs at depth 19.
Controls: Yuan et al. 91 and Xiang et al. 92 listings.
"""
import glob
import json
import os
import re
import sys

import aes_ref as A

BASE = "~/xor_ui/slp-plateau-search/campaign_87/e27_seven_lenses"
REC = os.path.join(BASE, "L6_cnot", "records")
INV = os.path.join(BASE, "L1_matroid", "invmc_from_mc")
CIRC = "~/xor_ui/slp-invmc/circuits"

MC = {c: A.binary_rows(A.mixcolumn, c) for c in ("LSB", "MSB")}
IMC = {c: A.binary_rows(A.invmixcolumn, c) for c in ("LSB", "MSB")}


# ---------------------------------------------------------------- parsing
def parse_xor_listing(path):
    """'x[t] ^= x[c]   [y_r]' lines; '#' comments ignored. Returns ops, marks{op_index: r}."""
    ops, marks = [], {}
    pat = re.compile(r"^\s*x\[\s*(\d+)\]\s*\^=\s*x\[\s*(\d+)\]\s*(?:\[y(\d+)\])?\s*$")
    for line in open(path):
        s = line.split("#", 1)[0].rstrip()
        if not s.strip():
            continue
        m = pat.match(s)
        if not m:
            raise ValueError(f"{path}: unparsable line {line!r}")
        t, c = int(m.group(1)), int(m.group(2))
        if m.group(3) is not None:
            marks[len(ops)] = int(m.group(3))
        ops.append((t, c))
    return ops, marks


def parse_tc_listing(path):
    """'t c' or 't c r' lines (x[t] ^= x[c]; r = output marker)."""
    ops, marks = [], {}
    for line in open(path):
        f = line.split()
        if not f:
            continue
        if len(f) not in (2, 3):
            raise ValueError(f"{path}: bad line {line!r}")
        if len(f) == 3:
            marks[len(ops)] = int(f[2])
        ops.append((int(f[0]), int(f[1])))
    return ops, marks


# ---------------------------------------------------------------- in-place model
def simulate(ops, init=None, n=32):
    regs = list(init) if init is not None else [1 << i for i in range(n)]
    trace = []
    for (t, c) in ops:
        if not (0 <= t < n and 0 <= c < n):
            raise ValueError(f"register out of range in {(t, c)}")
        if t == c:
            raise ValueError(f"self-XOR x[{t}] ^= x[{t}] is not a CNOT")
        regs[t] ^= regs[c]
        trace.append(regs[t])
    return regs, trace


def asap_depth(ops, n=32):
    """Greedy ASAP layering in listed order; a register is used by at most one CNOT per layer."""
    lvl = [0] * n
    layers = []
    for (t, c) in ops:
        L = max(lvl[t], lvl[c]) + 1
        lvl[t] = lvl[c] = L
        layers.append(L)
    return (max(layers) if layers else 0), layers


def match_perm(final, rows):
    """Return perm p with final[reg] == rows[p[reg]] for all regs, or None."""
    idx = {v: i for i, v in enumerate(rows)}
    if len(idx) != len(rows):
        raise ValueError("target rows not distinct")
    p = []
    for v in final:
        if v not in idx:
            return None
        p.append(idx[v])
    if sorted(p) != list(range(len(rows))):
        return None
    return p


def check_marks(ops, marks, trace, final, rows):
    """Each marked op (t,c,[y_r]): x[t] equals output r right after the op and is never touched again."""
    bad = []
    last_write = {}
    for k, (t, c) in enumerate(ops):
        last_write[t] = k
    for k, r in marks.items():
        t = ops[k][0]
        if trace[k] != rows[r] or last_write[t] != k or final[t] != rows[r]:
            bad.append((k, ops[k], r))
    covered = sorted(marks.values())
    return bad, covered


def verify_inplace(name, ops, marks, target_name="MixColumns", conv_try=("LSB", "MSB")):
    res = {"name": name, "instructions": len(ops)}
    final, trace = simulate(ops)
    res["depth_asap"] = asap_depth(ops)[0]
    res["valid"] = {}
    for conv in conv_try:
        rows = MC[conv] if target_name == "MixColumns" else IMC[conv]
        p = match_perm(final, rows)
        res["valid"][conv] = p is not None
        if p is not None:
            bad, covered = check_marks(ops, marks, trace, final, rows)
            res.setdefault("perm", {})[conv] = p
            res.setdefault("marks_bad", {})[conv] = bad
            res.setdefault("marks_cover", {})[conv] = (len(marks), covered == list(range(32)))
            res.setdefault("identity_perm", {})[conv] = p == list(range(32))
            # reversal: registers start holding the outputs (as symbols y_r in reg t with p[t]=r),
            # reversed word must leave register i holding input x_i, i.e. InvMC row i over y.
            init = [1 << p[t] for t in range(32)]
            back, _ = simulate(list(reversed(ops)), init=init)
            inv_rows = IMC[conv] if target_name == "MixColumns" else MC[conv]
            res.setdefault("reverse_is_inverse", {})[conv] = back == inv_rows
            # and on concrete data: output values -> inputs
    return res


def roundtrip_on_values(ops, p, conv, trials=200, seed=7):
    """Concrete-data check: run the listing on bit values of random columns (not masks)."""
    import random
    rnd = random.Random(seed)
    for _ in range(trials):
        col = [rnd.randrange(256) for _ in range(4)]
        bits = [0] * 32
        for j in range(4):
            for k in range(8):
                bits[A.bitpos(j, k, conv)] = (col[j] >> k) & 1
        x = list(bits)
        for (t, c) in ops:
            x[t] ^= x[c]
        want = A.mixcolumn(col)
        wb = [0] * 32
        for j in range(4):
            for k in range(8):
                wb[A.bitpos(j, k, conv)] = (want[j] >> k) & 1
        if any(x[t] != wb[p[t]] for t in range(32)):
            return False
        # reverse on values
        y = list(x)
        for (t, c) in reversed(ops):
            y[t] ^= y[c]
        if y != bits:
            return False
    return True


# ---------------------------------------------------------------- SLP model
def verify_slp(path, target_rows):
    d = json.load(open(path))
    gates = d["gates"]
    sig = [1 << i for i in range(32)]
    dep = [0] * 32
    for k, (a, b) in enumerate(gates):
        if not (0 <= a < len(sig) and 0 <= b < len(sig)):
            raise ValueError(f"{path}: gate {k} refers to a future/unknown signal {(a, b)}")
        if a == b:
            raise ValueError(f"{path}: gate {k} XORs a signal with itself")
        sig.append(sig[a] ^ sig[b])
        dep.append(1 + max(dep[a], dep[b]))
    out_sig = []
    for r in target_rows:
        cands = [s for s in range(len(sig)) if sig[s] == r]
        if not cands:
            return {"file": os.path.basename(path), "gates": len(gates), "valid": False}
        out_sig.append(min(cands, key=lambda s: dep[s]))
    depth = max(dep[s] for s in out_sig)
    # dead-gate check (backward reachability from outputs)
    live = set()
    stack = list(out_sig)
    while stack:
        s = stack.pop()
        if s in live or s < 32:
            continue
        live.add(s)
        a, b = gates[s - 32]
        stack += [a, b]
    dead = [s for s in range(32, len(sig)) if s not in live]
    zero = [s for s in range(32, len(sig)) if sig[s] == 0]
    dup = len(sig) - len(set(sig))
    prov = d.get("provenance", {}).get("outputs")
    prov_ok = None
    if prov is not None:
        prov_ok = all(sig[int(v)] == target_rows[int(k)] for k, v in prov.items()) and len(prov) == 32
    return {"file": os.path.basename(path), "gates": len(gates), "valid": True, "depth": depth,
            "dead_gates": len(dead), "zero_signals": len(zero), "duplicate_values": dup,
            "provenance_outputs_ok": prov_ok, "all_signal_max_depth": max(dep)}


# ---------------------------------------------------------------- main
def main():
    out = {}
    print("=== Claim 1: in-place MixColumns listings (own simulator) ===")
    files = sorted(glob.glob(os.path.join(REC, "inplace8*.txt")) + glob.glob(os.path.join(REC, "inplace9*.txt")))
    files = [f for f in files if "invmixcolumns" not in f and not f.endswith(".oracle.txt")]
    for f in files:
        ops, marks = parse_xor_listing(f)
        r = verify_inplace(os.path.basename(f), ops, marks)
        conv_ok = [c for c, v in r["valid"].items() if v]
        line = f"{r['name']:34s} n={r['instructions']:3d} depthASAP={r['depth_asap']:3d} valid={r['valid']}"
        for c in conv_ok:
            line += (f" | {c}: marks={r['marks_cover'][c][0]} coverAll={r['marks_cover'][c][1]}"
                     f" badMarks={len(r['marks_bad'][c])} identityPerm={r['identity_perm'][c]}"
                     f" reverse=InvMC:{r['reverse_is_inverse'][c]}"
                     f" valuesRoundtrip={roundtrip_on_values(ops, r['perm'][c], c)}")
        print(line)
        out[r["name"]] = {k: v for k, v in r.items() if k != "perm"}
        out[r["name"]]["perm"] = r.get("perm")

    print("\n=== Claim 1b: the shipped InvMixColumns in-place listing (inplace89_A_invmixcolumns.txt) ===")
    f = os.path.join(REC, "inplace89_A_invmixcolumns.txt")
    ops, _ = parse_xor_listing(f)
    txt = open(f).read()
    m = re.search(r"R\(o\)\s*=\s*([\d\s]+)\n", txt)
    R = [int(v) for v in m.group(1).split()]
    assert sorted(R) == list(range(32)), "placement is not a permutation"
    for conv in ("LSB",):
        init = [0] * 32
        for o in range(32):
            init[R[o]] = 1 << o          # register R(o) starts with InvMC input bit o
        fin, _ = simulate(ops, init=init)
        ok = fin == IMC[conv]
        print(f"{os.path.basename(f)} n={len(ops)} depthASAP={asap_depth(ops)[0]} "
              f"[{conv}] register i ends with InvMC output bit i: {ok}")
        A_ops, _ = parse_xor_listing(os.path.join(REC, "inplace89_A.txt"))
        print(f"   is exactly the reversed word of inplace89_A.txt: {ops == list(reversed(A_ops))}")
        out["inplace89_A_invmixcolumns.txt"] = {"n": len(ops), "valid": ok, "depth_asap": asap_depth(ops)[0],
                                                "is_reverse_of_A": ops == list(reversed(A_ops))}

    print("\n=== Controls: published in-place listings ===")
    for fn in ("mixcolumns_yuan91.txt", "mixcolumns_xiang92.txt"):
        ops, marks = parse_tc_listing(os.path.join(CIRC, fn))
        r = verify_inplace(fn, ops, marks)
        conv_ok = [c for c, v in r["valid"].items() if v]
        line = f"{fn:34s} n={r['instructions']:3d} depthASAP={r['depth_asap']:3d} valid={r['valid']}"
        for c in conv_ok:
            line += (f" | {c}: marks={r['marks_cover'][c][0]} coverAll={r['marks_cover'][c][1]}"
                     f" badMarks={len(r['marks_bad'][c])} identityPerm={r['identity_perm'][c]}"
                     f" reverse=InvMC:{r['reverse_is_inverse'][c]}")
        print(line)
        out[fn] = {k: v for k, v in r.items() if k != "perm"}

    print("\n=== Claim 2: InvMixColumns SLPs (all files in invmc_from_mc/) ===")
    rows = []
    for f in sorted(glob.glob(os.path.join(INV, "invmc_from_mc*.json"))):
        r = verify_slp(f, IMC["LSB"])
        rows.append(r)
        if "depth19" in f or not r["valid"] or r["gates"] < 88:
            print(r)
    print(f"files={len(rows)} all_valid={all(r['valid'] for r in rows)} "
          f"gates={sorted(set(r['gates'] for r in rows))} "
          f"min_depth={min(r['depth'] for r in rows if r['valid'])}")
    mism = [(r["file"], r["depth"]) for r in rows if r["valid"]
            and int(re.search(r"depth(\d+)", r["file"]).group(1)) != r["depth"]]
    print(f"filename-depth mismatches: {mism}")
    out["invmc_slps"] = rows
    json.dump(out, open("verify_out.json", "w"), indent=1, default=str)


if __name__ == "__main__":
    main()
