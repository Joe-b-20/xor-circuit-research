#!/usr/bin/env python3
"""Referee re-verification of the I5 / Theorem-A certificate for InvMixColumns.
Written from the primary definitions only (FIPS-197 InvMixColumns, the
convention header of spec/invmc_matrix.json, and Theorem A as stated in
OLD/beat88/understanding/u3_lowerbound/NOTEBOOK.md sec. 2).  Nothing under
bounds/i5/*.py was read before this file was written."""
import hashlib, itertools, json, sys

SPEC = "~/xor_ui/slp-invmc/spec/invmc_matrix.json"
K_CLAIMED = [0, 5, 7, 9, 13, 14, 19]

# ---------------------------------------------------------------- GF(2^8)
def gmul(a, b, mod=0x11B):
    r = 0
    while b:
        if b & 1:
            r ^= a
        a <<= 1
        if a & 0x100:
            a ^= mod
        b >>= 1
    return r & 0xFF

def build(coef, mod=0x11B):
    """M[8*ob+obit][8*ib+ibit] = 1 iff output bit (ob,obit) depends on input bit (ib,ibit),
    out_byte[ob] = XOR_k coef[k] * in_byte[(ob+k)%4], bit i of a byte = coeff of x^i."""
    M = [[0]*32 for _ in range(32)]
    for ob in range(4):
        for k in range(4):
            ib = (ob + k) % 4
            for ibit in range(8):
                prod = gmul(coef[k], 1 << ibit, mod)      # image of basis input bit
                for obit in range(8):
                    if (prod >> obit) & 1:
                        M[8*ob+obit][8*ib+ibit] ^= 1
    return M

def rank_gf2(rows_int):
    rows = list(rows_int); r = 0
    for bit in range(31, -1, -1):
        piv = next((i for i in range(r, len(rows)) if (rows[i] >> bit) & 1), None)
        if piv is None: continue
        rows[r], rows[piv] = rows[piv], rows[r]
        for i in range(len(rows)):
            if i != r and (rows[i] >> bit) & 1: rows[i] ^= rows[r]
        r += 1
    return r

d = json.load(open(SPEC))
prov = d["provenance"]
coef, mod = prov["mds_column"], prov["modulus"]
assert coef == [0x0e, 0x0b, 0x0d, 0x09] and mod == 0x11B, (coef, mod)
Mfile = [[int(ch) for ch in row] for row in d["rows"]]
Mmine = build(coef, mod)
print("[1] matrix rebuilt from GF(2^8)/0x11B, coef", [hex(c) for c in coef])
print("    entrywise equal to spec rows:", Mmine == Mfile)
assert Mmine == Mfile
# also confirm it is the inverse of forward MixColumns [2,3,1,1] over GF(2)
Mf = build([2, 3, 1, 1], mod)
prod = [[sum(Mmine[i][k] & Mf[k][j] for k in range(32)) & 1 for j in range(32)] for i in range(32)]
print("    M_inv * M_fwd == I over GF(2):", all(prod[i][j] == (i == j) for i in range(32) for j in range(32)))
masks = [sum(Mmine[r][c] << c for c in range(32)) for r in range(32)]
print("    masks_hex match:", [hex(m) for m in masks] == d["masks_hex"])
print("    rank:", rank_gf2(masks), " density:", sum(map(sum, Mmine)),
      " row weights:", sorted(set(sum(r) for r in Mmine)),
      " col weights:", sorted(set(sum(Mmine[r][c] for r in range(32)) for c in range(32))))
sha_variants = {
    "join('')": hashlib.sha256("".join(d["rows"]).encode()).hexdigest(),
    "join('\\n')": hashlib.sha256("\n".join(d["rows"]).encode()).hexdigest(),
    "join('\\n')+nl": hashlib.sha256(("\n".join(d["rows"]) + "\n").encode()).hexdigest(),
    "json.dumps(rows)": hashlib.sha256(json.dumps(d["rows"]).encode()).hexdigest(),
}
hit = [k for k, v in sha_variants.items() if v == prov["rows_sha256"]]
print("    rows_sha256 header reproduced by:", hit if hit else "NONE of " + ", ".join(sha_variants))

# ---------------------------------------------------------------- Theorem A hypothesis
def restricted(K):
    return [sum(Mmine[r][c] << i for i, c in enumerate(K)) for r in range(32)]

def admissible(K):
    R = restricted(K)
    return len(set(R)) == 32 and min(bin(x).count("1") for x in R) >= 2

R = restricted(K_CLAIMED)
w = [bin(x).count("1") for x in R]
print("\n[2] certificate K =", K_CLAIMED, "|K| =", len(K_CLAIMED))
print("    restricted rows (as |K|-bit ints):", R)
print("    pairwise distinct:", len(set(R)) == 32, " #distinct =", len(set(R)))
print("    weight histogram:", {k: w.count(k) for k in sorted(set(w))}, " min =", min(w))
print("    every column of M nonzero (Lemma 1 hypothesis at every zeroing step):",
      all(any(Mmine[r][c] for r in range(32)) for c in range(32)))
print("    admissible:", admissible(K_CLAIMED))
print("    ==> Theorem A: L(M_inv) >= (32 - %d) + 32 = %d" % (len(K_CLAIMED), 64 - len(K_CLAIMED)))

# ---------------------------------------------------------------- exhaustive small k
print("\n[3] exhaustive admissibility census (Python, independent of the C run)")
for k in range(1, int(sys.argv[1]) + 1 if len(sys.argv) > 1 else 7):
    cnt = 0; tot = 0; first = None
    for K in itertools.combinations(range(32), k):
        tot += 1
        if admissible(K):
            cnt += 1
            if first is None: first = K
    print("    k=%d: %8d subsets, admissible = %d%s" % (k, tot, cnt, ("  first=" + str(first)) if first else ""))
    print("       counting cap: 2^k-k-1 = %d weight>=2 vectors in F2^%d (need 32)" % (2**k - k - 1, k))
