#!/usr/bin/env python3
"""ceiling.py -- driver for maxq.c: the solver-free exhaustive ceiling of I5.

Loads the target from NEW/spec/*.json (provenance re-derived and self-checked by
i5_core), hands the 32 row masks to ./maxq, and prints the per-size max-q table
together with the ceiling argument:

    Theorem A (generalised)  L(M) >= max_K [(32-|K|) + q(M|_K)],  q <= 32
    =>  any K with |K| >= k0 gives at most 64 - k0
    =>  a certificate of size k0 is OPTIMAL for the technique as soon as every
        size < k0 has been enumerated and none of them reaches 64 - k0.

Usage:
    python3 ceiling.py --target invmc --kmax 8
    python3 ceiling.py --target mixcolumns --kmax 12 --dump-size 13
"""
import argparse
import json
import os
import subprocess
import sys
import time

import i5_core as core

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--target', default='invmc')
    ap.add_argument('--kmax', type=int, required=True)
    ap.add_argument('--dump-size', type=int, default=-1)
    ap.add_argument('--dump-file', default=None)
    a = ap.parse_args()

    t = core.load(a.target)
    print("=" * 78)
    print("I5 exhaustive ceiling (maxq.c)   target=%s   kmax=%d" % (t.key, a.kmax))
    print("=" * 78)
    core.rederive_and_compare(t)
    core.selfcheck(t)
    print()

    masks = ','.join('0x%08x' % r for r in t.rows)
    cmd = [os.path.join(HERE, 'maxq'), str(a.kmax), masks]
    if a.dump_size >= 0:
        df = a.dump_file or os.path.join(HERE, 'runs', 'admissible_%s_k%d.txt' % (t.key, a.dump_size))
        cmd += [str(a.dump_size), df]
    print("cmd: %s %d <32 masks from %s>%s"
          % (cmd[0], a.kmax, os.path.basename(t.path),
             (' %d %s' % (a.dump_size, cmd[4])) if a.dump_size >= 0 else ''))
    t0 = time.time()
    r0 = os.times()
    out = subprocess.run(cmd, capture_output=True, text=True)
    r1 = os.times()
    cpu = (r1.children_user - r0.children_user) + (r1.children_system - r0.children_system)
    sys.stdout.write(out.stdout)
    if out.returncode:
        sys.stderr.write(out.stderr)
        return out.returncode
    print("cpu_seconds %.2f   wall_seconds %.2f" % (cpu, time.time() - t0))

    # ---- the ceiling argument, spelled out from the table just printed
    rows = [l.split() for l in out.stdout.splitlines() if l and not l.startswith('#')]
    best = max(int(x[3]) for x in rows)
    bestk = [int(x[0]) for x in rows if int(x[3]) == best][0]
    print()
    print("-- ceiling argument " + "-" * 57)
    print("  enumerated sizes 0..%d exhaustively; best (32-k)+q there = %d at k = %d"
          % (a.kmax, best, bestk))
    print("  for every k > %d:   (32-k) + q <= (32-k) + 32 = %d - k < %d"
          % (a.kmax, 64, 64 - a.kmax))
    cap = 64 - (a.kmax + 1)
    print("  i.e. sizes >= %d are capped at %d" % (a.kmax + 1, cap))
    if best >= cap:
        print("  => the EXACT optimum of Theorem A on this matrix is %d, attained at |K| = %d"
              % (best, bestk))
    else:
        print("  => NOT yet decided: the cap %d exceeds the enumerated best %d; raise --kmax"
              % (cap, best))
    print()
    return 0 if core.acceptance(t, best) else 2


if __name__ == '__main__':
    sys.exit(main())
