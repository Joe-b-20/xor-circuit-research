#!/usr/bin/env python3
"""|IN| -- the Lemma-1 mask universe (F28 / U6 Lemma 1): all masks of weight >= 2
contained in the support of some target.  Port of
slp-plateau-search/fleet7/laneUNCOND/code/ulib.py:universe(), retargeted to a
target-mask file.  Forward control must print 1648.

Usage: python3 tools/mask_universe.py spec/<target_masks>.json
"""
import json, sys, time
from itertools import combinations

path = sys.argv[1]
J = json.load(open(path))
T = list(J["target_masks"])
t0 = time.time()
U = set()
for t in T:
    bits = [1 << i for i in range(32) if (t >> i) & 1]
    for k in range(2, len(bits) + 1):
        for c in combinations(bits, k):
            m = 0
            for x in c:
                m |= x
            U.add(m)
secs = time.time() - t0
W = [bin(t).count("1") for t in T]
hist = {}
for m in U:
    w = bin(m).count("1"); hist[w] = hist.get(w, 0) + 1
print("target file: %s  (%s)" % (path, J.get("provenance", {}).get("name")))
print("row-weight histogram:", {w: W.count(w) for w in sorted(set(W))})
print("|IN| = %d   (%.1fs)" % (len(U), secs))
print("by weight:", dict(sorted(hist.items())))
print(json.dumps({"ev": "mask_universe", "target": path, "IN": len(U),
                  "by_weight": dict(sorted(hist.items())), "secs": round(secs, 1)}))
