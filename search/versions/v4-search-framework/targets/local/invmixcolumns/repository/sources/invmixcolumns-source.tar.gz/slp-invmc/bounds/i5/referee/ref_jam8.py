#!/usr/bin/env python3
"""Free-closure 'jam' over a dumped layer of admissible keep-sets (referee check of runs/jam_*.txt and i7_pricing_probe.txt).
jam = number of restricted rows NOT reachable by greedy XOR-closure from the |K| unit inputs."""
import json, sys, re
d=json.load(open('~/xor_ui/slp-invmc/spec/invmc_matrix.json')); M=[[int(c) for c in r] for r in d['rows']]
sets=[ [int(x) for x in re.search(r'\[(.*)\]', l).group(1).split(',')] for l in open(sys.argv[1]) if 'admissible: [' in l]
from collections import Counter
jam=Counter(); w3=0
for K in sets:
    R=[sum(M[r][c]<<i for i,c in enumerate(K)) for r in range(32)]
    assert len(set(R))==32 and min(bin(x).count('1') for x in R)>=2
    if min(bin(x).count('1') for x in R)>=3: w3+=1
    V=set(R); avail=set(1<<i for i in range(len(K))); ch=True
    while ch:
        ch=False
        for v in V-avail:
            if any((v^a) in avail for a in avail): avail.add(v); ch=True
    jam[len(V-avail)]+=1
print("layer %s: %d keep-sets of size %d" % (sys.argv[1], len(sets), len(sets[0])))
print("  jam distribution:", dict(sorted(jam.items())))
print("  jam=32 (no restricted row derivable, i.e. all restricted weights >= 3):", jam[32], " [cross-check via min weight>=3:", w3, "]")
print("  jam>=30:", sum(v for j,v in jam.items() if j>=30))
