/* Referee exhaustive census of Theorem-A-admissible column sets K for the
   32x32 GF(2) matrix in spec/invmc_matrix.json.  K admissible iff the 32 rows
   restricted to K are pairwise distinct and each has weight >= 2.
   Usage: ref_exhaust <rows-file> <k> [dumpall]   (rows-file: 32 lines of 32 chars '0'/'1') */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned col[32];      /* col[c] bit r = M[r][c] */
static int k, cnt_adm, K[32], maxq=-1, maxqK[32], dumpall=0;
static long long tot;
static void check(void){
    unsigned rowv[32]; static unsigned char seen[1<<16]; memset(seen,0,1u<<k);
    tot++;
    for(int r=0;r<32;r++) rowv[r]=0;
    for(int i=0;i<k;i++){ unsigned c=col[K[i]]; for(int r=0;r<32;r++) if((c>>r)&1) rowv[r]|=1u<<i; }
    int q=0, adm=1;
    for(int r=0;r<32;r++){ unsigned v=rowv[r]; if(__builtin_popcount(v)<2){adm=0;continue;} if(seen[v]){adm=0;continue;} seen[v]=1; q++; }
    if(q>maxq){maxq=q; memcpy(maxqK,K,sizeof(int)*k);}
    if(!adm) return;
    cnt_adm++;
    if(dumpall || cnt_adm<=64){ printf("  admissible: ["); for(int i=0;i<k;i++) printf("%d%s",K[i],i+1<k?", ":""); printf("]\n"); }
}
static void rec(int pos,int start){
    if(pos==k){ check(); return; }
    for(int c=start;c<=32-(k-pos);c++){ K[pos]=c; rec(pos+1,c+1); }
}
int main(int argc,char**argv){
    if(argc<3){fprintf(stderr,"usage\n");return 2;}
    FILE*f=fopen(argv[1],"r"); if(!f){perror("open");return 2;}
    char line[64]; int r=0;
    while(r<32 && fgets(line,sizeof line,f)){ if(strlen(line)<32) continue; for(int c=0;c<32;c++) if(line[c]=='1') col[c]|=1u<<r; r++; }
    fclose(f); if(r!=32){fprintf(stderr,"bad rows\n");return 2;}
    k=atoi(argv[2]); if(argc>3) dumpall=1; if(k<1||k>16){fprintf(stderr,"k in 1..16\n");return 2;}
    rec(0,0);
    printf("k=%d: subsets=%lld admissible=%d  max_q=%d  (32-k)+max_q=%d  argmax=[",k,tot,cnt_adm,maxq,32-k+maxq);
    for(int i=0;i<k;i++) printf("%d%s",maxqK[i],i+1<k?",":""); printf("]\n");
    return 0;
}
