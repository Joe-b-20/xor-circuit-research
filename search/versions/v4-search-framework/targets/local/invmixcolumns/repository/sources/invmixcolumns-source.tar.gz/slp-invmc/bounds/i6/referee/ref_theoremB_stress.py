#!/usr/bin/env python3
"""Adversarial stress of Theorem B's machinery, from primary definitions.

T1  Lemma 3 + minE vs EXACT minimum SLP size.
    Claim under test:  L_c(V) == |V| + minE_c(V)   for V a set of distinct
    weight->=2 masks over c inputs.  L_c is computed by plain IDDFS over the
    RAW model (any gate = XOR of any two available signals; duplicate masks,
    weight-1 masks and zero masks all allowed) -- i.e. WITHOUT any of Lemma 3's
    normalisation.  minE is computed by dumb enumeration of extra-sets.
    A single case with L < |V| + minE would refute Theorem B.

T2  Lemma 3' (projection).  V supported inside K subset [n].  Claim under test:
    minE_n(V) >= minE_K(V)  -- i.e. the |n-K| dead dimensions cannot help.
    Both sides by dumb enumeration.  A single case with minE_n < minE_K would
    refute the step from Lemma 3 (32 inputs) to the |K|-input computation.
"""
import itertools, random, sys

def closure(c, V, E):
    """honest greedy closure: available starts at the c inputs; an element of
    V u E is added only when it is the XOR of two ALREADY-available signals."""
    A = set(1 << i for i in range(c))
    todo = list(V) + list(E)
    ch = True
    while ch:
        ch = False
        for s in todo:
            if s in A: continue
            for a in A:
                if (s ^ a) in A:
                    A.add(s); ch = True; break
    return A

def minE(c, V, maxb=4, pool=None):
    if pool is None:
        pool = [m for m in range(1 << c) if bin(m).count('1') >= 2]
    for b in range(0, maxb + 1):
        for E in itertools.combinations(pool, b):
            A = closure(c, V, E)
            if all(v in A for v in V):
                return b
    return None

def exactL(c, V, maxg=8):
    """exact minimum #gates in the RAW SLP model."""
    tgt = set(V)
    def dfs(avail, budget):
        rem = tgt - avail
        if not rem: return True
        if len(rem) > budget: return False
        al = sorted(avail)
        for i in range(len(al)):
            for j in range(i + 1, len(al)):
                m = al[i] ^ al[j]
                if m in avail: continue
                if dfs(avail | {m}, budget - 1): return True
        return False
    base = frozenset(1 << i for i in range(c))
    for g in range(0, maxg + 1):
        if dfs(set(base), g): return g
    return None

random.seed(20260908)
print("T1: exact L vs |V| + minE  (raw-model IDDFS vs extras enumeration)")
bad = 0; n = 0; hist = {}
for c in (4, 5):
    W = [m for m in range(1 << c) if bin(m).count('1') >= 2]
    for nv in (3, 4, 5):
        for t in range(60):
            V = random.sample(W, nv)
            e = minE(c, V, maxb=4)
            L = exactL(c, V, maxg=8)
            n += 1
            if e is None or L is None: continue
            hist[e] = hist.get(e, 0) + 1
            if L != nv + e:
                bad += 1
                print("  MISMATCH c=%d V=%s  exactL=%d  |V|+minE=%d" % (c, V, L, nv + e))
print("  cases=%d  mismatches=%d  minE hist=%s" % (n, bad, sorted(hist.items())))

print("T2: Lemma 3' projection   minE_n(V) >= minE_K(V) ?")
bad2 = 0; n2 = 0; strict = 0; hist2 = {}
for (nn, ck) in ((5, 3), (6, 3), (6, 4), (7, 4)):
    Wk = [m for m in range(1 << ck) if bin(m).count('1') >= 2]
    Wn = [m for m in range(1 << nn) if bin(m).count('1') >= 2]
    for t in range(40):
        K = sorted(random.sample(range(nn), ck))
        nv = min(len(Wk), random.choice([3, 4, 5]))
        Vk = random.sample(Wk, nv)
        # embed into F2^n along K
        emb = lambda m: sum(((m >> i) & 1) << K[i] for i in range(ck))
        Vn = [emb(m) for m in Vk]
        ek = minE(ck, Vk, maxb=3, pool=Wk)
        en = minE(nn, Vn, maxb=3, pool=Wn)
        n2 += 1
        hist2[(ek, en)] = hist2.get((ek, en), 0) + 1
        if ek is None or en is None: continue
        if en < ek:
            bad2 += 1
            print("  LEMMA-3' VIOLATION n=%d K=%s Vk=%s  minE_n=%d < minE_K=%d" % (nn, K, Vk, en, ek))
        if en > ek: strict += 1
print("  cases=%d  violations=%d  (strictly larger over n: %d)  (minE_K,minE_n) hist=%s"
      % (n2, bad2, strict, sorted(hist2.items(), key=lambda x: str(x))))
