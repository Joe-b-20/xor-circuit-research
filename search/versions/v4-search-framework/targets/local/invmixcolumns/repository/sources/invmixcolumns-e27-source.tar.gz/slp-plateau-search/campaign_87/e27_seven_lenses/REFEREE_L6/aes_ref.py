"""Referee L6 -- independent AES reference (written from FIPS-197 only).

GF(2^8) with the AES polynomial x^8+x^4+x^3+x+1 (0x11B), the S-box built from
inversion + affine map, full AES-128 cipher / inverse cipher, and the 32x32
binary matrices of MixColumns / InvMixColumns on one column.

Bit convention used for the binary matrices (convention "LSB"):
    index 8*j + k  <->  bit k (coefficient of x^k, value 2^k) of byte j of the column,
    bytes j = 0..3 are rows 0..3 of one state column (column-major state).
Convention "MSB" (index 8*j + (7-k)) is provided as an alternative.
"""

POLY = 0x11B


def xtime(a):
    a <<= 1
    if a & 0x100:
        a ^= POLY
    return a & 0xFF


def gmul(a, b):
    r = 0
    while b:
        if b & 1:
            r ^= a
        a = xtime(a)
        b >>= 1
    return r


def ginv(a):
    if a == 0:
        return 0
    # a^254
    r, e, base = 1, 254, a
    while e:
        if e & 1:
            r = gmul(r, base)
        base = gmul(base, base)
        e >>= 1
    return r


def rotl8(x, n):
    return ((x << n) | (x >> (8 - n))) & 0xFF


SBOX = []
for _a in range(256):
    _b = ginv(_a)
    SBOX.append(_b ^ rotl8(_b, 1) ^ rotl8(_b, 2) ^ rotl8(_b, 3) ^ rotl8(_b, 4) ^ 0x63)
INV_SBOX = [0] * 256
for _a in range(256):
    INV_SBOX[SBOX[_a]] = _a

MC_COEF = (0x02, 0x03, 0x01, 0x01)
IMC_COEF = (0x0E, 0x0B, 0x0D, 0x09)


def col_mul(coef, col):
    """b_i = sum_j coef[(j - i) mod 4] * a_j  (FIPS-197 eq. 5.6 / 5.10)."""
    out = []
    for i in range(4):
        acc = 0
        for j in range(4):
            acc ^= gmul(coef[(j - i) % 4], col[j])
        out.append(acc)
    return out


def mixcolumn(col):
    return col_mul(MC_COEF, col)


def invmixcolumn(col):
    return col_mul(IMC_COEF, col)


# ---------------- AES-128 (FIPS-197) ----------------
RCON = [0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1B, 0x36]


def key_expansion(key):
    w = [list(key[4 * i:4 * i + 4]) for i in range(4)]
    for i in range(4, 44):
        t = list(w[i - 1])
        if i % 4 == 0:
            t = t[1:] + t[:1]
            t = [SBOX[b] for b in t]
            t[0] ^= RCON[i // 4 - 1]
        w.append([w[i - 4][k] ^ t[k] for k in range(4)])
    return w


def to_state(block):
    # state[r][c] = in[r + 4c]
    return [[block[r + 4 * c] for c in range(4)] for r in range(4)]


def from_state(s):
    return bytes(s[r][c] for c in range(4) for r in range(4))


def add_round_key(s, w, rnd):
    for c in range(4):
        for r in range(4):
            s[r][c] ^= w[4 * rnd + c][r]


def sub_bytes(s, box):
    for r in range(4):
        for c in range(4):
            s[r][c] = box[s[r][c]]


def shift_rows(s):
    for r in range(4):
        s[r] = s[r][r:] + s[r][:r]


def inv_shift_rows(s):
    for r in range(4):
        s[r] = s[r][-r:] + s[r][:-r] if r else s[r]


def mix_columns(s, f):
    for c in range(4):
        col = f([s[r][c] for r in range(4)])
        for r in range(4):
            s[r][c] = col[r]


def encrypt(block, key):
    w = key_expansion(key)
    s = to_state(block)
    add_round_key(s, w, 0)
    for rnd in range(1, 10):
        sub_bytes(s, SBOX)
        shift_rows(s)
        mix_columns(s, mixcolumn)
        add_round_key(s, w, rnd)
    sub_bytes(s, SBOX)
    shift_rows(s)
    add_round_key(s, w, 10)
    return from_state(s)


def decrypt(block, key):
    w = key_expansion(key)
    s = to_state(block)
    add_round_key(s, w, 10)
    for rnd in range(9, 0, -1):
        inv_shift_rows(s)
        sub_bytes(s, INV_SBOX)
        add_round_key(s, w, rnd)
        mix_columns(s, invmixcolumn)
    inv_shift_rows(s)
    sub_bytes(s, INV_SBOX)
    add_round_key(s, w, 0)
    return from_state(s)


# ---------------- binary matrices ----------------
def bitpos(j, k, conv):
    return 8 * j + (k if conv == "LSB" else 7 - k)


def binary_rows(f, conv="LSB"):
    """rows[o] = 32-bit mask over input indices: output bit o = XOR of those inputs."""
    rows = [0] * 32
    for j in range(4):
        for k in range(8):
            col = [0, 0, 0, 0]
            col[j] = 1 << k
            out = f(col)
            i_in = bitpos(j, k, conv)
            for jo in range(4):
                for ko in range(8):
                    if (out[jo] >> ko) & 1:
                        rows[bitpos(jo, ko, conv)] |= 1 << i_in
    return rows


def apply_rows(rows, col, conv="LSB"):
    """Evaluate the binary matrix on a byte column (for linearity cross-checks)."""
    xin = 0
    for j in range(4):
        for k in range(8):
            if (col[j] >> k) & 1:
                xin |= 1 << bitpos(j, k, conv)
    out = [0, 0, 0, 0]
    for jo in range(4):
        for ko in range(8):
            if bin(rows[bitpos(jo, ko, conv)] & xin).count("1") & 1:
                out[jo] |= 1 << ko
    return out


def matmul_rows(A, B):
    """(A*B) where A,B given as row masks (row i of A = mask over columns); returns rows of A*B."""
    out = []
    for i in range(32):
        acc = 0
        a = A[i]
        for k in range(32):
            if (a >> k) & 1:
                acc ^= B[k]
        out.append(acc)
    return out


IDENTITY = [1 << i for i in range(32)]
