# Independent re-derivation of InvMixColumns as 32x32 GF(2) matrix.
# From provenance header only: field GF(2^8)/0x11B, mds_column [14,11,13,9],
# circulant: out_byte[col] = XOR_k coef[k]*in_byte[(col+k)%4]
# index: out_row = 8*out_byte + out_bit ; in_col = 8*in_byte + in_bit ; LSB-first bit order.
import json, hashlib

MOD = 0x11B
def gmul(a,b):
    r=0
    while b:
        if b&1: r^=a
        b>>=1
        a<<=1
        if a&0x100: a^=MOD
    return r

coef=[14,11,13,9]
M=[[0]*32 for _ in range(32)]
for col in range(4):            # output byte index
    for k in range(4):
        c=coef[k]
        ib=(col+k)%4            # input byte index
        # linear map x -> c*x over GF(2^8), LSB-first bit matrix
        for inbit in range(8):
            y=gmul(c, 1<<inbit)
            for outbit in range(8):
                if (y>>outbit)&1:
                    M[8*col+outbit][8*ib+inbit]^=1
rows=[''.join(str(M[r][c]) for c in range(32)) for r in range(32)]
h=hashlib.sha256(''.join(rows).encode()).hexdigest()
spec=json.load(open('~/xor_ui/slp-invmc/spec/invmc_matrix.json'))
same = rows==spec['rows']
print("my rows_sha256(concat) =",h)
print("spec rows_sha256 field =",spec['provenance']['rows_sha256'])
print("ENTRYWISE MATCH:", same)
if not same:
    for i,(a,b) in enumerate(zip(rows,spec['rows'])):
        if a!=b: print("row",i,"mine",a,"spec",b)
print("density mine",sum(r.count('1') for r in rows),"spec",spec['density'])
# rank
import copy
B=[int(r[::-1],2) for r in rows]   # not needed for rank orientation
def rank(vs):
    vs=list(vs); r=0
    for b in range(32):
        p=None
        for i in range(r,len(vs)):
            if (vs[i]>>b)&1: p=i;break
        if p is None: continue
        vs[r],vs[p]=vs[p],vs[r]
        for i in range(len(vs)):
            if i!=r and (vs[i]>>b)&1: vs[i]^=vs[r]
        r+=1
    return r
print("rank",rank(B))
json.dump({"rows":rows},open('~/xor_ui/slp-invmc/bounds/i6/referee/ref_matrix.json','w'))
