#!/usr/bin/env python3
"""i5_core.py -- target loading, provenance re-derivation, and the Theorem-A
primitives for the ported I5 column-zeroing lower bound.

PORTED FROM (read-only reference, never modified):
    OLD/beat88/understanding/u3_lowerbound/verify_bound.py   (the verifier)
    OLD/atlas/thinktank/proofside_code/mc.py                 (restrict/keepset_ok)
    OLD/atlas/thinktank/proofside_code/admis.py              (SAT keep-set search)
  where OLD = ~/xor_ui/slp-plateau-search

WHAT CHANGED IN THE PORT
  * The target matrix is NEVER typed in.  It is loaded from NEW/spec/*.json and
    INDEPENDENTLY RE-DERIVED here from the JSON's own declared `mds_column`
    using GF(2^8)/0x11B arithmetic; the two are compared entry by entry, and the
    sha256 of the row bitstrings is compared to the provenance header.
  * verify_bound.py:86-88 were three UNCONDITIONAL MixColumns tripwires
        assert rw.count(5) == 20 and rw.count(7) == 12
        assert cw.count(5) == 28 and cw.count(11) == 4
        assert sum(rw) == 184
    They are REPLACED (not deleted) by `selfcheck()` below, which carries one
    unconditional tripwire block PER TARGET (see TRIPWIRES) plus checks that are
    derived from the loaded file itself (declared row_weights / density /
    rank_gf2 vs recomputed).  The inverse gets its own weight profile
    {11:8, 13:8, 15:4, 17:4, 19:8}, 472 ones, rank 32.

CONVENTION (identical to NEW/spec/derive_invmc.py and to OLD's mc.py):
    row index r  = 8*out_byte + out_bit ;  column index c = 8*in_byte + in_bit
    mask(r) = OR_c M[r][c] << c   (a 32-bit int; bit c = input index c)
"""
import hashlib
import json
import os
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
SPEC = os.path.abspath(os.path.join(HERE, '..', '..', 'spec'))

TARGETS = {
    'invmc': 'invmc_matrix.json',
    'mixcolumns': 'mixcolumns_matrix.json',
}

# Unconditional per-target tripwires.  These REPLACE verify_bound.py:86-88.
# Keyed by provenance.name, so the wrong file under the right flag aborts.
TRIPWIRES = {
    'aes_inv_mixcolumns': {
        'mds_column': [14, 11, 13, 9],
        'row_weights': {11: 8, 13: 8, 15: 4, 17: 4, 19: 8},
        'col_weights': {11: 20, 19: 4, 21: 4, 23: 4},
        'ones': 472,
        'rank': 32,
        'ub_label': 'L(M_inv) <= 91 in hand (circuits/invmc_yuan91.json, '
                    '91 gates, depth 27, oracle-VALID)',
        'ub': 91,
    },
    'aes_mixcolumns': {
        'mds_column': [2, 3, 1, 1],
        'row_weights': {5: 20, 7: 12},
        'col_weights': {5: 28, 11: 4},
        'ones': 184,
        'rank': 32,
        'ub_label': 'L(M) <= 88 (five verified 88-gate circuits).',
        'ub': 88,
    },
}

AES_MODULUS = 0x11B


# ------------------------------------------------------------------ GF(2^8)
def xtime(a):
    a <<= 1
    return (a ^ AES_MODULUS) & 0xFF if (a & 0x100) else (a & 0xFF)


def gf_mul(a, b):
    r = 0
    for i in range(8):
        if (b >> i) & 1:
            t = a
            for _ in range(i):
                t = xtime(t)
            r ^= t
    return r & 0xFF


def build_matrix(coef):
    """32x32 GF(2) matrix of the circulant byte map with column `coef`.
    out_byte[col] = XOR_k coef[k] * in_byte[(col+k)%4]."""
    M = [[0] * 32 for _ in range(32)]
    for col in range(4):
        for k in range(4):
            c, ib = coef[k], (col + k) % 4
            for in_bit in range(8):
                v = gf_mul(c, 1 << in_bit)
                for out_bit in range(8):
                    if (v >> out_bit) & 1:
                        M[col * 8 + out_bit][ib * 8 + in_bit] ^= 1
    return M


def matrix_to_masks(M):
    return [sum(1 << c for c in range(32) if M[r][c]) for r in range(32)]


def masks_to_matrix(masks):
    return [[(m >> c) & 1 for c in range(32)] for m in masks]


def gf2_rank(masks):
    rows = list(masks)
    rank = 0
    for bit in range(32):
        p = next((i for i in range(rank, len(rows)) if (rows[i] >> bit) & 1), None)
        if p is None:
            continue
        rows[rank], rows[p] = rows[p], rows[rank]
        for i in range(len(rows)):
            if i != rank and (rows[i] >> bit) & 1:
                rows[i] ^= rows[rank]
        rank += 1
    return rank


# ------------------------------------------------------------------- loading
class Target(object):
    def __init__(self, key, doc, path):
        self.key = key
        self.doc = doc
        self.path = path
        self.name = doc['provenance']['name']
        self.rows = [int(x, 16) for x in doc['masks_hex']]
        self.M = masks_to_matrix(self.rows)


def load(key):
    """Load a target by short key ('invmc' / 'mixcolumns') or by path."""
    path = os.path.join(SPEC, TARGETS[key]) if key in TARGETS else os.path.abspath(key)
    doc = json.load(open(path))
    t = Target(key if key in TARGETS else doc['provenance']['name'], doc, path)
    return t


def rederive_and_compare(t, say=print):
    """Rebuild the matrix from the JSON's declared mds_column and compare.

    Three independent agreements are required:
      (a) rebuilt-from-GF(2^8) == the file's `rows` bitstrings, entry by entry;
      (b) the file's `masks_hex` == masks of the file's `rows`;
      (c) sha256 of the row bitstrings == provenance.rows_sha256.
    """
    p = t.doc['provenance']
    coef = p['mds_column']
    assert p['modulus'] == AES_MODULUS, 'unexpected field modulus %r' % (p['modulus'],)
    Mr = build_matrix(coef)
    mismatch = sum(1 for r in range(32) for c in range(32) if Mr[r][c] != t.M[r][c])
    rows_str = [''.join(str(b) for b in row) for row in t.M]
    file_rows = t.doc['rows']
    masks_ok = (matrix_to_masks(t.M) == t.rows)
    sha = hashlib.sha256('\n'.join(rows_str).encode()).hexdigest()
    sha_ok = (sha == p['rows_sha256'])
    rows_ok = (rows_str == file_rows)
    say("target %-10s  %s" % (t.key, t.path))
    say("  provenance : %s  |  mds_column %s  |  modulus 0x%03X" % (p['name'], coef, p['modulus']))
    say("  re-derived from GF(2^8) and compared entrywise : %s (%d differing entries)"
        % ('PASS' if mismatch == 0 else 'FAIL', mismatch))
    say("  file rows == matrix rows                       : %s" % ('PASS' if rows_ok else 'FAIL'))
    say("  file masks_hex == masks(rows)                  : %s" % ('PASS' if masks_ok else 'FAIL'))
    say("  sha256(rows) == provenance.rows_sha256         : %s  %s"
        % ('PASS' if sha_ok else 'FAIL', sha[:16] + '...'))
    ok = (mismatch == 0) and rows_ok and masks_ok and sha_ok
    assert ok, 'PROVENANCE RE-DERIVATION FAILED for %s' % t.key
    return ok


def selfcheck(t, say=print):
    """REPLACEMENT for verify_bound.py:86-88.

    Per-target unconditional tripwires (TRIPWIRES[name]) + agreement between the
    recomputed profile and the profile the spec file declares about itself.
    """
    rows = t.rows
    cols = [sum(((rows[r] >> c) & 1) << r for r in range(32)) for c in range(32)]
    rw = Counter(bin(r).count('1') for r in rows)
    cw = Counter(bin(c).count('1') for c in cols)
    ones = sum(bin(r).count('1') for r in rows)
    rank = gf2_rank(rows)
    tw = TRIPWIRES[t.name]

    say("  row-weight histogram    : %s" % dict(sorted(rw.items())))
    say("  column-weight histogram : %s" % dict(sorted(cw.items())))
    say("  ones in the matrix      : %d" % ones)
    say("  GF(2) rank              : %d" % rank)
    say("  rows pairwise distinct  : %s   columns distinct and nonzero : %s"
        % (len(set(rows)) == 32, len(set(cols)) == 32 and all(cols)))

    checks = [
        ('row-weight histogram == tripwire %s' % (tw['row_weights'],),
         dict(rw) == tw['row_weights']),
        ('column-weight histogram == tripwire %s' % (tw['col_weights'],),
         dict(cw) == tw['col_weights']),
        ('ones == %d' % tw['ones'], ones == tw['ones']),
        ('rank == %d (full)' % tw['rank'], rank == tw['rank']),
        ('mds_column == %s' % (tw['mds_column'],),
         t.doc['provenance']['mds_column'] == tw['mds_column']),
        ('declared row_weights == recomputed',
         list(t.doc['row_weights']) == [bin(r).count('1') for r in rows]),
        ('declared density == recomputed', t.doc['density'] == ones),
        ('declared rank_gf2 == recomputed', t.doc['rank_gf2'] == rank),
        ('rows pairwise distinct', len(set(rows)) == 32),
        ('columns distinct and nonzero', len(set(cols)) == 32 and all(cols)),
    ]
    bad = [c for c, v in checks if not v]
    for c, v in checks:
        say("  [%s] %s" % ('OK' if v else '!!', c))
    assert not bad, 'SELF-CHECK FAILED for %s: %s' % (t.key, bad)
    return {'row_weights': dict(rw), 'col_weights': dict(cw), 'ones': ones, 'rank': rank}


# --------------------------------------------------------- Theorem-A toolkit
def restrict(rows, K):
    """M|_K re-indexed onto |K| coordinates (bit i of the result = column K[i])."""
    return [sum(1 << i for i, c in enumerate(K) if (r >> c) & 1) for r in rows]


def popcount(x):
    return bin(x).count('1')


def q_value(rows, K):
    """q(M|_K) = number of DISTINCT rows of M|_K of weight >= 2."""
    rr = restrict(rows, K)
    return len({v for v in rr if popcount(v) >= 2})


def cols_outside_nonzero(rows, K):
    """Theorem-A hypothesis: every column of M OUTSIDE K is nonzero.

    A zeroing step on an all-zero column removes no gate, so without this
    hypothesis Theorem A is false (explicit 4-input counterexample in
    referee/REFEREE_REPORT.md sec. 2.6).  It holds for M_inv -- and for any
    invertible matrix -- since the minimum column weight is 11.
    Returns (ok, number of columns outside K, min weight over those columns).
    """
    ks = set(K)
    outside = [c for c in range(32) if c not in ks]
    w = [sum((r >> c) & 1 for r in rows) for c in outside]
    return (all(x > 0 for x in w), len(outside), min(w) if w else 0)


def keepset_ok(rows, K):
    """Theorem-A row hypothesis: the 32 rows of M|_K are pairwise distinct and
    each has weight >= 2.  Equivalent to q(M|_K) == 32.  The third hypothesis
    (every column outside K nonzero) is cols_outside_nonzero(); it is vacuous on
    both targets here, whose columns all have weight >= 5."""
    rr = restrict(rows, K)
    return len(set(rr)) == 32 and min(popcount(v) for v in rr) >= 2


def theorem_a_bound(K):
    return (32 - len(K)) + 32


# ------------------------------------------------------- acceptance tests (P5)
def acceptance(t, bound, say=print):
    """PHASE2_PLAN sec.4 P5.  Printed by EVERY tool that emits a bound.

    A bound above the target's known upper bound is a BUG, not a discovery.
    A bound below 32 means the port is not doing anything.
    """
    tw = TRIPWIRES[t.name]
    a1, a2 = bound <= tw['ub'], bound >= 32
    say("-- acceptance tests (PHASE2_PLAN sec.4 P5) " + "-" * 35)
    say("  [%s] emitted bound %d <= %d  (a bound above the known upper bound is a BUG)"
        % ('PASS' if a1 else 'FAIL', bound, tw['ub']))
    say("  [%s] emitted bound %d >= 32 (below 32 the port is doing nothing)"
        % ('PASS' if a2 else 'FAIL', bound))
    say("  [PASS] matrix self-check (row/col weight histogram, ones, full rank)")
    say("  upper bound for comparison: %s" % tw['ub_label'])
    if not (a1 and a2):
        say("ACCEPTANCE TEST FAILED -- stop and debug (P5)")
        return False
    say("ALL ACCEPTANCE TESTS PASS")
    return True
