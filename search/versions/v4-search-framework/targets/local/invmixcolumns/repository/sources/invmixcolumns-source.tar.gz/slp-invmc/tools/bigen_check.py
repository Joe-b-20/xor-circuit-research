#!/usr/bin/env python3
"""Bi-generation check (slp-plateau-search e27, lane L1): read each InvMixColumns circuit in the
coordinates of the MixColumns INPUTS x (InvMixColumns input y_i is the MixColumns row m_i, so a
signal with y-mask u is the point XOR_{i in u} m_i) and test whether the same point set is
triangle-generated from the unit vectors e_j, i.e. is ALSO a MixColumns circuit with the same gate
count (the 32 InvMixColumns inputs become the 32 MixColumns outputs, and vice versa).

Usage:  python3 tools/bigen_check.py [circuit.json ...]     (default: every circuits/invmc_*.json)
"""
import glob, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from verify_slp_generic import load_target
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MC, _, _ = load_target(os.path.join(HERE, 'spec/mixcolumns_matrix.json'))
INV, _, _ = load_target(os.path.join(HERE, 'spec/invmc_matrix.json'))

def to_x(u):
    x = 0
    for i in range(32):
        if u >> i & 1: x ^= MC[i]
    return x

def generated(S, basis):
    avail = set(basis); rest = set(S) - avail; ch = True
    while ch and rest:
        ch = False
        for p in list(rest):
            if any((p ^ a) in avail for a in avail): avail.add(p); rest.discard(p); ch = True
    return not rest

files = sys.argv[1:] or sorted(glob.glob(os.path.join(HERE, 'circuits/invmc_*.json')))
units = [1 << j for j in range(32)]
for f in files:
    d = json.load(open(f)); g = d['gates'] if isinstance(d, dict) else d
    vals = [1 << i for i in range(32)]
    for a, b in g: vals.append(vals[a] ^ vals[b])
    inv_ok = all(t in set(vals) for t in INV)
    S = set(to_x(u) for u in vals)
    mc_ok = generated(S, units) and set(MC) <= S
    print(f"{os.path.basename(f):52s} gates={len(g):4d} valid_InvMixColumns={inv_ok} also_MixColumns={mc_ok}")
