| label | PID | engine | cap | seed |
| v1_walk_yuan91 | 2406741 | walk | none | seeds/invmc_yuan91.json |
| v2_lns_cascade91 | 2406742 | lns | none | seeds/invmc_cascade_91_depth14.json |
| v3_alt_bp97 | 2406743 | alt | none | seeds/invmc_bp5ub2_97_depth22.json |
