#!/usr/bin/env python3
"""Stress test of Theorem A (column-zeroing bound) against EXACT L computed by BFS
over mask-sets -- exactly the 2-input XOR SLP model with cancellation and free fan-out.
n inputs, targets = sets of nonzero masks in F2^n.  For every target T and every
column set K, if Theorem A's hypothesis holds (rows restricted to K pairwise
distinct, all weight >= 2) then (n-|K|) + |T| must be <= L(T).
Also tests the generalized form  (n-|K|) + #distinct weight>=2 restricted rows,
under the chain hypothesis (every column j outside K lies in some row whose
K-restriction has weight >= 2), which the notebook does NOT claim but which the
same proof gives; and, as a NEGATIVE control, the generalized form WITHOUT the
chain hypothesis, which should be violated somewhere."""
import itertools, random, sys
from collections import deque

def bfs(n, maxd):
    inputs = [1 << i for i in range(n)]
    start = 0
    for m in inputs: start |= 1 << m          # state = bitset over masks 0..2^n-1
    dist = {start: 0}; q = deque([start])
    while q:
        S = q.popleft(); d = dist[S]
        if d == maxd: continue
        av = [m for m in range(1, 1 << n) if (S >> m) & 1]
        for a, b in itertools.combinations(av, 2):
            m = a ^ b
            if (S >> m) & 1: continue
            S2 = S | (1 << m)
            if S2 not in dist:
                dist[S2] = d + 1; q.append(S2)
    return dist

def exactL(dist, T, maxd):
    tb = 0
    for m in T: tb |= 1 << m
    best = maxd + 1
    for S, d in dist.items():
        if d < best and (S & tb) == tb: best = d
    return best   # maxd+1 means "> maxd"

def restrict(T, K):
    return [sum(((m >> c) & 1) << i for i, c in enumerate(K)) for m in T]

def boundA(T, n):
    """Theorem A as stated: all rows distinct & weight>=2 after restriction."""
    best = 0; arg = None
    for k in range(1, n + 1):
        for K in itertools.combinations(range(n), k):
            R = restrict(T, K)
            nz = all(any((m >> j) & 1 for m in T) for j in range(n) if j not in K)   # proof uses: zeroed columns are nonzero in M
            if nz and len(set(R)) == len(T) and all(bin(x).count("1") >= 2 for x in R):
                b = (n - k) + len(T)
                if b > best: best, arg = b, K
    return best, arg

def boundGen(T, n, chain):
    best = 0; arg = None
    for k in range(0, n + 1):
        for K in itertools.combinations(range(n), k):
            R = restrict(T, K)
            heavy = [x for x in R if bin(x).count("1") >= 2]
            q = len(set(heavy))
            if chain:
                ok = all(any(((m >> j) & 1) and bin(r).count("1") >= 2 for m, r in zip(T, R)) for j in range(n) if j not in K)
                if not ok: continue
            b = (n - k) + q
            if b > best: best, arg = b, K
    return best, arg

random.seed(int(sys.argv[3]) if len(sys.argv) > 3 else 1)
n = int(sys.argv[1]); maxd = int(sys.argv[2])
dist = bfs(n, maxd)
print("n=%d  BFS states within %d gates: %d" % (n, maxd, len(dist)))
masks = list(range(1, 1 << n))
viol_A = viol_G = viol_noc = 0; tested = 0; tight = 0
targets = []
if n <= 4:
    for m in range(1, 7):
        targets += list(itertools.combinations(masks, m))
else:
    for _ in range(int(sys.argv[4]) if len(sys.argv) > 4 else 400):
        m = random.randint(1, 6); targets.append(tuple(random.sample(masks, m)))
for T in targets:
    L = exactL(dist, T, maxd)
    if L > maxd: continue   # exact L unknown; cannot adjudicate
    bA, KA = boundA(T, n); bG, KG = boundGen(T, n, True); bN, KN = boundGen(T, n, False)
    tested += 1
    if bA > L: viol_A += 1; print("VIOLATION Theorem A: T=%s K=%s bound=%d L=%d" % (T, KA, bA, L))
    if bG > L: viol_G += 1; print("VIOLATION generalized(chain): T=%s K=%s bound=%d L=%d" % (T, KG, bG, L))
    if bN > L and viol_noc < 3: print("  (expected) negative control violated: T=%s K=%s bound=%d L=%d" % (T, KN, bN, L))
    if bN > L: viol_noc += 1
    if bA == L and bA > 0: tight += 1
print("targets tested=%d  TheoremA violations=%d  generalized(chain) violations=%d  tight(A)=%d  negative-control violations=%d"
      % (tested, viol_A, viol_G, tight, viol_noc))
