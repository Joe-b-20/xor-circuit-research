/* brute.c -- ASSUMPTION-FREE decision of `minE_K <= d` by exhaustion over the
 * WHOLE ambient mask space.  I6 / Theorem B (OLD NOTEBOOK.md sec. 2b).
 *
 * WHAT IT DOES.  minE_K(V) = min |E| over E with V u E realizable, E drawn from
 * the masks of weight >= 2.  This program enumerates EVERY subset E of the full
 * pool  W \ V,  W = { m in F2^k : wt(m) >= 2 },  with |E| <= maxdepth, and tests
 * realizability of G = V u E.  That is the definition, verbatim.
 *
 * WHAT IT DOES NOT USE.  None of the five completeness steps of NOTEBOOK
 * sec. 2b -- greedy-closure-WLOG, "the next extra is a pairsum of avail", the
 * last-level restriction, memoisation, weight-<=1 exclusion.  In particular the
 * candidate set at every level is the WHOLE pool, not the pairsums of the
 * current avail, so a bug in the notebook's branching argument cannot hide here.
 * The forward project could not afford this check: at |K| = 14 the pool has
 * 16 337 elements and C(16337,3) = 7.3e11.  At |K| = 8 it has 215 and at
 * |K| = 9 it has 470, so C(470,3) = 1.7e7.
 *
 * The ONE theorem used is that greedy decides realizability: if the greedy
 * fixpoint of G misses some g in G, then in any legal ordering the first missed
 * element has both operands earlier, hence in the fixpoint, hence it would have
 * been taken.  So greedy misses nothing.
 *
 * TRAP (a real bug that a first version of this file had, caught by
 * disagreement with brute_check.py).  An extra is NOT free: it is an element of
 * G and must itself be the XOR of two earlier available masks.  A version that
 * commits extras unconditionally reports, e.g. for the |K|=8 keep-set
 * [0,3,4,5,6,7,14,17], that the single extra 82 completes -- it does not, 82 has
 * weight 3 and nothing of weight 3 is constructible from 8 inputs alone.  Here
 * a committed extra goes into `pend` alongside the targets and becomes available
 * only when it is derivable; a later extra can unlock an earlier stuck one.
 *
 * usage: brute <k> <t0,..,t31> <maxdepth>
 *   exit 0 / "result=NONE"       no E with |E| <= maxdepth makes V u E realizable
 *   exit 1 / "result=COMPLETION" one does (that E has size <= maxdepth; run with
 *                                increasing maxdepth to read minE off exactly)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#define MAXPEND 128

static int K, NMASK, NT;
static uint32_t TGT[64];
static unsigned char *inav;       /* membership of `avail`                    */
static uint32_t *avail;           /* derived masks: inputs + derived G-elements*/
static int navail;
static uint32_t pend[MAXPEND];    /* elements of G not yet derived            */
static int npend;
static uint32_t *pool;            /* W \ V                                    */
static int npool;
static long long subsets = 0, closures = 0;
static uint32_t wit[8];
static int witlen = -1;

static int popc(uint32_t x) { return __builtin_popcount(x); }

/* Greedy fixpoint: move every element of `pend` that is the XOR of two
 * currently available masks into `avail`, repeating until nothing moves. */
static void close_fix(void)
{
    int changed = 1;
    while (changed && npend) {
        changed = 0;
        closures++;
        for (int i = 0; i < npend; i++) {
            uint32_t g = pend[i];
            for (int j = 0; j < navail; j++) {
                uint32_t x = g ^ avail[j];
                if (x && inav[x]) {
                    inav[g] = 1; avail[navail++] = g;
                    pend[i] = pend[--npend];
                    i--; changed = 1;
                    break;
                }
            }
        }
    }
}

/* enumerate every E of size <= depth drawn from pool[start..], each set once */
static int rec(int start, int depth, int lvl)
{
    if (npend == 0) { witlen = lvl; return 1; }     /* every element of G derived */
    if (depth == 0) return 0;
    int mark = navail, pmark = npend;
    uint32_t savepend[MAXPEND];
    memcpy(savepend, pend, sizeof(uint32_t) * npend);
    for (int p = start; p < npool; p++) {
        uint32_t e = pool[p];
        subsets++;
        pend[npend++] = e;                          /* an extra is NOT free */
        close_fix();
        if (rec(p + 1, depth - 1, lvl + 1)) { wit[lvl] = e; return 1; }
        for (int i = mark; i < navail; i++) inav[avail[i]] = 0;
        navail = mark;
        npend = pmark;
        memcpy(pend, savepend, sizeof(uint32_t) * npend);
    }
    return 0;
}

int main(int argc, char **argv)
{
    if (argc < 4) { fprintf(stderr, "usage: %s k t0,..,t31 maxdepth\n", argv[0]); return 2; }
    K = atoi(argv[1]); NMASK = 1 << K;
    char *p = argv[2]; int n = 0;
    while (*p && n < 64) { TGT[n++] = (uint32_t)strtoul(p, &p, 10); if (*p == ',') p++; }
    NT = n;
    int maxdepth = atoi(argv[3]);
    if (maxdepth > 7) { fprintf(stderr, "maxdepth > 7 not supported\n"); return 2; }

    inav = calloc(NMASK, 1);
    avail = malloc(sizeof(uint32_t) * (NMASK + 64));

    /* Theorem-A hypotheses on the residual rows, re-checked here */
    for (int i = 0; i < NT; i++) {
        if (popc(TGT[i]) < 2) { fprintf(stderr, "target of weight < 2\n"); return 3; }
        for (int j = i + 1; j < NT; j++)
            if (TGT[i] == TGT[j]) { fprintf(stderr, "targets not distinct\n"); return 3; }
    }

    pool = malloc(sizeof(uint32_t) * NMASK);
    npool = 0;
    for (uint32_t m = 1; m < (uint32_t)NMASK; m++) {
        if (popc(m) < 2) continue;
        int isT = 0;
        for (int t = 0; t < NT; t++) if (TGT[t] == m) { isT = 1; break; }
        if (!isT) pool[npool++] = m;
    }

    navail = 0; npend = 0;
    for (int i = 0; i < K; i++) { inav[1u << i] = 1; avail[navail++] = 1u << i; }
    for (int t = 0; t < NT; t++) pend[npend++] = TGT[t];
    close_fix();
    int jam = npend;

    int r = rec(0, maxdepth, 0);
    printf("k=%d ntargets=%d ambient=%d pool=%d jam=%d maxdepth=%d "
           "extra_sets=%lld closure_passes=%lld result=%s\n",
           K, NT, NMASK, npool, jam, maxdepth, subsets, closures,
           r ? "COMPLETION" : "NONE");
    if (r) { printf("  completion with %d extra(s):", witlen);
             for (int i = 0; i < witlen; i++) printf(" %u", wit[i]);
             printf("   => minE <= %d\n", witlen); }
    else   printf("  => minE >= %d  (exhaustive over every extra-set of size <= %d "
                  "drawn from the full %d-element pool)\n", maxdepth + 1, maxdepth, npool);
    return r ? 1 : 0;
}
