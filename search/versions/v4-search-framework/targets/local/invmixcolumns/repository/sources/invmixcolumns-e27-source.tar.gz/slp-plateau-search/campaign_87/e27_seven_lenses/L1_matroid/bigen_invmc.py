#!/usr/bin/env python3
"""Turn a bi-generated MixColumns value set (S = I u U with <O> = S in Gamma(S)) into an
InvMixColumns SLP and verify it independently.

Coordinates: the inverse program's inputs are y_0..y_31 (signal r <-> MC output point
TARGETS[r]); it must produce x_i (point 1<<i). A point p (mask over x) is the linear form
p.x = (p^T Minv) y, so signal values are replayed as masks over y and checked against the
rows of Minv rebuilt here from GF(2^8) (coefficients 0e 0b 0d 09).
usage: bigen_invmc.py IDX [IDX ...]   (indices into masks.bin)
"""
import sys, json, os, subprocess
import numpy as np
from lib import TARGETS, INPUTS, REPO, LANE, _gf_mul

OUTDIR = os.path.join(LANE, "invmc_from_mc")


def circ_masks(coef):
    M = [[0] * 32 for _ in range(32)]
    for col in range(4):
        for k in range(4):
            c, ib = coef[k], (col + k) % 4
            for in_bit in range(8):
                v = _gf_mul(c, 1 << in_bit)
                for out_bit in range(8):
                    if (v >> out_bit) & 1:
                        M[col * 8 + out_bit][ib * 8 + in_bit] ^= 1
    return [sum(1 << c for c in range(32) if M[r][c]) for r in range(32)]


MINV = circ_masks([0x0E, 0x0B, 0x0D, 0x09])
assert circ_masks([2, 3, 1, 1]) == TARGETS


def matmul_rows(A, B):
    """rows-as-masks product: (A B) row r = XOR of B rows selected by A row r."""
    out = []
    for a in A:
        s = 0
        for c in range(32):
            if (a >> c) & 1:
                s ^= B[c]
        out.append(s)
    return out


assert matmul_rows(MINV, TARGETS) == INPUTS, "Minv * M != I"


def gen_order(S, base):
    """BFS levels of the triangle closure of base inside S; returns list of (p, a, b, level)."""
    level = {v: 0 for v in base}
    order = []
    rem = set(S) - set(base)
    d = 0
    while rem:
        d += 1
        new = []
        for v in sorted(rem):
            for a in sorted(level):
                if level[a] < d and (v ^ a) in level and level[v ^ a] < d:
                    new.append((v, a, v ^ a))
                    break
        if not new:
            return None
        for v, a, b in new:
            level[v] = d
            order.append((v, a, b, d))
            rem.discard(v)
    return order


def build(U):
    S = set(INPUTS) | set(U)
    order = gen_order(S, TARGETS)
    if order is None:
        return None
    idx = {TARGETS[r]: r for r in range(32)}
    gates = []
    for v, a, b, d in order:
        gates.append([idx[a], idx[b]])
        idx[v] = 32 + len(gates) - 1
    # independent replay in y-coordinates
    sig = [1 << r for r in range(32)]
    for a, b in gates:
        sig.append(sig[a] ^ sig[b])
    ok = all(sig[idx[1 << i]] == MINV[i] for i in range(32))
    depth = max(d for *_, d in order)
    outputs = {str(i): idx[1 << i] for i in range(32)}
    return {"gates": gates, "ok": ok, "depth": depth, "outputs": outputs}


if __name__ == "__main__":
    os.makedirs(OUTDIR, exist_ok=True)
    mm = np.memmap(f"{REPO}/wrapup/day2/deletion_cert/masks.bin", dtype="<u4", mode="r").reshape(-1, 88)
    oracle = os.path.expanduser("~/xor_ui/slp-invmc/tools/verify_slp_generic.py")
    spec = os.path.expanduser("~/xor_ui/slp-invmc/spec/invmc_matrix.json")
    summary = []
    for s in sys.argv[1:]:
        i = int(s)
        U = set(int(x) for x in mm[i])
        r = build(U)
        if r is None:
            print(i, "not bi-generated"); continue
        path = os.path.join(OUTDIR, f"invmc_from_mc88_idx{i}_depth{r['depth']}.json")
        json.dump({"gates": r["gates"], "provenance": {
            "construction": "MixColumns 88 value set masks.bin[%d] re-generated from its output basis O "
                            "(triangle closure in Gamma(S)); L1 lane e27" % i,
            "gates": len(r["gates"]), "depth": r["depth"], "outputs": r["outputs"],
            "outputs_note": "output bit i (x_i) is held by signal outputs[i]"}},
            open(path, "w"))
        v = subprocess.run([sys.executable, oracle, "--target", spec, path],
                           capture_output=True, text=True)
        last = [l for l in v.stdout.splitlines() if l.strip()][-3:]
        print(i, "gates", len(r["gates"]), "depth", r["depth"], "own-replay", r["ok"],
              "| oracle:", " / ".join(last), "exit", v.returncode)
        summary.append({"idx": i, "gates": len(r["gates"]), "depth": r["depth"],
                        "own_replay_ok": r["ok"], "oracle_exit": v.returncode, "oracle": last,
                        "file": os.path.basename(path)})
    json.dump(summary, open(os.path.join(OUTDIR, "summary.json"), "w"), indent=1)
