#!/usr/bin/env python3
"""cnfsize.py -- closed form for dslp.build_cnf's CNF size, validated against
the encoder itself.  Symmetry ON, no implied clauses (they are budget-capped at
IMPLIED_BUDGET = 60,000 and, measured, contribute ZERO at r >= 16 -- see the
memo).  D is the depth cap (None = uncapped).
"""
import sys


def C2(n):
    return n * (n - 1) // 2


def sizes(r, m, k, T, D=None):
    P = [C2(m + i) for i in range(k)]
    nv = 2 * sum(P) + k * r + r * C2(k) + (k - 1) + k * T
    if D:
        nv += k * (D - 1)
    cl = k                                    # one-hot at-least-one
    cl += sum(3 * p - 2 for p in P)           # prefix-sum chain
    for i in range(k):                        # XOR definition, per bit-plane
        cl += r * (C2(m) * 1 + m * i * 2 + C2(i) * 4)
    for i in range(k):                        # N1/N2 symmetry
        cl += 1 + m + i * (2 * r + 1)
    for i in range(1, k):                     # N3 lex chain
        cl += P[i] + 1
    cl += T * (1 + k * r) + k                 # target coverage + used-gate
    if D:                                     # monotone + operand level clauses
        cl += k * max(D - 2, 0)
        cl += sum(2 * p * (D + 1) for p in P)  # upper bound, both operands
    return nv, cl


if __name__ == '__main__':
    # validation against measured build_cnf output (uncapped, this repo's runs)
    obs = [(8, 8, 6, 4, 813, 6152), (8, 8, 8, 4, 1335, 10505),
           (8, 8, 9, 4, 1652, 13307), (8, 8, 10, 4, 2009, 16574),
           (12, 12, 6, 4, 1473, 29126), (12, 12, 8, 4, 2311, 38305),
           (12, 12, 10, 4, 3349, 50020)]
    print('validation (uncapped, symmetry on, implied clauses excluded)')
    print('  r  m  k   nv_obs  nv_frm   cl_obs  cl_frm  cl_frm/cl_obs')
    for r, m, k, T, nv, cl in obs:
        a, b = sizes(r, m, k, T)
        print('%3d %2d %2d %8d %7d %8d %7d   %.3f' % (r, m, k, nv, a, cl, b, b / cl))
    print()
    BLK = [('fwd', 0, 8, 8, 7), ('fwd', 1, 12, 12, 9), ('fwd', 2, 8, 8, 7),
           ('fwd', 3, 12, 12, 9), ('fwd', 4, 12, 12, 9), ('fwd', 5, 8, 8, 7),
           ('fwd', 6, 8, 8, 7), ('fwd', 7, 8, 8, 7),
           ('inv', 0, 16, 16, 13), ('inv', 1, 20, 20, 15), ('inv', 2, 20, 20, 15),
           ('inv', 3, 28, 28, 21), ('inv', 4, 28, 28, 21), ('inv', 5, 24, 24, 19),
           ('inv', 6, 20, 20, 17), ('inv', 7, 16, 16, 13)]
    print('CNF size at the L1 ladder start k = lb  (T = 4, D = 5)')
    print(' set j   r  m  lb        nv       clauses')
    for w, j, r, m, lb in BLK:
        nv, cl = sizes(r, m, lb, 4, 5)
        print('%4s %d %3d %2d %3d %9d %13d' % (w, j, r, m, lb, nv, cl))
