#!/usr/bin/env bash
# K2 (Lemma R / Theorem T2) tripwire -- L1 controls.  Every one can fail.
#
#   a) FORWARD POSITIVE  the MixColumns circuits the forward project reports as
#      K2-compressible (laneDELTA/lemmaR_hits_nonsample.json) must compress and
#      oracle again, here, through the ported code.  Target: the FORWARD matrix.
#   b) FORWARD NEGATIVE  the five published MixColumns 88s must show 0 hits.
#   c) PLANTED POSITIVE  one redundant gate added to this repo's InvMixColumns
#      88 must be detected and removed, giving an oracle-VALID 88 back.
#   d) INVERSE NEGATIVE  the unplanted 88 must show 0 hits.
#   e) K1 CROSS-CHECK    the planted 89 must be INVISIBLE to tripwire_B, i.e.
#      K2 is strictly stronger than K1 on this defect.
set -u
cd "$(dirname "$0")/.."
OLD=~/xor_ui/slp-plateau-search
Q=$OLD/campaign_87/wave5_2026-08-04/burn/mutant_cluster/quarantine_misplaced
OUT=${K2_OUTDIR:-<tmp>/k2_out}
K2="nice -n 19 python3 tools/tripwire_K2.py"

echo "############ K2 CONTROLS  $(date -u +%Y-%m-%dT%H:%M:%SZ) ############"
echo "tool: tools/tripwire_K2.py   oracle: tools/verify_slp_generic.py"
echo

echo "===== (a) FORWARD POSITIVE CONTROL ====================================="
echo "8 circuits named by OLD/experiments/e17_pure/laneDELTA/lemmaR_hits_nonsample.json"
echo "(3 x 89 gates, 5 x 90 gates), plus OLD/evidence/circuits' 89/91/92/97."
$K2 --target spec/mixcolumns_matrix.json --outdir "$OUT" \
    $Q/BREAKTHROUGH_89gates_mutant_cluster_stock_b88_d00_extract_20260808T2055{12,13,14}Z.json \
    $Q/BREAKTHROUGH_90gates_mutant_cluster_stock_b88_d00_extract_20260808T2055{14,17,18,20,22}Z.json \
    $OLD/evidence/circuits/mixcolumns_89gates_depth5.json \
    $OLD/evidence/circuits/mixcolumns_91gates_depth4.json \
    $OLD/evidence/circuits/mixcolumns_92gates_depth4.json \
    $OLD/evidence/circuits/mixcolumns_97gates_depth3.json
echo "exit=$?  (1 == hits == PASS for a positive control)"
echo

echo "===== (b) FORWARD NEGATIVE CONTROL ====================================="
echo "the five published MixColumns 88s -- must be silent."
$K2 --target spec/mixcolumns_matrix.json --outdir "$OUT" \
    $OLD/evidence/circuits/mixcolumns_88gates_*.json
echo "exit=$?  (0 == clean == PASS for a negative control)"
echo

echo "===== (c) PLANTED POSITIVE ON THE INVERSE =============================="
echo "plant: re-associate c = a^b through a NEW gate x = a1^b, c := x^a2,"
echo "with a = a1^a2 kept alive by a second consumer.  +1 gate, mask-identical."
$K2 --target spec/invmc_matrix.json --outdir "$OUT" \
    --plant circuits/invmc_walk_88_depth33.json \
    --plant-out controls/K2_plant89_invmc.json
echo "plant exit=$?"
$K2 --target spec/invmc_matrix.json --outdir "$OUT" controls/K2_plant89_invmc.json
echo "exit=$?  (1 == hit == PASS)"
echo "round-trip: is the recovered 88 the same circuit as the original 88?"
nice -n 19 python3 - <<'PY'
import json, sys, glob
sys.path.insert(0, "tools")
from verify_slp_generic import load_index_pairs
def masks(p):
    g = load_index_pairs(json.load(open(p)))
    s = [1 << i for i in range(32)]
    for a, b in g: s.append(s[a] ^ s[b])
    return set(s[32:])
import os
out = os.environ.get("K2_OUTDIR", "<tmp>/k2_out")
rec = sorted(glob.glob(out + "/K2_K2_plant89_invmc_*_89to88.json"))
orig = masks("circuits/invmc_walk_88_depth33.json")
for r in rec:
    m = masks(r)
    print(f"   {os.path.basename(r)}: |masks|={len(m)}  "
          f"identical to the original 88: {m == orig}")
PY
echo

echo "===== (d) INVERSE NEGATIVE CONTROL ====================================="
$K2 --target spec/invmc_matrix.json --outdir "$OUT" \
    circuits/invmc_walk_88_depth33.json
echo "exit=$?  (0 == clean == PASS)"
echo

echo "===== (e) K1 CROSS-CHECK ON THE PLANT =================================="
echo "the same planted 89 through tripwire_B (K1).  If K1 is silent, K2 caught"
echo "a defect K1 provably cannot see."
nice -n 19 python3 tools/tripwire_B.py --target spec/invmc_matrix.json \
    controls/K2_plant89_invmc.json
echo "exit=$?  (0 == B clean == K1 SILENT)"
echo
echo "############ END K2 CONTROLS ############"
