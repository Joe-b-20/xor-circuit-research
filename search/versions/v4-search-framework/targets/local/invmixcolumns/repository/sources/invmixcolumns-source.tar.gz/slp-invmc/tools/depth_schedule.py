#!/usr/bin/env python3
"""depth_schedule.py -- the two depths of a circuit, reported separately.

(a) DEPTH AS TRANSCRIBED.  The longest input-to-output path in the SSA-
    unrolled DAG exactly as the circuit is written: replay the gate list,
    d(gate) = 1 + max(d(parents)), inputs at 0.  Reported over ALL gates and,
    separately, over the 32 output signals only (they differ iff the circuit
    carries dead gates deeper than every output).

(b) ASAP LEAST-FIXPOINT MINIMUM DEPTH OVER THE SAME MASK SET.  A port of
    `min_depth_schedule`, fleet8/unified/code/assemble.py:91 (read in full;
    the loop, the level bookkeeping, the `not closed` error and the emitted
    gate/order construction are reproduced, with the 32 hardcodes replaced by
    n_inputs and a dead-gate/duplicate accounting added).

    It re-derives the circuit level by level FROM THE SET OF MASKS: level L is
    exactly the masks of the set expressible as an XOR of two masks already
    settled at level < L.  Nothing can be produced earlier than that, so this
    is the provable minimum depth of ANY circuit whose gates carry exactly
    this mask set -- hence (b) <= (a) always, and (b) is a property of the
    SET, not of the writing order.

    Two accounting facts this makes visible and that the caller must be told:
      * the mask SET de-duplicates.  If the transcribed circuit builds the
        same mask twice, the rescheduled circuit has strictly fewer gates.
      * the rescheduled circuit keeps every mask of the set, dead ones
        included, so its gate count is |set| - n_inputs, not len(gates).

The rescheduled circuit is emitted in the oracle's encoding A so that the
ORACLE, not this file, is what says it is correct.

usage:
  depth_schedule.py --target spec/invmc_matrix.json C.json [--emit C_asap.json]
"""
import argparse
import datetime
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from verify_slp_generic import load_target, load_index_pairs, Refused


def min_depth_schedule(masks, n_in, on_level=None):
    """(gates, depth, order).  Raises ValueError if the set is not closed.
    Port of fleet8/unified/code/assemble.py:91."""
    S = list(dict.fromkeys(masks))
    inputs = [1 << i for i in range(n_in)]
    for m in inputs:
        assert m in S, "input singleton missing"
    rest = [m for m in S if m not in set(inputs)]
    settled = {m: 0 for m in inputs}
    by_level = {0: list(inputs)}
    remaining = set(rest)
    parents = {}
    level = 0
    while remaining:
        level += 1
        avail = list(settled.keys())
        xor_index = {}
        for i in range(len(avail)):
            ai = avail[i]
            for j in range(i + 1, len(avail)):
                x = ai ^ avail[j]
                if x in remaining and x not in xor_index:
                    xor_index[x] = (ai, avail[j])
        if not xor_index:
            raise ValueError(f"mask set not closed: {len(remaining)} unreachable")
        newly = list(xor_index)
        for m in newly:
            parents[m] = xor_index[m]
            settled[m] = level
            remaining.discard(m)
        by_level[level] = newly
        if on_level is not None:
            on_level(level, len(newly), len(remaining))
    order = list(inputs)
    for L in range(1, level + 1):
        order.extend(sorted(by_level.get(L, [])))
    idx = {m: i for i, m in enumerate(order)}
    gates = [[idx[parents[m][0]], idx[parents[m][1]]] for m in order[n_in:]]
    return gates, max(settled.values()), order


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", required=True)
    ap.add_argument("circuit")
    ap.add_argument("--emit", default=None)
    a = ap.parse_args()

    try:
        spec, n_in, info = load_target(a.target)
    except Refused as e:
        print(f"REFUSED target {a.target}: {e}")
        sys.exit(3)

    doc = json.load(open(a.circuit))
    pairs = load_index_pairs(doc)

    # ---------------------------------------------------- (a) as transcribed
    sig = [1 << i for i in range(n_in)]
    dep = [0] * n_in
    for x, y in pairs:
        sig.append(sig[x] ^ sig[y])
        dep.append(max(dep[x], dep[y]) + 1)
    d_all = max(dep)
    # depth over the outputs only: for each target, the shallowest signal
    # carrying it (that is what an input-to-OUTPUT path means)
    best = {}
    for i, m in enumerate(sig):
        if m in set(spec) and (m not in best or dep[i] < best[m]):
            best[m] = dep[i]
    missing = [j for j, m in enumerate(spec) if m not in best]
    d_out = max(best.values()) if not missing else None

    gate_masks = sig[n_in:]
    n_gates = len(pairs)
    n_distinct = len(set(gate_masks))
    dup = n_gates - n_distinct
    live = set()
    for i in range(len(sig) - 1, n_in - 1, -1):
        if sig[i] in set(spec) or i in live:
            live.add(i)
            live.add(pairs[i - n_in][0]); live.add(pairs[i - n_in][1])
    dead = sum(1 for i in range(n_in, len(sig)) if i not in live)

    print(f"circuit={a.circuit}")
    print(f"target={info['name']} inputs={n_in}")
    print(f"(a) depth AS TRANSCRIBED           = {d_all}   "
          f"[over all {n_gates} gates]")
    print(f"(a') depth as transcribed, outputs = {d_out}   "
          f"[longest input-to-output path]")
    print(f"    gates={n_gates}  distinct gate masks={n_distinct}  "
          f"duplicate-mask gates={dup}  dead gates={dead}")

    # ------------------------------------------- (b) ASAP over the same set
    allmasks = [1 << i for i in range(n_in)] + gate_masks
    gates, d_asap, order = min_depth_schedule(allmasks, n_in)
    print(f"(b) ASAP least-fixpoint MIN DEPTH  = {d_asap}   "
          f"[same mask set, {len(gates)} gates]")
    if len(gates) != n_gates:
        print(f"    !! the rescheduled circuit has {len(gates)} gates, "
              f"{n_gates - len(gates)} FEWER than as transcribed "
              f"(duplicate masks de-duplicated by the set)")

    if a.emit:
        idx = {m: i for i, m in enumerate(order)}
        outs = {}
        for j, m in enumerate(spec):
            if m not in idx:
                print(f"    !! target {j} not in the mask set")
                sys.exit(1)
            outs[str(j)] = idx[m]
        src = doc.get("provenance", {})
        out = {
            "provenance": {
                "produced_by": "tools/depth_schedule.py (ASAP least-fixpoint "
                               "reschedule; port of min_depth_schedule, "
                               "fleet8/unified/code/assemble.py:91)",
                "produced_utc": datetime.datetime.now(datetime.timezone.utc)
                                .strftime("%Y-%m-%dT%H:%M:%SZ"),
                "rescheduled_from": os.path.relpath(a.circuit),
                "mask_set": "identical to the source circuit's, de-duplicated",
                "depth_of_source_as_transcribed": d_all,
                "asap_depth": d_asap,
                "note": "the gate SET is unchanged; only the schedule is. "
                        "No mask was added, removed or hand-edited.",
                "source_provenance": src,
            },
            "gateCount": len(gates),
            "depth": d_asap,
            "gates": gates,
            "outputs": outs,
        }
        json.dump(out, open(a.emit, "w"), indent=1)
        print(f"    wrote {a.emit}  ({len(gates)} gates, depth {d_asap})")


if __name__ == "__main__":
    main()
