#!/usr/bin/env python3
"""verify_bound.py -- ported I5 / Theorem-A certificate verifier.

PORT OF  OLD/beat88/understanding/u3_lowerbound/verify_bound.py
         (OLD = ~/xor_ui/slp-plateau-search, read-only)

Theorem A.  If K is a set of columns such that every column of M OUTSIDE K is
NONZERO and the 32 rows of M restricted to K are pairwise DISTINCT and each of
weight >= 2, then any 2-input-XOR
straight-line program computing M uses at least (32 - |K|) + 32 gates.
(The nonzero-column hypothesis is necessary: referee/REFEREE_REPORT.md sec. 2.6.
 It holds for M_inv, min column weight 11.)
(Proof restated in README.md; the original is OLD/.../u3_lowerbound/NOTEBOOK.md
 sec. 2, adversarially refereed in PROOFCHECK.md.)

Differences from the original, all forced by the port:
  * --target selects the matrix; it is LOADED from NEW/spec/*.json and
    re-derived from the file's own declared mds_column (i5_core).  Nothing is
    typed in.  The SAME code runs on both matrices.
  * the original's lines 86-88 (unconditional MixColumns weight tripwires) are
    replaced by i5_core.selfcheck(), which carries a tripwire block per target.
  * acceptance tests (PHASE2_PLAN sec. 4 P5): the emitted bound must be <= the
    target's known upper bound (91 for InvMixColumns) and >= 32.
  * --emulate-original reproduces the original script's stdout verbatim so the
    forward positive control can be diffed line for line.

Usage:
    python3 verify_bound.py --target invmc
    python3 verify_bound.py --target mixcolumns --emulate-original
    python3 verify_bound.py --target invmc --cert 0,5,7,9,13,14,19
"""
import argparse
import json
import os
import sys
import time
from collections import Counter

import i5_core as core

HERE = os.path.dirname(os.path.abspath(__file__))

# ---------------------------------------------------------------------------
# The original script's three hardcoded MixColumns certificates.  They are kept
# ONLY as the forward positive control (they are the published I5/I6 objects).
ORIG_MC_CERTS = [
    ("Tier 1 certificate",
     [2, 8, 10, 13, 15, 18, 20, 21, 22, 23, 24, 29, 31]),
    ("Tier 2 certificate  (base; +minE>=4 gives 54)",
     [5, 7, 8, 10, 15, 17, 18, 21, 23, 26, 28, 29, 30, 31]),
    ("Tier 2 certificate' (base; +minE>=4 gives 54)",
     [0, 2, 5, 7, 10, 11, 13, 15, 18, 21, 23, 24, 29, 31]),
]
# minE >= 4 is OLD's Theorem-B result (three independent implementations,
# OLD NOTEBOOK.md sec. 2b).  It is NOT re-proved here; it appears only inside
# --emulate-original so that the forward transcript can be diffed.
ORIG_MC_MINE = 4


def check(M_rows, K, label, say=print, show_nonzero=True):
    """Byte-identical to the original `check()`, but on loaded rows.

    One line was ADDED to the original: the third Theorem-A hypothesis, that
    every column of M outside K is nonzero (a zeroing step on a zero column
    removes no gate; referee/REFEREE_REPORT.md sec. 2.6 has a 4-input
    counterexample to the statement without it).  It is checked always and
    printed unless show_nonzero=False, which --emulate-original passes so the
    forward control still diffs byte for byte against the original stdout.
    """
    rows = core.restrict(M_rows, K)
    weights = [core.popcount(r) for r in rows]
    distinct = len(set(rows)) == 32
    heavy = min(weights) >= 2
    nz_ok, n_outside, min_cw = core.cols_outside_nonzero(M_rows, K)
    base = (32 - len(K)) + 32
    say(f"{label}:  |K| = {len(K)}   K = {K}")
    say(f"    32 rows pairwise distinct : {distinct}")
    say(f"    min residual row weight   : {min(weights)}  (need >= 2)")
    hist = {}
    for w in weights:
        hist[w] = hist.get(w, 0) + 1
    say(f"    weight histogram          : {dict(sorted(hist.items()))}")
    if show_nonzero:
        say(f"    columns outside K nonzero : {nz_ok}  "
            f"({n_outside} columns, min column weight {min_cw}, need >= 1)")
    say(f"    Theorem A bound           : (32 - {len(K)}) + 32 = {base}")
    ok = distinct and heavy and nz_ok
    say(f"    => {'VERIFIED' if ok else 'FAILED'}")
    return ok, base


def profile_line(t):
    """Generic rendering of the original's 'matrix rebuilt' line.

    On the forward matrix this reproduces the original string exactly:
      'row weights 20x5+12x7, column weights 28x5+4x11, sum 184'
    On any other target it renders that target's own profile.
    """
    rows = t.rows
    cols = [sum(((rows[r] >> c) & 1) << r for r in range(32)) for c in range(32)]
    rw = Counter(core.popcount(r) for r in rows)
    cw = Counter(core.popcount(c) for c in cols)
    f = lambda h: '+'.join('%dx%d' % (h[w], w) for w in sorted(h))
    return ("matrix rebuilt from GF(2^8): row weights %s, column weights %s, "
            "sum %d  [OK]" % (f(rw), f(cw), sum(rows and [core.popcount(r) for r in rows])))


def default_certs(key):
    """Certificates for a target: the original three for the forward matrix,
    otherwise whatever certs_<key>.json holds (written by search_cert.py)."""
    if key == 'mixcolumns':
        return list(ORIG_MC_CERTS)
    p = os.path.join(HERE, 'certs_%s.json' % key)
    if not os.path.exists(p):
        return []
    d = json.load(open(p))
    return [(c['label'], c['K']) for c in d['certificates']]


def emulate_original(t, say):
    """Reproduce OLD/.../verify_bound.py stdout verbatim (forward control)."""
    say(profile_line(t))
    say("")
    res = []
    for label, K in ORIG_MC_CERTS:
        ok, b = check(t.rows, K, label, say, show_nonzero=False)
        say("")
        res.append((ok, b))
    assert all(ok for ok, _ in res)
    b1 = res[0][1]
    b2 = res[1][1]
    say(f"THEOREM A CERTIFICATE VERIFIED:  L(M) >= {b1}")
    say(f"THEOREM B (needs the exhaustive minE step): L(M) >= {b2} + {ORIG_MC_MINE}"
        f" = {b2 + ORIG_MC_MINE}")
    say("\nUpper bound for comparison: L(M) <= 88 (five verified 88-gate circuits).")
    return b1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--target', default='invmc',
                    help="'invmc', 'mixcolumns', or a path to a spec matrix json")
    ap.add_argument('--cert', action='append', default=[],
                    help='comma-separated column indices; repeatable')
    ap.add_argument('--emulate-original', action='store_true',
                    help='reproduce the OLD script stdout verbatim (forward control)')
    a = ap.parse_args()

    t0 = time.process_time()
    t = core.load(a.target)

    if a.emulate_original:
        if t.name != 'aes_mixcolumns':
            sys.exit('--emulate-original is only defined for the forward control')
        # provenance still checked, silently, before emulating
        core.rederive_and_compare(t, say=lambda s: None)
        core.selfcheck(t, say=lambda s: None)
        emulate_original(t, print)
        return 0

    print("=" * 78)
    print("I5 column-zeroing / Theorem-A certificate verifier   target=%s" % t.key)
    print("=" * 78)
    print("-- provenance " + "-" * 63)
    core.rederive_and_compare(t)
    print("-- matrix self-check  (replaces verify_bound.py:86-88) " + "-" * 23)
    core.selfcheck(t)
    print()
    print(profile_line(t))
    print()

    certs = [("cli certificate %d" % i, [int(x) for x in s.split(',')])
             for i, s in enumerate(a.cert)] or default_certs(t.key)
    if not certs:
        sys.exit("no certificates: run search_cert.py --target %s first" % t.key)

    results = []
    for label, K in certs:
        ok, b = check(t.rows, K, label)
        print()
        results.append((label, ok, b, K))

    verified = [(l, b, K) for l, ok, b, K in results if ok]
    failed = [l for l, ok, _, _ in results if not ok]
    if failed:
        print("FAILED certificates: %s" % failed)
    if not verified:
        print("NO CERTIFICATE VERIFIED -- no bound emitted")
        return 1
    best_label, best, best_K = max(verified, key=lambda x: x[1])
    print("THEOREM A CERTIFICATE VERIFIED:  L(%s) >= %d" % (t.name, best))
    print("   attaining certificate: |K| = %d  K = %s  (%s)" % (len(best_K), best_K, best_label))
    print()

    # ------------------------------------------------ acceptance tests (P5)
    accepted = core.acceptance(t, best)
    print()
    print("cpu_seconds %.3f" % (time.process_time() - t0))
    return 0 if accepted else 2


if __name__ == '__main__':
    sys.exit(main())
