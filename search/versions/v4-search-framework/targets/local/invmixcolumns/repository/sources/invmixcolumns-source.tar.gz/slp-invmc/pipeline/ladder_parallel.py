#!/usr/bin/env python3
"""
ladder_parallel.py  --  the record-hunting pipeline (parallel, reseeding),
ported from slp-plateau-search/pipeline to AES InvMixColumns.

    python3 ladder_parallel.py [--mode cascade|fixed] [--workers setA]
                               [--stop-gates N] [--stop-depth D]

Two modes (--mode overrides the MODE default below):

  "cascade"  the depth ladder.  THE FIRST RUNG IS DEPTH 5, NOT 3: the heaviest
             InvMixColumns target row has weight 19, so ceil(log2 19) = 5 is
             the arithmetic floor on this matrix's depth (invmc_core.MIN_DEPTH)
             and depths 3 and 4 are empty, not hard.  The rung starts from the
             cold naive set (315 gates @ depth 5, oracle-VALID), and each time
             the frontier rung beats its baseline (or times out) the next
             deeper rung launches seeded from it -- all rungs keep running, all
             reseed.

  "fixed"    launch a fixed set of workers at once (each with its own depth cap
             and seed) and let them run in parallel.  --workers picks the set;
             "setA" points lns / walk / alt at this project's best in-hand
             circuits (106@21, 113@17) uncapped, plus two depth-capped workers
             at 6 and 5 lifted from the 121@16.

The depth frontier for this matrix was EMPTY before this project: any verified
circuit at depth 5-7 at any count is a first.  That is why the D2 Pareto
tie-break (fewer gates, OR equal gates at strictly lower depth) is on from the
first run and why no stop bound is used in the shipped launches.

--stop-gates / --stop-depth make the coordinator shut everything down cleanly
as soon as a verified best satisfies BOTH given bounds (an omitted bound is a
don't-care).  The launched fleet omits both: it runs until stopped by PID.

Without stop bounds the run continues until Ctrl-C; either way every best is
already on disk.

Every worker is its own OS process (real parallelism). Every worker
verifies-before-claim and uses a PARETO tie-break (accept fewer gates, or
equal gates at lower depth) so shallow equal-gate circuits are not lost. The
coordinator maintains best_overall.json and offers each worker the best circuit
that is feasible at its depth cap (reseed_<label>.json), which the worker adopts
between chunks -- unless that worker was configured with reseed=False, which is
how independently seeded workers are kept from collapsing onto one circuit.

Every "best" written by a worker has passed the in-process verifier AND a
subprocess call to tools/verify_slp_generic.py (the oracle), after a dead-gate
strip (R8), and carries a provenance block.
"""
import argparse
import os, sys, json, time, shutil, subprocess

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import invmc_core as core          # the spec; imported for MIN_DEPTH + paths

# ==========================================================================
# CONFIG  --  edit everything here
# ==========================================================================
OUT_ROOT = "runs"
MODE = "fixed"                  # "cascade" or "fixed"
#   cascade = the from-scratch depth ladder, FIRST RUNG AT DEPTH 5 (the
#             arithmetic floor for this matrix; the forward pipeline started at
#             3 with anneal3, an engine that does not exist here).
#   fixed   = one of the WORKER_SETS below (--workers picks the set).

# ---- fixed-mode worker sets ----------------------------------------------
FIXED_WORKER_SET = "setA"       # --workers overrides

WORKER_SETS = {
    # ---------------------------------------------------------------- set A
    # The launch configuration for rung 2 (PHASE2_PLAN.md sec 3).  Six workers,
    # two jobs:
    #
    #   (i)  LOWER THE COUNT.  Four uncapped, count-first workers on this
    #        project's two best in-hand circuits -- the BP-fallback 106@21 and
    #        113@17 (RESULT.md, row W1-5b).  lns, walk and alt run side by side
    #        ON PURPOSE: the forward matrix's answer was "alt", but that was
    #        measured in the last-six-gates regime on a 5/7-weight matrix, and
    #        the incumbent here is 15 gates above the 91 with rows of weight
    #        11..19.  Which engine is right on this matrix is unmeasured; this
    #        set measures it.
    #
    #   (ii) PUT POINTS ON AN EMPTY DEPTH FRONTIER.  Two depth-capped lns
    #        workers, at 6 and at 5.  Depth 5 is core.MIN_DEPTH -- no shallower
    #        circuit exists.  NO InvMixColumns circuit at depth 5-8 exists
    #        anywhere, published or not, so ANY verified circuit those two
    #        produce, at ANY count, is a first-of-kind Pareto point.  Their seed (121@16) is far too
    #        deep for either cap, so worker.py LIFTS it onto the cold naive set
    #        and keeps whatever seed masks fit under the cap.
    #
    # Depth-capped workers use threshold acceptance, not SA: SA's uphill accepts
    # were tuned uncapped, where rebuilds are almost never larger, and under a
    # cap rebuilds are systematically larger so SA drifts up without recovering
    # (measured on the forward matrix, 2026-07-27).
    #
    # PROVENANCE: every seed here is this project's own (bp/bp5ub.c output or
    # this kit's Paar1 baseline) EXCEPT that no worker in set A is seeded from
    # the Yuan-reversed 91, which is transcribed from published work.  The 91
    # is in seeds/ as the incumbent to be measured against, not to be searched
    # from: anything descending from it would be derived work.  See
    # seeds/README.md.
    "setA": [
        dict(label="a1_lns_106", engine="lns", depth=None,
             start="seeds/invmc_bp5ub2_106_depth21.json"),
        dict(label="a2_alt_106", engine="alt", depth=None, reseed=False,
             start="seeds/invmc_bp5ub2_106_depth21.json", seeds=[11, 12, 13]),
        dict(label="a3_walk_106", engine="walk", depth=None, reseed=False,
             start="seeds/invmc_bp5ub2_106_depth21.json", seeds=[21, 22, 23]),
        dict(label="a4_alt_113", engine="alt", depth=None, reseed=False,
             start="seeds/invmc_bp5ub2_113_depth17.json", seeds=[31, 32, 33]),
        dict(label="a5_d6_from121", engine="lns", depth=6, seeds=[41, 42, 43],
             knobs=dict(accept="threshold", up_prob=0.10, up_slack=1, snapback=3),
             start="seeds/invmc_bp5ub2_121_depth16.json"),
        dict(label="a6_d5_from121", engine="lns", depth=5, seeds=[51, 52, 53],
             knobs=dict(accept="threshold", up_prob=0.10, up_slack=1, snapback=3),
             start="seeds/invmc_bp5ub2_121_depth16.json"),
    ],
    # A two-worker smoke set: fast to launch, seeded from the 106, no caps.
    "smoke": [
        dict(label="s1_lns_106", engine="lns", depth=None,
             start="seeds/invmc_bp5ub2_106_depth21.json"),
        dict(label="s2_walk_106", engine="walk", depth=None, seeds=[7, 8, 9],
             start="seeds/invmc_bp5ub2_106_depth21.json"),
    ],
}
FIXED_WORKERS = WORKER_SETS[FIXED_WORKER_SET]

# ---- cascade-mode ladder ---------------------------------------------------
# THE LADDER STARTS AT 5.  Depths 3 and 4 are not "hard" on this matrix, they
# are EMPTY: the heaviest target row has weight 19, so ceil(log2 19) = 5 is a
# floor no circuit can beat (invmc_core.MIN_DEPTH).  The forward pipeline's
# depth-3 rung ran `anneal3`, a structural model of weight-5/7 rows; that
# engine was removed in the port and every rung here runs `lns`.
DEPTHS = [5, 6, 7, 8, 9]
FINAL_UNCAPPED_DEPTH = True
MAX_WAIT_S = 900                # a rung triggers the next after this long even without a hit
                                # (forward used 2 h; the frontier here is empty,
                                # so ramping the ladder fast is the point)
IMPROVE_BY = 5                  # ...or as soon as it beats its baseline by this many gates
FIRST_RUNG_BASELINE = None      # set at run time to the cold naive count (see
                                # run_cascade); there is no published or
                                # searched depth-5 number to inherit, and
                                # inheriting one you have not derived is exactly
                                # what R14 forbids.
ENGINE_DEEP = "lns"

# ---- shared ---------------------------------------------------------------
SEEDS_PER_WORKER = [1, 2, 3]    # default RNG seeds (a worker dict may override)
POLL_S = 20                     # coordinator status cadence
CHUNK_S = 600                   # lns chunk length (each worker continues from its OWN best)
WALK_CHUNK_S = 300              # walk chunk length inside an "alt" worker
RESEED = True                   # coordinator offers each worker the best circuit
                                # feasible at its depth cap (as in both record
                                # runs); a worker dict may opt out with reseed=False

# Engine knobs. The values are the FORWARD campaign's measured-good
# configuration, carried over unchanged and unvalidated on this matrix (the
# forward sweep of 101 runs found knobs move throughput, not gate count; that
# is a forward measurement, not a claim here). Each line says what the knob does. Anything a worker wants different goes in its
# own knobs= dict (for an "alt" worker, keyed by engine: {"lns": {...}}).
LNS_KNOBS = dict(
    op_mix={"small": 0.35, "coneinj": 0.45, "biginj": 0.20},
                        # destroy operator mix. small = 1-4 random masks (the
                        # moves that actually rebuild); coneinj = a CONNECTED
                        # cone of the circuit + injected local candidates
                        # (~12x improvements/s over random destroys, forward); biginj = a
                        # big destroy, only viable because of peel_window.
                        # "uniform" (1..kmax random masks, the v1 destroy) is
                        # also accepted here.
    kmax=4,             # victim count of the "uniform" operator
    cone_lo=2, cone_hi=4,        # coneinj victim count range
    biginj_lo=8, biginj_hi=16,   # biginj victim count range
    kshake=12,          # every 997th iteration: forced kshake..kshake+4 destroy
    nsamp=(12, 12),     # (base, extra) pool draws and kept-pair draws per rebuild
                        # -- (12,12) is ~1.3-1.8x the throughput of v1's (24,24)
                        # at the same drift (knob sweep: champ_fast)
    hot_frac=0.5,       # fraction of pool draws taken from the hot list (masks a
                        # rebuild recently reintroduced) -- ~11x accepted moves (forward)
    vic_cost=3,         # pull-in cost class of a just-destroyed victim: victims
                        # stay available, so a rebuild never dead-ends (~34x
                        # accepted moves), but cost 3 pushes it to look elsewhere
    peel_window=6,      # peel a rebuild that came out up to this many masks too
                        # big before judging it (recovers near misses v1 dropped)
    accept="sa",        # "sa" = annealing with reheat (default), or "threshold"
    sa_T0=1.2, sa_cool=0.9997, sa_reheat=4000,
                        # temperature, per-iteration cooling, and the number of
                        # iterations without a new best that triggers a reheat
    up_prob=0.5, up_slack=4,     # the v1 threshold rule; used only if accept="threshold"
    snapback=12,        # restart from best once cur drifts this far above it
    harvest=True,       # append every distinct plateau state to <label>.pop.jsonl
                        # in the run folder (worker.py turns this switch into the
                        # engine's harvest_path; the engines take a path, not a
                        # bool, so that a run always states where it harvested)
    cross_pollinate=False,
                        # merge sibling workers' harvested masks into this
                        # worker's pool. OFF by default: it is a measured-good
                        # diversifier but it mixes the mask provenance of every
                        # worker in the run, so a circuit found afterwards is
                        # only cleanly "ours" if every seed in the run was.
    pop_period_s=120.0, # how often cross-pollination re-reads sibling harvests
)
WALK_KNOBS = dict(
    hub_move_p=0.30,    # probability of a remove-2-add-1 hub move
    close_hamming=8,    # half the hub moves pick the second victim within this
                        # Hamming distance of the first
    plateau_slack_p=0.15,
                        # probability of accepting a +1 move near the best. High
                        # on purpose: with exact repair the equal-size plateau is
                        # walkable (~2-3k distinct states/min FORWARD, where the
                        # 88s came from) -- v1's 0.02 was tuned for an engine
                        # whose repair usually failed. Whether this matrix has a
                        # walkable plateau at all is prediction P3, unscored.
    harvest=True,       # as above: worker.py resolves this to a harvest_path
)
# ANNEAL_KNOBS is gone with engine anneal3 (a depth-3 model; this matrix has no
# depth-3 circuit -- see invmc_core.MIN_DEPTH and engines.RETIRED_ENGINES).
# ==========================================================================
# END CONFIG
# ==========================================================================

HERE = os.path.dirname(os.path.abspath(__file__))

# Optional stop bounds, set from the command line in main(). The coordinator
# stops cleanly once ANY worker holds a verified best satisfying every bound.
#
# It tests every worker's best rather than only the Pareto-global one. The
# global best is a single (gates, depth) pair chosen by `pareto_better`, which
# prefers fewer gates at any depth, so a run that reaches, say, 100 gates at
# depth 12 replaces a 105 at depth 6 in that slot; testing only the global best
# then leaves `--stop-gates 105 --stop-depth 6` unsatisfiable for the rest of
# the run even though a worker is holding exactly the circuit asked for.
STOP_GATES = None
STOP_DEPTH = None


def _within_bounds(g, d):
    return (STOP_GATES is None or g <= STOP_GATES) and \
           (STOP_DEPTH is None or d <= STOP_DEPTH)


def target_reached(state):
    if STOP_GATES is None and STOP_DEPTH is None:
        return False
    for g, d in state.get("hits", ()):
        if _within_bounds(g, d):
            state["hit"] = (g, d)
            return True
    return False


def pareto_better(g2, d2, g1, d1):
    if g1 is None:
        return True
    return g2 < g1 or (g2 == g1 and d2 < d1)


def read_status(path):
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        return None


def launch(label, engine, depth, start, out_dir, log, seeds=None):
    # A cap below core.MIN_DEPTH is infeasible by arithmetic (max target row
    # weight 19 => depth >= 5). The worker refuses it too; refusing here means
    # the coordinator never even spends a fork on it.
    if depth is not None and depth < core.MIN_DEPTH:
        log("REFUSED %-16s depth cap %d < MIN_DEPTH %d -- no circuit of that "
            "depth exists for this matrix; not launched"
            % (label, depth, core.MIN_DEPTH))
        return None
    seeds = ",".join(str(s) for s in (seeds or SEEDS_PER_WORKER))
    depth_arg = "none" if depth is None else str(depth)
    start_abs = "scratch" if start == "scratch" else os.path.join(HERE, start) \
        if not os.path.isabs(start) else start
    cmd = [sys.executable, os.path.join(HERE, "worker.py"),
           label, engine, depth_arg, start_abs, out_dir, seeds]
    logf = open(os.path.join(out_dir, "%s.stdout" % label), "a")
    proc = subprocess.Popen(cmd, cwd=HERE, stdout=logf, stderr=subprocess.STDOUT)
    log("LAUNCH %-16s engine=%s depth=%s start=%s pid=%d"
        % (label, engine, depth_arg,
           os.path.basename(start) if start != "scratch" else "scratch", proc.pid))
    return proc


def gather_bests(meta):
    """label -> (gates, depth, best_path) for every worker with a verified best."""
    out = {}
    for lbl, m in meta.items():
        st = read_status(m["status_path"])
        if st and st.get("best_gates") is not None:
            out[lbl] = (st["best_gates"], st["best_depth"], m["best_path"])
    return out


def do_reseed(meta, procs, out_dir, log, state):
    """Update best_overall.json and offer each live worker the best circuit that
    is feasible at its depth cap (and Pareto-beats its own best)."""
    bests = gather_bests(meta)
    state["hits"] = [(g, d) for g, d, _ in bests.values()]
    if not bests:
        return
    gb_lbl = min(bests, key=lambda l: (bests[l][0], bests[l][1]))
    gg, gd, gp = bests[gb_lbl]
    if state["gb"] is None or pareto_better(gg, gd, state["gb"][0], state["gb"][1]):
        state["gb"] = (gg, gd)
        shutil.copy(gp, os.path.join(out_dir, "best_overall.json"))
        log("GLOBAL BEST %d gates depth %d (%s) -> best_overall.json" % (gg, gd, gb_lbl))
    if not RESEED:
        return
    for lbl, m in meta.items():
        if procs[lbl].poll() is not None or not m.get("reseed", True):
            continue
        cap = m["cap"]
        own = bests.get(lbl)
        own_g, own_d = (own[0], own[1]) if own else (None, None)
        cands = [(g, d, p) for l2, (g, d, p) in bests.items()
                 if l2 != lbl and (cap is None or d <= cap)]
        if not cands:
            continue
        cg, cd, cp = min(cands, key=lambda t: (t[0], t[1]))
        if pareto_better(cg, cd, own_g, own_d) and state["offer"].get(lbl) != (cg, cd, cp):
            shutil.copy(cp, os.path.join(out_dir, "reseed_%s.json" % lbl))
            state["offer"][lbl] = (cg, cd, cp)
            log("  reseed offer -> %-16s : %d gates depth %d (from %s)"
                % (lbl, cg, cd, os.path.basename(cp)))


def status_row(meta, procs):
    row = []
    for lbl, m in meta.items():
        st = read_status(m["status_path"])
        bg = st["best_gates"] if st else None
        bd = st["best_depth"] if st else None
        up = "up" if procs[lbl].poll() is None else "DOWN"
        row.append("%s=%s/%s(%s)" % (lbl, bg, bd, up))
    return "  ".join(row)


def cleanup(procs, meta, out_dir, log, state):
    for p in procs.values():
        if p.poll() is None:
            p.terminate()
    time.sleep(2)
    for p in procs.values():
        if p.poll() is None:
            p.kill()
    log("==================== FINAL BESTS ====================")
    for lbl in procs:
        st = read_status(meta[lbl]["status_path"])
        if st:
            log("%-16s depth_cap=%s  best=%s gates @ depth %s"
                % (lbl, st["cap"], st["best_gates"], st["best_depth"]))
    if state["gb"]:
        log("BEST OVERALL: %d gates @ depth %d  -> best_overall.json" % state["gb"])
    log("all circuits + logs in: %s" % out_dir)


def make_run():
    stamp = time.strftime("%Y%m%d_%H%M%S")
    out_dir = os.path.join(HERE, OUT_ROOT, stamp)
    os.makedirs(out_dir, exist_ok=True)
    # self-archive the EXACT code producing this run (so results are always
    # reproducible from their own folder -- no more in-place-edit ambiguity).
    code_dir = os.path.join(out_dir, "code")
    os.makedirs(code_dir, exist_ok=True)
    for fn in ("invmc_core.py", "engines.py", "worker.py", "ladder_parallel.py"):
        try:
            shutil.copy(os.path.join(HERE, fn), os.path.join(code_dir, fn))
        except Exception:
            pass
    seed_dir = os.path.join(code_dir, "seeds")
    os.makedirs(seed_dir, exist_ok=True)
    for w in FIXED_WORKERS:                       # archive the exact seed files
        st = w.get("start")
        if st and st != "scratch":
            try:
                shutil.copy(os.path.join(HERE, st),
                            os.path.join(seed_dir, os.path.basename(st)))
            except Exception:
                pass
    worker_knobs = {w["label"]: w["knobs"] for w in FIXED_WORKERS if w.get("knobs")}
    json.dump({"target": core.SPEC_MATRIX, "min_depth": core.MIN_DEPTH,
               "oracle": core.ORACLE,
               "mode": MODE, "worker_set": FIXED_WORKER_SET,
               "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
               "cmd": " ".join([sys.executable] + sys.argv),
               "chunk_s": CHUNK_S, "walk_chunk_s": WALK_CHUNK_S, "reseed": RESEED,
               "knobs": {"lns": LNS_KNOBS, "walk": WALK_KNOBS},
               "worker_knobs": worker_knobs},
              open(os.path.join(out_dir, "config.json"), "w"), indent=2)
    return out_dir


def run_fixed():
    out_dir = make_run()
    masterlog = open(os.path.join(out_dir, "coordinator.log"), "a", buffering=1)
    t0 = time.time()
    def log(msg):
        line = "[%8.1fs %s] %s" % (time.time() - t0, time.strftime("%H:%M:%S"), msg)
        print(line, flush=True); masterlog.write(line + "\n")
    log("FIXED-mode pipeline (%s) -> %s" % (FIXED_WORKER_SET, out_dir))
    log("workers: %s" % [(w["label"], w["engine"], w["depth"]) for w in FIXED_WORKERS])

    procs, meta = {}, {}
    for w in FIXED_WORKERS:
        lbl = w["label"]
        pr = launch(lbl, w["engine"], w["depth"], w["start"], out_dir, log,
                    seeds=w.get("seeds"))
        if pr is None:
            continue
        procs[lbl] = pr
        meta[lbl] = {"cap": w["depth"], "reseed": w.get("reseed", True),
                     "status_path": os.path.join(out_dir, "%s_status.json" % lbl),
                     "best_path": os.path.join(out_dir, "%s_best.json" % lbl)}
    state = {"gb": None, "offer": {}, "hits": []}
    try:
        while True:
            time.sleep(POLL_S)
            log("status: " + status_row(meta, procs))
            do_reseed(meta, procs, out_dir, log, state)
            if target_reached(state):
                log("STOP TARGET reached: %d gates @ depth %d -> shutting down"
                    % state["hit"])
                break
    except KeyboardInterrupt:
        log("Ctrl-C: stopping all workers")
    finally:
        cleanup(procs, meta, out_dir, log, state)


def run_cascade():
    out_dir = make_run()
    masterlog = open(os.path.join(out_dir, "coordinator.log"), "a", buffering=1)
    t0 = time.time()
    def log(msg):
        line = "[%8.1fs %s] %s" % (time.time() - t0, time.strftime("%H:%M:%S"), msg)
        print(line, flush=True); masterlog.write(line + "\n")
    log("CASCADE-mode pipeline -> %s" % out_dir)

    procs, meta = {}, {}
    started_at, baseline = {}, {}
    def rl(d): return "d%d" % d

    d0 = DEPTHS[0]; lbl = rl(d0)
    if d0 < core.MIN_DEPTH:
        raise SystemExit("cascade first rung is depth %d but MIN_DEPTH is %d "
                         "(max target row weight %d): that rung is empty."
                         % (d0, core.MIN_DEPTH, core.MAX_TARGET_WEIGHT))
    # The rung-1 baseline is DERIVED, not inherited (R14): it is the gate count
    # of the cold from-scratch start this rung actually begins from. There is no
    # published depth-5 InvMixColumns number to inherit -- the frontier is empty.
    cold = len(core.naive_masks())
    first_baseline = FIRST_RUNG_BASELINE if FIRST_RUNG_BASELINE is not None else cold
    log("cascade first rung = depth %d (MIN_DEPTH = %d); cold naive start = %d "
        "gates @ depth %d; rung baseline = %d, IMPROVE_BY = %d"
        % (d0, core.MIN_DEPTH, cold, core.MIN_DEPTH, first_baseline, IMPROVE_BY))
    procs[lbl] = launch(lbl, ENGINE_DEEP, d0, "scratch", out_dir, log)
    if procs[lbl] is None:
        raise SystemExit("first rung refused")
    meta[lbl] = {"cap": d0, "status_path": os.path.join(out_dir, "%s_status.json" % lbl),
                 "best_path": os.path.join(out_dir, "%s_best.json" % lbl)}
    started_at[lbl] = time.time(); baseline[lbl] = first_baseline
    frontier_idx = 0; final_launched = False
    state = {"gb": None, "offer": {}, "hits": []}
    try:
        while True:
            time.sleep(POLL_S)
            log("status: " + status_row(meta, procs))
            do_reseed(meta, procs, out_dir, log, state)
            if target_reached(state):
                log("STOP TARGET reached: %d gates @ depth %d -> shutting down"
                    % state["hit"])
                break
            if final_launched:
                continue
            fd = DEPTHS[frontier_idx]; flbl = rl(fd)
            st = read_status(meta[flbl]["status_path"])
            best = st["best_gates"] if st and st.get("best_gates") is not None else None
            target = baseline[flbl] - IMPROVE_BY
            elapsed = time.time() - started_at[flbl]
            if not ((best is not None and best <= target) or elapsed >= MAX_WAIT_S):
                continue
            why = ("hit %d<=%d" % (best, target)) if (best is not None and best <= target) \
                else ("timeout %.0fs" % elapsed)
            if not os.path.exists(meta[flbl]["best_path"]):
                started_at[flbl] = time.time(); continue
            seed_file = os.path.join(out_dir, "seed_from_%s.json" % flbl)
            shutil.copy(meta[flbl]["best_path"], seed_file)
            seed_count = best if best is not None else baseline[flbl]
            if frontier_idx + 1 < len(DEPTHS):
                nd = DEPTHS[frontier_idx + 1]; nlbl = rl(nd)
                log("TRIGGER %s (%s, seed=%d) -> launch %s at depth %d" % (flbl, why, seed_count, nlbl, nd))
                pr = launch(nlbl, ENGINE_DEEP, nd, seed_file, out_dir, log)
                if pr is None:
                    frontier_idx += 1
                    continue
                procs[nlbl] = pr
                meta[nlbl] = {"cap": nd, "status_path": os.path.join(out_dir, "%s_status.json" % nlbl),
                              "best_path": os.path.join(out_dir, "%s_best.json" % nlbl)}
                started_at[nlbl] = time.time(); baseline[nlbl] = seed_count
                frontier_idx += 1
            elif FINAL_UNCAPPED_DEPTH:
                log("TRIGGER %s (%s, seed=%d) -> launch FINAL (uncapped depth)" % (flbl, why, seed_count))
                procs["final"] = launch("final", ENGINE_DEEP, None, seed_file, out_dir, log)
                meta["final"] = {"cap": None, "status_path": os.path.join(out_dir, "final_status.json"),
                                 "best_path": os.path.join(out_dir, "final_best.json")}
                started_at["final"] = time.time(); baseline["final"] = seed_count
                final_launched = True
            else:
                final_launched = True
    except KeyboardInterrupt:
        log("Ctrl-C: stopping all workers")
    finally:
        cleanup(procs, meta, out_dir, log, state)


def main():
    global STOP_GATES, STOP_DEPTH, FIXED_WORKER_SET, FIXED_WORKERS
    parser = argparse.ArgumentParser(
        description="Record-hunting pipeline for AES InvMixColumns XOR circuits "
                    "(target: spec/invmc_matrix.json; MIN_DEPTH = 5).")
    parser.add_argument("--mode", choices=("cascade", "fixed"), default=MODE,
                        help="fixed = a fixed worker set (default, see --workers); "
                             "cascade = the from-scratch depth ladder, first rung "
                             "at depth %d" % DEPTHS[0])
    parser.add_argument("--workers", choices=tuple(WORKER_SETS), default=FIXED_WORKER_SET,
                        help="fixed-mode worker set: setA = 4 uncapped count-first "
                             "workers on the 106/113 + depth-6 and depth-5 capped "
                             "workers (default); smoke = a 2-worker smoke set")
    parser.add_argument("--stop-gates", type=int, default=None, metavar="N",
                        help="stop cleanly once a verified best has <= N gates")
    parser.add_argument("--stop-depth", type=int, default=None, metavar="D",
                        help="stop cleanly once the verified best also has depth <= D")
    args = parser.parse_args()
    STOP_GATES, STOP_DEPTH = args.stop_gates, args.stop_depth
    FIXED_WORKER_SET = args.workers
    FIXED_WORKERS = WORKER_SETS[FIXED_WORKER_SET]

    os.makedirs(os.path.join(HERE, OUT_ROOT), exist_ok=True)
    if args.mode == "fixed":
        run_fixed()
    else:
        run_cascade()


if __name__ == "__main__":
    main()
