#!/usr/bin/env bash
# W1 steps 7-8 (PHASE2_PLAN.md §6): transcribe the two published in-place
# programs, unroll them to verified g-XOR circuits, and measure their depth.
# Reproduces every number in controls/DEPTH_FRONTIER_W1.md from the PDFs.
# Run from the repo root.  Single-thread, nice -n 19, < 1 core-minute total.
set -u
N="nice -n 19"
V="$N python3 tools/verify_slp_generic.py"
D="$N python3 tools/depth_schedule.py"
X="$N python3 tools/extract_listing.py"
U="$N python3 tools/sxor_unroll.py"
mkdir -p listings

XPAP="Xiang, Zeng, Lin, Bao, Zhang, ToSC 2020(2) 120-145; ePrint 2020/903"
YPAP="Yuan, Wu, Shi, Zhang, Zhang, ToSC 2024(2) 322-347; DOI 10.46586/tosc.v2024.i2.322-347"

echo "=== 0. transcription: pdftotext -layout output -> canonical listings ==="
echo "# the .txt dumps beside the PDFs were produced by:"
echo "#   pdftotext -layout papers/xiang2020.pdf papers/xiang2020.txt"
echo "#   pdftotext -layout papers/yuan2024.pdf papers/yuan2024.txt"
echo "# -layout alone parsed both 3-column tables; no crop/page-range/-raw"
echo "# re-run was needed.  extract_listing.py handles the one artefact it"
echo "# leaves (an output annotation glued to the next column's number) by"
echo "# scanning the region rather than the line, then requiring the"
echo "# instruction numbers to be exactly the contiguous range."

X3="$X --txt papers/xiang2020.txt --start-marker 'Table 3: An implementation of AES MixColumns with 92 Xor operations.' --end-marker 'are the 32 input bits' --first 0 --count 92 --syntax plain --out listings/xiang2020_table3_mixcolumns_92.txt"
X4="$X --txt papers/xiang2020.txt --start-marker 'Table 4: An implementation of AES inverse MixColumns with 92 Xor operations.' --end-marker 'are the 32 input bits' --first 0 --count 92 --syntax plain --out listings/xiang2020_table4_invmixcolumns_92.txt"
Y4="$X --txt papers/yuan2024.txt --start-marker 'Table 4: The implementation of AES MixColumn with 91 XORs.' --end-marker 'Table 5:' --first 1 --count 91 --syntax bracket --out listings/yuan2024_table4_mixcolumns_91.txt"
eval "$X3"; eval "$X4"; eval "$Y4"

echo
echo "=== 0b. INDEPENDENT CROSS-CHECK of Table 3 against Xiang et al.'s own"
echo "===     GitHub listing (Implementations/AES.txt, papers/xiang_AES.txt) ==="
$N python3 - <<'EOF'
import re, json
txt = open('papers/xiang_AES.txt').read()
rows = txt.split('Original Matrix:')[1].split('Reduced Matrix:')[0].split()
repo = json.load(open('spec/mixcolumns_matrix.json'))['rows']
print("  their published matrix == spec/mixcolumns_matrix.json rows :", rows == repo)
gh = []
for line in txt.split('Xor Count =  92')[1].strip().splitlines():
    m = re.match(r"\s*x\[\s*(\d+)\s*\]\s*=\s*x\[\s*(\d+)\s*\]\s*\^\s*x\[\s*(\d+)\s*\]\s*(?:y\[\s*(\d+)\s*\])?\s*$", line)
    assert m, repr(line)
    gh.append((int(m.group(1)), int(m.group(3)), int(m.group(4)) if m.group(4) else None))
tab = []
for line in open('listings/xiang2020_table3_mixcolumns_92.txt'):
    p = line.split()
    tab.append((int(p[0]), int(p[1]), int(p[2]) if len(p) > 2 else None))
print("  our Table 3 transcription == their GitHub listing, gate-for-gate :", gh == tab)
EOF

echo
echo "=== 0c. the re-indexing question, decided by test and not by assumption ==="
$N python3 - <<'EOF'
import json, sys
sys.path.insert(0, 'tools')
from sxor_unroll import parse_listing, unroll, PERMS
MC = [int(x, 16) for x in json.load(open('spec/mixcolumns_matrix.json'))['masks_hex']]
for tag, path in (("Xiang T3", 'listings/xiang2020_table3_mixcolumns_92.txt'),
                  ("Yuan  T4", 'listings/yuan2024_table4_mixcolumns_91.txt')):
    for name, p in PERMS.items():
        g, outs, _ = unroll(parse_listing(path), p, False)
        sig = [1 << i for i in range(32)]
        for x, y in g:
            sig.append(sig[x] ^ sig[y])
        got = [sig[outs[j]] for j in range(32)]
        exact = sum(got[j] == MC[j] for j in range(32))
        inset = sum(got[j] in set(MC) for j in range(32))
        print(f"  {tag}  bit-order {name:9s}  outputs on target j: {exact:2d}/32   "
              f"anywhere in the target set: {inset:2d}/32")
EOF

echo
echo "=== 1. mixcolumns_xiang92  (Table 3, forward -- POSITIVE CONTROL) ==="
eval "$U --listing listings/xiang2020_table3_mixcolumns_92.txt --out circuits/mixcolumns_xiang92.json --bit-order identity --paper '$XPAP' --table 'Table 3' --page 'p. 136' --computes 'AES MixColumns' --extract-cmd \"$X3\""
$V --target spec/mixcolumns_matrix.json circuits/mixcolumns_xiang92.json
$D --target spec/mixcolumns_matrix.json circuits/mixcolumns_xiang92.json --emit circuits/mixcolumns_xiang92_asap.json
$V --target spec/mixcolumns_matrix.json circuits/mixcolumns_xiang92_asap.json 6

echo
echo "=== 2. invmc_xiang92  (Table 4 as printed) ==="
eval "$U --listing listings/xiang2020_table4_invmixcolumns_92.txt --out circuits/invmc_xiang92.json --bit-order identity --paper '$XPAP' --table 'Table 4' --page 'p. 137' --computes 'AES InvMixColumns' --extract-cmd \"$X4\""
$V --target spec/invmc_matrix.json circuits/invmc_xiang92.json
$D --target spec/invmc_matrix.json circuits/invmc_xiang92.json --emit circuits/invmc_xiang92_asap.json
$V --target spec/invmc_matrix.json circuits/invmc_xiang92_asap.json 26

echo
echo "=== 3. invmc_xiang92_reversed_from_T3  (Table 3 reversed -- reversal check) ==="
eval "$U --listing listings/xiang2020_table3_mixcolumns_92.txt --out circuits/invmc_xiang92_reversed_from_T3.json --bit-order identity --reverse --paper '$XPAP' --table 'Table 3, REVERSED' --page 'p. 136' --computes 'AES InvMixColumns' --extract-cmd \"$X3\""
$V --target spec/invmc_matrix.json circuits/invmc_xiang92_reversed_from_T3.json
$D --target spec/invmc_matrix.json circuits/invmc_xiang92_reversed_from_T3.json --emit circuits/invmc_xiang92_reversed_from_T3_asap.json
$V --target spec/invmc_matrix.json circuits/invmc_xiang92_reversed_from_T3_asap.json 26
echo "--- is the printed Table 4 the reversal of the printed Table 3? ---"
$N python3 - <<'EOF'
import json
a = json.load(open('circuits/invmc_xiang92.json'))
b = json.load(open('circuits/invmc_xiang92_reversed_from_T3.json'))
print("  gate lists identical  :", a['gates'] == b['gates'])
print("  output maps identical :", a['outputs'] == b['outputs'])
EOF

echo
echo "=== 4. mixcolumns_yuan91  (Table 4, forward -- POSITIVE CONTROL) ==="
eval "$U --listing listings/yuan2024_table4_mixcolumns_91.txt --out circuits/mixcolumns_yuan91.json --bit-order identity --paper '$YPAP' --table 'Table 4' --page 'p. 340' --computes 'AES MixColumns' --extract-cmd \"$Y4\""
$V --target spec/mixcolumns_matrix.json circuits/mixcolumns_yuan91.json
$D --target spec/mixcolumns_matrix.json circuits/mixcolumns_yuan91.json --emit circuits/mixcolumns_yuan91_asap.json
$V --target spec/mixcolumns_matrix.json circuits/mixcolumns_yuan91_asap.json 6

echo
echo "=== 5. invmc_yuan91  (Yuan Table 4 REVERSED -- the incumbent) ==="
eval "$U --listing listings/yuan2024_table4_mixcolumns_91.txt --out circuits/invmc_yuan91.json --bit-order identity --reverse --paper '$YPAP' --table 'Table 4, REVERSED' --page 'p. 340' --computes 'AES InvMixColumns' --extract-cmd \"$Y4\" --note \"the paper never states this circuit: it applies BKL16 Cor. 1 to Yuan et al.'s forward 91 s-XOR listing. The word 'inverse' does not occur in that paper.\""
$V --target spec/invmc_matrix.json circuits/invmc_yuan91.json
$D --target spec/invmc_matrix.json circuits/invmc_yuan91.json --emit circuits/invmc_yuan91_asap.json
$V --target spec/invmc_matrix.json circuits/invmc_yuan91_asap.json 27

echo
echo "=== 6. B = n - 32 tripwire on every inverse circuit ==="
$N python3 tools/tripwire_B.py --target spec/invmc_matrix.json \
  --calibrate circuits/invmc_paar1.json \
  circuits/invmc_xiang92.json circuits/invmc_xiang92_reversed_from_T3.json \
  circuits/invmc_yuan91.json circuits/invmc_xiang92_asap.json \
  circuits/invmc_xiang92_reversed_from_T3_asap.json circuits/invmc_yuan91_asap.json \
  --jsonl controls/B_invmc_ledger.jsonl | tee controls/B3_tripwire_transcribed.txt
