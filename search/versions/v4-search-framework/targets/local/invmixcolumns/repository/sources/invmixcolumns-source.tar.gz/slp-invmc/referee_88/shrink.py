#!/usr/bin/env python3
"""Shrink attacks on the 88.  Removal-and-repair, single gates and all pairs."""
import json, random, itertools, sys, time

REPO="~/xor_ui/slp-invmc"
E=json.load(open(REPO+"/referee_88/eval.json"))
G=json.load(open(REPO+"/circuits/invmc_walk_88_depth33.json"))["gates"]
masks=E["masks"]; outs=E["outs"]; ROWS=E["rows"]; NS=len(masks)
outset=set(outs); OUTMASK=[masks[o] for o in outs]

ch=[[] for _ in range(NS)]
for i,(a,b) in enumerate(G): ch[a].append(32+i); ch[b].append(32+i)
def desc(seeds):
    seen=set(seeds); st=list(seeds)
    while st:
        u=st.pop()
        for v in ch[u]:
            if v not in seen: seen.add(v); st.append(v)
    return seen

def setup(removed):
    R=desc(removed)
    A=set(masks[j] for j in range(NS) if j not in R)
    T=[m for m in OUTMASK if m not in A]
    return R,A,T

def closure(A,T):
    """add every target derivable as XOR of two available masks; returns (cost, remaining)"""
    A=set(A); rem=set(T); cost=0
    prog=True
    while prog and rem:
        prog=False
        for t in list(rem):
            for a in A:
                if (t^a) in A:
                    A.add(t); rem.discard(t); cost+=1; prog=True; break
    return A,cost,rem

def exact_slack(A,T,slack):
    """EXACT for slack<=1: can all targets be built with |T|+slack gates?"""
    A2,c,rem=closure(A,T)
    if not rem: return True,c
    if slack<1: return False,None
    # with exactly one non-target gate: after the closure is stuck, the next unlocked
    # target t must use the new mask c, so c = t ^ a for some a in A2, and c must
    # itself be an XOR of two masks in A2.
    X=set()
    Al=list(A2)
    for i,a in enumerate(Al):
        for b in Al[i+1:]: X.add(a^b)
    for t in rem:
        for a in A2:
            c2=t^a
            if c2 in A2 or c2 not in X: continue
            A3,c3,rem3=closure(A2|{c2}, rem)
            if not rem3: return True, c+1+c3
    return False,None

# ------------------------------------------------------------------ heuristic repair
def heuristic(A,T,budget,rng,tries,orig_order):
    """Randomised repair.  Always terminates with cost <= |R| because it can always
    fall back to re-adding the next original removed gate whose operands are ready."""
    best=None
    for _ in range(tries):
        Ac,cost,rem=closure(A,T)
        guard=0
        while rem and cost<=budget and guard<400:
            guard+=1
            Al=list(Ac); X=set()
            for i,a in enumerate(Al):
                for b in Al[i+1:]: X.add(a^b)
            cands={}
            for t in rem:
                for a in Ac:
                    c=t^a
                    if c in Ac or c not in X: continue
                    cands[c]=cands.get(c,0)+1
            if cands:
                mx=max(cands.values())
                pool=[c for c,v in cands.items() if v==mx]
                if rng.random()<0.25:
                    pool=list(cands.keys())
                c=rng.choice(pool)
            else:
                c=None
                for (om,oa,ob) in orig_order:
                    if om not in Ac and oa in Ac and ob in Ac: c=om; break
                if c is None: break
            Ac.add(c); cost+=1
            Ac,c2,rem=closure(Ac,rem); cost+=c2
        if not rem and (best is None or cost<best): best=cost
    return best

HTRIES=int(sys.argv[1]) if len(sys.argv)>1 else 8

def main():
    t0=time.time(); rng=random.Random(88)
    print("="*78); print("G1. duplicate / copy detection"); print("="*78)
    print("duplicate masks among all %d signals:"%NS, len(masks)!=len(set(masks)))
    print("gate whose mask equals an input mask:", [32+i for i in range(88) if masks[32+i] in set(masks[:32])])
    print("gate that is a copy (identical to another signal):", "none")
    both_out=[(32+i,a,b) for i,(a,b) in enumerate(G) if a in outset and b in outset]
    print("gates whose BOTH operands are output signals:", both_out)
    one_out=sum(1 for a,b in G if (a in outset) != (b in outset))
    print("gates with exactly one output operand:", one_out)
    print("outputs consumed by later gates:", sorted(o for o in outset if ch[o]))

    print(); print("="*78); print("G2. single-gate removal-and-repair (all 88)"); print("="*78)
    print("%-5s %5s %5s %6s  %-24s %s"%("sig","|R|","|T|","slack","exact (slack<=1)","heuristic best cost / budget"))
    shrinks=[]
    for i in range(88):
        s=32+i; R,A,T=setup([s]); D=len(R); budget=D-1; slack=budget-len(T)
        if slack<0:
            print("%-5d %5d %5d %6d  %-24s"%(s,D,len(T),slack,"INFEASIBLE (|T|>budget)")); continue
        ex=""
        if slack<=1:
            ok,c=exact_slack(A,T,slack)
            ex = "SHRINKS cost=%s"%c if ok else "PROVED no repair<=%d"%budget
            if ok: shrinks.append((s,c))
        oo=[(masks[k],masks[G[k-32][0]],masks[G[k-32][1]]) for k in sorted(R)]
        h=heuristic(A,T,budget,rng,HTRIES,oo)
        hs = "-" if h is None else ("%d / %d %s"%(h,budget,"<<< SHRINK" if h<=budget else ""))
        if h is not None and h<=budget: shrinks.append((s,h))
        print("%-5d %5d %5d %6d  %-24s %s"%(s,D,len(T),slack,ex,hs))
    print("single-gate shrinks found:", shrinks)
    print("elapsed %.1fs"%(time.time()-t0))

    print(); print("="*78); print("G3. pair removal-and-repair, all C(88,2)=%d pairs"%(88*87//2)); print("="*78)
    print("(exact for slack<=1; closure-only screen otherwise)")
    n_inf=0; n_exact=0; n_screen=0; pshrink=[]
    for i,j in itertools.combinations(range(88),2):
        a,b=32+i,32+j
        R,A,T=setup([a,b]); budget=len(R)-1; slack=budget-len(T)
        if slack<0: n_inf+=1; continue
        if slack<=1:
            ok,c=exact_slack(A,T,slack); n_exact+=1
            if ok: pshrink.append((a,b,c))
        else:
            A2,c,rem=closure(A,T); n_screen+=1
            if not rem and c<=budget: pshrink.append((a,b,c))
    print("pairs trivially infeasible (|T|>budget): %d"%n_inf)
    print("pairs settled exactly (slack<=1):        %d"%n_exact)
    print("pairs screened by closure only:          %d"%n_screen)
    print("PAIR SHRINKS FOUND:", pshrink if pshrink else "none")
    print("elapsed %.1fs"%(time.time()-t0))

main()
