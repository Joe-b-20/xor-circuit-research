#!/usr/bin/env python3
"""Focused stress of Lemma 3' with instances chosen so that minE_K > 0."""
import itertools, random
import ref_theoremB_stress_lib as L
closure=L.closure; minE=L.minE
random.seed(777)
bad=0; n=0; hist={}
for (nn,ck) in ((6,4),(7,4),(8,4),(7,5),(8,5)):
    Wk=[m for m in range(1<<ck) if bin(m).count('1')>=2]
    Wn=[m for m in range(1<<nn) if bin(m).count('1')>=2]
    for t in range(60):
        K=sorted(random.sample(range(nn),ck))
        nv=random.choice([len(Wk)-3,len(Wk)-2,max(3,len(Wk)//2)])
        Vk=random.sample(Wk,nv)
        emb=lambda m: sum(((m>>i)&1)<<K[i] for i in range(ck))
        Vn=[emb(m) for m in Vk]
        ek=minE(ck,Vk,maxb=3,pool=Wk)
        en=minE(nn,Vn,maxb=3,pool=Wn)
        n+=1; hist[(ek,en)]=hist.get((ek,en),0)+1
        if ek is not None and en is not None and en<ek:
            bad+=1; print("VIOLATION n=%d K=%s Vk=%s minE_n=%d < minE_K=%d"%(nn,K,Vk,en,ek))
print("focused Lemma3' stress: cases=%d violations=%d  (minE_K,minE_n) hist=%s"%(n,bad,sorted(hist.items(),key=lambda x:str(x))))
