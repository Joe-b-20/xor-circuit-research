#!/usr/bin/env python3
"""Referee step 5 side-checks: ASAP re-schedule depths, Xiang T4 == reverse(T3)?, and the implicit InvMixColumns
depth point hidden in Yuan 2024 Table 5 (depth-13, 98-CNOT in-place MixColumns; CNOT layering is reversal-invariant)."""
import re, json, sys
sys.argv=[sys.argv[0]]
exec(open("~/xor_ui/slp-invmc/referee_89/literature_circuits.py").read().split("print(\"== parsed")[0])  # reuse parsers/targets
def asap_depth(masks_needed_rows, all_masks):
    """least-fixpoint ASAP depth over a fixed mask set (inputs + gate masks), any 2-XOR wiring allowed."""
    d={1<<i:0 for i in range(32)}; pool=set(all_masks)|set(d)
    changed=True
    while changed:
        changed=False
        for m in pool:
            if m in d and d[m]==0: continue
            best=d.get(m)
            for a in list(d):
                b=m^a
                if b in d and a<b:
                    cand=max(d[a],d[b])+1
                    if best is None or cand<best: best=cand
            if best is not None and best!=d.get(m): d[m]=best; changed=True
    return max(d[r] for r in masks_needed_rows), d
IMC=TARGETS[("IMC",False)]; MC=TARGETS[("MC",False)]
rev=lambda prog:[(i,j,None) for (i,j,_) in reversed(prog)]
def perm(prog):
    init=[None]*32
    for i,j,l in prog:
        if l is not None: init[i]=l
    assert sorted(init)==list(range(32)); return init
p3=perm(xi_mc)
print("== 5a. Xiang T4 == reverse(Xiang T3) gate-for-gate?  raw register pairs:", [(i,j) for i,j,_ in xi_imc]==[(i,j) for i,j,_ in reversed(xi_mc)],
      "  after relabelling register r of reversed T3 as input p(r):", [(i,j) for i,j,_ in xi_imc]==[(p3[i],p3[j]) for i,j,_ in reversed(xi_mc)])
for nm,prog,init in [("Xiang T4 (as printed)",xi_imc,None),("reverse(Yuan T4)",rev(yu_mc),perm(yu_mc))]:
    g,reg,mask,depth=sxor_unroll(prog,init)
    D=max(depth[reg[i]] for i in range(32)); A,_=asap_depth(IMC,mask)
    print("   %-22s ops=%d transcribed depth=%d  ASAP-over-same-masks depth=%d"%(nm,len(prog),D,A))
# Yuan Table 5: depth-annotated in-place quantum MixColumn, 98 CNOT, depth 13
Y=txt(f"{NEW}/papers/yuan2024.txt")
blk=after(Y,'Table 5: The quantum implementation of AES MixColumn with depth of 13 and 98 XORs',60)
pat=re.compile(r'(\d+)\s+x\[(\d+)\] = x\[(\d+)\] \+ x\[(\d+)\](?: y\[(\d+)\])?')
cols=[[],[],[]]
for L in blk:
    ms=pat.findall(L)
    if not ms: continue
    for c,m in enumerate(ms): cols[c].append(m)
ents=cols[0]+cols[1]+cols[2]
print("== 5b. Yuan Table 5 parsed entries:",len(ents),"  depth layers:",sorted(set(int(e[0]) for e in ents))[-1])
ents.sort(key=lambda e:int(e[0]))   # instructions within a layer act on disjoint qubits, so layer order is a valid order
prog=[(int(i),int(j),None if l=='' else int(l)) for d,i,a,j,l in ents]
assert all(int(e[1])==int(e[2]) for e in ents)
# disjointness within layers (CNOT layer validity)
from collections import defaultdict
lay=defaultdict(list)
for d,i,a,j,l in ents: lay[int(d)]+= [int(i),int(j)]
print("   layers valid (disjoint qubits within each layer):", all(len(v)==len(set(v)) for v in lay.values()))
g,reg,mask,depth=sxor_unroll(prog); final=[mask[reg[i]] for i in range(32)]
print("   forward Table 5 computes:",identify(final)," unrolled SLP depth=%d (paper's CNOT depth 13)"%max(depth[reg[i]] for i in range(32)))
init=[None]*32          # derive the output->register permutation from the forward run itself (labels in Table 5 are partial in pdftotext)
for r in range(32): init[r]=MC.index(final[r])
assert sorted(init)==list(range(32))
gr,regr,maskr,depthr=sxor_unroll(rev(prog),init); finalr=[maskr[regr[i]] for i in range(32)]
Dr=max(depthr[regr[i]] for i in range(32)); Ar,_=asap_depth(IMC,maskr)
print("   reverse(Table 5) computes:",identify(finalr)," ops=%d  unrolled SLP depth=%d  ASAP-over-masks depth=%d  (CNOT layer depth of reversed = 13 by layer reversal)"%(len(prog),Dr,Ar))
# is (Dr, 98) dominated by the project's frontier {(5,225),(6,216),(9,164),(16,89)}?
front=[(5,225),(6,216),(9,164),(16,89)]
dom=[p for p in front if p[0]<=Dr and p[1]<=98]
print("   dominated by a project frontier point?", dom if dom else "NO -> a published-implied InvMixColumns point (%d, 98) is missing from the frontier"%Dr)
json.dump({"yuan_T5_prog":prog},open(f"{NEW}/referee_89/yuan_T5_transcription.json","w"))

# ---- Shi-Feng ePrint 2024/381 Table 11: in-place CNOT circuit of MixColumns, 131 CNOT, CNOT depth 10 ----
Q=txt(f"{S}/q2024_381.txt")
blk=after(Q,'A     The depth 10 implementation of AES MixColumns.',30)
tok=re.compile(r'\((\d+),\s*(\d+)\)|Depth\s+(\d+)')
rowsT=[]
for L in blk[1:]:
    ms=[(m.start(),m.groups()) for m in tok.finditer(L)]
    if ms: rowsT.append(ms)
# column anchors from the header positions of 'Operation'
hdr=[L for L in blk if L.count('Operation')>=6][0]
anchors=[m.start() for m in re.finditer('Operation',hdr)]
cols=[[] for _ in anchors]
for ms in rowsT:
    for pos,g in ms:
        c=min(range(len(anchors)),key=lambda k:abs(anchors[k]-pos)); cols[c].append(g)
seq=[g for c in cols for g in c]
layer=0; prog11=[]; lay=defaultdict(list)
for i,j,d in seq:
    if d: layer=int(d); continue
    prog11.append((int(j),int(i),None)); lay[layer]+=[int(i),int(j)]   # (i,j): add qubit i to qubit j  => x_j ^= x_i
print("== 5c. ePrint 2024/381 Table 11 parsed: %d CNOTs, %d layers, layers disjoint: %s"%(len(prog11),len(lay),all(len(v)==len(set(v)) for v in lay.values())))
g11,reg11,m11,d11=sxor_unroll(prog11); f11=[m11[reg11[i]] for i in range(32)]
print("   forward computes:",identify(f11),"  unrolled SLP depth=%d (CNOT depth 10)"%max(d11[reg11[i]] for i in range(32)))
stated=[0,17,18,27,28,21,22,15,16,25,26,3,20,29,30,7,24,1,10,19,12,5,6,31,8,9,2,11,4,13,14,23]
print("   paper's stated output qubits consistent with my evaluation:", all(m11[reg11[stated[l]]]==MC[l] for l in range(32)))
init11=[MC.index(f11[r]) for r in range(32)]
gr,regr,mr,dr=sxor_unroll(rev(prog11),init11); fr=[mr[regr[i]] for i in range(32)]
Dr11=max(dr[regr[i]] for i in range(32)); Ar11,_=asap_depth(IMC,mr)
print("   reverse(Table 11) computes:",identify(fr)," ops=%d unrolled SLP depth=%d ASAP-over-masks depth=%d; CNOT depth of the reversed layering = 10"%(len(prog11),Dr11,Ar11))
json.dump({"shi_feng_2024_381_T11_prog":prog11},open(f"{NEW}/referee_89/shifeng_T11_transcription.json","w"))
