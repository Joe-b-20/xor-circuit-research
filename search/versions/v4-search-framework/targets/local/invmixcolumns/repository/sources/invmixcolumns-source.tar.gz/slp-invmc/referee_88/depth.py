#!/usr/bin/env python3
"""Item 4: ASAP minimum depth over the circuit's own mask set (my own least fixpoint).
Given the multiset of 120 signal masks, re-wire freely: a gate mask m may be produced
by ANY pair (x,y) of masks in the set with x^y=m.  level(input)=0;
level(m) = min over such pairs of max(level(x),level(y))+1.  Least fixpoint from +inf
(so a mask that can only be 'derived' circularly stays unreachable)."""
import json, itertools
REPO="~/xor_ui/slp-invmc"
E=json.load(open(REPO+"/referee_88/eval.json"))
G=json.load(open(REPO+"/circuits/invmc_walk_88_depth33.json"))["gates"]
masks=E["masks"]; outs=E["outs"]; dep=E["depth"]
INF=10**9
print("="*78); print("I. depth"); print("="*78)
print("as-wired longest input->output path:", max(dep[o] for o in outs))

M=list(masks); idx={m:i for i,m in enumerate(M)}
lev=[0]*32+[INF]*(len(M)-32)
# precompute, for each mask, the list of unordered pairs from M producing it
pairs={}
for i in range(len(M)):
    for j in range(i+1,len(M)):
        c=M[i]^M[j]
        if c in idx: pairs.setdefault(idx[c],[]).append((i,j))
npairs=sum(len(v) for v in pairs.values())
print("derivation pairs available inside the mask set: %d (avg %.1f per gate mask)"
      %(npairs, npairs/88.0))
changed=True; rounds=0
while changed:
    changed=False; rounds+=1
    for k in range(32,len(M)):
        best=INF
        for (i,j) in pairs.get(k,[]):
            v=max(lev[i],lev[j])+1
            if v<best: best=v
        if best<lev[k]: lev[k]=best; changed=True
print("least fixpoint reached in %d sweeps"%rounds)
unreach=[k for k in range(32,len(M)) if lev[k]>=INF]
print("gate masks unreachable within the set:", unreach)
asap=max(lev[o] for o in outs)
print("ASAP minimum depth over this mask set:", asap)
print("per-output ASAP level:", [lev[o] for o in outs])
print("as-wired per-output level:", [dep[o] for o in outs])
print("max gate ASAP level (all signals):", max(lev[32:]))
print()
print("VERDICT on depth: as-wired 33 ; ASAP over the same masks", asap,
      "->", "LOWER than 33" if asap<33 else ("equal to 33" if asap==33 else "higher"))
if asap<33:
    # emit the ASAP-rewired circuit
    order=sorted(range(32,len(M)), key=lambda k:(lev[k],k))
    pos={}; out=[]
    for t,m in enumerate(M[:32]): pos[m]=t
    ng=[]
    for k in order:
        cand=min(pairs[k], key=lambda p: max(lev[p[0]],lev[p[1]]))
        ng.append([cand[0],cand[1]])
    print("(an ASAP re-wiring exists at depth %d with the same 88 masks)"%asap)
    json.dump({"note":"ASAP re-wiring of the same mask set; signal k of the ORIGINAL numbering",
               "asap_level":lev,"depth":asap},
              open(REPO+"/referee_88/asap_levels.json","w"))
