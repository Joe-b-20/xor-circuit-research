#!/usr/bin/env python3
"""
worker.py  --  one search worker of the pipeline, run in CHUNKS forever.

Launched by ladder_parallel.py as its own OS process. It runs one engine at a
fixed depth cap, and between fixed-length chunks it RE-SEEDS from the best
circuit the coordinator has offered it (reseed_<label>.json) whenever that
circuit Pareto-beats its own best. It continuously:
  * saves the best VERIFIED circuit so far to  <out_dir>/<label>_best.json
  * writes live status to                      <out_dir>/<label>_status.json
  * appends a log to                           <out_dir>/<label>.log
  * (if harvesting is on) appends every distinct plateau state it visits to
    <out_dir>/<label>.pop.jsonl

verify-before-claim, TWICE: a candidate is only accepted by improve() after
(a) the in-process GF(2^8) verifier and (b) a SUBPROCESS call to the generic
oracle `tools/verify_slp_generic.py --target spec/invmc_matrix.json`, which
shares no code with the engines and re-derives the target from the field
itself.  The oracle decides; nothing is written as a "best" without its VALID.
Every emitted file is the canonical index-pair JSON with a provenance block.

R8: a dead-gate strip (core.strip_dead) runs before either verifier, so the
count that is claimed is the count of the stripped circuit.

Pareto tie-break: improve() accepts a candidate when it has FEWER gates, OR the
same gate count at STRICTLY LOWER depth. So an n@depth5 found while the best is
n@depth6 is kept, not discarded. On a matrix whose depth frontier was EMPTY
before this project, that clause is not a tie-break -- it is the result.

The engine name "alt" is not an engine but a worker mode: it alternates a short
`walk` chunk with a longer `lns` chunk, each starting from the worker's own
best. The walk sprays across the plateau (hundreds of iterations per second,
harvesting as it goes) and the lns then punches down from wherever the walk
ended up; this alternation is what the FORWARD campaign's best-performing hunt
workers ran (it reached all five forward 88-gate circuits).  Whether it is the
right mode on this matrix is an open question, which is why set A runs lns,
walk and alt side by side.

Depth caps below core.MIN_DEPTH (= 5 here: the heaviest target row has weight
19) are infeasible by arithmetic and are refused at startup, not searched.

Usage (the coordinator calls this):
  python3 worker.py <label> <engine|alt> <depth|none> <scratch|seedfile> <out_dir> <seeds_csv>
Engine knobs, chunk lengths, and reseeding are read from <out_dir>/config.json.
"""
import os, sys, json, time, socket
import invmc_core as core
import engines


def atomic_write_json(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(obj, f)
    os.replace(tmp, path)


def pareto_better(g2, d2, g1, d1):
    """(g2,d2) beats (g1,d1): fewer gates, or equal gates at lower depth."""
    if g1 is None:
        return True
    return g2 < g1 or (g2 == g1 and d2 < d1)


class WorkerCtx:
    def __init__(self, label, cap, out_dir, engine="?", seed_desc="?", cmd=""):
        self.label = label
        self.cap = cap
        self.engine = engine
        self.seed_desc = seed_desc
        self.out_dir = out_dir
        self.cmd = cmd
        self.oracle_line = "(not yet run)"
        self.oracle_cmdline = " ".join(core.oracle_cmd("<circuit.json>", cap))
        self.n_oracle_fail = 0
        self.best_path = os.path.join(out_dir, "%s_best.json" % label)
        self.status_path = os.path.join(out_dir, "%s_status.json" % label)
        self.logf = open(os.path.join(out_dir, "%s.log" % label), "a", buffering=1)
        self.t0 = time.time()
        self.best_n = None
        self.best_depth = None
        self.best_masks = None
        self.status = {"label": label, "cap": cap, "pid": os.getpid(),
                       "best_gates": None, "best_depth": None,
                       "started": self.t0, "updated": self.t0, "alive": True}
        self._flush_status()

    def _flush_status(self):
        self.status["updated"] = time.time()
        atomic_write_json(self.status_path, self.status)

    def log(self, msg):
        line = "[%8.1fs %s] %s" % (time.time() - self.t0,
                                   time.strftime("%H:%M:%S"), msg)
        print(line, flush=True)
        self.logf.write(line + "\n")
        self._flush_status()

    def cpu_s(self):
        """CPU-seconds of this worker process (user+sys, self+children), from
        the OS -- never wall clock (D17)."""
        t = os.times()
        return round(t[0] + t[1] + t[2] + t[3], 3)

    def provenance(self, gates, depth, note):
        return {"engine": self.engine, "seed": self.seed_desc,
                "worker": self.label, "worker_pid": os.getpid(),
                "host": socket.gethostname(),
                "depth_cap": self.cap, "depth": depth, "gates": len(gates),
                "cpu_s": self.cpu_s(), "wall_s": round(time.time() - self.t0, 1),
                "note": note, "run_dir": self.out_dir,
                "cmd": self.cmd,
                "oracle": self.oracle_line,
                "oracle_cmd": self.oracle_cmdline,
                "target": core.SPEC_MATRIX,
                "dead_gate_stripped": True,
                "produced_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}

    def _record(self, circuit, gates, depth, masks, note=""):
        self.best_n = gates; self.best_depth = depth; self.best_masks = set(masks)
        core.save(circuit, self.best_path,
                  extra={"depth": depth, "verified": True, "cap": self.cap,
                         "provenance": self.provenance(circuit, depth, note)})
        self.status["best_gates"] = gates; self.status["best_depth"] = depth
        self.status["cpu_s"] = self.cpu_s()
        self._flush_status()

    def _oracle_ok(self, circuit, what):
        """The ground truth.  A subprocess call to tools/verify_slp_generic.py,
        which shares no code with the engines.  A failure here is loud: it means
        the in-process verifier and the oracle disagree, which is a stop-work
        condition, not a rejected candidate."""
        ok, out, cmd = core.oracle_verify(circuit, self.cap)
        self.oracle_cmdline = cmd
        line = [l for l in out.splitlines() if l.startswith("VERDICT")]
        self.oracle_line = (line[0] if line else out.strip()[:200])
        if not ok:
            self.n_oracle_fail += 1
            self.log("  *** ORACLE REJECTED a candidate the in-process verifier "
                     "PASSED (%s) -- NOT claimed. This is a disagreement between "
                     "two verifiers and must be chased to ground." % what)
            for l in out.splitlines():
                self.log("      oracle| %s" % l)
        return ok

    def improve(self, circuit, masks, note=""):
        circuit = core.strip_dead(circuit)          # R8, before any count is quoted
        v = core.verify(circuit, max_depth=self.cap)
        if not v["ok"]:
            self.log("  WARNING candidate REJECTED (outputs=%d/32 depth=%d) -- not claimed"
                     % (v["outputs"], v["depth"]))
            return False
        if not pareto_better(v["gates"], v["depth"], self.best_n, self.best_depth):
            return False
        if not self._oracle_ok(circuit, "%d gates depth %d" % (v["gates"], v["depth"])):
            return False
        self._record(circuit, v["gates"], v["depth"], masks, note)
        self.log("  NEW BEST %d gates depth %d VERIFIED+ORACLED %s -> %s  [%s]"
                 % (v["gates"], v["depth"], note,
                    os.path.basename(self.best_path), self.oracle_line))
        return True

    def adopt(self, circuit, masks, source):
        """Adopt a coordinator-offered reseed as this worker's best (already
        verified feasible at cap by the coordinator; re-verified here, oracle
        included -- an offer is a file another process wrote)."""
        circuit = core.strip_dead(circuit)
        v = core.verify(circuit, max_depth=self.cap)
        if not v["ok"] or not pareto_better(v["gates"], v["depth"], self.best_n, self.best_depth):
            return False
        if not self._oracle_ok(circuit, "reseed from %s" % source):
            return False
        self._record(circuit, v["gates"], v["depth"], masks, "adopted from " + source)
        self.log("  ADOPTED reseed %d gates depth %d from %s"
                 % (v["gates"], v["depth"], source))
        return True


def knobs_for(cfg, engine, label):
    """Knobs for one engine: the run's defaults plus this worker's overrides.
    An override dict is either flat (a single-engine worker) or keyed by engine
    name, which is how an "alt" worker overrides its walk and lns chunks
    separately."""
    knobs = dict(cfg["knobs"][engine])
    over = cfg.get("worker_knobs", {}).get(label, {})
    if any(name in over for name in cfg["knobs"]):
        over = over.get(engine, {})
    knobs.update(over)
    return knobs


def wire_harvest(knobs, out_dir, label):
    """Turn the harvest / cross_pollinate switches into the paths the engines
    use: this worker harvests into <label>.pop.jsonl, and -- only if explicitly
    asked -- also reads every sibling *.pop.jsonl of the run into its rebuild
    pool. Cross-pollination mixes the mask provenance of all workers in the run,
    so it is off unless a config turns it on (see ladder_parallel.py)."""
    if knobs.pop("harvest", False):
        knobs["harvest_path"] = os.path.join(out_dir, "%s.pop.jsonl" % label)
    if knobs.pop("cross_pollinate", False):
        knobs["pop_glob"] = os.path.join(out_dir, "*.pop.jsonl")
    return knobs


def main():
    label = sys.argv[1]; engine = sys.argv[2]; depth_arg = sys.argv[3]
    start_arg = sys.argv[4]; out_dir = sys.argv[5]
    seeds = [int(x) for x in sys.argv[6].split(",")] if len(sys.argv) > 6 and sys.argv[6] else [1]
    cap = None if depth_arg.lower() in ("none", "free", "-1") else int(depth_arg)

    # INFEASIBLE CAPS ARE REFUSED UP FRONT.  The heaviest InvMixColumns target
    # row has weight 19, so every circuit for this matrix has depth >=
    # ceil(log2 19) = 5.  A cap below that is not a hard search, it is an empty
    # one; exit loudly instead of burning a core on it.
    if cap is not None and cap < core.MIN_DEPTH:
        sys.stderr.write(
            "worker %s REFUSED: depth cap %d < MIN_DEPTH %d (max target row "
            "weight %d). No circuit of that depth exists for this matrix.\n"
            % (label, cap, core.MIN_DEPTH, core.MAX_TARGET_WEIGHT))
        sys.exit(4)
    if engine in engines.RETIRED_ENGINES:
        sys.stderr.write("worker %s REFUSED: %s\n"
                         % (label, engines.RETIRED_ENGINES[engine]))
        sys.exit(4)

    with open(os.path.join(out_dir, "config.json")) as f:
        cfg = json.load(f)
    chunk_s = cfg.get("chunk_s", 600)
    walk_chunk_s = cfg.get("walk_chunk_s", 300)
    reseed_on = cfg.get("reseed", True)
    # "alt" alternates walk and lns chunks; any other name is a single engine.
    cycle = ("walk", "lns") if engine == "alt" else (engine,)
    knobs = {e: wire_harvest(knobs_for(cfg, e, label), out_dir, label) for e in cycle}

    ctx = WorkerCtx(label, cap, out_dir, engine=engine,
                    seed_desc=os.path.basename(start_arg),
                    cmd=" ".join([sys.executable] + sys.argv))
    ctx.log("worker start: engine=%s depth=%s start=%s seeds=%s chunk=%ds reseed=%s"
            % (engine, cap, start_arg, seeds, chunk_s, reseed_on))
    ctx.log("target=%s MIN_DEPTH=%d oracle=%s"
            % (core.SPEC_MATRIX, core.MIN_DEPTH, core.ORACLE))
    ctx.log("knobs: %s" % json.dumps(knobs, sort_keys=True))

    # initial seed
    if start_arg == "scratch":
        seed_masks = None
    else:
        seed_masks = core.load_circuit_masks(start_arg)
        # A capped worker seeded from a deeper circuit: LIFT it rather than let
        # the engine abort the stage every chunk (which would spin a core).
        if cap is not None and not engines.feasible_at(seed_masks, cap):
            lifted, adm, off = engines.lift_to_cap(seed_masks, cap)
            ctx.log("  seed %s is NOT feasible at cap %d -- lifted onto the cold "
                    "naive set: %d of %d seed masks admitted, start = %d masks"
                    % (os.path.basename(start_arg), cap, adm, off, len(lifted)))
            ctx.seed_desc = "%s (lifted to cap %d: %d/%d masks kept)" % (
                os.path.basename(start_arg), cap, adm, off)
            seed_masks = lifted

    reseed_path = os.path.join(out_dir, "reseed_%s.json" % label)
    chunk = 0; short = 0
    try:
        while True:
            # (a) consider a coordinator reseed before this chunk
            if reseed_on and os.path.exists(reseed_path):
                try:
                    with open(reseed_path) as f:
                        rg = json.load(f)["gates"]
                    rmasks = core.load_circuit_masks(reseed_path)
                    if ctx.adopt(rg, rmasks, os.path.basename(reseed_path)):
                        seed_masks = set(rmasks)
                except Exception as e:
                    ctx.log("  reseed read failed: %s" % e)
            # (b) run one bounded chunk from the current seed (never self-stops)
            eng = cycle[chunk % len(cycle)]
            secs = walk_chunk_s if (engine == "alt" and eng == "walk") else chunk_s
            t_chunk = time.time()
            engines.run_engine(eng, seed_masks, cap, None, secs, seeds, knobs[eng], ctx)
            # A chunk that returns instantly means the engine aborted (an
            # infeasible start, say).  Two in a row is a dead worker spinning a
            # core, not a search: stop and say so.
            if time.time() - t_chunk < 2.0:
                short += 1
                if short >= 2:
                    ctx.log("  FATAL: engine %s returned in <2s twice -- the "
                            "start is not usable at cap %s. Stopping worker."
                            % (eng, cap))
                    break
            else:
                short = 0
            # (c) continue next chunk from this worker's own best
            if ctx.best_masks is not None:
                seed_masks = set(ctx.best_masks)
            seeds = [s + 1 for s in seeds]        # vary RNG across chunks
            chunk += 1
    except KeyboardInterrupt:
        pass
    finally:
        ctx.status["alive"] = False
        ctx.status["cpu_s"] = ctx.cpu_s()
        ctx.status["oracle_failures"] = ctx.n_oracle_fail
        ctx._flush_status()
        ctx.log("worker stopped (cpu_s=%.1f oracle_failures=%d)"
                % (ctx.cpu_s(), ctx.n_oracle_fail))


if __name__ == "__main__":
    main()
