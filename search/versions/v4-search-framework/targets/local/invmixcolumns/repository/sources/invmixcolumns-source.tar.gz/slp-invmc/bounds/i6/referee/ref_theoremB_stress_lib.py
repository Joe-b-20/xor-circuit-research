#!/usr/bin/env python3

import itertools, random, sys

def closure(c, V, E):
    """honest greedy closure: available starts at the c inputs; an element of
    V u E is added only when it is the XOR of two ALREADY-available signals."""
    A = set(1 << i for i in range(c))
    todo = list(V) + list(E)
    ch = True
    while ch:
        ch = False
        for s in todo:
            if s in A: continue
            for a in A:
                if (s ^ a) in A:
                    A.add(s); ch = True; break
    return A

def minE(c, V, maxb=4, pool=None):
    if pool is None:
        pool = [m for m in range(1 << c) if bin(m).count('1') >= 2]
    for b in range(0, maxb + 1):
        for E in itertools.combinations(pool, b):
            A = closure(c, V, E)
            if all(v in A for v in V):
                return b
    return None

def exactL(c, V, maxg=8):
    """exact minimum #gates in the RAW SLP model."""
    tgt = set(V)
    def dfs(avail, budget):
        rem = tgt - avail
        if not rem: return True
        if len(rem) > budget: return False
        al = sorted(avail)
        for i in range(len(al)):
            for j in range(i + 1, len(al)):
                m = al[i] ^ al[j]
                if m in avail: continue
                if dfs(avail | {m}, budget - 1): return True
        return False
    base = frozenset(1 << i for i in range(c))
    for g in range(0, maxg + 1):
        if dfs(set(base), g): return g
    return None

