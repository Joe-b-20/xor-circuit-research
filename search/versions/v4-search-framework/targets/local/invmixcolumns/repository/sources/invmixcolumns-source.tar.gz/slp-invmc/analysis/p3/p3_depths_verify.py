import json,sys,os,random,subprocess,collections,tempfile
sys.path.insert(0,"~/xor_ui/slp-invmc/pipeline")
import invmc_core as core, engines
REPO="~/xor_ui/slp-invmc"
ORACLE=os.path.join(REPO,"tools","verify_slp_generic.py")
TGT=os.path.join(REPO,"spec","invmc_matrix.json")
random.seed(4242)

cen=json.load(open(sys.argv[1]))
sets88=json.load(open(sys.argv[2]))
outp=sys.argv[3]

def rot8(m): return ((m<<8)|(m>>24))&0xFFFFFFFF

pop={}   # n -> list of mask sets to analyse
pop[88]=sets88
for n,v in cen["samples"].items():
    n=int(n)
    if 88<=n<=95 and n!=88: pop[n]=v

res={}
tmpd=tempfile.mkdtemp()
for n in sorted(pop):
    sets=pop[n]
    depths=collections.Counter(); bad=0
    for ms in sets:
        try:
            g=engines.indexpairs_from_masks(set(ms),None)
            v=core.verify(g)
            if not v["ok"] or v["gates"]!=n: bad+=1; continue
            depths[v["depth"]]+=1
        except Exception:
            bad+=1
    # rho-fixed check (P7 side-control): is any set equal to its own byte-rotation?
    rho=0
    for ms in sets:
        s=set(ms)
        if set(rot8(m) for m in s)==s: rho+=1
    # oracle sample: up to 20
    idx=random.sample(range(len(sets)),min(20,len(sets)))
    npass=0; verdicts=[]
    for i in idx:
        ms=set(sets[i])
        g=engines.indexpairs_from_masks(ms,None)
        p=os.path.join(tmpd,"c_%d_%d.json"%(n,i))
        json.dump({"gateCount":len(g),"gates":g},open(p,"w"))
        r=subprocess.run(["python3",ORACLE,"--target",TGT,p],capture_output=True,text=True)
        line=[l for l in r.stdout.splitlines() if l.startswith("VERDICT")]
        verdicts.append((i,r.returncode,line[0] if line else r.stdout.strip()[:80]))
        if r.returncode==0: npass+=1
    res[n]={"analysed":len(sets),"depth_hist":dict(depths),"rebuild_failures":bad,
            "rho_fixed":rho,"oracle_sampled":len(idx),"oracle_pass":npass,
            "oracle_verdicts":verdicts[:3]}
    print(n,"analysed",len(sets),"depths",dict(sorted(depths.items())),"badrebuild",bad,
          "rho_fixed",rho,"ORACLE %d/%d"%(npass,len(idx)),flush=True)
json.dump(res,open(outp,"w"),indent=1)
