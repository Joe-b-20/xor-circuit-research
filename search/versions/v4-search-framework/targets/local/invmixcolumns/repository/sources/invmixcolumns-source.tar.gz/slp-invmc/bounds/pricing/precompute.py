#!/usr/bin/env python3
"""precompute.py -- time dslp_ref's two 2^r precomputes, which build_cnf runs
ONCE PER k-LEVEL: delta_array (always) and reach_levels (only when a depth cap
is set).  Reports CPU seconds and peak RSS at each rank actually reachable.
"""
import json, os, resource, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import dslp_ref as D
from blocks import block


def cpu():
    r = resource.getrusage(resource.RUSAGE_SELF)
    return r.ru_utime + r.ru_stime


which, j, what = sys.argv[1], int(sys.argv[2]), sys.argv[3]
b = block(which, j)
r, iv = b['r'], b['inputs']
o = dict(which=which, j=j, r=r, m=len(iv), what=what)
c0 = cpu()
if what == 'delta':
    d = D.delta_array(r, iv)
    o['n_unreachable_within_2'] = int((d > 2).sum())
else:
    R = D.reach_levels(r, iv, [0] * len(iv), 5)
    o['reach_sizes'] = [int(x.sum()) for x in R]
o['cpu'] = round(cpu() - c0, 2)
o['maxrss_mb'] = round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024, 1)
print(json.dumps(o), flush=True)
