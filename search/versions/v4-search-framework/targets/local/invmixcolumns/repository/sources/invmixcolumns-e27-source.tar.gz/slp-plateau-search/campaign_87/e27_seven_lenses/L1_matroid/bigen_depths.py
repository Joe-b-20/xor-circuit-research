#!/usr/bin/env python3
"""Depth (ASAP, from O) of the InvMixColumns circuit for every bi-generated corpus 88;
oracle-verify the 12 shallowest distinct-up-to-rotation ones."""
import json, collections, subprocess, sys, os
import numpy as np
from lib import TARGETS, INPUTS, REPO, LANE
from bigen_invmc import build, OUTDIR
mm = np.memmap(f"{REPO}/wrapup/day2/deletion_cert/masks.bin", dtype="<u4", mode="r").reshape(-1, 88)
idx = [int(l.split()[1]) for l in open("bigen_full.txt") if l.startswith("FULL")]
rot = lambda p, k: ((p << (8 * k)) | (p >> (32 - 8 * k))) & 0xFFFFFFFF if k else p
rows = []; canon = {}
for i in idx:
    U = set(int(x) for x in mm[i])
    r = build(U)
    assert r is not None and r["ok"], i
    c = min(tuple(sorted(rot(p, k) for p in U)) for k in range(4))
    canon.setdefault(c, []).append(i)
    rows.append((r["depth"], i))
print("bi-generated corpus 88s:", len(idx), "; distinct up to byte rotation:", len(canon))
print("InvMC depth histogram:", sorted(collections.Counter(d for d, _ in rows).items()))
rows.sort()
seen = set(); pick = []
for d, i in rows:
    U = set(int(x) for x in mm[i]); c = min(tuple(sorted(rot(p, k) for p in U)) for k in range(4))
    if c in seen: continue
    seen.add(c); pick.append(i)
    if len(pick) == 12: break
json.dump({"n": len(idx), "distinct_rot": len(canon), "depth_hist": sorted(collections.Counter(d for d, _ in rows).items()),
           "shallowest12": pick}, open("bigen_depths.json", "w"))
print("verifying shallowest 12 (distinct up to rotation):", pick)
subprocess.run([sys.executable, "bigen_invmc.py"] + [str(i) for i in pick])
