#!/usr/bin/env python3
"""xcheck_brute.py -- validate ./brute and the ported DFS against a from-scratch
Python enumerator, on random instances small enough to decide by brute force.

Three code paths, written independently of each other:
  A  i6_core.Search        -- the port of OLD deep_extras.py: pairsum branching
                              with prunings P1/P2/P3.  Fast, and complete only
                              because of NOTEBOOK sec. 2b's five-step argument.
  B  ./brute (C)           -- full-pool exhaustion, incremental closure, no
                              pruning of any kind.
  C  reference() below     -- itertools.combinations over the full pool with a
                              from-scratch realizability test.  Slowest, most
                              obviously correct.

If A, B and C agree on minE for every random instance, the five-step argument
and both implementations are exercised together.  This is the analogue of the
forward referee's 700-instance validation (OLD PROOFCHECK.md:238-252), which is
what let their `minE >= 4` be believed.

Usage: python3 xcheck_brute.py --c 6 --n 200 --seed 1 --cap 3
"""
import argparse
import itertools
import os
import random
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import i6_core as i6                                    # noqa: E402


def realizable(c, G):
    avail = set(1 << i for i in range(c))
    todo = set(G) - avail
    changed = True
    while changed and todo:
        changed = False
        for g in list(todo):
            for a in avail:
                if (g ^ a) in avail:
                    avail.add(g)
                    todo.discard(g)
                    changed = True
                    break
    return not todo


def reference(c, V, cap):
    """Path C.  Returns minE if <= cap, else cap+1."""
    Vs = set(V)
    pool = sorted(m for m in range(1, 1 << c)
                  if bin(m).count('1') >= 2 and m not in Vs)
    for d in range(cap + 1):
        for E in itertools.combinations(pool, d):
            if realizable(c, Vs | set(E)):
                return d
    return cap + 1


def path_a(c, V, cap):
    s = i6.Search(c, V, prune_last=True, memo=True)
    k, wit = s.run(cap)
    return k


def path_b(c, V, cap):
    """Iterative deepening on ./brute: the smallest d at which it says
    COMPLETION."""
    t = ','.join(str(v) for v in V)
    for d in range(cap + 1):
        r = subprocess.run([os.path.join(HERE, 'brute'), str(c), t, str(d)],
                           capture_output=True, text=True)
        if r.returncode == 1:
            return d
        if r.returncode != 0:
            raise RuntimeError(r.stderr)
    return cap + 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--c', type=int, default=6)
    ap.add_argument('--n', type=int, default=200)
    ap.add_argument('--ntargets', type=int, default=12)
    ap.add_argument('--seed', type=int, default=1)
    ap.add_argument('--cap', type=int, default=3)
    ap.add_argument('--minwt', type=int, default=2,
                    help='draw targets only from masks of weight >= this, to force jams')
    a = ap.parse_args()

    rng = random.Random(a.seed)
    pool = [m for m in range(1, 1 << a.c) if bin(m).count('1') >= a.minwt]
    t0 = time.process_time()
    agree = 0
    hist = {}
    for i in range(a.n):
        V = rng.sample(pool, min(a.ntargets, len(pool)))
        ka = path_a(a.c, V, a.cap)
        kb = path_b(a.c, V, a.cap)
        kc = reference(a.c, V, a.cap)
        hist[kc] = hist.get(kc, 0) + 1
        if ka == kb == kc:
            agree += 1
        else:
            print("DISAGREE c=%d V=%s : Search=%d brute=%d reference=%d"
                  % (a.c, V, ka, kb, kc))
    dt = time.process_time() - t0
    print("c=%d  %d random instances of %d targets (weight >= %d), cap=%d, seed=%d"
          % (a.c, a.n, a.ntargets, a.minwt, a.cap, a.seed))
    print("  Search(A) == brute.c(B) == reference(C) on %d/%d" % (agree, a.n))
    print("  minE histogram (reference) : %s" % dict(sorted(hist.items())))
    print("  %s" % ("ALL AGREE" if agree == a.n else "*** MISMATCH ***"))
    print("cpu_seconds %.3f  (excludes the C subprocesses' own CPU)" % dt)
    return 0 if agree == a.n else 1


if __name__ == '__main__':
    sys.exit(main())
