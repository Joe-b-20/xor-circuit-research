#!/usr/bin/env bash
# K2 tripwire over EVERY circuit in circuits/ -- the InvMixColumns ones against
# spec/invmc_matrix.json, the four MixColumns transcriptions that live in the
# same directory against spec/mixcolumns_matrix.json.
set -u
cd "$(dirname "$0")/.."
OUT=${K2_OUTDIR:-<tmp>/k2_out}
K2="nice -n 19 python3 tools/tripwire_K2.py"

echo "############ K2 SWEEP  $(date -u +%Y-%m-%dT%H:%M:%SZ) ############"
echo "host=$(hostname)  python=$(python3 -V 2>&1)"
echo "commit=$(git rev-parse --short HEAD)"
echo
echo "===== InvMixColumns circuits (target spec/invmc_matrix.json) ====="
$K2 --target spec/invmc_matrix.json --outdir "$OUT" \
    --jsonl controls/K2_invmc_ledger.jsonl \
    $(ls circuits/invmc_*.json | sort)
echo "exit=$?"
echo
echo "===== MixColumns transcriptions in the same directory ====="
echo "(these are forward circuits kept here as controls; scanned for free)"
$K2 --target spec/mixcolumns_matrix.json --outdir "$OUT" \
    --jsonl controls/K2_invmc_ledger.jsonl \
    $(ls circuits/mixcolumns_*.json | sort)
echo "exit=$?"
echo
echo "############ END K2 SWEEP ############"
