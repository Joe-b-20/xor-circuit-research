#!/bin/bash
# Collect every worker best from both live runs, oracle it, schedule it, and
# print a Pareto frontier. Read-only with respect to the running fleet.
set -u
cd ~/xor_ui/slp-invmc
A=pipeline/runs/20260908_135521      # FIXED setA
C=pipeline/runs/20260908_135525      # CASCADE
echo "collected_utc: $(date -u +%Y-%m-%dT%H:%M:%SZ)   local: $(date +%H:%M:%S)"
echo
for R in $A $C; do
  echo "##### run $R"
  for f in $R/*_best.json; do
    [ -e "$f" ] || continue
    python3 - "$f" <<'PY'
import json,sys
f=sys.argv[1]
d=json.load(open(f))
p=d.get("provenance",{})
print("  %-42s %4d gates @ depth %-3s cap=%-5s cpu_s=%-9s engine=%-5s seed=%s"
      % (f.split("/")[-1], d["gateCount"], d.get("depth"), p.get("depth_cap"),
         p.get("cpu_s"), p.get("engine"), p.get("seed")))
PY
  done
  echo "  -- status files (cpu_s, oracle_failures) --"
  for s in $R/*_status.json; do
    [ -e "$s" ] || continue
    python3 -c "
import json,sys
d=json.load(open('$s'))
print('  %-20s best=%s@%s cpu_s=%s alive=%s oracle_failures=%s'%(d['label'],d.get('best_gates'),d.get('best_depth'),d.get('cpu_s'),d.get('alive'),d.get('oracle_failures','-')))"
  done
  echo "  -- exceptions --"
  grep -l "Traceback" $R/*.log $R/*.stdout 2>/dev/null || echo "  none"
  echo
done
echo "##### oracle + ASAP depth on every distinct best"
for f in $A/*_best.json $C/*_best.json; do
  [ -e "$f" ] || continue
  echo "--- $f"
  nice -n 19 python3 tools/verify_slp_generic.py --target spec/invmc_matrix.json "$f" | tail -2 | sed 's/^/    /'
  nice -n 19 python3 tools/depth_schedule.py --target spec/invmc_matrix.json "$f" 2>&1 | grep -E "^\(|gates=" | sed 's/^/    /'
done
