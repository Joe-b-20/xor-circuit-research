#!/usr/bin/env python3
"""Referee: (2) shrink attacks on the 89, (4) s-XOR (in-place, 32 registers, no temporaries) realisability."""
import json, itertools, sys, random
random.seed(1)
NEW="~/xor_ui/slp-invmc"
J=json.load(open(f"{NEW}/circuits/invmc_alt_89_depth16.json")); gates=J["gates"]; n=len(gates)
E=json.load(open(f"{NEW}/referee_89/eval.json")); rows=E["rows"]; mask=E["mask"]
outsig={int(k):v for k,v in E["outsig"].items()}; OUT=set(outsig.values())
NS=32+n
children={s:[] for s in range(NS)}
for k,(a,b) in enumerate(gates): children[a].append(32+k); children[b].append(32+k)
def descendants(gs):
    D=set(gs); st=list(gs)
    while st:
        s=st.pop()
        for c in children[s]:
            if c not in D: D.add(c); st.append(c)
    return D

print("== 2(c). remove-and-repair test (single gates). Remove gate g; all descendants lose their derivation;")
print("   try to re-derive each descendant (original topological order) as XOR of two AVAILABLE masks; also allow")
print("   re-deriving any needed OUTPUT mask instead of the exact descendant mask. Success => an 88-gate circuit exists.")
def repair(removed):
    """Return list of new gates (mask pairs) if all outputs recoverable with <= len(gates)-len(removed) gates, else None."""
    D=descendants(removed)
    avail={}                       # mask -> signal id (available masks)
    for s in range(NS):
        if s not in D: avail[mask[s]]=s
    # targets: descendants needed = we need all output masks. Rebuild descendants in topological order, but only
    # those that are ancestors of some output that is currently unavailable.
    need_out=[rows[o] for o in range(32) if rows[o] not in avail]
    added=0; budget=n-len(removed)-(n-len(D))   # gates we may add = descendants count - #removed
    # greedy: repeatedly find any target (needed descendant masks in top. order, or output masks) expressible as XOR of two avail
    todo=[s for s in sorted(D) if s not in removed]   # descendants in original order (excluding removed ones)
    progress=True
    while need_out and progress and added<budget:
        progress=False
        # first priority: outputs directly
        for m in list(need_out):
            for x in list(avail):
                if (m^x) in avail:
                    avail[m]=('new',added); added+=1; need_out.remove(m); progress=True; break
            if progress: break
        if progress: continue
        for s in list(todo):
            m=mask[s]
            if m in avail: todo.remove(s); continue
            for x in list(avail):
                if (m^x) in avail:
                    avail[m]=('new',added); added+=1; todo.remove(s); progress=True; break
            if progress: break
        need_out=[m for m in need_out if m not in avail]
    return (added if not need_out else None), len(D)
hits=[]
for g in range(32,NS):
    r,nd=repair({g})
    if r is not None and r < nd:
        hits.append((g,r,nd))
print("   single-gate removals that repair with fewer gates:", hits if hits else "NONE (0/89)")
# how many descendants' worth of re-derivation was needed: report distribution of (r-nd) for info
print("== 2(c'). pair removals (all C(89,2)=3916 pairs), same repair test")
hits2=[]
for g,h in itertools.combinations(range(32,NS),2):
    r,nd=repair({g,h})
    if r is not None and r < nd-1+1 and r <= nd-2:
        hits2.append((g,h,r,nd))
print("   pair removals that repair to <= 88 gates:", hits2 if hits2 else "NONE (0/3916)")

print("== 2(d). redundancy census: gates whose mask equals XOR of two OTHER signals' masks (any two of the 120 others)")
allm={}
for s in range(NS): allm.setdefault(mask[s],[]).append(s)
red=[]
for g in range(32,NS):
    m=mask[g]; alts=[]
    for s in range(NS):
        if s==g: continue
        t=m^mask[s]
        if t in allm and t!=0:
            for u in allm[t]:
                if u!=g and s<u: alts.append((s,u))
    if len(alts)>1: red.append((g,len(alts)))   # >1 because the gate's own operand pair is always one
print("   gates with an ALTERNATIVE 2-XOR derivation (beyond its own operands):", len(red), red[:40])

print("== 2(e). rank/greedy lower-bound sanity: outputs need >= 32 gates; every gate mask distinct; all 121 masks distinct:", len(allm)==NS)

# ---------------- 4. s-XOR realisability ----------------
print("== 4. in-place (s-XOR) realisability of THIS gate set on 32 registers, no temporaries")
print("   model: each gate r_i ^= r_j overwrites (kills) one of its two operands; every non-output signal must be killed")
print("   exactly once (121 signals - 89 kills = 32 survivors = outputs); the killer must be the LAST consumer of the")
print("   killed signal; the resulting precedence relation (DAG edges + 'other consumers before killer') must be acyclic.")
cons={s:[c for c in children[s]] for s in range(NS)}
nonout=[s for s in range(NS) if s not in OUT]
no_consumer=[s for s in nonout if not cons[s]]
print("   non-output signals:",len(nonout),"  non-output signals with NO consumer (cannot be killed => not in-place):",no_consumer)
# candidate killers per non-output signal = its consumers; each gate kills exactly one of its operands (which must be non-output)
gate_opts={32+k:[x for x in gates[k] if x not in OUT] for k in range(n)}
print("   gates with 0 killable operands (both operands are outputs):",[g for g,o in gate_opts.items() if not o])
print("   gates with exactly 1 killable operand:",sum(1 for o in gate_opts.values() if len(o)==1))
# enumerate all perfect matchings via backtracking with propagation
def acyclic(kill):   # kill: gate->signal killed
    # edges: operand->gate (DAG); for each signal s killed by k: every other consumer c of s -> k
    adj={s:set() for s in range(NS)}
    for k in range(n):
        for x in gates[k]: adj[x].add(32+k)
    for g,s in kill.items():
        for c in cons[s]:
            if c!=g: adj[c].add(g)
    indeg={s:0 for s in range(NS)}
    for s in adj:
        for t in adj[s]: indeg[t]+=1
    st=[s for s in range(NS) if indeg[s]==0]; order=[]
    while st:
        s=st.pop(); order.append(s)
        for t in adj[s]:
            indeg[t]-=1
            if indeg[t]==0: st.append(t)
    return (len(order)==NS), order
sols=[]; count=[0]
def bt(kill, killed, gate_list):
    count[0]+=1
    if count[0]>5_000_000: return
    if not gate_list:
        ok,order=acyclic(kill)
        if ok: sols.append((dict(kill),order))
        return
    # pick most constrained gate
    gate_list=sorted(gate_list,key=lambda g: len([x for x in gate_opts[g] if x not in killed]))
    g=gate_list[0]; rest=gate_list[1:]
    for x in gate_opts[g]:
        if x in killed: continue
        kill[g]=x; killed.add(x)
        # feasibility: every remaining non-output signal must still have a possible killer
        bt(kill,killed,rest)
        del kill[g]; killed.discard(x)
        if len(sols)>=1: return
bt({},set(),list(range(32,NS)))
print("   backtracking nodes:",count[0],"  in-place schedules found:",len(sols))
if sols:
    kill,order=sols[0]
    # build explicit s-XOR program and simulate it on 32 registers
    reg_of={i:i for i in range(32)}   # signal -> register
    prog=[]
    for s in order:
        if s<32: continue
        a,b=gates[s-32]; kx=kill[s]; other=b if kx==a else a
        ri=reg_of[kx]; rj=reg_of[other]; prog.append((ri,rj)); reg_of[s]=ri
    # simulate with masks
    R=[1<<i for i in range(32)]
    for ri,rj in prog: R[ri]^=R[rj]
    final={R[i]:i for i in range(32)}
    ok=all(rows[o] in final for o in range(32))
    print("   simulated %d-instruction in-place program: registers hold all 32 InvMixColumns rows: %s"%(len(prog),ok))
    print("   output o -> register:", [final[rows[o]] for o in range(32)])
    json.dump({"sxor_program_ri_xoreq_rj":prog,"register_of_output":[final[rows[o]] for o in range(32)]},open(f"{NEW}/referee_89/invmc_89_sxor.json","w"),indent=0)
    # BKL16 Corollary 1: reverse the in-place program => in-place program for the inverse map (MixColumns)
    R=[1<<i for i in range(32)]
    for ri,rj in reversed(prog): R[ri]^=R[rj]
    # MixColumns rows in the same convention
    def xtime(a):
        a<<=1
        return (a^0x11b)&0xff if a&0x100 else a
    def gmul(a,b):
        r=0
        while b:
            if b&1: r^=a
            a=xtime(a); b>>=1
        return r
    def mixcol(c):
        s0,s1,s2,s3=c
        return [gmul(2,s0)^gmul(3,s1)^s2^s3, s0^gmul(2,s1)^gmul(3,s2)^s3, s0^s1^gmul(2,s2)^gmul(3,s3), gmul(3,s0)^s1^s2^gmul(2,s3)]
    mrows=[0]*32
    for i in range(32):
        c=[((1<<i)>>(8*b))&0xff for b in range(4)]; out=mixcol(c); v=sum(out[b]<<(8*b) for b in range(4))
        for o in range(32):
            if (v>>o)&1: mrows[o]|=1<<i
    # reversed program applied to registers: output o must be read from the register where the forward program READ input? Check as a set + mapping
    # Reversed in-place program computes M^{-1} composed with the register permutation; check: the map is exactly MixColumns up to the output/input register wiring
    finalM={R[i]:i for i in range(32)}
    # Actually reversing r_i^=r_j sequence inverts the linear map L exactly (each step is an involution). Forward: regs (identity in) -> L(x) with output o in register p(o).
    # So reversed program maps y placed as y_o in register p(o) back to x. i.e. reversed program on registers = M applied to permuted-input. Verify by simulation:
    import random
    okM=True
    for _ in range(2000):
        col=[random.randrange(256) for _ in range(4)]; v=sum(col[b]<<(8*b) for b in range(4))
        regs=[0]*32
        for o in range(32): regs[final[rows[o]]]=(v>>o)&1     # place input bit o in register p(o)
        for ri,rj in reversed(prog): regs[ri]^=regs[rj]
        got=sum(regs[i]<<i for i in range(32))
        exp=sum(mixcol(col)[b]<<(8*b) for b in range(4))
        if got!=exp: okM=False; break
    print("   BKL16 Cor.1 check: reversed program (input bit o placed in register p(o)) computes MixColumns in registers 0..31:",okM)
else:
    print("   NO in-place schedule exists for this gate set (exhaustive over kill-assignments).")
    # diagnose: structural obstruction
    # try: count perfect matchings ignoring acyclicity
    cnt=[0]
    def bt2(killed,gl):
        if cnt[0]>2_000_000: return
        if not gl: cnt[0]+=1; return
        gl=sorted(gl,key=lambda g: len([x for x in gate_opts[g] if x not in killed])); g=gl[0]
        for x in gate_opts[g]:
            if x in killed: continue
            killed.add(x); bt2(killed,gl[1:]); killed.discard(x)
    bt2(set(),list(range(32,NS)))
    print("   perfect kill-matchings ignoring order:",cnt[0])
