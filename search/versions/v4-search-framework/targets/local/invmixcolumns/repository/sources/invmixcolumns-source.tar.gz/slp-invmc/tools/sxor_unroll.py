#!/usr/bin/env python3
"""sxor_unroll.py -- an in-place (s-XOR) instruction listing  ->  a g-XOR
circuit in the oracle's encoding A, with provenance.

THE UNROLLING (BKL16 / Xiang et al. sec.5.3; PRIOR_ART_INVMC.md sec.1)

An s-XOR program is a list of `reg[i] ^= reg[j]` on 32 registers preloaded
with the 32 inputs.  SSA-unrolling walks the list keeping `cur[r]` = the
index of the signal currently held by register r (inputs are signals 0..31,
gate k is signal 32+k).  Each instruction emits ONE gate
`[cur[i], cur[j]]` and then sets `cur[i]` to that new signal.  So a
k-instruction s-XOR program becomes a k-gate 2-input-XOR circuit; the count
is preserved exactly and the depth is preserved exactly (each gate's depth
is 1 + max of its two parents, in both models).

REVERSAL (BKL16 Corollary 1)

Each instruction is the elementary matrix I + E_{i,j}, an involution over
GF(2), so running the list BACKWARDS computes the inverse map with the same
number of instructions.  Book-keeping, done here and not by hand:

  let A = the register-file map of the forward program, so the FINAL mask of
  register r is row r of A, and the listing's annotations say
  row r of A = row ann(r) of M, i.e. A = P*M with P[r][ann(r)] = 1.
  The reversed program has map A^-1 = M^-1 * P^-1, and
      (M^-1 P^-1)[r][c] = M^-1[r][ann(c)].
  Read off:  in the reversed program register c must be PRELOADED with the
  matrix input ann(c) (i.e. with y_{ann(c)}, which is exactly what the
  forward program left there), and register r FINISHES holding row r of
  M^-1, i.e. output r.
  So --reverse loads register c with input signal ann(c) and takes output r
  from register r.  Nothing is hand-placed.

--reverse additionally REQUIRES that every annotated register is never
written again after its annotation (otherwise the final state is not P*M and
the identity above does not hold).  That is checked, not assumed.

RE-INDEXING

The papers index registers by their own bit convention.  --bit-order names a
permutation p from PAPER index to THIS REPO's index (README "The convention":
index = 8*byte + bit, bit i = coefficient of x^i, LSB-first inside the byte):

  identity  p(8b+k) = 8b + k
  revbit    p(8b+k) = 8b + (7-k)          bit order inside each byte flipped
  revbyte   p(8b+k) = 8*(3-b) + k         byte order flipped
  revboth   p(8b+k) = 8*(3-b) + (7-k)     = 31 - i

It is applied to BOTH the input preload and the output annotations, because
a paper uses one convention for its x's and its y's.

usage:
  sxor_unroll.py --listing L.txt --out C.json --bit-order identity \
      [--reverse] --paper "..." --table "..." --page "..." [--note "..."]
"""
import argparse
import datetime
import hashlib
import json
import os
import sys

PERMS = {
    "identity": lambda i: i,
    "revbit":   lambda i: 8 * (i // 8) + (7 - i % 8),
    "revbyte":  lambda i: 8 * (3 - i // 8) + i % 8,
    "revboth":  lambda i: 31 - i,
}


def parse_listing(path):
    """-> [(dst, src, out_or_None), ...]"""
    prog = []
    for ln, line in enumerate(open(path), 1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        p = line.split()
        if len(p) not in (2, 3):
            sys.exit(f"{path}:{ln}: expected '<i> <j>' or '<i> <j> <k>', got {line!r}")
        d, s = int(p[0]), int(p[1])
        o = int(p[2]) if len(p) == 3 else None
        if d == s:
            sys.exit(f"{path}:{ln}: reg[{d}] ^= reg[{d}] is a zeroing, not an XOR gate")
        prog.append((d, s, o))
    return prog


def unroll(prog, perm, reverse):
    """-> (gates, outputs, notes).  outputs[j] = signal index holding target j."""
    ann = {}                       # register -> paper output index
    for d, s, o in prog:
        if o is not None:
            ann[d] = o
    if len(ann) != 32 or sorted(ann.values()) != list(range(32)):
        sys.exit(f"annotations do not put 32 distinct outputs on 32 distinct "
                 f"registers: {len(ann)} registers, outputs {sorted(ann.values())}")

    notes = []
    if reverse:
        # every annotated register must be final -- checked, not assumed
        last_write = {}
        for k, (d, s, o) in enumerate(prog):
            last_write[d] = k
        ann_at = {}
        for k, (d, s, o) in enumerate(prog):
            if o is not None:
                ann_at[d] = k
        late = [r for r in ann if last_write[r] != ann_at[r]]
        if late:
            sys.exit(f"--reverse refused: registers {late} are written AFTER "
                     f"their output annotation, so the final register map is "
                     f"not P*M and the reversal identity does not apply")
        notes.append("checked: every annotated register is written for the "
                     "last time by its own annotated instruction, so the "
                     "final register map is exactly P*M")
        work = list(reversed(prog))
        cur = [perm(ann[r]) for r in range(32)]     # preload reg c with input ann(c)
        out_of_reg = {r: perm(r) for r in range(32)}  # reg r finishes with output r
    else:
        work = list(prog)
        cur = [perm(r) for r in range(32)]
        out_of_reg = None

    gates = []
    outputs = [None] * 32
    for d, s, o in work:
        gates.append([cur[d], cur[s]])
        cur[d] = 32 + len(gates) - 1
        if not reverse and o is not None:
            outputs[perm(o)] = cur[d]
    if reverse:
        for r in range(32):
            outputs[out_of_reg[r]] = cur[r]
    missing = [j for j in range(32) if outputs[j] is None]
    if missing:
        sys.exit(f"outputs {missing} never assigned")
    return gates, outputs, notes


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--listing", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--bit-order", choices=sorted(PERMS), default="identity")
    ap.add_argument("--reverse", action="store_true")
    ap.add_argument("--paper", required=True)
    ap.add_argument("--table", required=True)
    ap.add_argument("--page", required=True)
    ap.add_argument("--computes", required=True,
                    help="what the emitted circuit computes, e.g. 'AES InvMixColumns'")
    ap.add_argument("--note", action="append", default=[])
    ap.add_argument("--extract-cmd", default="")
    a = ap.parse_args()

    raw = open(a.listing, "rb").read()
    prog = parse_listing(a.listing)
    perm = PERMS[a.bit_order]
    gates, outputs, notes = unroll(prog, perm, a.reverse)

    # replay, purely as a self-description (the ORACLE is the judge)
    sig = [1 << i for i in range(32)]
    dep = [0] * 32
    for x, y in gates:
        sig.append(sig[x] ^ sig[y])
        dep.append(max(dep[x], dep[y]) + 1)

    beside = os.path.splitext(a.out)[0] + ".txt"
    if os.path.abspath(beside) != os.path.abspath(a.listing):
        open(beside, "wb").write(raw)

    doc = {
        "provenance": {
            "produced_by": "tools/sxor_unroll.py",
            "produced_utc": datetime.datetime.now(datetime.timezone.utc)
                            .strftime("%Y-%m-%dT%H:%M:%SZ"),
            "paper": a.paper,
            "table": a.table,
            "page": a.page,
            "computes": a.computes,
            "model": "g-XOR circuit, SSA-unrolled from a published s-XOR "
                     "(in-place) listing; count and depth are preserved by the "
                     "unrolling",
            "source_listing_file": os.path.relpath(a.listing),
            "source_listing_sha256": hashlib.sha256(raw).hexdigest(),
            "source_listing_beside_circuit": os.path.relpath(beside),
            "extract_cmd": a.extract_cmd,
            "n_instructions": len(prog),
            "reversed": bool(a.reverse),
            "reversal_theorem": ("Beierle-Kranz-Leander CRYPTO 2016 Cor. 1 "
                                 "(ePrint 2016/119): reversing an in-place "
                                 "listing computes the inverse map at the same "
                                 "instruction count") if a.reverse else None,
            "bit_order": a.bit_order,
            "bit_order_meaning": {
                "identity": "paper index == repo index (8*byte+bit, LSB-first)",
                "revbit":   "bit order inside each byte flipped",
                "revbyte":  "byte order flipped",
                "revboth":  "index -> 31-index",
            }[a.bit_order],
            "repo_convention": "out row = 8*out_byte+out_bit, in col = "
                               "8*in_byte+in_bit, bit i of a byte = coefficient "
                               "of x^i (LSB-first), mask bit c = input index c "
                               "(README 'The convention')",
            "notes": notes + a.note,
        },
        "gateCount": len(gates),
        "depth_as_transcribed": max(dep),
        "gates": gates,
        "outputs": {str(j): outputs[j] for j in range(32)},
        "output_masks_hex": [hex(sig[outputs[j]]) for j in range(32)],
    }
    with open(a.out, "w") as f:
        json.dump(doc, f, indent=1)
    print(f"{a.out}: {len(gates)} gates, depth-as-transcribed {max(dep)}, "
          f"reversed={a.reverse}, bit_order={a.bit_order}")
    print(f"  listing sha256 {hashlib.sha256(raw).hexdigest()}")
    print(f"  raw listing written beside circuit: {beside}")
    for n in notes:
        print(f"  note: {n}")


if __name__ == "__main__":
    main()
