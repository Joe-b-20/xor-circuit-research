#!/usr/bin/env python3
"""P3 plateau census: stream every *.pop.jsonl harvest, dedupe by mask set."""
import json, os, sys, random, hashlib
from array import array

SNAP = sys.argv[1]          # snapshot_sizes.txt : "<path> <bytes>"
OUT  = sys.argv[2]          # json out
SAMPLE_PER_N = 400
random.seed(20260909)

def rot8(m):
    return ((m << 8) | (m >> 24)) & 0xFFFFFFFF

def h64(b):
    return hashlib.blake2b(b, digest_size=10).digest()

files = []
for line in open(SNAP):
    p, s = line.rsplit(" ", 1)
    files.append((p.strip(), int(s)))

glob_raw = {}          # n -> set(rawhash)
glob_orb = {}          # n -> set(orbhash)
rows_by_n = {}         # n -> rows
per_file = {}          # path -> {"rows":{n:c}, "distinct":{n:c}, "orb":{n:c}, "bytes":b, "trunc":bool}
samples = {}           # n -> {rawhash: masklist}  (reservoir-ish, capped)
sample_seen = {}       # n -> count of distinct seen (for reservoir)

for path, size in files:
    fr = {}; fd = {}; fo = {}
    seen_raw = set(); seen_orb = set()
    nbytes = 0; trunc = False
    with open(path, "rb") as f:
        while True:
            line = f.readline()
            if not line:
                break
            if nbytes + len(line) > size:      # past the snapshot point
                trunc = True
                break
            nbytes += len(line)
            if not line.endswith(b"\n"):
                trunc = True
                break
            s = line.strip()
            if not s:
                continue
            try:
                ms = json.loads(s)
            except ValueError:
                trunc = True
                continue
            n = len(ms)
            fr[n] = fr.get(n, 0) + 1
            rows_by_n[n] = rows_by_n.get(n, 0) + 1
            rh = h64(s)
            if rh not in seen_raw:
                seen_raw.add(rh)
                fd[n] = fd.get(n, 0) + 1
            g = glob_raw.setdefault(n, set())
            new_global = rh not in g
            if new_global:
                g.add(rh)
                # reservoir sample over globally-distinct sets at this n
                k = sample_seen.get(n, 0); sample_seen[n] = k + 1
                sm = samples.setdefault(n, [])
                if len(sm) < SAMPLE_PER_N:
                    sm.append(ms)
                else:
                    j = random.randrange(k + 1)
                    if j < SAMPLE_PER_N:
                        sm[j] = ms
            # Z/4 byte-rotation orbit canonical form
            best = None
            cur = ms
            for _ in range(4):
                t = tuple(sorted(cur))
                if best is None or t < best:
                    best = t
                cur = [rot8(m) for m in cur]
            oh = h64(array("I", best).tobytes())
            if oh not in seen_orb:
                seen_orb.add(oh)
                fo[n] = fo.get(n, 0) + 1
            glob_orb.setdefault(n, set()).add(oh)
    per_file[path] = {"rows": fr, "distinct": fd, "orbits": fo,
                      "bytes_read": nbytes, "snapshot_bytes": size,
                      "truncated_at_snapshot": trunc,
                      "n_rows": sum(fr.values()),
                      "n_distinct": sum(fd.values()),
                      "n_orbits": sum(fo.values())}
    sys.stderr.write("done %s rows=%d distinct=%d\n" % (path, sum(fr.values()), sum(fd.values())))
    sys.stderr.flush()

res = {"rows_by_n": rows_by_n,
       "distinct_by_n": {n: len(v) for n, v in glob_raw.items()},
       "orbits_by_n": {n: len(v) for n, v in glob_orb.items()},
       "per_file": per_file,
       "samples": {n: v for n, v in samples.items()}}
with open(OUT, "w") as f:
    json.dump(res, f)
print("TOTAL rows", sum(rows_by_n.values()),
      "distinct", sum(len(v) for v in glob_raw.values()),
      "orbits", sum(len(v) for v in glob_orb.values()))
