#!/usr/bin/env python3
"""Referee's shared-nothing check of circuits/invmc_alt_89_depth16.json.
Everything here is rebuilt from FIPS-197; nothing is imported from the project."""
import json, random, sys, os, subprocess, itertools
random.seed(20260908)
NEW = "~/xor_ui/slp-invmc"
CIRC = f"{NEW}/circuits/invmc_alt_89_depth16.json"

# ---------- 1. GF(2^8) and (Inv)MixColumns from FIPS-197 ----------
def xtime(a):                       # FIPS-197 §4.2.1: multiply by x, reduce mod m(x)=x^8+x^4+x^3+x+1 (0x11b)
    a <<= 1
    if a & 0x100: a ^= 0x11b
    return a & 0xff
def gmul(a, b):                     # FIPS-197 §4.2: polynomial multiplication mod m(x), via xtime
    r = 0
    while b:
        if b & 1: r ^= a
        a = xtime(a); b >>= 1
    return r
def mixcol(c):                      # FIPS-197 §5.1.3, eq. (5.6): a(x)={03}x^3+{01}x^2+{01}x+{02}
    s0,s1,s2,s3 = c
    return [gmul(2,s0)^gmul(3,s1)^s2^s3,
            s0^gmul(2,s1)^gmul(3,s2)^s3,
            s0^s1^gmul(2,s2)^gmul(3,s3),
            gmul(3,s0)^s1^s2^gmul(2,s3)]
def invmixcol(c):                   # FIPS-197 §5.3.3, eq. (5.10): a^-1(x)={0b}x^3+{0d}x^2+{09}x+{0e}
    s0,s1,s2,s3 = c
    return [gmul(0xe,s0)^gmul(0xb,s1)^gmul(0xd,s2)^gmul(0x9,s3),
            gmul(0x9,s0)^gmul(0xe,s1)^gmul(0xb,s2)^gmul(0xd,s3),
            gmul(0xd,s0)^gmul(0x9,s1)^gmul(0xe,s2)^gmul(0xb,s3),
            gmul(0xb,s0)^gmul(0xd,s1)^gmul(0x9,s2)^gmul(0xe,s3)]

print("== 1. GF(2^8) sanity: FIPS-197 §4.2 example {57}*{83}={c1}; §4.2.1 {57}*{13}={fe}")
assert gmul(0x57,0x83)==0xc1, hex(gmul(0x57,0x83))
assert gmul(0x57,0x13)==0xfe, hex(gmul(0x57,0x13))
print("   gmul(57,83)=%02x gmul(57,13)=%02x  OK" % (gmul(0x57,0x83), gmul(0x57,0x13)))
# a(x)*a^-1(x) = 1 in GF(2^8)[x]/(x^4+1): check invmixcol o mixcol = id on all 2^16 (2-byte-varying) columns + random
for _ in range(20000):
    c=[random.randrange(256) for _ in range(4)]
    assert invmixcol(mixcol(c))==c and mixcol(invmixcol(c))==c
print("   invmixcol(mixcol(c))==c on 20000 random columns  OK")

print("== 1b. Published FIPS-197 round-trace state pairs")
# FIPS-197 Appendix B (Cipher Example), Round 1: 'After ShiftRows' -> 'After MixColumns' (state shown column-wise)
B_shift = [[0xd4,0xbf,0x5d,0x30],[0xe0,0xb4,0x52,0xae],[0xb8,0x41,0x11,0xf1],[0x1e,0x27,0x98,0xe5]]
B_mix   = [[0x04,0x66,0x81,0xe5],[0xe0,0xcb,0x19,0x9a],[0x48,0xf8,0xd3,0x7a],[0x28,0x06,0x26,0x4c]]
for sc, mc in zip(B_shift, B_mix):
    assert mixcol(sc)==mc, (sc, mixcol(sc), mc)
    assert invmixcol(mc)==sc, (mc, invmixcol(mc), sc)
print("   App. B round 1: 4 columns, MixColumns(AfterShiftRows)==AfterMixColumns and InvMixColumns back  OK")
# FIPS-197 Appendix C.1 (AES-128) lines: round[ 1].s_row = 6353e08c0960e104cd70b751bacad0e7 ; round[ 1].m_col = 5f72641557f5bc92f7be3b291db9f91a
srow = bytes.fromhex("6353e08c0960e104cd70b751bacad0e7"); mcol = bytes.fromhex("5f72641557f5bc92f7be3b291db9f91a")
for k in range(4):
    assert mixcol(list(srow[4*k:4*k+4]))==list(mcol[4*k:4*k+4])
    assert invmixcol(list(mcol[4*k:4*k+4]))==list(srow[4*k:4*k+4])
print("   App. C.1 round[1].s_row -> round[1].m_col: 4 columns forward and inverse  OK")
# Also the decryption trace, App. C.1: round[ 1].ik_sch? -- use: round[ 1].im_col ... (inverse cipher) not needed; instead full AES below.

# ---------- 1c. Full AES-128 with my invmixcol, compared against openssl (independent implementation) ----------
SBOX=[0]*256
p=q=1
while True:  # generate S-box from the field definition (no table typed in)
    p = p ^ ((p<<1)&0xff) ^ (0x1b if p&0x80 else 0); q ^= q<<1; q ^= q<<2; q ^= q<<4; q &= 0xff
    if q&0x80: q ^= 0x09
    x = q ^ (q<<1) ^ (q<<2) ^ (q<<3) ^ (q<<4); x = (x ^ (x>>8) ^ 0x63) & 0xff
    SBOX[p]=x
    if p==1: break
SBOX[0]=0x63
assert SBOX[0x53]==0xed  # FIPS-197 §5.1.1 example
INV=[0]*256
for i,v in enumerate(SBOX): INV[v]=i
def expand(key):
    w=[list(key[4*i:4*i+4]) for i in range(4)]; rc=1
    for i in range(4,44):
        t=w[i-1][:]
        if i%4==0:
            t=t[1:]+t[:1]; t=[SBOX[b] for b in t]; t[0]^=rc; rc=xtime(rc)
        w.append([w[i-4][j]^t[j] for j in range(4)])
    return [sum(w[4*r:4*r+4],[]) for r in range(11)]
def enc(pt,key):
    rk=expand(key); s=[pt[i]^rk[0][i] for i in range(16)]
    for r in range(1,11):
        s=[SBOX[b] for b in s]
        s=[s[(i + 4*(i%4))%16] for i in range(16)]           # ShiftRows on column-major state
        if r<10: s=sum([mixcol(s[4*c:4*c+4]) for c in range(4)],[])
        s=[s[i]^rk[r][i] for i in range(16)]
    return bytes(s)
def dec(ct,key):
    rk=expand(key); s=[ct[i]^rk[10][i] for i in range(16)]
    for r in range(9,-1,-1):
        s=[s[(i - 4*(i%4))%16] for i in range(16)]           # InvShiftRows
        s=[INV[b] for b in s]
        s=[s[i]^rk[r][i] for i in range(16)]
        if r>0: s=sum([invmixcol(s[4*c:4*c+4]) for c in range(4)],[])
    return bytes(s)
key=bytes.fromhex("000102030405060708090a0b0c0d0e0f"); pt=bytes.fromhex("00112233445566778899aabbccddeeff")
ct=enc(pt,key); print("   AES-128 C.1: ct=",ct.hex())
assert ct.hex()=="69c4e0d86a7b0430d8cdb78070b4c55a"   # FIPS-197 App. C.1 output
assert dec(ct,key)==pt
keyB=bytes.fromhex("2b7e151628aed2a6abf7158809cf4f3c"); ptB=bytes.fromhex("3243f6a8885a308d313198a2e0370734")
assert enc(ptB,keyB).hex()=="3925841d02dc09fbdc118597196a0b32"   # FIPS-197 App. B output
assert dec(bytes.fromhex("3925841d02dc09fbdc118597196a0b32"),keyB)==ptB
print("   App. B and App. C.1 full-cipher vectors: encrypt and decrypt (decrypt uses my invmixcol)  OK")
# openssl cross-check on random blocks/keys (decrypt direction exercises invmixcol)
for _ in range(50):
    k=bytes(random.randrange(256) for _ in range(16)); c=bytes(random.randrange(256) for _ in range(16))
    out=subprocess.run(["openssl","enc","-d","-aes-128-ecb","-nopad","-K",k.hex()],input=c,capture_output=True,check=True).stdout
    assert out==dec(c,k), "openssl mismatch"
print("   openssl aes-128-ecb decrypt == my dec() on 50 random (key,block) pairs  OK")

# ---------- 2. Target matrix in the claimed bit convention: index 8*byte+bit, bit i = coeff of x^i ----------
def col_to_bits(c):  # -> 32-bit int, bit (8*byte+bit)
    v=0
    for byte in range(4):
        v |= c[byte] << (8*byte)
    return v
def bits_to_col(v): return [(v>>(8*b))&0xff for b in range(4)]
# rows[o] = mask of inputs that feed output bit o
rows=[0]*32
for i in range(32):
    out = col_to_bits(invmixcol(bits_to_col(1<<i)))
    for o in range(32):
        if (out>>o)&1: rows[o] |= 1<<i
print("== 2. target matrix: rows=32, distinct rows=%d, total ones=%d" % (len(set(rows)), sum(bin(r).count('1') for r in rows)))
# linearity sanity: matrix applied to random column == invmixcol
def apply_rows(v): return sum(((bin(rows[o]&v).count('1')&1)<<o) for o in range(32))
for _ in range(5000):
    c=[random.randrange(256) for _ in range(4)]
    assert bits_to_col(apply_rows(col_to_bits(c)))==invmixcol(c)
print("   matrix == invmixcol on 5000 random columns  OK")

# ---------- 3. Evaluate the circuit ----------
J=json.load(open(CIRC)); gates=J["gates"]; n=len(gates)
print("== 3. circuit: %d gates (file says gateCount=%s depth=%s)" % (n, J.get("gateCount"), J.get("depth")))
assert n==89
mask=[1<<i for i in range(32)]; depth=[0]*32
for k,(a,b) in enumerate(gates):
    assert 0<=a<32+k and 0<=b<32+k and a!=b, ("bad operand", k,a,b)
    mask.append(mask[a]^mask[b]); depth.append(max(depth[a],depth[b])+1)
# which signals hold the outputs (from my own evaluation)
outsig={}
for o in range(32):
    holders=[s for s in range(32+n) if mask[s]==rows[o]]
    assert len(holders)==1, ("output %d holders"%o, holders)
    outsig[o]=holders[0]
print("   outputs found on signals:", [outsig[o] for o in range(32)])
assert all(s>=32 for s in outsig.values()) and len(set(outsig.values()))==32
print("   every output on a distinct gate  OK")
# duplicate masks
dups=[(s,t) for s in range(32+n) for t in range(s) if mask[s]==mask[t]]
print("   duplicate masks (gate==gate or gate==input):", dups)
zero=[s for s in range(32,32+n) if mask[s]==0]; print("   zero-mask gates:", zero)
# dead gates
live=set(outsig.values()); stack=list(live)
while stack:
    s=stack.pop()
    if s>=32:
        for x in gates[s-32]:
            if x not in live: live.add(x); stack.append(x)
dead=[s for s in range(32,32+n) if s not in live]; print("   dead gates:", dead)
unused_inputs=[i for i in range(32) if i not in live]; print("   unused inputs:", unused_inputs)
D=max(depth[outsig[o]] for o in range(32)); print("   depth (longest input->output path):", D, " per-output:", [depth[outsig[o]] for o in range(32)])
# direct evaluation vs invmixcol on random columns (independent of the matrix)
def run_circuit(v):
    sig=[(v>>i)&1 for i in range(32)]
    for a,b in gates: sig.append(sig[a]^sig[b])
    return sum(sig[outsig[o]]<<o for o in range(32))
N=20000; bad=0
for _ in range(N):
    c=[random.randrange(256) for _ in range(4)]
    if bits_to_col(run_circuit(col_to_bits(c)))!=invmixcol(c): bad+=1
print("   random evaluation: %d/%d columns wrong" % (bad,N))
# and all 32 unit vectors + all 2^16 columns with bytes 2,3 fixed? do exhaustive over 2^16 pairs of byte positions
for i in range(32):
    assert bits_to_col(run_circuit(1<<i))==invmixcol(bits_to_col(1<<i))
print("   32 unit vectors  OK")
# exhaustive over all 65536 values of (byte0,byte1) with byte2=byte3=0 and of (byte2,byte3) with byte0=byte1=0 -- by linearity this + unit vectors is redundant but cheap
for v in range(65536):
    assert bits_to_col(run_circuit(v))==invmixcol(bits_to_col(v))
    assert bits_to_col(run_circuit(v<<16))==invmixcol(bits_to_col(v<<16))
print("   2*65536 exhaustive half-columns  OK")

# compare afterwards with the provenance block
prov=J.get("provenance",{})
print("== 3b. provenance block keys:", sorted(prov.keys()))
for key in prov:
    if "output" in key.lower():
        print("   provenance[%s] = %s" % (key, json.dumps(prov[key])[:600]))
json.dump({"outsig":outsig,"rows":rows,"mask":mask,"depth":depth}, open(f"{NEW}/referee_89/eval.json","w"))
print("saved referee_89/eval.json")
