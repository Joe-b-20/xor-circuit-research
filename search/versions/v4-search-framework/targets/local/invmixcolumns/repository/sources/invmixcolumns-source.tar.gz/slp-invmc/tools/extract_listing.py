#!/usr/bin/env python3
"""extract_listing.py -- pull a printed in-place (s-XOR) listing out of a
pdftotext -layout dump of a paper, and emit it as one instruction per line.

The printed tables are 3-column ("No. Operation | No. Operation | No.
Operation") and pdftotext -layout interleaves the columns on one physical
line, sometimes gluing an output annotation to the next column's number
("... [y2 ] 73  x26 =x26 +x1").  So we do NOT parse line-by-line: we scan
the whole table region for every occurrence of

    <no> <reg><i> = <reg><i> + <reg><j> [ <out><k> ]?

and then re-sort by <no>.  The instruction numbers are then REQUIRED to be
exactly the contiguous range the table claims, which is the transcription's
own self-check: a dropped or duplicated instruction cannot pass it.

Supported printed syntaxes (both papers):
    x23 =x23 +x31            [y29 ]        (Xiang et al. ToSC 2020(2) T3/T4,
    u27 =u27 +u3             [v19 ]         registers x/u, outputs y/v)
    x[15] = x[15] + x[23]    y[11]         (Yuan et al. ToSC 2024(2) T4)

Output format (canonical, one line per instruction, 0-indexed numbering
dropped -- order IS the numbering):
    <i> <j>            or      <i> <j> <k>
meaning  reg[i] ^= reg[j]   and, if <k> present, reg[i] now holds output <k>.

usage:
  extract_listing.py --txt papers/xiang2020.txt --start-marker "Table 3:" \
      --end-marker "x0 , x1 ," --first 0 --count 92 --out circuits/foo.txt
"""
import argparse
import hashlib
import re
import sys

# <no>  <reg><i> = <reg><i> + <reg><j>   [<out><k>]
PLAIN = re.compile(
    r"(?<![\w\[])(\d{1,3})\s+([a-z])\s*(\d{1,2})\s*=\s*\2\s*(\d{1,2})\s*\+\s*\2\s*(\d{1,2})"
    r"(?:\s*\[\s*([a-z])\s*(\d{1,2})\s*\])?")
# <no>  x[ i] = x[ i] + x[ j]   y[k]
BRACK = re.compile(
    r"(?<![\w\[])(\d{1,3})\s+([a-z])\[\s*(\d{1,2})\s*\]\s*=\s*\2\[\s*(\d{1,2})\s*\]\s*"
    r"\+\s*\2\[\s*(\d{1,2})\s*\]"
    r"(?:\s+([a-z])\[\s*(\d{1,2})\s*\])?")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--txt", required=True)
    ap.add_argument("--start-marker", required=True)
    ap.add_argument("--end-marker", required=True)
    ap.add_argument("--first", type=int, required=True,
                    help="the number the table gives its first instruction")
    ap.add_argument("--count", type=int, required=True)
    ap.add_argument("--syntax", choices=["plain", "bracket"], required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    doc = open(a.txt, encoding="utf-8", errors="replace").read()
    s = doc.index(a.start_marker)
    e = doc.index(a.end_marker, s)
    region = doc[s:e]

    rx = PLAIN if a.syntax == "plain" else BRACK
    seen = {}
    for m in rx.finditer(region):
        no = int(m.group(1))
        reg, dst, src1, src2 = m.group(2), int(m.group(3)), int(m.group(4)), int(m.group(5))
        if dst != src1:
            sys.exit(f"instruction {no}: not in-place ({reg}{dst} = {reg}{src1} + ...)")
        if not (0 <= dst < 32 and 0 <= src2 < 32):
            sys.exit(f"instruction {no}: register out of range")
        out = int(m.group(7)) if m.group(7) is not None else None
        if out is not None and not (0 <= out < 32):
            sys.exit(f"instruction {no}: output index out of range")
        if no in seen:
            sys.exit(f"instruction number {no} occurs twice")
        seen[no] = (dst, src2, out)

    want = list(range(a.first, a.first + a.count))
    got = sorted(seen)
    if got != want:
        miss = [n for n in want if n not in seen]
        extra = [n for n in got if n not in set(want)]
        sys.exit(f"instruction numbers are not {want[0]}..{want[-1]}: "
                 f"{len(got)} found, missing={miss[:8]} extra={extra[:8]}")

    outs = [seen[n][2] for n in want if seen[n][2] is not None]
    if sorted(outs) != list(range(32)):
        sys.exit(f"output annotations are not a permutation of 0..31: "
                 f"{len(outs)} annotations, sorted={sorted(outs)}")

    lines = []
    for n in want:
        d, s2, o = seen[n]
        lines.append(f"{d} {s2}" + (f" {o}" if o is not None else ""))
    txt = "\n".join(lines) + "\n"
    open(a.out, "w").write(txt)
    print(f"extracted {a.count} instructions from {a.txt} "
          f"[{a.start_marker!r} .. {a.end_marker!r}]")
    print(f"  32/32 output annotations present, a permutation of 0..31")
    print(f"  wrote {a.out}  sha256={hashlib.sha256(txt.encode()).hexdigest()}")


if __name__ == "__main__":
    main()
