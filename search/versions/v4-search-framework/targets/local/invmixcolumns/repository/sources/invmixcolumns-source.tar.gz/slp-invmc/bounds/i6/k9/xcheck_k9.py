#!/usr/bin/env python3
"""xcheck_k9.py -- three-path cross-validation of the k9 census decider.

For each keep-set K in the list:
  path 1  my C decider           ./k9 one K kmax
  path 2  the author's Python DFS  bounds/i6/i6_core.Search (P1+P2+P3)
  path 3  the author's C exhaustion over the FULL 470-mask pool,
          bounds/i6/brute, at depth minE-1 (must say NONE) and at depth
          minE (must say COMPLETION) -- this path uses none of the
          search theory of README sec.4.
All three must return the same minE.  Any disagreement is a hard failure.

  python3 xcheck_k9.py --sets sets.txt [--kmax 4] [--no-brute] [--no-python]
"""
import argparse, os, subprocess, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
I6 = os.path.abspath(os.path.join(HERE, '..'))
sys.path.insert(0, I6)
import i6_core as i6                                   # noqa: E402
core = i6.core

ap = argparse.ArgumentParser()
ap.add_argument('--sets', required=True)
ap.add_argument('--kmax', type=int, default=4)
ap.add_argument('--no-brute', action='store_true')
ap.add_argument('--no-python', action='store_true')
a = ap.parse_args()

t = core.load('invmc')
core.rederive_and_compare(t, say=lambda *x: None)
core.selfcheck(t, say=lambda *x: None)
rows = t.rows

def realizable(c, G):
    """definition-only realizability check (no search theory)."""
    avail = set(1 << i for i in range(c)); todo = set(G) - avail
    ch = True
    while ch and todo:
        ch = False
        for g in list(todo):
            for x in avail:
                if (g ^ x) in avail:
                    avail.add(g); todo.discard(g); ch = True; break
    return not todo

ndis = 0; n = 0
print("idx  K                              C   py  brute   witness-replay")
for line in open(a.sets):
    line = line.strip()
    if not line or line.startswith('#'):
        continue
    K = [int(x) for x in line.split(',')]
    c = len(K)
    assert i6.admissible(rows, K), 'not admissible: %s' % line
    V = i6.restrict(rows, K)
    n += 1

    # path 1 -- my C
    out = subprocess.run([os.path.join(HERE, 'k9'), 'one', line, str(a.kmax), '-1'],
                         capture_output=True, text=True).stdout
    tail = out.strip().split('\n')[-1]
    fields = dict(kv.split('=', 1) for kv in tail.split() if '=' in kv)
    cV = [int(x) for x in out.split('\n')[0][2:].split(',')]
    assert cV == list(V), 'V_K disagreement on %s' % line
    c_minE = int(fields['minE'])
    c_wit = tail.split('witness=')[1].split() if 'witness=' in tail else []
    c_wit = [int(x) for x in c_wit]

    # path 2 -- the author's Python DFS
    py_minE = '-'
    if not a.no_python:
        s = i6.Search(c, V)
        k, w = s.run(a.kmax)
        py_minE = k

    # path 3 -- the author's full-pool C exhaustion
    br = '-'
    if not a.no_brute and c_minE <= a.kmax:
        vs = ','.join(str(x) for x in V)
        ok = True
        if c_minE > 0:
            r = subprocess.run([os.path.join(I6, 'brute'), str(c), vs, str(c_minE - 1)],
                               capture_output=True, text=True)
            ok = ok and ('result=NONE' in r.stdout)
        r = subprocess.run([os.path.join(I6, 'brute'), str(c), vs, str(c_minE)],
                           capture_output=True, text=True)
        ok = ok and ('result=COMPLETION' in r.stdout)
        br = c_minE if ok else 'FAIL'

    # witness replay, definition only
    rep = '-'
    if c_wit:
        G = set(V) | set(c_wit)
        rep = (len(set(c_wit) - set(V)) == c_minE
               and all(bin(x).count('1') >= 2 for x in c_wit)
               and realizable(c, G))

    bad = (py_minE not in ('-', c_minE)) or (br not in ('-', c_minE)) or (rep is False)
    if bad:
        ndis += 1
    print("%3d  %-30s %2s  %3s  %5s   %s%s" % (n, line, c_minE, py_minE, br, rep,
                                               '   <<< DISAGREEMENT' if bad else ''))
    sys.stdout.flush()

print("\n%d sets, %d disagreements" % (n, ndis))
sys.exit(1 if ndis else 0)
