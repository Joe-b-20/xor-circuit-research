"""Reverse D and rename registers so the InvMixColumns inputs sit in natural order (register r holds
input bit r); outputs then come out permuted -- the same convention as Xiang Table 4."""
import os
import verify as V
ops, marks = V.parse_xor_listing(os.path.join(V.REC, "inplace89_D_depth27.txt"))
fin, _ = V.simulate(ops)
p = V.match_perm(fin, V.MC["LSB"])          # register t ends with y_{p[t]}
rev = list(reversed(ops))
ren = [(p[t], p[c]) for (t, c) in rev]      # rename register t -> p[t]
fin2, _ = V.simulate(ren)                    # natural input placement
q = V.match_perm(fin2, V.IMC["LSB"])
print("renamed reversed D: n =", len(ren), "valid InvMC with natural inputs:", q is not None,
      "identity output perm:", q == list(range(32)), "CNOT depth (ASAP):", V.asap_depth(ren)[0])
with open("invmc_inplace89_depth27_from_D.txt", "w") as fh:
    fh.write("# AES InvMixColumns, 89 in-place instructions, CNOT depth 27 (ASAP, listed order).\n")
    fh.write("# = reversal of L6_cnot/records/inplace89_D_depth27.txt with registers renamed so that\n")
    fh.write("#   register r starts with InvMixColumns input bit r (r = 8*byte + bit, bit = coeff of x^bit).\n")
    fh.write("# Output bit i ends in register OUT[i]:\n#   OUT = " + " ".join(str(q.index(i)) for i in range(32)) + "\n")
    for (t, c) in ren:
        fh.write(f"x[{t}] ^= x[{c}]\n")
ops2, _ = V.parse_xor_listing("invmc_inplace89_depth27_from_D.txt")
f2, _ = V.simulate(ops2)
print("re-read file valid:", V.match_perm(f2, V.IMC["LSB"]) is not None, "depth", V.asap_depth(ops2)[0])
