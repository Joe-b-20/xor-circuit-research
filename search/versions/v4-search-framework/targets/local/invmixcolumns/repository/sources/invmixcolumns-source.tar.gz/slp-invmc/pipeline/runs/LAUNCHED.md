# LAUNCHED — rung-2 search fleet, 2026-09-08

Two coordinators, 12 worker processes total on a 20-core box (8 cores left
free), everything `nice -n 19`, `setsid nohup`, banked to disk continuously.
**No stop bounds on either run: they run until stopped by PID.**

Gate passed before launch: `controls/R2_pipeline_smoke.txt` (part a) and
`controls/R2_pipeline_smoke_b.txt` (part b), both PASS.

---

## Launch commands, verbatim

```bash
cd ~/xor_ui/slp-invmc/pipeline

# FIXED set A -- 6 workers
setsid nohup nice -n 19 python3 ladder_parallel.py --mode fixed --workers setA \
    > runs/launch_setA.out 2>&1 < /dev/null &

# CASCADE -- the depth ladder, first rung at depth 5; grows to 6 workers
setsid nohup nice -n 19 python3 ladder_parallel.py --mode cascade \
    > runs/launch_cascade.out 2>&1 < /dev/null &
```

## Identity table (PIDs as launched)

| run | coordinator PID | PGID | run dir | started (local) |
|---|---|---|---|---|
| FIXED setA | **524626** | 524626 | `pipeline/runs/20260908_135521/` | 13:55:21 |
| CASCADE | **524916** | 524916 | `pipeline/runs/20260908_135525/` | 13:55:25 |

### FIXED setA workers (all launched at t=0)

| label | PID | engine | depth cap | seed |
|---|---|---|---|---|
| `a1_lns_106` | 524638 | lns | none | `seeds/invmc_bp5ub2_106_depth21.json` |
| `a2_alt_106` | 524639 | alt | none | `seeds/invmc_bp5ub2_106_depth21.json` |
| `a3_walk_106` | 524640 | walk | none | `seeds/invmc_bp5ub2_106_depth21.json` |
| `a4_alt_113` | 524641 | alt | none | `seeds/invmc_bp5ub2_113_depth17.json` |
| `a5_d6_from121` | 524642 | lns | **6** | `seeds/invmc_bp5ub2_121_depth16.json` (lifted) |
| `a6_d5_from121` | 524643 | lns | **5** | `seeds/invmc_bp5ub2_121_depth16.json` (lifted) |

### CASCADE workers

Rungs launch progressively (`DEPTHS = [5,6,7,8,9]`, then one uncapped `final`),
each when the frontier rung beats its baseline by `IMPROVE_BY = 5` gates or
after `MAX_WAIT_S = 900 s`. Six worker processes at full ramp.

| label | PID | engine | depth cap | seed |
|---|---|---|---|---|
| `d5` | 524939 | lns | **5** | `scratch` = `invmc_core.naive_circuit()`, 315 gates @ depth 5 |
| `d6` | (on trigger) | lns | 6 | `seed_from_d5.json` |
| `d7` | (on trigger) | lns | 7 | `seed_from_d6.json` |
| `d8` | (on trigger) | lns | 8 | `seed_from_d7.json` |
| `d9` | (on trigger) | lns | 9 | `seed_from_d8.json` |
| `final` | (on trigger) | lns | none | `seed_from_d9.json` |

The rung-1 baseline (315) is **derived at run time** from the cold start the
rung actually begins from, not inherited (R14). It is logged in
`coordinator.log`'s first line.

---

## Process control — identity-based only. `pkill` is BANNED (D16).

Each coordinator is its own session leader and each worker is in the
coordinator's process group, so the whole run is addressable by PGID.

```bash
# what is running, by identity
ps -o pid,ppid,pgid,ni,etimes,stat,args -C python3 | grep -E 'ladder_parallel|worker\.py'

# stop ONE run cleanly (SIGINT -> the coordinator's Ctrl-C path -> cleanup()
# terminates its own workers and prints FINAL BESTS):
kill -INT 524626      # FIXED setA
kill -INT 524916      # CASCADE

# stop a whole process group if a coordinator has already exited:
kill -INT -524626
kill -INT -524916

# stop ONE worker (the coordinator will NOT relaunch it):
kill 524642           # e.g. a5_d6_from121
```

Never `pkill python3` on this box. Never `killall`. Both are how the D16
incident happened.

---

## What is banked, continuously

Under each run dir, written as it happens:

- `coordinator.log`, `config.json` (target, `min_depth`, oracle path, mode,
  worker set, the full launch command, every resolved knob)
- `code/` — the exact `invmc_core.py`, `engines.py`, `worker.py`,
  `ladder_parallel.py` that produced the run, plus `code/seeds/` with the exact
  seed files
- per worker: `<label>_best.json` (canonical index-pair JSON + provenance
  block: engine, seed, worker, pid, host, cap, depth, gates, `cpu_s` from
  `os.times()`, the worker command line, the oracle's VERDICT line and the
  oracle command), `<label>_status.json`, `<label>.log`, `<label>.stdout`,
  `<label>.pop.jsonl` (harvest)
- `best_overall.json`, `reseed_<label>.json`

Every `_best.json` passed a dead-gate strip (R8), the in-process verifier at
that worker's cap, the D2 Pareto test, **and** a subprocess call to
`tools/verify_slp_generic.py --target spec/invmc_matrix.json` before it was
written. `oracle_failures` in each status file must stay 0; a non-zero value
means the two verifiers disagree and is a stop-work condition.

## Disk

`*.pop.jsonl` harvests grow at a few MB per worker-minute (`walk` fastest:
~11 MB in 120 s in the smoke run). Watch `du -sh pipeline/runs/*`.

## Note on the seeds, before any result is reported

No worker in either run is seeded from `seeds/invmc_yuan91.json` (the
Yuan-reversed 91, transcribed from published work). Every worker starts either
from this project's own BP-fallback circuits or from nothing.
`cross_pollinate` is off in both runs. **Everything these runs produce is this
project's own lineage.**

---

## Status at the 40-minute report (2026-09-08 14:36 local), fleet LEFT RUNNING

Both coordinators and all 12 workers alive; 0 exceptions, 0 oracle failures.
Frontier and full transcript: `controls/W2_rung2_frontier_40min.txt`.

| worker | best at 40 min | cpu_s |
|---|---|---|
| `a1_lns_106` | 89 @ 16 (adopted from a4 by reseed — same mask set) | 599.8 |
| `a2_alt_106` | 90 @ 23 | 142.2 |
| `a3_walk_106` | 90 @ 31 | 127.7 |
| **`a4_alt_113`** | **89 @ 16** — the count record | 265.7 |
| **`a5_d6_from121`** | **216 @ 6** — first depth-6 circuit ever | 985.0 |
| **`a6_d5_from121`** | **225 @ 5** — first depth-5 circuit ever (and 5 is the arithmetic minimum) | 1282.4 |
| `d5` | 235 @ 5 *from nothing* | 1001.5 |
| `d6` `d7` `d8` `d9` `final` | all 222 @ 6 *from nothing* | 1178.8 / 1155.5 / 1121.6 / 1000.1 / 771.6 |

Fleet CPU at the mark: **9,769.6 s** (sum of the 12 status files' `os.times()`).

### Two things a later session must know

1. **Contention.** A foreign 17-worker **nice-0** fleet on the *forward* matrix
   (`scripts.run_xorslp_valueset --target aes_mc`, `scripts.run_xorslp_vs_control`)
   started at **14:12:44**, 17 minutes into the window. This fleet is nice 19,
   so its per-worker CPU share fell to ~77%. It was **not** stopped — it is not
   ours. CPU-second accounting is unaffected in meaning; wall-clock throughput
   before and after 14:12 is not comparable.

2. **Disk / git.** `*.pop.jsonl` harvests reached **164 MB in 44 minutes** and
   grow at roughly 14 MB/min for the fleet. A concurrent session's `git add -A`
   (commit `1768e20`) committed 14 of them into the repository before a
   `.gitignore` rule existed. The rule is now in `.gitignore`; untracking the
   already-committed ones needs
   `git rm --cached 'pipeline/runs/*/*.pop.jsonl'`, deliberately **not** run
   while another session is mid-flight here.
