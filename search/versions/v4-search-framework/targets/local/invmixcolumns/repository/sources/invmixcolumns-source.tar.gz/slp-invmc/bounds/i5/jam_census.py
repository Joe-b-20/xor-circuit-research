#!/usr/bin/env python3
"""jam_census.py -- I7/Theorem-B PRICING ONLY.  Emits no bound.

PORT OF  OLD/atlas/thinktank/proofside_code/mc.py::jam  and  checkwit.py
         (OLD = ~/xor_ui/slp-plateau-search, read-only)

For a keep-set K, `jam(K)` = how many of the 32 restricted rows are NOT reachable
by free closure from the |K| kept inputs (repeatedly adjoin any target that is
the XOR of two already-available masks).  jam = 0  =>  minE_K = 0  =>  Theorem B
(and hence I7) adds NOTHING at that keep-set; the argument then has to move out
one column, exactly as it did forward (|K| 13 -> 14).

This script exists so that the I7 analogue can be PRICED without running it.

Usage: python3 jam_census.py --target invmc --layer layer_invmc_k7.json
"""
import argparse
import json
import os
import sys
import time
from collections import Counter

import i5_core as core

HERE = os.path.dirname(os.path.abspath(__file__))


def jam(rows, K):
    tg = core.restrict(rows, K)
    av = set(1 << i for i in range(len(K)))
    todo = set(tg)
    while True:
        add = [t for t in todo if any((t ^ a) in av for a in av)]
        if not add:
            break
        for t in add:
            av.add(t)
            todo.discard(t)
    return len(todo), len(av)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--target', default='invmc')
    ap.add_argument('--layer', required=True, help='json list of keep-sets, or a maxq dump .txt')
    a = ap.parse_args()
    t0 = time.process_time()
    t = core.load(a.target)
    core.rederive_and_compare(t, say=lambda s: None)
    core.selfcheck(t, say=lambda s: None)
    if a.layer.endswith('.json'):
        layer = json.load(open(a.layer))
    else:
        layer = [[int(x) for x in l.split(',')] for l in open(a.layer) if l.strip()]
    print("target %s   layer %s   %d keep-sets of size %d"
          % (t.key, os.path.basename(a.layer), len(layer), len(layer[0])))
    res = []
    for K in layer:
        assert core.keepset_ok(t.rows, K), 'non-admissible keep-set in layer: %s' % K
        j, nav = jam(t.rows, K)
        res.append((tuple(K), j, nav))
    print("  jam distribution : %s" % dict(sorted(Counter(j for _, j, _ in res).items())))
    print("  |avail| after free closure, distribution : %s"
          % dict(sorted(Counter(n for _, _, n in res).items())))
    mx = max(res, key=lambda x: x[1])
    print("  max jam = %d at K = %s" % (mx[1], list(mx[0])))
    if mx[1] == 0:
        print("  => minE = 0 on EVERY keep-set of this layer: Theorem B / I7 add"
              " nothing here; the argument must move to |K| = %d." % (len(layer[0]) + 1))
    print("cpu_seconds %.3f" % (time.process_time() - t0))
    return 0


if __name__ == '__main__':
    sys.exit(main())
