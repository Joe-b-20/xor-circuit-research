#!/bin/bash
# Referee transcript driver. Regenerates NEW/controls/I5_referee.txt from scratch.
# Everything here is the referee's own code (bounds/i5/referee/); nothing under bounds/i5/*.py is executed.
set -u
NEW=~/xor_ui/slp-invmc; R=$NEW/bounds/i5/referee; cd $R
OUT=$NEW/controls/I5_referee.txt
{
echo "I5 REFEREE TRANSCRIPT  $(date -u +%Y-%m-%dT%H:%M:%SZ)   host $(uname -srm)"
echo "shared-nothing: all code under bounds/i5/referee/, written before bounds/i5/*.py was read; nice -n 19 throughout"
echo
echo "############ [1] spec rows dumped for the C census (rows_from_spec.txt = spec/invmc_matrix.json 'rows' verbatim)"
python3 -c "import json; d=json.load(open('$NEW/spec/invmc_matrix.json')); open('rows_from_spec.txt','w').write('\n'.join(d['rows'])+'\n'); R=d['rows']; open('rows_invmc_transposed.txt','w').write('\n'.join(''.join(R[r][c] for r in range(32)) for c in range(32))+'\n')
d=json.load(open('$NEW/spec/mixcolumns_matrix.json')); R=d['rows']; open('rows_mixcolumns_from_spec.txt','w').write('\n'.join(R)+'\n'); open('rows_mixcolumns_transposed.txt','w').write('\n'.join(''.join(R[r][c] for r in range(32)) for c in range(32))+'\n'); print('ok')"
sha256sum rows_from_spec.txt
echo
echo "############ [2] gcc -O2 -Wall -o ref_exhaust ref_exhaust.c"
gcc -O2 -Wall -o ref_exhaust ref_exhaust.c && echo compiled
echo
echo "############ [3] python3 ref_check.py 7  -- GF(2^8) rebuild, entrywise compare, certificate, exhaustive census k=1..7 (pure Python)"
/usr/bin/time -f "TIMED cpu_user %U cpu_sys %S wall %e" nice -n 19 python3 ref_check.py 7 2>&1
echo
echo "############ [4] C census, M_inv, k=1..8 (admissible count + max q per size), dumping the k=7 and k=8 layers"
for k in 1 2 3 4 5 6 7 8; do /usr/bin/time -f "TIMED wall %e" nice -n 19 ./ref_exhaust rows_from_spec.txt $k dump > layer_k$k.txt 2>&1; tail -2 layer_k$k.txt; done
echo
echo "############ [5] C census, M_inv^T (transposed frame), k=5..8"
for k in 5 6 7 8; do /usr/bin/time -f "TIMED wall %e" nice -n 19 ./ref_exhaust rows_invmc_transposed.txt $k 2>&1 | tail -2; done
echo
echo "############ [6] diff: my 44 admissible 7-sets vs bounds/i5/layer_invmc_k7.json and runs/admissible_invmc_k7.txt"
grep 'admissible: \[' layer_k7.txt | sed 's/.*\[\(.*\)\].*/\1/; s/ //g' | sort > mine44.txt
python3 -c "import json; L=json.load(open('$NEW/bounds/i5/layer_invmc_k7.json')); print('\n'.join(','.join(map(str,x)) for x in L))" | sort > theirs44.txt
sort $NEW/bounds/i5/runs/admissible_invmc_k7.txt > theirs44b.txt
wc -l mine44.txt theirs44.txt theirs44b.txt
diff mine44.txt theirs44.txt && echo "IDENTICAL: layer_invmc_k7.json"
diff mine44.txt theirs44b.txt && echo "IDENTICAL: runs/admissible_invmc_k7.txt"
grep 'admissible: \[' layer_k8.txt | sed 's/.*\[\(.*\)\].*/\1/; s/ //g' | sort > mine8.txt; sort $NEW/bounds/i5/runs/admissible_invmc_k8.txt > theirs8.txt
wc -l mine8.txt theirs8.txt; diff -q mine8.txt theirs8.txt && echo "IDENTICAL: runs/admissible_invmc_k8.txt (42388 sets)"
echo
echo "############ [7] free-closure jam over my own k=7 and k=8 layers (checks runs/jam_invmc_k7.txt, i7_pricing_probe.txt)"
/usr/bin/time -f "TIMED wall %e" nice -n 19 python3 ref_jam8.py layer_k7.txt 2>&1
/usr/bin/time -f "TIMED wall %e" nice -n 19 python3 ref_jam8.py layer_k8.txt 2>&1
echo
echo "############ [8] upper-bound sanity: own replay of the shipped circuits against M_inv rebuilt from GF(2^8); forward circuit as negative control"
for f in invmc_yuan91 invmc_xiang92 invmc_paar1 invmc_from_mc_cubed_264 mixcolumns_yuan91; do nice -n 19 python3 ref_replay.py $NEW/circuits/$f.json 2>&1 | tail -1; done
echo "-- repo tool (not the code under review) on the 91:"; nice -n 19 python3 $NEW/tools/verify_slp_generic.py --target $NEW/spec/invmc_matrix.json $NEW/circuits/invmc_yuan91.json 2>&1 | tail -2
echo
echo "############ [9] Theorem A stress test vs EXACT L (BFS over mask-sets = g-XOR SLP model with cancellation)"
echo "-- n=4, ALL targets with 1..6 rows, exact L up to 8 gates"
/usr/bin/time -f "TIMED wall %e" nice -n 19 python3 ref_theoremA_stress.py 4 8 2>&1 | tail -4
echo "-- n=5, 300 random targets, exact L up to 6 gates"
/usr/bin/time -f "TIMED wall %e" nice -n 19 python3 ref_theoremA_stress.py 5 6 7 300 2>&1 | tail -3
echo "-- the zero-column counterexample to Theorem A AS STATED (hypothesis 'no zero column' is used in the proof but absent from the statement):"
python3 -c "
T=[0b1001,0b1010,0b1011]; K=[0,1,3]
R=[sum(((t>>c)&1)<<i for i,c in enumerate(K)) for t in T]
print('   rows',[format(t,'04b') for t in T],'K=',K,'(column 2 is zero in every row); restricted',[format(r,'03b') for r in R],'distinct, all weight>=2')
print('   stated bound (4-3)+3 = 4, but g1=x0^x3, g2=x1^x3, g3=g1^x1 computes all three: L=3.  On M_inv every column has weight >= 11, so the hypothesis holds.')"
echo
echo "############ [10] forward positive control (MixColumns, OLD record: no admissible 12-set, exactly 72 admissible 13-sets; M^T: none at 14, some at 15 -> 49)"
for k in 12 13; do /usr/bin/time -f "TIMED wall %e" nice -n 19 ./ref_exhaust rows_mixcolumns_from_spec.txt $k 2>&1 | tail -2; done
for k in 14 15; do /usr/bin/time -f "TIMED wall %e" nice -n 19 ./ref_exhaust rows_mixcolumns_transposed.txt $k 2>&1 | tail -2; done
echo
echo "############ [11] arithmetic of the ceiling"
python3 -c "
from math import comb
print('   2^k-k-1 weight>=2 vectors in F2^k:', {k:2**k-k-1 for k in range(1,9)}, '-> need >=32: k>=6 -> 64-k <= 58')
print('   sum_{k<=6} C(32,k) =', sum(comb(32,k) for k in range(7)), '  sum_{k<=8} C(32,k) =', sum(comb(32,k) for k in range(9)), '  sum_{k<=13} =', sum(comb(32,k) for k in range(14)), '  sum_{1<=k<=12} =', sum(comb(32,k) for k in range(1,13)))"
echo
echo "END $(date -u +%Y-%m-%dT%H:%M:%SZ)"
} > $OUT 2>&1
echo "wrote $OUT"
