#!/usr/bin/env python3
"""Referee's own SLP replay: rebuild M_inv from GF(2^8), replay the gate list, check all 32 rows appear."""
import json, sys
def gmul(a, b, mod=0x11B):
    r = 0
    while b:
        if b & 1: r ^= a
        a <<= 1
        if a & 0x100: a ^= mod
        b >>= 1
    return r & 0xFF
def build(coef, mod=0x11B):
    M = [[0]*32 for _ in range(32)]
    for ob in range(4):
        for k in range(4):
            ib = (ob + k) % 4
            for ibit in range(8):
                prod = gmul(coef[k], 1 << ibit, mod)
                for obit in range(8):
                    if (prod >> obit) & 1: M[8*ob+obit][8*ib+ibit] ^= 1
    return M
M = build([14, 11, 13, 9]); target = [sum(M[r][c] << c for c in range(32)) for r in range(32)]
c = json.load(open(sys.argv[1])); g = c["gates"] if isinstance(c, dict) else c
sig = [1 << i for i in range(32)]
for e in g:
    a, b = (e[0], e[1]) if isinstance(e, list) else (e["a"], e["b"])
    assert 0 <= a < len(sig) and 0 <= b < len(sig)
    sig.append(sig[a] ^ sig[b])
have = set(sig)
missing = [r for r in range(32) if target[r] not in have]
print("%s: gates=%d  outputs_found=%d/32  missing_rows=%s" % (sys.argv[1], len(g), 32 - len(missing), missing))
