#!/usr/bin/env python3
"""Aut(TARGETS) as bit-permutations of the 32 input coordinates (J6 / P7).

Port of slp-plateau-search/experiments/e3b_fresh/code/symgf.py part 1 (the
complete-backtracking permutation automorphism group), retargeted to an
arbitrary target-mask file.  Only change: TARGETS is loaded from the JSON
given on the command line instead of pipeline/mixcolumns_core.py.

Usage: python3 tools/aut_perm.py spec/invmc_target_masks.json
"""
import json, sys, time

path = sys.argv[1]
J = json.load(open(path))
T = list(J["target_masks"])
n = len(T)
assert n == 32
ROWS = [frozenset(i for i in range(n) if (m >> i) & 1) for m in T]
W = [len(r) for r in ROWS]


def perm_aut():
    inrow = [frozenset(j for j in range(n) if i in ROWS[j]) for i in range(n)]
    sols = []
    pi = [-1] * n
    used = [False] * n

    def consistent(col, img):
        for j in range(n):
            ok = False
            for j2 in range(n):
                if W[j2] != W[j]:
                    continue
                good = True
                for c in range(n):
                    if pi[c] < 0:
                        continue
                    if (c in ROWS[j]) != (pi[c] in ROWS[j2]):
                        good = False
                        break
                if good:
                    ok = True
                    break
            if not ok:
                return False
        return True

    order = sorted(range(n), key=lambda c: -len(inrow[c]))

    def bt(k):
        if k == n:
            img = set()
            for j in range(n):
                m = 0
                for c in ROWS[j]:
                    m |= 1 << pi[c]
                img.add(m)
            if img == set(T):
                sols.append(list(pi))
            return
        col = order[k]
        for img in range(n):
            if used[img]:
                continue
            if sorted(W[j] for j in inrow[col]) != sorted(W[j] for j in inrow[img]):
                continue
            pi[col] = img
            used[img] = True
            if consistent(col, img):
                bt(k + 1)
            pi[col] = -1
            used[img] = False

    bt(0)
    return sols


def as_perm_str(p):
    for k in range(4):
        if all(p[i] == ((i + 8 * k) % 32) for i in range(32)):
            return "rho^%d (byte rotation by %d)" % (k, k)
    return "OTHER: " + ",".join(map(str, p))


t0 = time.time()
sols = perm_aut()
secs = time.time() - t0
print("target file: %s  (%s)" % (path, J.get("provenance", {}).get("name")))
print("row-weight histogram:", {w: W.count(w) for w in sorted(set(W))})
print("Aut(TARGETS) as bit-permutations of the 32 inputs: |Aut| = %d  (%.1fs)" % (len(sols), secs))
for p in sols:
    print("   ", as_perm_str(p))
print(json.dumps({"ev": "aut_permutation_group", "target": path, "order": len(sols),
                  "elements": [as_perm_str(p) for p in sols], "secs": round(secs, 1)}))
