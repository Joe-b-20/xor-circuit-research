#!/usr/bin/env python3
"""Verify an IN-PLACE (s-XOR / ancilla-free CNOT) listing against any GF(2) target.

The target is loaded, rebuilt and cross-checked by verify_slp_generic.load_target (same trust rules).
Listing: one instruction per line, `x[t] ^= x[c]` (t != c, 0 <= t,c < 32); `#` lines are comments.
Register r starts with input r. The program computes the target iff the final 32 registers hold
exactly the 32 target rows, in some order (output-register permutation is free, as in every
published in-place listing: Xiang et al. ToSC 2020(2) Table 3, Yuan et al. ToSC 2024(2) Table 4).
Also prints the CNOT depth: greedy ASAP layering in listed order, each register in at most one CNOT
per layer (= the "move-equivalent" / Q# depth of Zhu-Huang, ePrint 2023/165).

Usage:  python3 tools/verify_inplace_listing.py --target <matrix.json> <listing.txt>
Exit 0 iff valid.
"""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from verify_slp_generic import load_target, Refused

def main():
    a = sys.argv[1:]
    if a and a[0] == "--target": a = a[1:]
    if len(a) != 2: print(__doc__); sys.exit(2)
    try: spec, n_in, info = load_target(a[0])
    except Refused as e: print("REFUSED:", e); sys.exit(3)
    prog = []
    for ln in open(a[1]):
        s = ln.split('#')[0].strip()
        if not s: continue
        m = re.match(r"x\[(\d+)\]\s*\^=\s*x\[(\d+)\]", s)
        if not m: print("unparsed line:", ln.rstrip()); sys.exit(1)
        t, c = int(m.group(1)), int(m.group(2))
        if t == c or not (0 <= t < n_in and 0 <= c < n_in): print("bad instruction:", ln.rstrip()); sys.exit(1)
        prog.append((t, c))
    R = [1 << i for i in range(n_in)]; last = [0] * n_in; D = 0
    for t, c in prog:
        R[t] ^= R[c]; L = max(last[t], last[c]) + 1; last[t] = last[c] = L; D = max(D, L)
    ok = sorted(R) == sorted(spec)
    print(f"target={info['name']} rows_sha256={info['sha256'][:16]} target rebuilt: {info['rederived']}")
    print(f"instructions={len(prog)} registers={n_in} cnot_depth_asap={D} final_registers_are_target_rows={ok}")
    print("VERDICT:", f"VALID in-place {info['name']} program" if ok else "INVALID")
    sys.exit(0 if ok else 1)

if __name__ == "__main__":
    main()
