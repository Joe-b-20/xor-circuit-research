#!/usr/bin/env python3
"""tripwire_K2.py -- Lemma R / Theorem T2, ported to an arbitrary GF(2) target.

PORTED FROM  experiments/e17_pure/laneDELTA/{witness.py,cone_theorem.py} of
slp-plateau-search (catalog entry K2, METHOD_CATALOG.md:5182).  The two theorems
are circuit-generic; the forward code was not (see bounds/k2/README.md for the
file:line inventory of what had to be replaced).  What changed here:

  * the target set comes from a provenance-checked matrix file, re-derived from
    GF(2^8) by `verify_slp_generic.load_target` -- not from a hard-coded
    MixColumns `frame.py` (`0x11B`, `coef=[2,3,1,1]`, `range(32)`);
  * the four `if f.n != 88: continue` guards are gone; every circuit is scanned
    at whatever size it is;
  * `minrep` is searched only to `|D|+1` (violation depth), and the `|D|+2`
    upper bound is *constructed* from the cone identity instead of searched --
    cheaper and exact, and it is what lets this run on a 264-gate circuit;
  * every compression is built, written as canonical index-pair JSON, and put
    through `verify_slp_generic.py` before it is reported (Law 1).

------------------------------------------------------------------------------
THE THEOREMS  (statements; proofs and hypotheses in bounds/k2/README.md)

Fix a GF(2) target set T of q distinct masks over n_in inputs, and let C be an
XOR SLP computing T.  Signals are 0..n_in-1 (inputs) and n_in+k (gate k).
Desc(c) = strict forward-reachable set of c.

LEMMA R.  Let c be a gate and x an operand of c with
    (h1) x is a gate, not an input;
    (h2) x does not carry a target mask as its designated producer;
    (h3) x has fanout exactly 1, its only consumer being c.
Put  Avail(c,x) = { mask(s) : s not in Desc(c) u {c, x} }.
If C is optimal then minrep( mask(c) | Avail(c,x) ) = 3, exactly.

THEOREM T2.  For a gate c let D(c) be the private cone of c: the gates that die
(lose every consumer, transitively) when c is deleted, outputs never dying.  Put
    Avail(c) = { mask(s) : s not in Desc(c) u {c} u D(c) }.
If C is optimal then
    (i)   minrep( mask(c) | Avail(c) ) = |D(c)| + 2, exactly;
    (ii)  the sub-DAG on D(c) u {c} is a tree (every g in D(c) has exactly one
          consumer inside the cone);
    (iii) its |D(c)|+2 outside operand slots carry pairwise-distinct masks.
|D| = 0 is "no repeated gate mask and no gate equal to an input"; |D| = 1 is
Lemma R.

A HIT is a failure of the "exactly" in either statement, i.e. a representation
of mask(c) that is SHORTER than the theorem allows.  A hit is not an oracle
saying "this circuit is non-optimal": the representation IS the smaller circuit.
Rewire c to the short representation, delete the gates that just died, prune,
and you hold a circuit with at least one gate fewer -- which this file then
hands to the independent verifier.

Usage
  python3 tripwire_K2.py --target <matrix.json> <circuit.json> [more ...]
  python3 tripwire_K2.py --target <matrix.json> --list paths.txt
  python3 tripwire_K2.py --target <matrix.json> --plant <c.json> --plant-out <p.json>
Options
  --maxD K      largest private cone examined by T2 (default 3)
  --outdir D    where compressed circuits are written (default: scratch)
  --jsonl F     append one JSON row per circuit
  --quiet       one line per circuit, no per-gate detail
Exit 0 iff no circuit produced a verified compression; 1 if any did (a hit is
good news, but it means the input was not optimal, so it is a nonzero exit for
an always-on wire); 2 usage; 3 target refused.
"""
import argparse
import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from verify_slp_generic import load_target, load_index_pairs, Refused   # noqa: E402

ORACLE = os.path.join(HERE, "verify_slp_generic.py")


# ----------------------------------------------------------------- the circuit
class Frame:
    """Generic replacement for e15_campaign3/compose/frame.py:Frame.

    Same fields (pairs, sig, n, mask, out, outsig, consumers, cone) with the
    target set injected rather than imported, and n_in a parameter rather than
    the literal 32.
    """

    def __init__(self, path, targets, n_in=32):
        self.path = path
        self.n_in = n_in
        data = json.load(open(path))
        self.pairs = [tuple(g) for g in load_index_pairs(data)]
        self.n = len(self.pairs)
        sig = [1 << i for i in range(n_in)]
        for k, (a, b) in enumerate(self.pairs):
            if not (0 <= a < n_in + k and 0 <= b < n_in + k):
                raise ValueError(f"gate {k} references a non-earlier signal")
            sig.append(sig[a] ^ sig[b])
        self.sig = sig
        self.mask = {n_in + k: sig[n_in + k] for k in range(self.n)}
        # designated producer of each target: the FIRST signal carrying it
        pos = {}
        for s in range(n_in + self.n):
            pos.setdefault(sig[s], s)
        self.out = {}
        missing = [oi for oi, tm in enumerate(targets) if tm not in pos]
        if missing:
            raise ValueError(f"{len(missing)} target(s) not built, first {missing[:4]}")
        for oi, tm in enumerate(targets):
            self.out[oi] = pos[tm]
        self.outsig = {v: k for k, v in self.out.items()}
        self.consumers = {s: [] for s in range(n_in + self.n)}
        for k, (a, b) in enumerate(self.pairs):
            self.consumers[a].append(n_in + k)
            self.consumers[b].append(n_in + k)

    def depth(self):
        d = [0] * self.n_in
        for a, b in self.pairs:
            d.append(max(d[a], d[b]) + 1)
        return max(d)


def desc(f, s):
    """Strict forward cone (VERBATIM from lane536/completeD.py:108)."""
    out = set()
    st = [s]
    while st:
        x = st.pop()
        for c in f.consumers[x]:
            if c not in out:
                out.add(c)
                st.append(c)
    return out


def private_cone(f, c):
    """D(c): the gates that die when c is deleted (cone_theorem.py:56).

    Outputs never die.  cone_theorem.py relaxes over all n gates to a fixed
    point (O(n^2) per gate, O(n^3) per circuit -- affordable only because it
    ran on 88-gate circuits).  Same result here from a worklist: the only
    gates that can newly die are the operands of a gate that just died.
    """
    n_in = f.n_in
    dead = {c}
    st = [c]
    while st:
        u = st.pop()
        for s in f.pairs[u - n_in]:
            if s < n_in or s in dead or s in f.outsig:
                continue
            cs = f.consumers[s]
            if cs and all(x in dead for x in cs):
                dead.add(s)
                st.append(s)
    return dead - {c}


# ---------------------------------------------------------------- minrep search
def build_pairs(A):
    """{ a^b : a != b in A } with one witness pair each."""
    L = list(A)
    P = {}
    for i in range(len(L)):
        a = L[i]
        for j in range(i + 1, len(L)):
            v = a ^ L[j]
            if v and v not in P:
                P[v] = (a, L[j])
    return P


def minrep_witness(m, A, k, P=None):
    """Smallest r <= k with m = XOR of r DISTINCT members of A.

    Returns (r, [masks]) or (None, None).  Generalises cone_theorem.py:69
    `minrep_upto`, which returned only the size; the witness list is what makes
    the compression constructive.
    """
    if m == 0 or k < 1:
        return None, None
    if m in A:
        return 1, [m]
    if k < 2:
        return None, None
    for p in A:                                   # r = 2
        q = m ^ p
        if q != p and q in A:
            return 2, [p, q]
    if k < 3:
        return None, None
    if P is None:
        P = build_pairs(A)
    for a in A:                                   # r = 3
        t = m ^ a
        if t in P:
            b, c = P[t]
            if len({a, b, c}) == 3:
                return 3, [a, b, c]
    if k < 4:
        return None, None
    for p, (a, b) in P.items():                   # r = 4
        t = m ^ p
        if t in P:
            c, d = P[t]
            if len({a, b, c, d}) == 4:
                return 4, [a, b, c, d]
    if k < 5:
        return None, None
    for a in A:                                   # r = 5
        ma = m ^ a
        for p, (b, c) in P.items():
            t = ma ^ p
            if t in P:
                d, e = P[t]
                if len({a, b, c, d, e}) == 5:
                    return 5, [a, b, c, d, e]
    return None, None


# --------------------------------------------------------- rebuild + prune + oracle
def build_prune(want, targets, n_in):
    """want: mask -> (pmask, qmask).  Keep only the live cone of the targets,
    emit an index-pair gate list in topological order.

    Ported from lane536/completeD.py:41; `TARGET` and `INPUTS` are arguments now
    (completeD.py:38 hard-codes `INPUTS = {1 << i: i for i in range(32)}` and
    :45 reads the MixColumns `TARGET`).
    """
    INPUTS = {1 << i: i for i in range(n_in)}
    for t in targets:
        if t not in want and t not in INPUTS:
            return None, "target-missing"
    live = set()
    st = [t for t in targets if t in want]
    while st:
        m = st.pop()
        if m in live:
            continue
        live.add(m)
        p, q = want[m]
        for x in (p, q):
            if x in INPUTS:
                continue
            if x not in want:
                return None, "dangling"
            if x not in live:
                st.append(x)
    sub = {m: want[m] for m in live}
    sig = dict(INPUTS)
    order = []
    done = set(sig)
    prog = True
    while prog:
        prog = False
        for m, (p, q) in list(sub.items()):
            if m in done:
                continue
            if p in done and q in done:
                sig[m] = n_in + len(order)
                order.append([sig[p], sig[q]])
                done.add(m)
                prog = True
    if len(order) != len(sub):
        return None, "cyclic"
    return order, len(order)


def base_want(f, drop):
    """completeD.py:77, with ONE correction forced by the port.

    completeD's `want[f.mask[g]] = ...` lets the LAST gate carrying a mask win.
    On the forward 88s that is harmless (their masks are all distinct -- that is
    the B = n - q theorem).  Off the 88-gate plateau it is not: this repo's
    264-gate seed carries repeated masks, and last-wins defines a mask from
    operands built later, so every rebuild came back "cyclic".  FIRST-wins is
    always acyclic: the earliest producer of a mask depends only on masks whose
    earliest producers are earlier still.
    """
    want = {}
    for g in range(f.n_in, f.n_in + f.n):
        if g in drop:
            continue
        p, q = f.pairs[g - f.n_in]
        want.setdefault(f.mask[g], (f.sig[p], f.sig[q]))
    return want


def write_circuit(order, path, n_in):
    json.dump({"inputCount": n_in, "gateCount": len(order), "gates": order},
              open(path, "w"))


def oracle(order, path, target_path, n_in):
    """Independent verification -- the ONLY thing that turns a candidate into a
    hit.  Runs the repo's generic oracle as a separate process."""
    write_circuit(order, path, n_in)
    r = subprocess.run(["python3", ORACLE, "--target", target_path, path],
                       capture_output=True, text=True)
    return ("VERDICT: VALID" in r.stdout), r.stdout.strip()


def chain_want(want, W, m_final, A):
    """Left chain over the witness list W, ending at m_final.

    An intermediate that already exists on an AVAILABLE signal is reused rather
    than redefined: redefining it could point a surviving mask at the chain and
    close a cycle, and reusing it is also one gate cheaper.
    """
    cur = W[0]
    for x in W[1:]:
        nxt = cur ^ x
        if nxt != m_final and nxt in A:
            cur = nxt
            continue
        want[nxt] = (cur, x)
        cur = nxt
    assert cur == m_final, "chain does not reach the target mask"
    return want


# ------------------------------------------------------------------- detectors
def scan_lemmaR(f, targets):
    """Every (gate, private-operand) pair, with minrep over Avail(c,x) capped at
    2.  Generalises witness.py:45 `lemmaR`; the `assert` sanity checks of
    witness.py:52-53 are kept because they are the theorem's <= direction."""
    stats = {"pairs": 0, "r1": 0, "r2": 0, "r3plus": 0}
    hits = []
    n_in = f.n_in
    for c in range(n_in, n_in + f.n):
        a, b = f.pairs[c - n_in]
        if a == b:                            # mask(c) == 0; degenerate
            continue
        dc = None
        for x, y in ((a, b), (b, a)):
            if x < n_in:                      # (h1) x must be a gate
                continue
            if x in f.outsig:                 # (h2) x must not be an output
                continue
            if len(f.consumers[x]) != 1:      # (h3) fanout(x) == 1
                continue
            if dc is None:
                dc = desc(f, c)
            bad = dc | {c, x}
            A = {f.sig[s] for s in range(n_in + f.n) if s not in bad}
            mc = f.mask[c]
            xa, xb = f.pairs[x - n_in]
            # the <= 3 direction, checked rather than trusted
            assert f.sig[y] in A and f.sig[xa] in A and f.sig[xb] in A
            assert f.sig[y] ^ f.sig[xa] ^ f.sig[xb] == mc
            stats["pairs"] += 1
            r, W = minrep_witness(mc, A, 2)
            if r is None:
                stats["r3plus"] += 1
                continue
            stats[f"r{r}"] += 1
            hits.append({"kind": "lemmaR", "c": c - n_in, "x": x - n_in,
                         "minrep": r, "witness": W, "_A": A,
                         "drop": [x] + ([c] if r == 1 else [])})
    return stats, hits


def scan_T2(f, targets, maxD=3):
    """Theorem T2 on every gate with |D(c)| <= maxD.

    The forward code (cone_theorem.py:116) searched minrep up to |D|+2 and then
    compared.  Here the <= |D|+2 side is CONSTRUCTED from the cone identity
    (free) and only <= |D|+1 is searched, which is both the violation depth and
    a large constant-factor saving on big circuits.
    """
    n_in = f.n_in
    stats = {"gates": 0, "skipped_bigD": 0, "tree": 0, "NOTtree": 0,
             "distinct": 0, "NOTdistinct": 0}
    Dhist = {}
    hits = []
    struct = []
    for c in range(n_in, n_in + f.n):
        D = private_cone(f, c)
        d = len(D)
        Dhist[d] = Dhist.get(d, 0) + 1
        if d > maxD:
            stats["skipped_bigD"] += 1
            continue
        stats["gates"] += 1
        cone = D | {c}
        outside = []
        for g in cone:
            for s in f.pairs[g - n_in]:
                if s not in cone:
                    outside.append(f.sig[s])
        istree = all(len([u for u in f.consumers[g] if u in cone]) == 1 for g in D)
        distinct = (len(set(outside)) == len(outside))
        stats["tree" if istree else "NOTtree"] += 1
        stats["distinct" if distinct else "NOTdistinct"] += 1
        bad = desc(f, c) | {c} | D
        A = {f.sig[s] for s in range(n_in + f.n) if s not in bad}
        mc = f.mask[c]
        if istree:
            # the cone identity: XOR of the outside slots IS mask(c)
            x = 0
            for m in outside:
                x ^= m
            assert x == mc, "cone identity failed on a tree cone"
            assert len(outside) == d + 2, "tree cone has the wrong slot count"
        r, W = minrep_witness(mc, A, d + 1)
        if r is not None:
            hits.append({"kind": "T2", "c": c - n_in, "D": sorted(g - n_in for g in D),
                         "d": d, "minrep": r, "witness": W, "_A": A,
                         "drop": sorted(cone)})
        elif not istree or not distinct:
            struct.append({"c": c - n_in, "d": d, "tree": istree,
                           "distinct": distinct})
    stats["D_hist"] = {k: Dhist[k] for k in sorted(Dhist)}
    return stats, hits, struct


# ----------------------------------------------------------------- compression
def compress(f, hit, targets, outdir, target_path, tag, n_base=None):
    """Turn a hit into a circuit and verify it.  Returns a dict."""
    n_in = f.n_in
    mc = f.mask[hit["c"] + n_in]
    if hit["kind"] == "lemmaR":
        drop = set(hit["drop"])
        want = base_want(f, drop)
        if hit["minrep"] == 2:
            p, q = hit["witness"]
            want[mc] = (p, q)
        # minrep == 1: mask(c) already exists elsewhere; c and x both go
    else:
        drop = {g for g in hit["drop"]}
        want = base_want(f, drop)
        if hit["minrep"] >= 2:
            chain_want(want, hit["witness"], mc, hit["_A"])
        # minrep == 1: nothing to mint
    order, nn = build_prune(want, targets, n_in)
    if order is None:
        return {"built": False, "reason": nn}
    if nn >= f.n:
        return {"built": False, "reason": f"no gain ({nn} >= {f.n})"}
    os.makedirs(outdir, exist_ok=True)
    path = os.path.join(outdir, f"K2_{tag}_{f.n}to{nn}.json")
    ok, out = oracle(order, path, target_path, n_in)
    d = [0] * n_in
    for a, b in order:
        d.append(max(d[a], d[b]) + 1)
    return {"built": True, "n_new": nn, "depth": max(d), "oracle_VALID": ok,
            "n_base": n_base,
            "k2_attributable": (n_base is None or nn < n_base),
            "path": path, "oracle_out": out}


# ---------------------------------------------------------------------- plant
def plant(f, targets, out_path, target_path):
    """L1 planted positive: add ONE redundant gate that violates Lemma R.

    Take a gate c = a ^ b whose operand a is itself a gate a = a1 ^ a2 with
    fanout(a) >= 2.  Re-associate through a NEW gate  x := a1 ^ b, and set
    c := x ^ a2.  mask(c) is unchanged, a survives (it had another consumer),
    x is fresh, non-output and consumed only by c -- so (c, x) is a
    private-operand pair, and mask(c) = mask(a) ^ mask(b) with both operands
    still available, i.e. minrep = 2 < 3.  Exactly one gate is added, so the
    tripwire must fire and hand back the original count.

    Note this plant is INVISIBLE to the B = n - q tripwire (K1): the planted
    circuit has no duplicate mask and no dead gate, so B = n - q holds.
    """
    n_in = f.n_in
    tset = set(targets)
    allmasks = set(f.sig)
    for ci in range(f.n):
        c = n_in + ci
        a, b = f.pairs[ci]
        for a, b in ((a, b), (b, a)):
            if a < n_in or len(f.consumers[a]) < 2:
                continue
            a1, a2 = f.pairs[a - n_in]
            newmask = f.sig[a1] ^ f.sig[b]
            if newmask == 0 or newmask in allmasks or newmask in tset:
                continue
            want = base_want(f, set())
            want[newmask] = (f.sig[a1], f.sig[b])
            want[f.mask[c]] = (newmask, f.sig[a2])
            order, nn = build_prune(want, targets, n_in)
            if order is None or nn != f.n + 1:
                continue
            ok, out = oracle(order, out_path, target_path, n_in)
            if not ok:
                continue
            return {"gate": ci, "a": a - n_in, "b": b, "newmask": hex(newmask),
                    "n": nn, "path": out_path, "oracle_VALID": ok}
    return None


# ---------------------------------------------------------------------- driver
def run_one(path, targets, n_in, args):
    t0 = time.process_time()
    row = {"file": path}
    try:
        f = Frame(path, targets, n_in)
    except Exception as e:
        row.update(valid=False, error=str(e))
        print(f"[SKIP] {path}: {e}")
        return row, []
    row.update(valid=True, n=f.n, depth=f.depth())
    # canonical rebuild of the circuit AS GIVEN: collapses repeated masks and
    # drops dead gates.  Anything K2 saves is measured against THIS, so a
    # "hit" can never be credited with a saving that mask-dedup alone gives.
    base_order, n_base = build_prune(base_want(f, set()), targets, n_in)
    row["n_base"] = n_base if base_order is not None else f"FAILED:{n_base}"
    if base_order is None:
        n_base = f.n
    elif n_base < f.n:
        # not a K2 finding -- report it separately so no K2 hit is credited
        # with a saving that plain mask-dedup + dead-gate pruning already gives
        os.makedirs(args.outdir, exist_ok=True)
        bp = os.path.join(args.outdir,
                          f"BASE_{os.path.splitext(os.path.basename(path))[0]}"
                          f"_{f.n}to{n_base}.json")
        bok, _ = oracle(base_order, bp, args.target, n_in)
        row["baseline_oracle_VALID"] = bok
        row["baseline_path"] = bp
    lstat, lhits = scan_lemmaR(f, targets)
    tstat, thits, struct = scan_T2(f, targets, args.maxD)
    row.update(lemmaR=lstat, T2={k: v for k, v in tstat.items()},
               n_lemmaR_hits=len(lhits), n_T2_hits=len(thits),
               n_structural=len(struct))
    verified = []
    tag = os.path.splitext(os.path.basename(path))[0]
    for i, h in enumerate(lhits + thits):
        c = compress(f, h, targets, args.outdir, args.target, f"{tag}_{i}",
                     n_base=n_base)
        h.pop("_A", None)
        h["compression"] = {k: v for k, v in c.items() if k != "oracle_out"}
        if c.get("oracle_VALID"):
            verified.append((h, c))
    row["verified_compressions"] = [
        {"kind": h["kind"], "c": h["c"], "minrep": h["minrep"],
         "n_new": c["n_new"], "depth": c["depth"],
         "k2_attributable": c["k2_attributable"], "path": c["path"]}
        for h, c in verified]
    row["cpu_s"] = round(time.process_time() - t0, 2)

    best = min((c["n_new"] for _, c in verified), default=None)
    flag = "  *** HIT ***" if verified else ""
    if n_base != f.n:
        flag += f"  [canonical rebuild alone: {f.n}->{n_base}]"
    print(f"{os.path.basename(path):<42} n={f.n:<4} d={f.depth():<3} "
          f"|R-pairs={lstat['pairs']:<4} R-hits={len(lhits):<3} "
          f"|D|<={args.maxD} T2-hits={len(thits):<3} "
          f"struct={len(struct):<2} Dhist={tstat['D_hist']} "
          f"-> {'n/a' if best is None else best} "
          f"[{row['cpu_s']}s]{flag}")
    if not args.quiet:
        for h, c in verified:
            print(f"      {h['kind']} c={h['c']} minrep={h['minrep']} "
                  f"=> {f.n} -> {c['n_new']} gates @ depth {c['depth']}, "
                  f"oracle VALID, K2-attributable={c['k2_attributable']} "
                  f"(baseline {n_base})   {c['path']}")
        for h in lhits + thits:
            if not h.get("compression", {}).get("oracle_VALID"):
                if h.get("compression"):
                    print(f"      {h['kind']} c={h['c']} minrep={h['minrep']} "
                          f"NOT verified: {h['compression']}")
        for s in struct[:4]:
            print(f"      structural T2 note (no shorter rep): {s}")
    return row, verified


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", required=True)
    ap.add_argument("circuits", nargs="*")
    ap.add_argument("--list")
    ap.add_argument("--maxD", type=int, default=3)
    ap.add_argument("--outdir", default=os.environ.get(
        "K2_OUTDIR", "<tmp>/k2_out"))
    ap.add_argument("--jsonl")
    ap.add_argument("--quiet", action="store_true")
    ap.add_argument("--plant")
    ap.add_argument("--plant-out")
    ap.add_argument("--n-inputs", type=int, default=32)
    args = ap.parse_args()

    try:
        spec, n_in, info = load_target(args.target)
    except Refused as e:
        print(f"target={args.target}\nREFUSED: {e}\nVERDICT: TARGET REFUSED")
        sys.exit(3)
    except Exception as e:
        print(f"target={args.target}\nREFUSED: unreadable ({type(e).__name__}: {e})"
              f"\nVERDICT: TARGET REFUSED")
        sys.exit(3)
    print(f"target={info['name']} inputs={n_in} outputs={len(spec)} "
          f"rank={info['rank']} rows_sha256={info['sha256'][:16]}")
    print(f"target rebuilt: {info['rederived']}")
    print(f"maxD={args.maxD}  outdir={args.outdir}")

    if args.plant:
        f = Frame(args.plant, spec, n_in)
        out = args.plant_out or (args.outdir + "/plant.json")
        os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
        r = plant(f, spec, out, args.target)
        print(f"PLANT on {args.plant} (n={f.n}): {r}")
        sys.exit(0 if r else 1)

    files = list(args.circuits)
    if args.list:
        files += [l.strip() for l in open(args.list) if l.strip()
                  and not l.startswith("#")]
    if not files:
        ap.error("no circuits given")

    rows = []
    anyhit = 0
    t0 = time.time()
    for p in files:
        row, ver = run_one(p, spec, n_in, args)
        rows.append(row)
        anyhit += len(ver)
    print()
    print(f"=== {len(files)} circuit(s), {time.time()-t0:.1f}s wall, "
          f"{sum(r.get('cpu_s', 0) for r in rows):.1f}s CPU (this process) ===")
    print(f"VERIFIED COMPRESSIONS: {anyhit}")
    for r in rows:
        for v in r.get("verified_compressions", []):
            print(f"   {os.path.basename(r['file'])}: {r['n']} -> "
                  f"{v['n_new']} @ depth {v['depth']}  ({v['kind']}, "
                  f"minrep={v['minrep']})  {v['path']}")
    print("VERDICT:", "K2 HITS" if anyhit else "K2 CLEAN")
    if args.jsonl:
        with open(args.jsonl, "a") as fh:
            for r in rows:
                fh.write(json.dumps(r, sort_keys=True) + "\n")
    sys.exit(1 if anyhit else 0)


if __name__ == "__main__":
    main()
