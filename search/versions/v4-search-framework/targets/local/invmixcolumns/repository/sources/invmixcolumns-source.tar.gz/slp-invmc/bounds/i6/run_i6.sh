#!/usr/bin/env bash
# run_i6.sh -- regenerate NEW/controls/I6_certificate.txt from scratch.
# Single core, nice -n 19.  CPU-seconds are reported per step by /usr/bin/time.
set -u
cd "$(dirname "$0")"
T() { /usr/bin/time -f "    [cpu user %U sys %S | wall %e s]  <<< $*" nice -n 19 "$@"; }

echo "=============================================================================="
echo " I6 / Theorem B on AES InvMixColumns -- certificate + controls"
echo " date $(date -u +%Y-%m-%dT%H:%M:%SZ)   host cores $(nproc)   nice 19, one core"
echo "=============================================================================="

gcc -O2 -march=native -o brute brute.c || exit 1
echo "built ./brute from brute.c"

K8=0,3,4,5,6,7,14,17
K9=0,1,3,7,14,16,17,28,29

echo
echo "### 1. THE |K| = 8 CERTIFICATE -- L(M_inv) >= 58 ############################"
echo "--- 1a. ported DFS (OLD deep_extras.py semantics), exact minE ---------------"
T python3 mine_search.py --target invmc --K $K8 --kmax 3 2>&1 | sed -n '/keep-set(s)/,$p'
echo "--- 1b. Python full-pool exhaustion, uses none of the search theory ---------"
T python3 brute_check.py --target invmc --K $K8 --depth 2 2>&1 | sed -n '/^K = /,$p'
echo "--- 1c. C full-pool exhaustion, independent implementation ------------------"
TG8=$(python3 emit_targets.py --target invmc --K $K8)
echo "V_K = $TG8"
T ./brute 8 "$TG8" 1 ; echo "  (exit $? : 0 = NONE = minE >= 2)"
T ./brute 8 "$TG8" 2 ; echo "  (exit $? : 1 = COMPLETION = minE <= 2)"

echo
echo "### 2. OPTIMALITY AT |K| = 8 -- no admissible 8-set beats 58 ################"
echo "--- 2a. the full 42,388-set sweep is banked in runs/sweep_k8_full.jsonl -----"
sed -n '/^swept /,$p' runs/sweep_k8_full.txt
echo "--- 2b. verified without the search theory: witnesses + full-pool exhaustion "
T python3 verify_i6.py --target invmc --layer ../i5/runs/admissible_invmc_k8.txt \
    --bank runs/sweep_k8_full.jsonl 2>&1 | sed -n '/^layer /,$p'

echo
echo "### 3. THE |K| = 9 CERTIFICATE -- L(M_inv) >= 59 ############################"
echo "--- 3a. ported DFS ---------------------------------------------------------"
T python3 mine_search.py --target invmc --K $K9 --kmax 4 2>&1 | sed -n '/keep-set(s)/,$p'
echo "--- 3b. Python full-pool exhaustion to depth 2 (=> minE >= 3) ---------------"
T python3 brute_check.py --target invmc --K $K9 --depth 2 2>&1 | sed -n '/^K = /,$p'
echo "--- 3c. C full-pool exhaustion to depth 3 (=> minE >= 4), 17.3e6 extra-sets -"
TG9=$(python3 emit_targets.py --target invmc --K $K9)
echo "V_K = $TG9"
T ./brute 9 "$TG9" 3 ; echo "  (exit $? : 0 = NONE = minE >= 4)"
echo "--- 3d. a SECOND |K|=9 keep-set, 5-of-9-disjoint from the first ------------"
echo "        K = 0,3,4,5,6,7,13,14,17 (jam = 32).  Same bound 59, and the C"
echo "        exhaustion and the Python DFS must return the same witness."
TG9B=$(python3 emit_targets.py --target invmc --K 0,3,4,5,6,7,13,14,17)
T ./brute 9 "$TG9B" 3 ; echo "  (exit $? : 0 = NONE = minE >= 4  =>  L(M_inv) >= 55 + 4 = 59)"
T ./brute 9 "$TG9B" 4 ; echo "  (exit $? : 1 = COMPLETION = minE = 4 exactly)"
T python3 -c "
import sys,time; sys.path.insert(0,'.')
import i6_core as i6
t=i6.core.load('invmc'); i6.core.rederive_and_compare(t,say=lambda s:None); i6.core.selfcheck(t,say=lambda s:None)
K=[0,3,4,5,6,7,13,14,17]
assert i6.admissible(t.rows,K)
s=i6.Search(9,i6.restrict(t.rows,K)); r=s.rec(set(s.I),[],4)
print('  ported DFS at budget 4 only: witness', sorted(r), ' nodes', s.nodes)
"

echo "--- 3e. positive control: the same C binary DOES find a depth-3 completion --"
echo "        on an admissible 9-set whose minE is 3 (K = 0,1,2,3,5,9,22,23,29)"
TG9C=$(python3 emit_targets.py --target invmc --K 0,1,2,3,5,9,22,23,29)
T ./brute 9 "$TG9C" 3 ; echo "  (exit $? : 1 = COMPLETION at depth <= 3 -- not vacuously NONE)"

echo
echo "### 4. CROSS-VALIDATION -- three code paths on random instances #############"
T python3 xcheck_brute.py --c 7 --n 120 --ntargets 20 --minwt 4 --seed 3 --cap 4 2>&1 | sed -n '/^c=/,$p'
T python3 xcheck_brute.py --c 8 --n 60 --ntargets 32 --minwt 4 --seed 5 --cap 4 2>&1 | sed -n '/^c=/,$p'

echo
echo "### 5. NEGATIVE CONTROL -- the forward matrix at its Theorem-A optimum ######"
echo "  OLD NOTEBOOK.md:352-357 reports minE = 0 on all 72 admissible |K|=13"
echo "  MixColumns keep-sets.  Reproduced here through the ported code:"
rm -f runs/sweep_mixcolumns_k13.jsonl      # sweep.py resumes from its bank; this
                                          # control must re-decide all 72 every run
T python3 sweep.py --target mixcolumns --layer ../i5/runs/admissible_mixcolumns_k13.txt \
    --kmax 2 --bank runs/sweep_mixcolumns_k13.jsonl --flush 8 2>&1 | sed -n '/^layer /,$p'

echo
echo "### 6. OLD REPOSITORY UNTOUCHED #############################################"
echo -n "  git status --porcelain in OLD : "
(cd ~/xor_ui/slp-plateau-search && git status --porcelain | wc -l)
echo "  (must be 0)"
echo "=============================================================================="
