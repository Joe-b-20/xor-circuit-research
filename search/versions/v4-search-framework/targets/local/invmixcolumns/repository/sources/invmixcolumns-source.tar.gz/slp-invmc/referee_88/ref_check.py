#!/usr/bin/env python3
"""Referee check for circuits/invmc_walk_88_depth33.json.
Shared-nothing: InvMixColumns is rebuilt here from FIPS-197 text only.
Nothing from spec/, tools/ or pipeline/ is imported or read."""
import json, random, sys, subprocess, os

REPO = "~/xor_ui/slp-invmc"
CIRC = REPO + "/circuits/invmc_walk_88_depth33.json"

# ---------------------------------------------------------------- FIPS-197 GF(2^8)
# FIPS-197 sec 4.2: m(x) = x^8 + x^4 + x^3 + x + 1  ->  0x11B
def xtime(a):                      # FIPS-197 sec 4.2.1
    a <<= 1
    if a & 0x100:
        a ^= 0x11B
    return a & 0xFF

def gmul(a, b):                    # FIPS-197 sec 4.2, repeated xtime
    r = 0
    for i in range(8):
        if (b >> i) & 1:
            r ^= a
        a = xtime(a)
    return r

# FIPS-197 sec 5.1.3 eq (5.6): MixColumns, a(x) = {03}x^3+{01}x^2+{01}x+{02}
def mixcol(c):
    s0, s1, s2, s3 = c
    return [gmul(s0,2)^gmul(s1,3)^s2^s3,
            s0^gmul(s1,2)^gmul(s2,3)^s3,
            s0^s1^gmul(s2,2)^gmul(s3,3),
            gmul(s0,3)^s1^s2^gmul(s3,2)]

# FIPS-197 sec 5.3.3 eq (5.10): InvMixColumns, a^-1(x) = {0b}x^3+{0d}x^2+{09}x+{0e}
def invmixcol(c):
    s0, s1, s2, s3 = c
    return [gmul(s0,0x0e)^gmul(s1,0x0b)^gmul(s2,0x0d)^gmul(s3,0x09),
            gmul(s0,0x09)^gmul(s1,0x0e)^gmul(s2,0x0b)^gmul(s3,0x0d),
            gmul(s0,0x0d)^gmul(s1,0x09)^gmul(s2,0x0e)^gmul(s3,0x0b),
            gmul(s0,0x0b)^gmul(s1,0x0d)^gmul(s2,0x09)^gmul(s3,0x0e)]

L = []
def say(*a):
    s = " ".join(str(x) for x in a)
    print(s); L.append(s)

ok_all = True
def chk(name, cond, extra=""):
    global ok_all
    ok_all &= bool(cond)
    say(("  OK   " if cond else "  FAIL ") + name + ((" | " + extra) if extra else ""))

say("="*78)
say("A. FIPS-197 reference primitives")
say("="*78)
# FIPS-197 sec 4.2 worked example: {57} . {83} = {c1}
chk("{57}.{83} = {c1}  (FIPS-197 sec 4.2 worked example)", gmul(0x57,0x83)==0xc1, hex(gmul(0x57,0x83)))
# FIPS-197 sec 4.2.1 worked example: {57} . {13} = {fe}
chk("{57}.{13} = {fe}  (FIPS-197 sec 4.2.1 worked example)", gmul(0x57,0x13)==0xfe, hex(gmul(0x57,0x13)))
chk("{57}.{02} = {ae}  (sec 4.2.1 xtime chain)", gmul(0x57,2)==0xae, hex(gmul(0x57,2)))
chk("{57}.{04} = {47}  (sec 4.2.1 xtime chain)", gmul(0x57,4)==0x47, hex(gmul(0x57,4)))
chk("{57}.{08} = {8e}  (sec 4.2.1 xtime chain)", gmul(0x57,8)==0x8e, hex(gmul(0x57,8)))
chk("{57}.{10} = {07}  (sec 4.2.1 xtime chain)", gmul(0x57,16)==0x07, hex(gmul(0x57,16)))

rnd = random.Random(20260909)
bad = 0
for _ in range(20000):
    c = [rnd.randrange(256) for _ in range(4)]
    if invmixcol(mixcol(c)) != c: bad += 1
chk("invmixcol o mixcol = id on 20000 random columns", bad==0, "bad=%d"%bad)

# ---------------------------------------------------------------- FIPS-197 round traces
def hx(s): return [int(s[i:i+2],16) for i in range(0,len(s),2)]
def cols(b):  # 16 bytes in column-major AES state order -> 4 columns
    return [b[4*i:4*i+4] for i in range(4)]
def flat(cs):
    return [x for c in cs for x in c]

say("")
say("="*78)
say("B. FIPS-197 round traces")
say("="*78)
# FIPS-197 Appendix B ("Cipher Example"), Round 1 rows
# input 3243f6a8885a308d313198a2e0370734, key 2b7e151628aed2a6abf7158809cf4f3c
# Round 1:  Start of Round   19a09ae93df4c6f8e3e28d48be2b2a08
#           After SubBytes   d4e0b81e27bfb44111985d52aef1e530
#           After ShiftRows  d4e0b81ebfb441275d521198e5302ae1   (state, column-major)
#           After MixColumns 046681e5e0cb199a48f8d37a2806264c
# FIPS-197 Appendix B ("Cipher Example"), Round 1: the printed 4x4 state arrays
#   After ShiftRows   d4 e0 b8 1e / bf b4 41 27 / 5d 52 11 98 / 30 ae f1 e5   (rows as printed)
#   After MixColumns  04 e0 48 28 / 66 cb f8 06 / 81 19 d3 26 / e5 9a 7a 4c
# read COLUMN-major (AES state order):
B_srow = "d4bf5d30e0b452aeb84111f11e2798e5"
B_mcol = "046681e5e0cb199a48f8d37a2806264c"
got = flat([mixcol(c) for c in cols(hx(B_srow))])
chk("App.B round[1]: MixColumns(s_row)=m_col", got==hx(B_mcol), "".join("%02x"%x for x in got))
got = flat([invmixcol(c) for c in cols(hx(B_mcol))])
chk("App.B round[1]: InvMixColumns(m_col)=s_row", got==hx(B_srow), "".join("%02x"%x for x in got))

# FIPS-197 Appendix C.1 (AES-128, PLAINTEXT 00112233445566778899aabbccddeeff,
# KEY 000102030405060708090a0b0c0d0e0f).  Named "round[r].s_row" / "round[r].m_col" lines:
for r, sr, mc in [
    (1, "6353e08c0960e104cd70b751bacad0e7", "5f72641557f5bc92f7be3b291db9f91a"),
    (2, "a7be1a6997ad739bd8c9ca451f618b61", "ff87968431d86a51645151fa773ad009"),
    (3, "3bd92268fc74fb735767cbe0c0590e2d", "4c9c1e66f771f0762c3f868e534df256"),
]:
    got = flat([mixcol(c) for c in cols(hx(sr))])
    chk("App.C.1 round[%d].s_row -> round[%d].m_col" % (r,r), got==hx(mc), "".join("%02x"%x for x in got))
    got = flat([invmixcol(c) for c in cols(hx(mc))])
    chk("App.C.1 round[%d].m_col -> round[%d].s_row  (INVERSE)" % (r,r), got==hx(sr), "".join("%02x"%x for x in got))

# ---------------------------------------------------------------- full AES on these primitives
SBOX=[None]*256
def inv(a):
    if a==0: return 0
    for b in range(1,256):
        if gmul(a,b)==1: return b
def rotl8(x,n): return ((x<<n)|(x>>(8-n)))&0xFF
for a in range(256):
    b=inv(a)
    SBOX[a]=b^rotl8(b,1)^rotl8(b,2)^rotl8(b,3)^rotl8(b,4)^0x63   # FIPS-197 sec 5.1.1 eq (5.2)
INVS=[0]*256
for i,v in enumerate(SBOX): INVS[v]=i
def keyexp(key):
    Nk,Nr=4,10; w=[list(key[4*i:4*i+4]) for i in range(Nk)]
    rc=1
    for i in range(Nk,4*(Nr+1)):
        t=list(w[i-1])
        if i%Nk==0:
            t=t[1:]+t[:1]; t=[SBOX[x] for x in t]; t[0]^=rc; rc=xtime(rc)
        w.append([w[i-Nk][j]^t[j] for j in range(4)])
    return w
def ark(st,w,r): return [[st[c][j]^w[4*r+c][j] for j in range(4)] for c in range(4)]
def srow(st): return [[st[c][0],st[(c+1)%4][1],st[(c+2)%4][2],st[(c+3)%4][3]] for c in range(4)]
def isrow(st): return [[st[c][0],st[(c-1)%4][1],st[(c-2)%4][2],st[(c-3)%4][3]] for c in range(4)]
def enc(pt,key):
    w=keyexp(key); st=cols(pt); st=ark(st,w,0)
    for r in range(1,10):
        st=[[SBOX[x] for x in c] for c in st]; st=srow(st); st=[mixcol(c) for c in st]; st=ark(st,w,r)
    st=[[SBOX[x] for x in c] for c in st]; st=srow(st); st=ark(st,w,10)
    return flat(st)
def dec(ct,key):
    w=keyexp(key); st=cols(ct); st=ark(st,w,10)
    for r in range(9,0,-1):
        st=isrow(st); st=[[INVS[x] for x in c] for c in st]; st=ark(st,w,r); st=[invmixcol(c) for c in st]
    st=isrow(st); st=[[INVS[x] for x in c] for c in st]; st=ark(st,w,0)
    return flat(st)
say("")
def hs(b): return "".join("%02x"%x for x in b)
e=enc(hx("3243f6a8885a308d313198a2e0370734"),hx("2b7e151628aed2a6abf7158809cf4f3c"))
chk("FIPS-197 App.B full encrypt -> 3925841d02dc09fbdc118597196a0b32", hs(e)=="3925841d02dc09fbdc118597196a0b32", hs(e))
d=dec(hx("3925841d02dc09fbdc118597196a0b32"),hx("2b7e151628aed2a6abf7158809cf4f3c"))
chk("FIPS-197 App.B full decrypt (uses invmixcol) -> 3243f6a8...", hs(d)=="3243f6a8885a308d313198a2e0370734", hs(d))
e=enc(hx("00112233445566778899aabbccddeeff"),hx("000102030405060708090a0b0c0d0e0f"))
chk("FIPS-197 App.C.1 full encrypt -> 69c4e0d86a7b0430d8cdb78070b4c55a", hs(e)=="69c4e0d86a7b0430d8cdb78070b4c55a", hs(e))
d=dec(hx("69c4e0d86a7b0430d8cdb78070b4c55a"),hx("000102030405060708090a0b0c0d0e0f"))
chk("FIPS-197 App.C.1 full decrypt (uses invmixcol) -> 00112233...", hs(d)=="00112233445566778899aabbccddeeff", hs(d))

# openssl cross-check of the decrypt path
try:
    okc=0; n=50
    for _ in range(n):
        k=bytes(rnd.randrange(256) for _ in range(16)); p=bytes(rnd.randrange(256) for _ in range(16))
        c=subprocess.run(["openssl","enc","-aes-128-ecb","-nopad","-K",k.hex()],
                         input=p,capture_output=True).stdout
        if bytes(dec(list(c),list(k)))==p: okc+=1
    chk("my dec() == openssl aes-128-ecb on %d random (key,block)"%n, okc==n, "%d/%d"%(okc,n))
except FileNotFoundError:
    say("  SKIP  openssl not available")

# ---------------------------------------------------------------- target matrix
# bit index 8*byte + bit ; bit i = coefficient of x^i (LSB-first)
say("")
say("="*78)
say("C. Target matrix (my own, from invmixcol above)")
say("="*78)
ROWS=[0]*32          # ROWS[o] = 32-bit mask over inputs
for i in range(32):
    col=[0,0,0,0]; col[i//8] = 1<<(i%8)
    out=invmixcol(col)
    for o in range(32):
        if (out[o//8]>>(o%8))&1: ROWS[o]|=1<<i
say("rows distinct:", len(set(ROWS))==32, " total ones:", sum(bin(r).count('1') for r in ROWS))
prof={}
for r in ROWS: prof[bin(r).count('1')]=prof.get(bin(r).count('1'),0)+1
say("row-weight profile:", dict(sorted(prof.items())))
# matrix vs invmixcol on random columns
def apply_matrix(x):     # x = 32-bit input vector
    y=0
    for o in range(32):
        if bin(ROWS[o]&x).count('1')&1: y|=1<<o
    return y
def col2vec(c): return c[0]|(c[1]<<8)|(c[2]<<16)|(c[3]<<24)
bad=0
for _ in range(5000):
    c=[rnd.randrange(256) for _ in range(4)]
    if apply_matrix(col2vec(c))!=col2vec(invmixcol(c)): bad+=1
chk("matrix == invmixcol on 5000 random columns", bad==0, "bad=%d"%bad)
json.dump({"rows":ROWS}, open(REPO+"/referee_88/target_rows.json","w"))

# ---------------------------------------------------------------- circuit
say("")
say("="*78)
say("D. Circuit structural checks")
say("="*78)
D=json.load(open(CIRC))
G=D["gates"]; prov=D.get("provenance",{})
say("gates in file: %d   provenance says gates=%s depth=%s" % (len(G), prov.get("gates"), prov.get("depth")))
chk("gate count == 88", len(G)==88, str(len(G)))
say("provenance has an 'outputs' field:", "outputs" in prov)

# topological / well-formedness
bad=[]
for i,g in enumerate(G):
    if len(g)!=2: bad.append((i,"arity"))
    a,b=g; sig=32+i
    if not(0<=a<sig and 0<=b<sig): bad.append((i,"ref"))
    if a==b: bad.append((i,"self"))
chk("all gates 2-input, operands < own index, operands distinct", not bad, str(bad))

masks=[1<<i for i in range(32)]
for a,b in G: masks.append(masks[a]^masks[b])
chk("no zero-mask gate", all(m!=0 for m in masks[32:]), str([32+i for i,m in enumerate(masks[32:]) if m==0]))
seen={}; dups=[]
for s,m in enumerate(masks):
    if m in seen: dups.append((seen[m],s))
    else: seen[m]=s
chk("no duplicate masks among all 120 signals", not dups, str(dups))

# output recovery BY MASK MATCHING (done before consulting provenance)
m2s={m:s for s,m in enumerate(masks)}
outs=[]
missing=[]
for o in range(32):
    if ROWS[o] in m2s: outs.append(m2s[ROWS[o]])
    else: missing.append(o); outs.append(None)
chk("all 32 target rows realised as some signal mask", not missing, "missing outputs: "+str(missing))
say("recovered output signals (out bit 0..31):", outs)
chk("all outputs on gates (signal>=32)", all(o is not None and o>=32 for o in outs))
chk("all outputs on distinct signals", len(set(outs))==32)
if "outputs" in prov:
    chk("matches provenance 'outputs'", list(prov["outputs"])==outs, str(prov["outputs"]))
else:
    say("  NOTE  provenance carries NO 'outputs' field -> nothing to compare against")

# dead gates
used=set()
for a,b in G: used.add(a); used.add(b)
outset=set(outs)
dead=[32+i for i in range(88) if (32+i) not in used and (32+i) not in outset]
chk("0 dead gates", not dead, str(dead))
unused_in=[i for i in range(32) if i not in used]
chk("no unused inputs", not unused_in, str(unused_in))

# depth (my own longest input->output path)
dep=[0]*len(masks)
for i,(a,b) in enumerate(G): dep[32+i]=max(dep[a],dep[b])+1
D_out=max(dep[o] for o in outs)
D_all=max(dep)
say("my longest-path depth over outputs: %d   (over all signals: %d)" % (D_out, D_all))
chk("depth == 33 as claimed", D_out==33, "computed %d"%D_out)

# ---------------------------------------------------------------- functional evaluation
say("")
say("="*78)
say("E. Functional evaluation (independent of masks: simulate the gate list)")
say("="*78)
def evalc(x):
    v=[(x>>i)&1 for i in range(32)]
    for a,b in G: v.append(v[a]^v[b])
    y=0
    for o in range(32):
        if v[outs[o]]: y|=1<<o
    return y
def ref(x):
    c=[(x>>0)&255,(x>>8)&255,(x>>16)&255,(x>>24)&255]
    return col2vec(invmixcol(c))
bad=[u for u in range(32) if evalc(1<<u)!=ref(1<<u)]
chk("32 unit vectors", not bad, str(bad))
b1=sum(1 for x in range(65536) if evalc(x)!=ref(x))
chk("exhaustive low half-column x in [0,65536) (bytes 0,1)", b1==0, "bad=%d"%b1)
b2=sum(1 for x in range(65536) if evalc(x<<16)!=ref(x<<16))
chk("exhaustive high half-column x<<16 (bytes 2,3)", b2==0, "bad=%d"%b2)
r2=random.Random(4242); bad=0
N=25000
for _ in range(N):
    x=r2.randrange(1<<32)
    if evalc(x)!=ref(x): bad+=1
chk("%d random full columns"%N, bad==0, "bad=%d"%bad)
# linearity sanity: the circuit is linear by construction; confirm eval == matrix apply
bad=sum(1 for _ in range(5000) if (lambda x: evalc(x)!=apply_matrix(x))(r2.randrange(1<<32)))
chk("circuit == my matrix on 5000 more random columns", bad==0, "bad=%d"%bad)

# ---------------------------------------------------------------- B = n - q tripwire
say("")
say("="*78)
say("F. Tripwire arithmetic (rebuilt)")
say("="*78)
n_nonout = len(masks)-32-len(outset)     # gates that are not outputs
say("signals=%d  inputs=32  gates=%d  outputs=32  non-output gates=%d" % (len(masks),len(G),n_nonout))
say("B = gates - ... : outputs(32) + non-output gates(%d) = %d gates" % (n_nonout, 32+n_nonout))
chk("outputs + non-output gates == gate count", 32+n_nonout==len(G))

say("")
say("ALL CHECKS PASSED" if ok_all else "*** SOME CHECK FAILED ***")
json.dump({"masks":masks,"outs":outs,"depth":dep,"rows":ROWS},
          open(REPO+"/referee_88/eval.json","w"))
open(REPO+"/referee_88/ref_check.log","w").write("\n".join(L)+"\n")
sys.exit(0 if ok_all else 1)
