/* k10.c -- k9.c with the ambient widened to 1024 masks (|K| <= 10), for the
 * |K| = 10 PRICING PROBE ONLY.  Generated from k9.c by widening NW to 16 and
 * the two arrays that scale with the ambient; the search is line-for-line the
 * same.  No bound in RESULT_K9.md rests on this file.
 *
 * original header follows
 * k9.c -- independent C implementation of the |K|=9 Theorem-B (minE) census
 * for AES InvMixColumns.  NEW/bounds/i6/k9/.
 *
 * WRITTEN FRESH for this task.  It shares no code with bounds/i6/{i6_core.py,
 * brute.c,verify_i6.py}; those were read (their semantics are the contract) but
 * every line here is new, the data layout is different (512-bit bitsets and an
 * incrementally maintained pairsum set, instead of Python sets / linear scans),
 * and the matrix is re-derived here from GF(2^8)/0x11B rather than loaded.
 *
 * MODEL (NEW/bounds/i6/README.md sec.1-3, referee/REFEREE_REPORT.md sec.1):
 *   V = the 32 rows of M restricted to K, re-indexed onto |K| = c coordinates
 *       (bit i of the restricted mask is column K[i], K sorted ascending).
 *   minE_K(V) = min |G \ V| over G realizable over the c inputs, elements
 *       pairwise distinct and of weight >= 2, V subset of G.
 *   realizable: G admits an order g_1..g_m with each g_i = a^b for a,b earlier
 *       (inputs always available).
 *
 * SEARCH.  Build-order iterative-deepening DFS.  State = set E of committed
 * extras; avail = closure of {inputs} u E under "adjoin any v in V that is the
 * XOR of two available masks"; candidates for the next extra = pairsums(avail)
 * \ avail.  Prunings P1 (greedy closure), P2 (last-level restriction) and P3
 * (memoisation on the extra SET) are the forward project's, re-proved in
 * PRUNING.md.  Orbit reduction under Aut(M_inv) = Z/4 is proved there too.
 *
 * KEY DATA STRUCTURE.  ps = { a^b : a != b in avail }, a 512-bit set kept
 * incrementally.  Then:
 *   - a target t is derivable  <=>  ps[t]  (t != 0, t not in avail);
 *   - the candidate set is exactly  ps & ~avail.
 * Both closure and branching therefore cost O(1) per element after the O(|avail|)
 * update that adding one mask costs.
 *
 * usage:
 *   k9 selftest
 *   k9 admis <outfile>                       enumerate admissible 9-sets
 *   k9 census <layerfile> <first> <count> <kmax> <nodecap> <outfile> [--canon]
 *   k9 sample <layerfile> <n> <seed> <outfile>
 *   k9 one <K> <kmax> <nodecap>              decide one keep-set, verbose
 *   k9 greedy <layerfile> <first> <count> <width> <outfile>   cheap-witness stage
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>

/* ---------------------------------------------------------------- GF(2^8) */
static int xtime_(int a){ a<<=1; return (a&0x100)? ((a^0x11B)&0xFF) : (a&0xFF); }
static int gfmul(int a,int b){ int r=0; for(int i=0;i<8;i++){ if((b>>i)&1){ int t=a; for(int k=0;k<i;k++) t=xtime_(t); r^=t; } } return r&0xFF; }

static uint32_t ROW[32];      /* row masks of M_inv, bit c = input column c */

static void build_matrix(void)
{
    static const int coef[4] = {14,11,13,9};
    int M[32][32];
    memset(M,0,sizeof M);
    for(int col=0;col<4;col++)
      for(int k=0;k<4;k++){
        int c=coef[k], ib=(col+k)&3;
        for(int in_bit=0;in_bit<8;in_bit++){
            int v=gfmul(c,1<<in_bit);
            for(int out_bit=0;out_bit<8;out_bit++)
                if((v>>out_bit)&1) M[col*8+out_bit][ib*8+in_bit]^=1;
        }
      }
    for(int r=0;r<32;r++){ uint32_t m=0; for(int c=0;c<32;c++) if(M[r][c]) m|=1u<<c; ROW[r]=m; }
}

/* ------------------------------------------------------- 512-bit bitsets  */
#ifndef NW
#define NW 16                      /* 1024 bits: c <= 10 */
#endif
typedef struct { uint64_t w[NW]; } bs;
#define BS_GET(s,x)  (((s).w[(x)>>6]>>((x)&63))&1ull)
#define BS_SET(s,x)  ((s).w[(x)>>6] |= 1ull<<((x)&63))

/* ---------------------------------------------------------- search state  */
typedef struct {
    int      c;                    /* number of inputs                       */
    uint32_t V[32];                /* the 32 restricted rows                 */
    /* mutable */
    bs       av, ps;
    uint32_t alist[NW*64+64]; int na;
    uint32_t todo[32];   int nt;
    long long nodes;
    uint32_t wit[8]; int witlen;
    long long cap;                 /* node cap, <0 = none                    */
    int hit_cap;
} St;

/* add mask x to avail, updating ps = {a^b : a!=b in avail} */
static inline void add_avail(St *s, uint32_t x)
{
    for(int i=0;i<s->na;i++){ uint32_t y = x ^ s->alist[i]; BS_SET(s->ps, y); }
    s->alist[s->na++] = x;
    BS_SET(s->av, x);
}

/* greedy maximal closure over the still-undone targets (P1) */
static inline void closure(St *s)
{
    int changed = 1;
    while(changed && s->nt){
        changed = 0;
        for(int i=0;i<s->nt;i++){
            uint32_t t = s->todo[i];
            if(BS_GET(s->ps,t)){                 /* t = a^b, a!=b in avail   */
                add_avail(s,t);
                s->todo[i] = s->todo[--s->nt];
                i--; changed = 1;
            }
        }
    }
}

/* ------------------------------------------------------------ memo (P3)   */
#define MEMO_BITS 20
#define MEMO_SZ  (1u<<MEMO_BITS)
static uint64_t *memo_key; static uint32_t *memo_gen; static uint32_t memo_cur = 0;
static void memo_init(void){ memo_key=calloc(MEMO_SZ,8); memo_gen=calloc(MEMO_SZ,4); }
static void memo_new_gen(void){ if(++memo_cur==0){ memset(memo_gen,0,4*(size_t)MEMO_SZ); memo_cur=1; } }
static int memo_seen(uint64_t k)   /* returns 1 if already present, else inserts */
{
    uint64_t h = k*0x9E3779B97F4A7C15ull; h ^= h>>29; h *= 0xBF58476D1CE4E5B9ull; h ^= h>>32;
    uint32_t i = (uint32_t)(h & (MEMO_SZ-1));
    for(int probe=0; probe<8; probe++){
        uint32_t j = (i+probe) & (MEMO_SZ-1);
        if(memo_gen[j]!=memo_cur){ memo_gen[j]=memo_cur; memo_key[j]=k; return 0; }
        if(memo_key[j]==k) return 1;
    }
    return 0;                                   /* table full here: no prune  */
}
/* canonical key of a committed extra set: sorted 10-bit fields (c<=9 -> <512) */
static uint64_t ekey(const uint32_t *e,int n)
{
    uint32_t t[8]; for(int i=0;i<n;i++) t[i]=e[i];
    for(int i=1;i<n;i++){ uint32_t v=t[i]; int j=i-1; while(j>=0&&t[j]>v){t[j+1]=t[j];j--;} t[j+1]=v; }
    uint64_t k=0; for(int i=0;i<n;i++) k = (k<<10) | t[i];
    return k | (1ull<<(10*n));
}

/* --------------------------------------------------------------- the DFS  */
/* returns 1 if a completion using <= budget further extras exists.          */
static int rec(St *s, uint32_t *ext, int nex, int budget)
{
    s->nodes++;
    if(s->cap>=0 && s->nodes>s->cap){ s->hit_cap=1; return 0; }

    bs sav_av = s->av, sav_ps = s->ps;
    int  sna = s->na, snt = s->nt;
    uint32_t stodo[32]; memcpy(stodo,s->todo,sizeof(uint32_t)*s->nt);

    closure(s);
    if(s->nt==0){ s->witlen = nex; return 1; }
    if(budget==0) goto fail;

    /* ekey packs sorted masks into 10-bit fields plus a length tag; injective
     * only while 10*nex + 10 <= 64, i.e. nex <= 5 at c <= 10.  Beyond that we
     * simply decline to memoise (costs time, never soundness). */
    if(nex>0 && nex<=5){ if(memo_seen(ekey(ext,nex))) goto fail; }

    {
      bs cand;
      for(int w=0;w<NW;w++) cand.w[w] = s->ps.w[w] & ~s->av.w[w];
      if(budget==1){                           /* P2: last-level restriction */
        bs en; memset(&en,0,sizeof en);
        for(int i=0;i<s->nt;i++){ uint32_t v=s->todo[i];
            for(int j=0;j<s->na;j++) BS_SET(en, v ^ s->alist[j]); }
        for(int w=0;w<NW;w++) cand.w[w] &= en.w[w];
      }
      for(int w=0;w<NW;w++){
        uint64_t m = cand.w[w];
        while(m){
            int b = __builtin_ctzll(m); m &= m-1;
            uint32_t e = (uint32_t)(w*64+b);
            /* commit e; it is a pairsum of two available masks, hence legal   */
            bs kav=s->av, kps=s->ps; int kna=s->na, knt=s->nt;
            uint32_t ktodo[32]; memcpy(ktodo,s->todo,sizeof(uint32_t)*s->nt);
            add_avail(s,e);
            ext[nex]=e;
            if(rec(s,ext,nex+1,budget-1)){ s->wit[nex]=e; return 1; }
            s->av=kav; s->ps=kps; s->na=kna; s->nt=knt;
            memcpy(s->todo,ktodo,sizeof(uint32_t)*knt);
            if(s->hit_cap) goto fail;
        }
      }
    }
fail:
    s->av=sav_av; s->ps=sav_ps; s->na=sna; s->nt=snt;
    memcpy(s->todo,stodo,sizeof(uint32_t)*snt);
    return 0;
}

static void st_reset(St *s)
{
    memset(&s->av,0,sizeof s->av); memset(&s->ps,0,sizeof s->ps);
    s->na=0; s->nt=0; s->hit_cap=0;
    for(int i=0;i<s->c;i++) add_avail(s,1u<<i);
    for(int i=0;i<32;i++) s->todo[s->nt++] = s->V[i];
    /* targets equal to an input cannot occur (weight >= 2 is checked) */
}

/* jam of the free closure */
static int jam_of(St *s)
{
    st_reset(s); closure(s); return s->nt;
}

/* iterative deepening; returns minE if <= kmax, else kmax+1 (proved) or -1
 * if a node cap was hit (undecided). */
static int decide(St *s, int kmax, long long cap, long long *nodes_out, uint32_t *wit, int *witlen)
{
    uint32_t ext[8];
    s->nodes = 0;
    for(int b=0;b<=kmax;b++){
        memo_new_gen();
        st_reset(s); s->cap = cap; s->hit_cap = 0; s->witlen=-1;
        if(rec(s,ext,0,b)){
            *nodes_out = s->nodes; *witlen = s->witlen;
            for(int i=0;i<s->witlen;i++) wit[i]=s->wit[i];
            return b;
        }
        if(s->hit_cap){ *nodes_out = s->nodes; *witlen=-1; return -1; }
    }
    *nodes_out = s->nodes; *witlen=-1;
    return kmax+1;
}

/* ------------------------------ cheap witness stage: greedy beam, width w */
/* Proved-sound ONLY as an upper bound: it either returns an explicit witness
 * (certificate of minE <= |E|) or gives up.  Never used to conclude minE >= e. */
typedef struct { bs av, ps; uint32_t alist[NW*64+64]; int na; uint32_t todo[32]; int nt;
                 uint32_t ext[8]; int nex; } Beam;

static int greedy_witness(St *s, int width, int depth, uint32_t *wit, int *witlen, long long *work)
{
    static Beam cur[64], nxt[64];
    int ncur=1;
    st_reset(s); closure(s);
    cur[0].av=s->av; cur[0].ps=s->ps; cur[0].na=s->na; cur[0].nt=s->nt;
    memcpy(cur[0].alist,s->alist,sizeof(uint32_t)*s->na);
    memcpy(cur[0].todo,s->todo,sizeof(uint32_t)*s->nt);
    cur[0].nex=0;
    if(s->nt==0){ *witlen=0; return 1; }
    for(int d=1; d<=depth; d++){
        int nn=0; int bestscore[64];
        for(int q=0;q<ncur;q++){
            bs cand; for(int w=0;w<NW;w++) cand.w[w]=cur[q].ps.w[w] & ~cur[q].av.w[w];
            for(int w=0;w<NW;w++){
                uint64_t m=cand.w[w];
                while(m){ int b=__builtin_ctzll(m); m&=m-1;
                    uint32_t e=(uint32_t)(w*64+b);
                    s->av=cur[q].av; s->ps=cur[q].ps; s->na=cur[q].na; s->nt=cur[q].nt;
                    memcpy(s->alist,cur[q].alist,sizeof(uint32_t)*s->na);
                    memcpy(s->todo,cur[q].todo,sizeof(uint32_t)*s->nt);
                    add_avail(s,e); closure(s); (*work)++;
                    if(s->nt==0){ for(int i=0;i<cur[q].nex;i++) wit[i]=cur[q].ext[i];
                                  wit[cur[q].nex]=e; *witlen=cur[q].nex+1; return 1; }
                    int sc = s->nt;                  /* fewer todo is better */
                    if(nn<width){
                        nxt[nn].av=s->av; nxt[nn].ps=s->ps; nxt[nn].na=s->na; nxt[nn].nt=s->nt;
                        memcpy(nxt[nn].alist,s->alist,sizeof(uint32_t)*s->na);
                        memcpy(nxt[nn].todo,s->todo,sizeof(uint32_t)*s->nt);
                        memcpy(nxt[nn].ext,cur[q].ext,sizeof(uint32_t)*cur[q].nex);
                        nxt[nn].ext[cur[q].nex]=e; nxt[nn].nex=cur[q].nex+1;
                        bestscore[nn]=sc; nn++;
                    } else {
                        int worst=0; for(int i=1;i<nn;i++) if(bestscore[i]>bestscore[worst]) worst=i;
                        if(sc<bestscore[worst]){
                            nxt[worst].av=s->av; nxt[worst].ps=s->ps; nxt[worst].na=s->na; nxt[worst].nt=s->nt;
                            memcpy(nxt[worst].alist,s->alist,sizeof(uint32_t)*s->na);
                            memcpy(nxt[worst].todo,s->todo,sizeof(uint32_t)*s->nt);
                            memcpy(nxt[worst].ext,cur[q].ext,sizeof(uint32_t)*cur[q].nex);
                            nxt[worst].ext[cur[q].nex]=e; nxt[worst].nex=cur[q].nex+1;
                            bestscore[worst]=sc;
                        }
                    }
                }
            }
        }
        if(nn==0) return 0;
        memcpy(cur,nxt,sizeof(Beam)*nn); ncur=nn;
    }
    return 0;
}

/* --------------------------------------------------------- keep-set logic */
static int restrict_rows(const int *K,int c,uint32_t *V)
{
    for(int r=0;r<32;r++){ uint32_t m=0;
        for(int i=0;i<c;i++) if((ROW[r]>>K[i])&1) m|=1u<<i;
        V[r]=m; }
    /* weight >= 2 and pairwise distinct */
    for(int r=0;r<32;r++) if(__builtin_popcount(V[r])<2) return 0;
    unsigned char seen[NW*64]; memset(seen,0,sizeof seen);
    for(int r=0;r<32;r++){ if(seen[V[r]]) return 0; seen[V[r]]=1; }
    return 1;
}
/* every column of M outside K is nonzero */
static int cols_outside_nonzero(const int *K,int c)
{
    uint32_t inK=0; for(int i=0;i<c;i++) inK|=1u<<K[i];
    for(int col=0;col<32;col++){
        if((inK>>col)&1) continue;
        uint32_t cm=0; for(int r=0;r<32;r++) if((ROW[r]>>col)&1) cm|=1u<<r;
        if(!cm) return 0;
    }
    return 1;
}
static uint32_t rot_set(uint32_t km,int s)
{
    uint32_t o=0;
    for(int c=0;c<32;c++) if((km>>c)&1){ int b=c>>3, i=c&7; o |= 1u<<(8*((b+s)&3)+i); }
    return o;
}
static int is_canonical(uint32_t km)
{
    for(int s=1;s<4;s++) if(rot_set(km,s) < km) return 0;
    return 1;
}

/* ---------------------------------------------------------------- helpers */
static double cpusec(void){ struct timespec t; clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&t); return t.tv_sec+1e-9*t.tv_nsec; }
static int parseK(const char *s,int *K){ int n=0; const char*p=s;
    while(*p && n<16){ while(*p==' '||*p=='\t') p++;
        if(*p<'0'||*p>'9') break;
        K[n++]=(int)strtol(p,(char**)&p,10);
        while(*p==' '||*p=='\t') p++;
        if(*p==',') p++; else break; }
    return n; }

/* recursive admissible enumeration */
static FILE *AF; static long long ACOUNT=0;
static void admis_rec(int start,int depth,int *K,int c)
{
    if(depth==c){
        uint32_t V[32];
        if(!restrict_rows(K,c,V)) return;
        uint32_t km=0; for(int i=0;i<c;i++) km|=1u<<K[i];
        if(!cols_outside_nonzero(K,c)) return;
        ACOUNT++;
        for(int i=0;i<c;i++) fprintf(AF,"%d%c",K[i], i==c-1?'\n':',');
        return;
    }
    for(int x=start;x<32-(c-depth-1);x++){ K[depth]=x; admis_rec(x+1,depth+1,K,c); }
}

/* splitmix64 */
static uint64_t sm_s;
static uint64_t sm64(void){ uint64_t z=(sm_s+=0x9E3779B97F4A7C15ull); z=(z^(z>>30))*0xBF58476D1CE4E5B9ull; z=(z^(z>>27))*0x94D049BB133111EBull; return z^(z>>31); }

int main(int argc,char**argv)
{
    build_matrix();
    memo_init();
    if(argc<2){ fprintf(stderr,"usage: see header\n"); return 2; }

    if(!strcmp(argv[1],"selftest")){
        for(int r=0;r<32;r++) printf("%08x\n",ROW[r]);
        return 0;
    }
    if(!strcmp(argv[1],"admis")){
        AF=fopen(argv[2],"w"); int K[16];
        double t0=cpusec(); admis_rec(0,0,K,atoi(argc>3?argv[3]:"9")); double t1=cpusec();
        fclose(AF);
        printf("admissible_9sets=%lld cpu=%.2f\n",ACOUNT,t1-t0);
        return 0;
    }

    /* modes that read a layer file */
    if(!strcmp(argv[1],"one")){
        int K[16]; int c=parseK(argv[2],K);
        int kmax=atoi(argv[3]); long long cap=atoll(argv[4]);
        St s; s.c=c;
        if(!restrict_rows(K,c,s.V)){ printf("NOT ADMISSIBLE (rows)\n"); return 3; }
        if(!cols_outside_nonzero(K,c)){ printf("NOT ADMISSIBLE (cols)\n"); return 3; }
        printf("V="); for(int i=0;i<32;i++) printf("%u%c",s.V[i],i==31?'\n':',');
        int jam=jam_of(&s);
        long long nodes; uint32_t wit[8]; int wl;
        double t0=cpusec();
        int r=decide(&s,kmax,cap,&nodes,wit,&wl);
        double t1=cpusec();
        printf("c=%d jam=%d minE=%d nodes=%lld cpu=%.4f",c,jam,r,nodes,t1-t0);
        if(wl>=0){ printf(" witness="); for(int i=0;i<wl;i++) printf("%u%s",wit[i],i==wl-1?"":" "); }
        printf("\n");
        return 0;
    }

    if(!strcmp(argv[1],"census") || !strcmp(argv[1],"greedy") || !strcmp(argv[1],"sample")){
        FILE *lf=fopen(argv[2],"r");
        if(!lf){ perror("layer"); return 2; }
        static int (*LAY)[9]; static long long NLAY=0;
        LAY=malloc(sizeof(int)*9*1100000);
        char line[256];
        while(fgets(line,sizeof line,lf)){
            int K[16]; int c=parseK(line,K); if(c!=9) continue;
            for(int i=0;i<9;i++) LAY[NLAY][i]=K[i];
            NLAY++;
        }
        fclose(lf);
        fprintf(stderr,"layer size %lld\n",NLAY);

        if(!strcmp(argv[1],"sample")){
            long long n=atoll(argv[3]); sm_s=strtoull(argv[4],0,10);
            FILE *o=fopen(argv[5],"w");
            unsigned char *used=calloc(NLAY,1); long long got=0;
            while(got<n){ long long i=(long long)(sm64()%(uint64_t)NLAY);
                if(used[i]) continue; used[i]=1; got++;
                for(int j=0;j<9;j++) fprintf(o,"%d%c",LAY[i][j], j==8?'\n':',');
            }
            fclose(o); printf("sampled=%lld from=%lld seed=%s\n",got,NLAY,argv[4]);
            return 0;
        }

        long long first=atoll(argv[3]), count=atoll(argv[4]);
        if(count<0 || first+count>NLAY) count = NLAY-first;

        if(!strcmp(argv[1],"greedy")){
            int width=atoi(argv[5]); FILE *o=fopen(argv[6],"w");
            long long found=0,tot=0; double t0=cpusec(); long long work=0;
            for(long long idx=first; idx<first+count; idx++){
                St s; s.c=9; s.cap=-1;
                if(!restrict_rows(LAY[idx],9,s.V)) continue;
                uint32_t wit[8]; int wl=-1; tot++;
                int ok=greedy_witness(&s,width,4,wit,&wl,&work);
                if(ok) found++;
                fprintf(o,"%lld %d %d",idx,ok,wl);
                for(int i=0;i<(ok?wl:0);i++) fprintf(o," %u",wit[i]);
                fprintf(o,"\n");
            }
            double t1=cpusec(); fclose(o);
            printf("greedy width=%d sets=%lld witnessed=%lld frac=%.6f closures=%lld cpu=%.3f\n",
                   width,tot,found,(double)found/(double)tot,work,t1-t0);
            return 0;
        }

        /* census */
        int kmax=atoi(argv[5]); long long cap=atoll(argv[6]);
        int canon = (argc>8 && !strcmp(argv[8],"--canon"));
        /* resume: count lines already in outfile */
        long long done=0; FILE *chk=fopen(argv[7],"r");
        if(chk){ int ch; long long nl=0; while((ch=fgetc(chk))!=EOF) if(ch=='\n') nl++; fclose(chk); done=nl; }
        FILE *o=fopen(argv[7],"a");
        long long hist[8]; memset(hist,0,sizeof hist); long long undecided=0, seen=0, totnodes=0;
        double t0=cpusec();
        for(long long idx=first; idx<first+count; idx++){
            if(canon){ uint32_t km=0; for(int i=0;i<9;i++) km|=1u<<LAY[idx][i];
                       if(!is_canonical(km)) continue; }
            seen++;
            if(seen<=done) continue;               /* resume */
            St s; s.c=9;
            if(!restrict_rows(LAY[idx],9,s.V)){ fprintf(o,"%lld INADMISSIBLE\n",idx); continue; }
            long long nodes; uint32_t wit[8]; int wl;
            double a=cpusec();
            int jam=jam_of(&s);
            int r=decide(&s,kmax,cap,&nodes,wit,&wl);
            double b=cpusec();
            totnodes+=nodes;
            if(r<0) undecided++; else hist[r<8?r:7]++;
            fprintf(o,"%lld ",idx);
            for(int i=0;i<9;i++) fprintf(o,"%d%c",LAY[idx][i], i==8?' ':',');
            fprintf(o,"%d %d %lld %.6f",jam,r,nodes,b-a);
            if(wl>0){ fprintf(o," W"); for(int i=0;i<wl;i++) fprintf(o," %u",wit[i]); }
            fprintf(o,"\n");
            if((seen & 1023)==0) fflush(o);
        }
        double t1=cpusec(); fflush(o); fclose(o);
        printf("census first=%lld count=%lld canon=%d decided=%lld undecided=%lld nodes=%lld cpu=%.3f hist=",
               first,count,canon,seen-done-undecided,undecided,totnodes,t1-t0);
        for(int i=0;i<8;i++) printf("%lld%c",hist[i], i==7?'\n':',');
        return 0;
    }
    fprintf(stderr,"unknown mode\n"); return 2;
}
