/* maxq.c -- solver-free exhaustive ceiling for the I5 / Theorem-A bound.
 *
 * Enumerates EVERY subset K of the 32 columns with |K| <= kmax and evaluates
 *      q(M|_K) = # DISTINCT rows of M restricted to K that have weight >= 2
 * reporting, per size, max q, the argmax, and the count of ADMISSIBLE sets
 * (q == 32, i.e. Theorem-A certificates).
 *
 * Theorem A gives L(M) >= (32-|K|) + 32 from an admissible K, and the
 * generalised form of the bound is (32-|K|) + q.  Since q <= 32 always,
 * (32-|K|) + q <= 64 - |K|, so once a certificate of size k0 is in hand only
 * the sizes |K| < k0 can possibly beat it -- which is exactly what this program
 * enumerates.  No solver, no LP, no trust in anything else in this directory.
 *
 * This is the analogue of the referee's `maxq.c` described in
 *   OLD/beat88/understanding/u3_lowerbound/NOTEBOOK.md sec.3 and
 *   OLD/wrapup/METHOD_CATALOG.md entry I5
 * ("all 462,411,532 subsets of [32] of size <= 12 enumerated in C").  That file
 * was not banked in OLD, so this is a fresh implementation of the same object.
 * OLD = ~/xor_ui/slp-plateau-search (read-only).
 *
 * Build:  gcc -O2 -o maxq maxq.c
 * Run  :  ./maxq <kmax> <32 comma-separated row masks>  [dump_size dump_file]
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

static uint32_t colmask[32];      /* colmask[c] bit r = M[r][c] */
static int KMAX;
static uint16_t vals[33][32];
static uint8_t  wts[33][32];
static int stack_col[33];

static uint32_t seen[1 << 13];
static uint32_t stamp = 0;

static int    best_q[33];
static int    best_K[33][33];
static long long nsub[33];
static long long nadm[33];

static int dump_size = -1;
static FILE *dumpf = NULL;
static long long ndump = 0;

static void visit(int d)
{
    int q = 0;
    uint16_t *V = vals[d];
    uint8_t  *W = wts[d];
    stamp++;
    for (int r = 0; r < 32; r++) {
        if (W[r] < 2) continue;
        uint16_t v = V[r];
        if (seen[v] != stamp) { seen[v] = stamp; q++; }
    }
    nsub[d]++;
    if (q == 32) {
        nadm[d]++;
        if (d == dump_size && dumpf) {
            for (int i = 0; i < d; i++) fprintf(dumpf, "%d%c", stack_col[i], i + 1 == d ? '\n' : ',');
            ndump++;
        }
    }
    if (q > best_q[d]) {
        best_q[d] = q;
        for (int i = 0; i < d; i++) best_K[d][i] = stack_col[i];
    }
}

static void dfs(int start, int d)
{
    visit(d);
    if (d == KMAX) return;
    for (int c = start; c < 32; c++) {
        memcpy(vals[d + 1], vals[d], sizeof(vals[0]));
        memcpy(wts[d + 1], wts[d], sizeof(wts[0]));
        uint32_t m = colmask[c];
        while (m) {
            int r = __builtin_ctz(m);
            m &= m - 1;
            vals[d + 1][r] |= (uint16_t)(1u << d);
            wts[d + 1][r]++;
        }
        stack_col[d] = c;
        dfs(c + 1, d + 1);
    }
}

int main(int argc, char **argv)
{
    if (argc < 3) { fprintf(stderr, "usage: %s kmax rowmasks[,..] [dump_size dump_file]\n", argv[0]); return 2; }
    KMAX = atoi(argv[1]);
    if (KMAX < 0 || KMAX > 13) { fprintf(stderr, "kmax must be 0..13 (value bitmap is 2^13)\n"); return 2; }
    uint32_t R[32];
    {
        char *s = strdup(argv[2]), *p = strtok(s, ",");
        int n = 0;
        while (p && n < 32) { R[n++] = (uint32_t)strtoul(p, NULL, 0); p = strtok(NULL, ","); }
        if (n != 32) { fprintf(stderr, "need exactly 32 row masks, got %d\n", n); return 2; }
    }
    if (argc >= 5) { dump_size = atoi(argv[3]); dumpf = fopen(argv[4], "w"); }

    for (int c = 0; c < 32; c++) {
        uint32_t m = 0;
        for (int r = 0; r < 32; r++) if ((R[r] >> c) & 1u) m |= 1u << r;
        colmask[c] = m;
    }
    for (int i = 0; i <= 32; i++) best_q[i] = -1;
    memset(vals[0], 0, sizeof(vals[0]));
    memset(wts[0], 0, sizeof(wts[0]));

    dfs(0, 0);

    long long tot = 0, totadm = 0;
    printf("# maxq: exhaustive over all subsets of [32] of size <= %d\n", KMAX);
    printf("# size   subsets        max_q  bound=(32-k)+q   admissible(q=32)   argmax_K\n");
    int overall = -1, overall_k = -1;
    for (int k = 0; k <= KMAX; k++) {
        tot += nsub[k]; totadm += nadm[k];
        int b = (32 - k) + best_q[k];
        if (b > overall) { overall = b; overall_k = k; }
        printf("%6d %12lld %8d %12d %14lld   ", k, nsub[k], best_q[k], b, nadm[k]);
        for (int i = 0; i < k; i++) printf("%d%s", best_K[k][i], i + 1 == k ? "" : ",");
        printf("\n");
    }
    printf("# total subsets enumerated (sizes 0..%d): %lld\n", KMAX, tot);
    printf("# total admissible (q=32) sets found    : %lld\n", totadm);
    printf("# MAX over enumerated sizes: (32-k)+q = %d at k = %d\n", overall, overall_k);
    if (dumpf) { fclose(dumpf); printf("# dumped %lld admissible sets of size %d\n", ndump, dump_size); }
    return 0;
}
