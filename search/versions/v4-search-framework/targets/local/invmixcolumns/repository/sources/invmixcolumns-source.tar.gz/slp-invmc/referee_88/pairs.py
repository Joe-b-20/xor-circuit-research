import json,itertools,random,time,sys
src=open('~/xor_ui/slp-invmc/referee_88/shrink.py').read()
ns={}; exec(src[:src.index('HTRIES=')],ns)
setup=ns['setup']; closure=ns['closure']; exact_slack=ns['exact_slack']; heuristic=ns['heuristic']
masks=ns['masks']; G=ns['G']
rng=random.Random(2026); t0=time.time()
slackhist={}; found=[]; best_margin=[]
for i,j in itertools.combinations(range(88),2):
    a,b=32+i,32+j
    R,A,T=setup([a,b]); budget=len(R)-1; slack=budget-len(T)
    slackhist[min(slack,9)]=slackhist.get(min(slack,9),0)+1
    if slack<0: continue
    if slack<=1:
        ok,c=exact_slack(A,T,slack)
        if ok: found.append((a,b,c,'exact'))
        continue
    oo=[(masks[k],masks[G[k-32][0]],masks[G[k-32][1]]) for k in sorted(R)]
    h=heuristic(A,T,budget,rng,3,oo)
    if h is not None:
        best_margin.append((h-budget,a,b,h,budget))
        if h<=budget: found.append((a,b,h,'heuristic'))
print("slack histogram (9 = >=9):",dict(sorted(slackhist.items())))
print("pairs where the heuristic completed within/near budget:",len(best_margin))
best_margin.sort()
print("10 best (cost-budget, gates removed, cost, budget):",best_margin[:10])
print("PAIR SHRINKS:",found if found else "none")
print("elapsed %.1fs"%(time.time()-t0))
