#!/usr/bin/env python3
"""one_level.py WHICH J K [DEPTH] -- one SAT/UNSAT decision at exactly K gates
for the record-free sector block of blocks.py, using an UNMODIFIED copy of
fleet8/unified/code/dslp.py (dslp_ref.py, sha256 e2ca2ea2...).

Prints one JSON line with CNF size, CPU seconds split into build and solve, and
the verdict.  Run it under `timeout` so a hopeless level is bounded.
"""
import json, os, resource, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import dslp_ref as D
from blocks import block


def cpu():
    r = resource.getrusage(resource.RUSAGE_SELF)
    return r.ru_utime + r.ru_stime


def main():
    which, j, k = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    depth = int(sys.argv[4]) if len(sys.argv) > 4 and sys.argv[4] != 'None' else None
    b = block(which, j)
    r, iv, tv = b['r'], b['inputs'], b['targets']
    lv = [0] * len(iv)
    out = dict(which=which, j=j, lines=b['lines'], r=r, m=len(iv), T=len(tv),
               k=k, depth=depth)
    c0 = cpu(); t0 = time.monotonic()
    cnf, V, Z, A = D.build_cnf(r, iv, tv, k, depth, lv, True, None)
    out['build_cpu'] = round(cpu() - c0, 2)
    out['nv'] = cnf.nv
    out['nclauses'] = len(cnf.clauses)
    c1 = cpu()
    with D._PysatSolver(name=D.DEFAULT_SOLVER, bootstrap_with=cnf.clauses) as S:
        sat = S.solve()
    out['solve_cpu'] = round(cpu() - c1, 2)
    out['total_cpu'] = round(cpu() - c0, 2)
    out['wall'] = round(time.monotonic() - t0, 2)
    out['maxrss_mb'] = round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024, 1)
    out['result'] = 'SAT' if sat else 'UNSAT'
    print(json.dumps(out), flush=True)


if __name__ == '__main__':
    main()
