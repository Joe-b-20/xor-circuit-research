#!/usr/bin/env python3
"""
invmc_core.py  --  shared math + verification for the record hunter.

Port of slp-plateau-search/pipeline/mixcolumns_core.py to AES InvMixColumns.
Same file shape, same public names; four things differ and each is deliberate:

  1. coef = [0x0e, 0x0b, 0x0d, 0x09]   (InvMixColumns, FIPS-197 5.3.3)
  2. the two MixColumns weight-profile asserts (.count(5)==20, .count(7)==12)
     are GONE.  The inverse profile is {11:8, 13:8, 15:4, 17:4, 19:8}, checked
     below.
  3. the mask list is checked AGAINST THE SPEC FILE (spec/invmc_target_masks.json),
     loaded from disk -- the spec is verified here, not trusted.
  4. the matrix is built by the ORACLE's own routine, copied verbatim from
     tools/verify_slp_generic.py:build_circulant_matrix, so the built-in
     verifier and the ground-truth oracle cannot drift apart in convention:
     out row 8*out_byte+out_bit, in col 8*in_byte+in_bit, LSB-first inside a
     byte, mask bit c = input index c.

Pure fact, no tuning knobs: the spec, a few bit helpers, the in-process
verifier, a SUBPROCESS call to the generic oracle (the thing that actually
decides), a dead-gate strip (R8), and two utilities the hunter needs --
loading a seed circuit into a value-set, and building a from-scratch start.

Circuit format everywhere: a list of index pairs `gates = [[a, b], ...]` where
signals 0..31 are the inputs x0..x31 (signal i = mask 1<<i) and gate k produces
signal 32+k whose mask = sig[a] ^ sig[b].

MINIMUM DEPTH IS 5, not 3.  The heaviest target row has weight 19, so no
circuit for this matrix can be shallower than ceil(log2 19) = 5 and every
depth cap below MIN_DEPTH is infeasible by arithmetic, not by search.
"""
import json
import os
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
SPEC_MASKS = os.path.join(REPO, "spec", "invmc_target_masks.json")
SPEC_MATRIX = os.path.join(REPO, "spec", "invmc_matrix.json")
ORACLE = os.path.join(REPO, "tools", "verify_slp_generic.py")

MODULUS = 0x11B
COEF = [0x0e, 0x0b, 0x0d, 0x09]

# --------------------------------------------------------------------------
# AES InvMixColumns spec from GF(2^8).
# --------------------------------------------------------------------------
def _xtime(a, modulus=MODULUS):
    a <<= 1
    return (a ^ modulus) & 0xFF if (a & 0x100) else (a & 0xFF)


def _gf_mul(a, b, modulus=MODULUS):
    r = 0
    for i in range(8):
        if (b >> i) & 1:
            t = a
            for _ in range(i):
                t = _xtime(t, modulus)
            r ^= t
    return r & 0xFF


def _build_circulant_matrix(coef, modulus):
    """VERBATIM from tools/verify_slp_generic.py:build_circulant_matrix --
    the oracle's convention, so the in-process verifier and the oracle agree
    by construction: out row 8*col+out_bit, in col 8*ib+in_bit, LSB-first
    inside each byte, out_byte[col] = XOR_k coef[k]*in_byte[(col+k)%4]."""
    M = [[0] * 32 for _ in range(32)]
    for col in range(4):
        for k in range(4):
            c, ib = coef[k], (col + k) % 4
            for in_bit in range(8):
                v = _gf_mul(c, 1 << in_bit, modulus)
                for out_bit in range(8):
                    if (v >> out_bit) & 1:
                        M[col * 8 + out_bit][ib * 8 + in_bit] ^= 1
    return M


def invmixcolumns_masks():
    M = _build_circulant_matrix(COEF, MODULUS)
    return [sum(1 << c for c in range(32) if M[r][c]) for r in range(32)]


TARGETS = invmixcolumns_masks()
TARGET_SET = frozenset(TARGETS)
INPUTS = [1 << i for i in range(32)]
INPUT_SET = frozenset(INPUTS)

# ---- the inverse weight profile, and the spec file it must agree with -----
WEIGHT_PROFILE = {11: 8, 13: 8, 15: 4, 17: 4, 19: 8}
_prof = {}
for _m in TARGETS:
    _w = bin(_m).count("1")
    _prof[_w] = _prof.get(_w, 0) + 1
assert _prof == WEIGHT_PROFILE, \
    "InvMixColumns weight profile is %r, expected %r" % (_prof, WEIGHT_PROFILE)
assert len(TARGET_SET) == 32, "target masks are not distinct"

with open(SPEC_MASKS) as _f:
    _spec = json.load(_f)
assert [int(x) for x in _spec["target_masks"]] == TARGETS, (
    "spec file %s disagrees with the from-scratch GF(2^8) derivation in this "
    "file -- one of the two is wrong; do not run anything until it is chased "
    "to ground" % SPEC_MASKS)
assert _spec["provenance"]["mds_column"] == COEF, \
    "spec file mds_column %r != COEF %r" % (_spec["provenance"]["mds_column"], COEF)
assert int(_spec["provenance"]["modulus"]) == MODULUS

# ceil(log2(max row weight)) = the arithmetic floor on this matrix's depth.
MAX_TARGET_WEIGHT = max(bin(m).count("1") for m in TARGETS)      # 19
MIN_DEPTH = (MAX_TARGET_WEIGHT - 1).bit_length()                 # 5
assert MIN_DEPTH == 5


def bits_of(m):
    return [b for b in range(32) if (m >> b) & 1]


def wt(m):
    return bin(m).count("1")


# --------------------------------------------------------------------------
# The in-process verifier.  (The ORACLE below is what decides; this is the
# cheap gate that runs on every candidate.)
# --------------------------------------------------------------------------
def verify(gates, max_depth=None):
    """Replay an index-pair circuit; check every gate references earlier
    signals, all 32 outputs are produced, and (if given) depth <= max_depth.
    Returns {gates, depth, outputs, ok, problems}."""
    sig = [1 << i for i in range(32)]
    depth = [0] * 32
    problems = []
    for k, g in enumerate(gates):
        if len(g) != 2:
            problems.append("gate %d not 2-input" % k)
            sig.append(0); depth.append(0); continue
        a, b = g
        idx = 32 + k
        if not (0 <= a < idx and 0 <= b < idx):
            problems.append("gate %d references non-earlier signal" % k)
            sig.append(0); depth.append(0); continue
        sig.append(sig[a] ^ sig[b])
        depth.append(max(depth[a], depth[b]) + 1)
    built = set(sig)
    outputs = sum(1 for t in TARGETS if t in built)
    D = max(depth) if depth else 0
    ok = outputs == 32 and not problems and (max_depth is None or D <= max_depth)
    return {"gates": len(gates), "depth": D, "outputs": outputs,
            "ok": ok, "problems": problems}


# --------------------------------------------------------------------------
# R8: dead-gate strip.  No count is ever quoted before this runs.
# --------------------------------------------------------------------------
def strip_dead(gates):
    """Drop every gate no target output transitively depends on, and renumber.
    Returns a new index-pair list.  If the circuit does not build all 32
    targets it is returned unchanged -- verify() is what rejects it."""
    sig = [1 << i for i in range(32)]
    for g in gates:
        if len(g) != 2:
            return list(gates)
        a, b = g
        if not (0 <= a < len(sig) and 0 <= b < len(sig)):
            return list(gates)
        sig.append(sig[a] ^ sig[b])
    first = {}
    for i, m in enumerate(sig):
        if m in TARGET_SET and m not in first:
            first[m] = i
    if len(first) != 32:
        return list(gates)
    keep = set()
    stack = [first[t] for t in TARGETS]
    while stack:
        i = stack.pop()
        if i < 32 or i in keep:
            continue
        keep.add(i)
        a, b = gates[i - 32]
        stack.append(a); stack.append(b)
    newidx = {i: i for i in range(32)}
    out = []
    for i in range(32, len(sig)):
        if i in keep:
            a, b = gates[i - 32]
            out.append([newidx[a], newidx[b]])
            newidx[i] = 32 + len(out) - 1
    return out


# --------------------------------------------------------------------------
# The ORACLE.  A subprocess call to tools/verify_slp_generic.py, which shares
# no code with the engines and re-derives the target from GF(2^8) itself.
# Nothing is ever written as a "best" without this printing VALID.
# --------------------------------------------------------------------------
def oracle_cmd(path, max_depth=None):
    cmd = [sys.executable, ORACLE, "--target", SPEC_MATRIX, path]
    if max_depth is not None:
        cmd.append(str(max_depth))
    return cmd


def oracle_verify(gates_or_path, max_depth=None, timeout=120):
    """Run the generic oracle on a circuit.  Accepts a path or a gate list
    (which is written to a temp file).  Returns (ok, stdout, cmd_string)."""
    tmp = None
    try:
        if isinstance(gates_or_path, str):
            path = gates_or_path
        else:
            fd, tmp = tempfile.mkstemp(suffix=".json", prefix="oracle_")
            with os.fdopen(fd, "w") as f:
                json.dump({"gateCount": len(gates_or_path),
                           "gates": gates_or_path}, f)
            path = tmp
        cmd = oracle_cmd(path, max_depth)
        try:
            p = subprocess.run(cmd, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, timeout=timeout)
            out = p.stdout.decode("utf-8", "replace")
            return p.returncode == 0, out, " ".join(cmd)
        except Exception as e:                       # oracle unreachable = FAIL
            return False, "oracle call failed: %r" % (e,), " ".join(cmd)
    finally:
        if tmp:
            try:
                os.unlink(tmp)
            except OSError:
                pass


def save(gates, path, extra=None):
    obj = {"gateCount": len(gates), "gates": gates}
    if extra:
        obj.update(extra)
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(obj, f)
    os.replace(tmp, path)
    return path


# --------------------------------------------------------------------------
# Load a seed circuit into a value-set (set of non-input masks).
# --------------------------------------------------------------------------
def load_circuit_masks(path):
    """Read a circuit JSON and return the SET of non-input signal masks it
    computes. Accepts index-pair gates {"gates":[[a,b],...]} or mask-triple
    gates {"gates":[{"m","a","b"}]} or a bare list of either."""
    with open(path) as f:
        data = json.load(f)
    gates = data["gates"] if isinstance(data, dict) else data
    if gates and isinstance(gates[0], dict):
        return set(int(g["m"]) & 0xFFFFFFFF for g in gates)
    sig = [1 << i for i in range(32)]
    for a, b in gates:
        sig.append(sig[a] ^ sig[b])
    return set(sig[32:])


# --------------------------------------------------------------------------
# From-scratch starting circuit: a balanced XOR tree per output (no sharing
# beyond opportunistic subexpression reuse).  Row weights are 11..19, so the
# tree depth is ceil(log2 19) = 5 = MIN_DEPTH -- this cold start is feasible
# for ANY legal depth cap, and infeasible for none.  (Forward MixColumns had
# weights 5/7 and this same routine gave depth 3; that is the whole reason the
# depth ladder here starts at 5.)
# --------------------------------------------------------------------------
def naive_circuit():
    """Return index-pair gates building every output as a balanced XOR tree
    (opportunistically reusing subexpressions)."""
    sig_index = {1 << i: i for i in range(32)}
    gates = []

    def combine(a, b):
        m = a ^ b
        if m not in sig_index:
            gates.append([sig_index[a], sig_index[b]])
            sig_index[m] = 32 + len(gates) - 1
        return m

    for t in TARGETS:
        items = [1 << b for b in bits_of(t)]
        while len(items) > 1:
            nxt = []
            for k in range(0, len(items) - 1, 2):
                nxt.append(combine(items[k], items[k + 1]))
            if len(items) % 2 == 1:
                nxt.append(items[-1])
            items = nxt
    return gates


def naive_masks():
    """The value-set (non-input masks) of naive_circuit()."""
    sig = [1 << i for i in range(32)]
    for a, b in naive_circuit():
        sig.append(sig[a] ^ sig[b])
    return set(sig[32:])


# --------------------------------------------------------------------------
# self-test:  python3 invmc_core.py
# --------------------------------------------------------------------------
if __name__ == "__main__":
    print("invmc_core self-test")
    print("  coef                = %s" % [hex(c) for c in COEF])
    print("  modulus             = 0x%X" % MODULUS)
    print("  targets             = %d distinct masks" % len(TARGET_SET))
    print("  weight profile      = %r  (expected %r)" % (_prof, WEIGHT_PROFILE))
    print("  spec file agreement = %s  (%s)" % ("OK", SPEC_MASKS))
    print("  max target weight   = %d" % MAX_TARGET_WEIGHT)
    print("  MIN_DEPTH           = %d  (ceil(log2 %d))"
          % (MIN_DEPTH, MAX_TARGET_WEIGHT))
    nc = naive_circuit()
    v = verify(nc)
    print("  naive_circuit       = %d gates, depth %d, outputs %d/32, ok=%s"
          % (v["gates"], v["depth"], v["outputs"], v["ok"]))
    ok, out, cmd = oracle_verify(nc)
    print("  oracle on naive     = %s" % ("VALID" if ok else "INVALID"))
    print("  oracle cmd          = %s" % cmd)
