#!/usr/bin/env python3
"""Referee (k9): rebuild M_inv from the provenance header alone, entrywise-compare.

Provenance (spec/invmc_matrix.json header, quoted):
  field GF(2^8)=F2[x]/(x^8+x^4+x^3+x+1), modulus 0x11B
  mds_column = [14,11,13,9]
  circulant: out_byte[col] = XOR_k coef[k]*in_byte[(col+k)%4]
  out_row_index = 8*out_byte + out_bit ; in_col_index = 8*in_byte + in_bit
  bit_order LSB-first ; mask(r) = OR_c M[r][c] << c
Nothing below is copied from spec/derive_invmc.py's body (only its docstring/header
convention, which is the provenance I am told to rebuild from).
"""
import json, sys

MOD = 0x11B

def gmul(a, b):
    r = 0
    while b:
        if b & 1: r ^= a
        b >>= 1
        a <<= 1
        if a & 0x100: a ^= MOD
    return r

def build(coef):
    # M[r][c] in {0,1}; r = 8*outbyte+outbit, c = 8*inbyte+inbit
    M = [[0]*32 for _ in range(32)]
    for col in range(4):                      # output byte index
        for k in range(4):
            ib = (col + k) % 4                # input byte index
            cf = coef[k]
            # linear map byte->byte: bit j of input contributes gmul(cf, 1<<j)
            for j in range(8):
                prod = gmul(cf, 1 << j)
                for i in range(8):
                    if (prod >> i) & 1:
                        M[8*col + i][8*ib + j] ^= 1
    return M

def rows_to_masks(M):
    return [sum(M[r][c] << c for c in range(32)) for r in range(32)]

def matmul(A, B):
    # over GF(2), 32x32 lists of lists
    n = len(A)
    Bt = [[B[k][j] for k in range(n)] for j in range(n)]
    return [[sum(A[i][k] & Bt[j][k] for k in range(n)) & 1 for j in range(n)] for i in range(n)]

def main():
    INV = build([0x0E, 0x0B, 0x0D, 0x09])
    FWD = build([0x02, 0x03, 0x01, 0x01])
    print("== C2: M_fwd*M_inv == I ?", matmul(FWD, INV) == [[1 if i==j else 0 for j in range(32)] for i in range(32)])
    print("== C2: M_inv*M_fwd == I ?", matmul(INV, FWD) == [[1 if i==j else 0 for j in range(32)] for i in range(32)])
    F3 = matmul(matmul(FWD, FWD), FWD)
    print("== C3: M_fwd^3 == M_inv ?", F3 == INV)
    # forward weight self-check (FIPS/oracle assertion): 20 rows wt 5, 12 rows wt 7
    fw = {}
    for r in range(32):
        w = sum(FWD[r]); fw[w] = fw.get(w, 0) + 1
    print("== C4: forward row-weight histogram", dict(sorted(fw.items())))

    spec = json.load(open('~/xor_ui/slp-invmc/spec/invmc_matrix.json'))
    srows = [[1 if ch == '1' else 0 for ch in s] for s in spec['rows']]
    same = (srows == INV)
    print("== ENTRYWISE vs spec/invmc_matrix.json rows:", "MATCH" if same else "MISMATCH")
    if not same:
        for r in range(32):
            if srows[r] != INV[r]:
                print("   row", r, "differs")
    dens = sum(sum(row) for row in INV)
    print("== density", dens, "(spec says", spec['density'], ")")
    rw = {}
    for r in range(32):
        w = sum(INV[r]); rw[w] = rw.get(w, 0) + 1
    cw = {}
    for c in range(32):
        w = sum(INV[r][c] for r in range(32)); cw[w] = cw.get(w, 0) + 1
    print("== inv row-weight hist", dict(sorted(rw.items())))
    print("== inv col-weight hist", dict(sorted(cw.items())))
    print("== min column weight", min(sum(INV[r][c] for r in range(32)) for c in range(32)))

    masks = rows_to_masks(INV)
    tm = json.load(open('~/xor_ui/slp-invmc/spec/invmc_target_masks.json'))
    print("== target_masks json keys:", list(tm)[:6] if isinstance(tm, dict) else "list")
    cand = tm['masks'] if isinstance(tm, dict) and 'masks' in tm else tm
    print("== masks match spec target masks:", cand == masks)

    # rho: column index i -> (i+8) mod 32; check M[rho(r)][rho(c)] == M[r][c]
    rho = lambda i: (i + 8) % 32
    ok = all(INV[rho(r)][rho(c)] == INV[r][c] for r in range(32) for c in range(32))
    print("== rho (i -> i+8 mod 32) is a matrix automorphism (rows&cols simultaneously):", ok)
    # order of rho
    print("== rho order:", 4)
    # also check no smaller shift works
    for s in (1,2,4,16):
        f = lambda i, s=s: (i + s) % 32
        o = all(INV[f(r)][f(c)] == INV[r][c] for r in range(32) for c in range(32))
        print("   shift %2d is an automorphism: %s" % (s, o))
    with open('~/xor_ui/slp-invmc/bounds/i6/k9/referee/ref_masks.txt','w') as fh:
        for m in masks: fh.write("%d\n" % m)
    print("== wrote ref_masks.txt")

main()
