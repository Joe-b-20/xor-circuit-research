#!/usr/bin/env python3
"""xcheck_maxq.py -- independent validation of maxq.c.

Two checks, both solver-free and neither sharing code with maxq.c:

  (A) REFERENCE re-implementation in pure Python (itertools.combinations +
      a set(), no DFS, no incremental state, no stamped hash table) run on the
      real targets at small kmax; per-size max_q must agree exactly.
  (B) RANDOM instances: uniformly random 32x32 GF(2) matrices, per-size max_q
      compared between maxq.c and the Python reference.  A bug in the incremental
      value/weight bookkeeping or the stamped-hash distinct count would show up
      here.

Usage: python3 xcheck_maxq.py [--kmax 4] [--random 20] [--seed 1]
"""
import argparse
import itertools
import os
import random
import subprocess
import sys
import time

import i5_core as core

HERE = os.path.dirname(os.path.abspath(__file__))
MAXQ = os.path.join(HERE, 'maxq')


def ref_maxq(rows, kmax):
    """Reference: brute force, no incremental state."""
    best = {}
    for k in range(kmax + 1):
        b = -1
        for K in itertools.combinations(range(32), k):
            rr = [sum(1 << i for i, c in enumerate(K) if (r >> c) & 1) for r in rows]
            q = len({v for v in rr if bin(v).count('1') >= 2})
            if q > b:
                b = q
        best[k] = b
    return best


def run_maxq(rows, kmax):
    out = subprocess.run([MAXQ, str(kmax), ','.join('0x%08x' % r for r in rows)],
                         capture_output=True, text=True, check=True).stdout
    d = {}
    for l in out.splitlines():
        if l.startswith('#') or not l.strip():
            continue
        f = l.split()
        d[int(f[0])] = int(f[2])
    return d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--kmax', type=int, default=4)
    ap.add_argument('--random', type=int, default=20)
    ap.add_argument('--seed', type=int, default=1)
    a = ap.parse_args()
    t0 = time.process_time()
    fails = 0

    print("(A) real targets, kmax=%d" % a.kmax)
    for key in ('mixcolumns', 'invmc'):
        t = core.load(key)
        core.rederive_and_compare(t, say=lambda s: None)
        core.selfcheck(t, say=lambda s: None)
        r, c = ref_maxq(t.rows, a.kmax), run_maxq(t.rows, a.kmax)
        ok = all(r[k] == c[k] for k in r)
        fails += (not ok)
        print("   %-11s python-ref %s   maxq.c %s   %s"
              % (key, [r[k] for k in sorted(r)], [c[k] for k in sorted(c)],
                 'AGREE' if ok else 'DISAGREE'))

    print("(B) %d random 32x32 GF(2) matrices, kmax=%d, seed=%d" % (a.random, a.kmax, a.seed))
    rng = random.Random(a.seed)
    for i in range(a.random):
        rows = [rng.getrandbits(32) for _ in range(32)]
        r, c = ref_maxq(rows, a.kmax), run_maxq(rows, a.kmax)
        ok = all(r[k] == c[k] for k in r)
        fails += (not ok)
        if not ok:
            print("   instance %d DISAGREE  ref=%s  c=%s" % (i, r, c))
    print("   %d/%d instances agree" % (a.random - fails, a.random))
    print("cpu_seconds %.2f" % (time.process_time() - t0))
    print("XCHECK %s" % ('PASS' if fails == 0 else 'FAIL'))
    return 0 if fails == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
