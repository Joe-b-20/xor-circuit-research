#!/usr/bin/env python3
"""brute_check.py -- ASSUMPTION-FREE verification of `minE_K >= e` at small |K|.

The DFS of `mine_search.py` (ported from OLD deep_extras.py / mine.c) is only
complete because of the five-step argument in NOTEBOOK sec. 2b -- greedy
closure is WLOG, the next extra is a pairsum of avail, the last-level
restriction, memoisation, weight->=1 exclusion.  Every one of those steps is a
place a bug can hide, and the forward project needed three independent
implementations to be comfortable with `minE >= 4`.

At |K| = 8 that whole trust surface can simply be deleted.  The ambient space
is F2^8: only 2^8 - 1 - 8 = 247 masks of weight >= 2 exist, so
    minE_K <= e - 1   iff   some E subset of (W \\ V) with |E| <= e-1 makes
                             G = V u E realizable,
and W \\ V has 247 - 32 = 215 elements.  Enumerating every such E costs
C(215,1) = 215 for e = 2, C(215,2) = 23,005 for e = 3 and
C(215,3) = 1,633,355 for e = 4.  That is a complete decision procedure using
NOTHING but the definition of realizable, so it checks the DEFINITION, not the
search.  (Forward could not do this: F2^14 holds 16,369 masks of weight >= 2, so
its extra pool has 16,337 and C(16337,3) = 7.3e11.)

Realizability of a finite mask set G over the c inputs is itself decided
greedily and that IS a theorem, not a heuristic: repeatedly adjoin any g in G
that is the XOR of two already-available masks.  If the greedy fixpoint is not
all of G then no ordering works, since any legal ordering's first unreached
element would have both operands available at the fixpoint.

Usage:
  python3 brute_check.py --target invmc --K 6,9,12,24,27,29,30,31 --depth 2
"""
import argparse
import itertools
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import i6_core as i6                                    # noqa: E402
core = i6.core


def realizable(c, G):
    """True iff the mask set G can be ordered so each element is the XOR of two
    strictly earlier elements (inputs count as available from the start)."""
    avail = set(1 << i for i in range(c))
    todo = set(G) - avail
    changed = True
    while changed and todo:
        changed = False
        for g in list(todo):
            for a in avail:
                if (g ^ a) in avail:
                    avail.add(g)
                    todo.discard(g)
                    changed = True
                    break
    return not todo


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--target', default='invmc')
    ap.add_argument('--K', required=True)
    ap.add_argument('--depth', type=int, default=2,
                    help='exhaust every extra-set of size <= depth')
    a = ap.parse_args()

    t = core.load(a.target)
    core.rederive_and_compare(t)
    core.selfcheck(t)
    rows = t.rows
    K = [int(x) for x in a.K.split(',')]
    assert i6.admissible(rows, K, say=print), 'non-admissible keep-set'

    c = len(K)
    V = i6.restrict(rows, K)
    assert len(set(V)) == 32, 'restricted rows not distinct'
    assert min(i6.popcount(v) for v in V) >= 2, 'restricted row of weight < 2'
    Vs = set(V)
    W = [m for m in range(1, 1 << c) if i6.popcount(m) >= 2]
    pool = sorted(set(W) - Vs)
    print("\nK = %s   |K| = %d" % (K, c))
    print("  ambient masks of weight >= 2 in F2^%d : %d" % (c, len(W)))
    print("  targets V : %d   extra pool W \\ V : %d" % (len(Vs), len(pool)))

    t0 = time.process_time()
    found = None
    counted = 0
    for d in range(0, a.depth + 1):
        for E in itertools.combinations(pool, d):
            counted += 1
            if realizable(c, Vs | set(E)):
                found = (d, E)
                break
        print("  size %d : %d extra-sets enumerated, cumulative %d, %s"
              % (d, sum(1 for _ in itertools.combinations(range(len(pool)), d)),
                 counted, 'COMPLETION FOUND' if found else 'none realizable'),
              flush=True)
        if found:
            break
    dt = time.process_time() - t0

    if found:
        d, E = found
        print("\n  minE_K = %d   witness extras %s" % (d, list(E)))
        bound = i6.theorem_b_bound(K, d)
    else:
        print("\n  NO realizable G with |G \\ V| <= %d exists." % a.depth)
        print("  => minE_K >= %d, BY EXHAUSTION OVER THE WHOLE MASK SPACE"
              % (a.depth + 1))
        bound = i6.theorem_b_bound(K, a.depth + 1)
    print("  extra-sets examined : %d      %.3f CPU-s" % (counted, dt))
    print("\n  THEOREM B:  L(%s) >= (32-%d) + 32 + minE = %d" % (t.name, c, bound))
    core.acceptance(t, bound)
    print("\ncpu_seconds %.3f" % dt)
    return 0


if __name__ == '__main__':
    sys.exit(main())
