#!/usr/bin/env python3
"""sweep.py -- minE over a whole keep-set layer, with continuous banking.

The Theorem-B BOUND needs only ONE keep-set (see README sec. 5).  This sweep is
for the *optimality* question: what is max_K minE_K over the layer, i.e. how
far can I6 go at this |K|.  It is the analogue of the forward project's
"minE = 0 on all 72 |K|=13 keep-sets" census (NOTEBOOK sec. 4.1), which is what
forced their argument out to |K| = 14.

Results are appended to --bank (one JSON object per keep-set, flushed every
--flush records) so a kill at any point loses at most --flush records; rerunning
with the same --bank resumes after the last banked index.

Usage:
  python3 sweep.py --target invmc --layer L.txt --kmax 3 --bank runs/sweep_k8.jsonl
  python3 sweep.py ... --sample 400 --seed 7 --bank /dev/null   # pricing only
"""
import argparse
import json
import os
import random
import sys
import time
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import i6_core as i6                                    # noqa: E402
core = i6.core


def _fsync(fh):
    try:
        os.fsync(fh.fileno())
    except OSError:
        pass          # e.g. --bank /dev/null during a pricing run


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--target', default='invmc')
    ap.add_argument('--layer', required=True)
    ap.add_argument('--kmax', type=int, default=3)
    ap.add_argument('--bank', required=True)
    ap.add_argument('--sample', type=int, default=0)
    ap.add_argument('--seed', type=int, default=1)
    ap.add_argument('--flush', type=int, default=256)
    ap.add_argument('--progress', type=int, default=2000)
    a = ap.parse_args()

    t = core.load(a.target)
    core.rederive_and_compare(t)
    core.selfcheck(t)
    rows = t.rows

    layer = [[int(x) for x in l.split(',')] for l in open(a.layer) if l.strip()]
    idx = list(range(len(layer)))
    tag = 'full'
    if a.sample and a.sample < len(layer):
        random.Random(a.seed).shuffle(idx)
        idx = sorted(idx[:a.sample])
        tag = 'sample%d_seed%d' % (a.sample, a.seed)
    print("layer %s : %d keep-sets of size %d ; sweeping %d (%s) ; kmax=%d"
          % (os.path.basename(a.layer), len(layer), len(layer[0]), len(idx), tag, a.kmax),
          flush=True)

    done = set()
    if a.bank != '/dev/null' and os.path.exists(a.bank):
        for line in open(a.bank):
            line = line.strip()
            if line:
                try:
                    done.add(json.loads(line)['i'])
                except Exception:
                    pass
        print("  resuming: %d records already banked" % len(done), flush=True)

    fh = open(a.bank, 'a')
    t0 = time.process_time()
    hist = Counter()
    nodes_tot = 0
    best = None
    n = 0
    for pos, i in enumerate(idx):
        if i in done:
            continue
        K = layer[i]
        assert i6.admissible(rows, K), 'non-admissible keep-set at index %d: %s' % (i, K)
        V = i6.restrict(rows, K)
        s = i6.Search(len(K), V, prune_last=True, memo=True)
        av0, todo0 = i6.closure(set(s.I), s.V)
        if not todo0:
            k, wit, nodes = 0, [], 1
        else:
            k, wit = s.run(a.kmax)
            nodes = s.nodes
        nodes_tot += nodes
        n += 1
        key = ('=' if wit is not None else '>=') + str(k)
        hist[key] += 1
        rec = {'i': i, 'K': K, 'jam': len(todo0), 'avail0': len(av0),
               'minE': k, 'exact': wit is not None, 'nodes': nodes,
               'witness': sorted(wit) if wit is not None else None}
        if best is None or (k, wit is None) > (best['minE'], not best['exact']):
            best = rec
        fh.write(json.dumps(rec, sort_keys=True) + '\n')
        if n % a.flush == 0:
            fh.flush()
            _fsync(fh)
        if n % a.progress == 0:
            print("  %6d/%6d  cpu %8.1f s  nodes %10d  minE hist %s"
                  % (n, len(idx), time.process_time() - t0, nodes_tot,
                     dict(sorted(hist.items()))), flush=True)
    fh.flush()
    _fsync(fh)
    fh.close()
    dt = time.process_time() - t0

    print("\nswept %d keep-sets   nodes %d   %.3f CPU-s   (%.4f CPU-s/set)"
          % (n, nodes_tot, dt, dt / max(n, 1)))
    print("minE distribution : %s" % dict(sorted(hist.items())))
    if best:
        b = i6.theorem_b_bound(best['K'], best['minE'])
        print("best K = %s  jam=%d  minE %s %d  ->  L(%s) >= %d"
              % (best['K'], best['jam'], '=' if best['exact'] else '>=',
                 best['minE'], t.name, b))
        core.acceptance(t, b)
    print("cpu_seconds %.3f" % dt)
    return 0


if __name__ == '__main__':
    sys.exit(main())
