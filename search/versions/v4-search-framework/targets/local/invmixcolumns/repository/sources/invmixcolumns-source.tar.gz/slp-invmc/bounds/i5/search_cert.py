#!/usr/bin/env python3
"""search_cert.py -- find Theorem-A certificates for a target matrix.

PORT OF  OLD/atlas/thinktank/proofside_code/admis.py  (+ enum14.py's layer census)
         OLD = ~/xor_ui/slp-plateau-search, read-only.

A CERTIFICATE is a column set K with q(M|_K) = 32, i.e. the 32 rows of M
restricted to K are pairwise distinct and each has weight >= 2.  Theorem A then
gives L(M) >= (32 - |K|) + 32 = 64 - |K|.  So the BEST certificate is the
SMALLEST admissible K, and the search is a minimisation.

Encoding (admis.py, unchanged in substance):
  variable c+1  <-> column c is kept
  for each row r : at least 2 of the columns in supp(r) are kept   (weight >= 2)
  for each pair (a,b) : at least one column where rows a,b differ is kept
                                                                  (distinctness)
  cardinality bound |K| <= k
UNSAT at k-1 together with a model at k proves the minimum is exactly k, so the
bound 64-k is the exact optimum of Theorem A among CERTIFICATES.  (The exact
optimum of the technique also has to rule out q < 32 at smaller |K| paying for
itself; that is maxq.c's job -- see RESULT_I5.md.)

Usage:
    python3 search_cert.py --target invmc [--enumerate] [--limit N]
"""
import argparse
import itertools
import json
import os
import sys
import time

import i5_core as core
from pysat.formula import IDPool, CNF
from pysat.card import CardEnc, EncType
from pysat.solvers import Cadical153

HERE = os.path.dirname(os.path.abspath(__file__))


def base_clauses(rows, pool, forbidden=()):
    supp = [[c for c in range(32) if (r >> c) & 1] for r in rows]
    cnf = CNF()
    for r in range(32):
        cnf.extend(CardEnc.atleast(lits=[c + 1 for c in supp[r]], bound=2,
                                   vpool=pool, encoding=EncType.seqcounter).clauses)
    for a, b in itertools.combinations(range(32), 2):
        d = rows[a] ^ rows[b]
        cl = [c + 1 for c in range(32) if (d >> c) & 1]
        assert cl, 'rows %d and %d are equal -- no certificate can exist' % (a, b)
        cnf.append(cl)
    for c in forbidden:
        cnf.append([-(c + 1)])
    return cnf


def min_admissible(rows, say=print, forbidden=()):
    pool = IDPool(start_from=33)
    cnf = base_clauses(rows, pool, forbidden)
    for k in range(2, 33):
        s = Cadical153(bootstrap_with=cnf)
        s.append_formula(CardEnc.atmost(lits=list(range(1, 33)), bound=k,
                                        vpool=pool, encoding=EncType.seqcounter).clauses)
        t0 = time.process_time()
        sat = s.solve()
        dt = time.process_time() - t0
        if sat:
            K = sorted(l - 1 for l in s.get_model() if 0 < l <= 32)
            s.delete()
            say("  |K| <= %-2d : SAT    %.3f s   witness %s" % (k, dt, K))
            return k, K
        s.delete()
        say("  |K| <= %-2d : UNSAT  %.3f s" % (k, dt))
    return None, None


def enumerate_exact(rows, size, limit=10 ** 7, say=print):
    pool = IDPool(start_from=33)
    cnf = base_clauses(rows, pool)
    s = Cadical153(bootstrap_with=cnf)
    s.append_formula(CardEnc.atmost(lits=list(range(1, 33)), bound=size,
                                    vpool=pool, encoding=EncType.seqcounter).clauses)
    s.append_formula(CardEnc.atleast(lits=list(range(1, 33)), bound=size,
                                     vpool=pool, encoding=EncType.seqcounter).clauses)
    out = []
    while len(out) < limit and s.solve():
        K = sorted(l - 1 for l in s.get_model() if 0 < l <= 32)
        out.append(K)
        s.add_clause([-(c + 1) for c in K])
    s.delete()
    return out


def transpose_rows(rows):
    return [sum(((rows[r] >> c) & 1) << r for r in range(32)) for c in range(32)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--target', default='invmc')
    ap.add_argument('--enumerate', action='store_true',
                    help='complete enumeration of the minimal admissible layer')
    ap.add_argument('--limit', type=int, default=10 ** 6)
    ap.add_argument('--out', default=None)
    a = ap.parse_args()

    t0 = time.process_time()
    t = core.load(a.target)
    print("=" * 78)
    print("I5 certificate search   target=%s" % t.key)
    print("=" * 78)
    core.rederive_and_compare(t)
    core.selfcheck(t)
    print()

    print("-- minimum admissible keep-set, primal frame (M) " + "-" * 29)
    k, K = min_admissible(t.rows)
    assert core.keepset_ok(t.rows, K), 'SAT model is not admissible'
    print("  minimum |K| = %d   bound (32-|K|)+32 = %d" % (k, 64 - k))
    print()

    # L(M) = L(M^T) is the transposition principle (Jukna, Boolean Function
    # Complexity, sec. 1 "transposition principle"; Boyar-Peralta), valid for
    # square full-rank matrices computed by XOR circuits.  Not load-bearing:
    # this frame gives 56 < 57 on M_inv, so no emitted bound depends on it.
    print("-- same technique in the TRANSPOSED frame (M^T; L(M)=L(M^T)) " + "-" * 17)
    Rt = transpose_rows(t.rows)
    kt, Kt = min_admissible(Rt)
    assert core.keepset_ok(Rt, Kt)
    print("  minimum |K| = %d   bound = %d   (%s frame)"
          % (kt, 64 - kt, 'transposed frame WINS' if kt < k else 'primal frame is at least as good'))
    print()

    certs = [{'label': 'Theorem A certificate (minimum |K|, SAT-optimal)',
              'K': K, 'frame': 'primal', 'bound': 64 - k}]
    layer = None
    if a.enumerate:
        print("-- complete enumeration of the |K| = %d admissible layer " % k + "-" * 20)
        te = time.process_time()
        layer = enumerate_exact(t.rows, k, limit=a.limit)
        print("  admissible %d-sets : %d   (all re-checked: %s)   %.1f cpu-s"
              % (k, len(layer), all(core.keepset_ok(t.rows, x) for x in layer),
                 time.process_time() - te))
        if layer:
            from collections import Counter
            print("  column frequency over the layer: %s"
                  % dict(sorted(Counter(c for x in layer for c in x).items())))
            n = 0
            for x in sorted(layer):
                if x == K:
                    continue
                certs.append({'label': 'Theorem A certificate (layer member %d)' % n,
                              'K': x, 'frame': 'primal', 'bound': 64 - k})
                n += 1
                if n == 4:
                    break
        json.dump(sorted(layer), open(os.path.join(HERE, 'layer_%s_k%d.json' % (t.key, k)), 'w'))
        print("  -> layer_%s_k%d.json" % (t.key, k))
    print()

    doc = {'target': t.key, 'matrix': t.path,
           'rows_sha256': t.doc['provenance']['rows_sha256'],
           'min_admissible_K': k, 'bound': 64 - k,
           'min_admissible_K_transposed': kt, 'bound_transposed': 64 - kt,
           'layer_size': (len(layer) if layer is not None else None),
           'certificates': certs,
           'cpu_seconds': round(time.process_time() - t0, 3)}
    out = a.out or os.path.join(HERE, 'certs_%s.json' % t.key)
    json.dump(doc, open(out, 'w'), indent=1)
    print("wrote %s" % out)
    print()
    accepted = core.acceptance(t, 64 - min(k, kt))
    print("cpu_seconds %.3f" % (time.process_time() - t0))
    return 0 if accepted else 2


if __name__ == '__main__':
    sys.exit(main())
