#!/usr/bin/env python3
"""blocks.py -- build the record-free per-line "sector block" instances, forward
and inverse, in exactly fleet8/unified's own coordinates.

A block that owns output bit-line j works on a LINE SET L (L1):
    forward   L = workset(j) = {j} u QLINES[j]          sizes [2,3,2,3,3,2,2,2]
    inverse   L = GEN[j]     = support of span{d_j,2d_j,4d_j,8d_j}
                                                        sizes [4,5,5,7,7,6,5,4]
Its TARGETS are the four column targets on that line (masks -> line vectors).
Its SUPPLY here is RAWS ONLY -- the four raw input bits of each line of L.
That is the record-free (naive/ladder) supply: no currency menu, no committed
interface, so it carries no F1 flag and needs no InvMixColumns record.

Values are packed with algebra.pack's convention: ascending line order, one
nibble (4 bits) per line, so r = dim = 4*|L|.

Nothing is written outside this repository; theory.py is IMPORTED read-only
from the frozen OLD tree (run with PYTHONDONTWRITEBYTECODE=1).
"""
import os, sys

NEW = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OLD = '~/xor_ui/slp-plateau-search'
sys.path.insert(0, os.path.join(OLD, 'fleet8/unified/code'))
sys.path.insert(0, os.path.join(NEW, 'spec'))
import theory                                                    # noqa: E402
from derive_invmc import build_matrix, matrix_to_masks, FWD_COEF, INV_COEF  # noqa: E402
sys.path.insert(0, os.path.join(NEW, 'spec'))
from sector_probe import chain_coords                            # noqa: E402


def pack(x, L):
    v = 0
    for i, m in enumerate(sorted(L)):
        v |= (x[m] & 0xF) << (4 * i)
    return v


def raw_line_vectors(line):
    """the four raw input bits carrying d_line (x) y^a, as 8-line nibble vectors.
    algebra.raws(line) = [lv(line, ypow(a)) for a in range(4)]."""
    out = []
    for a in range(4):
        x = [0] * 8
        x[line] = theory.ypow(a) & 0xF
        out.append(tuple(x))
    return out


GEN = [set().union(*[chain_coords(k, i) for i in range(4)]) for k in range(8)]
FWD_WS = [tuple(sorted({k} | theory.QLINES[k])) for k in range(8)]
INV_WS = [tuple(sorted(GEN[k])) for k in range(8)]

_FWD_MASKS = matrix_to_masks(build_matrix(FWD_COEF))
_INV_MASKS = matrix_to_masks(build_matrix(INV_COEF))


def block(which, j):
    """(name, lines, r, inputs, targets) for the block owning output line j."""
    L = FWD_WS[j] if which == 'fwd' else INV_WS[j]
    masks = _FWD_MASKS if which == 'fwd' else _INV_MASKS
    tv = []
    for col in range(4):
        Lv = theory.mask_to_lines(masks[8 * col + j])
        assert theory.support(Lv) <= set(L), (which, j, col, theory.support(Lv), L)
        tv.append(pack(Lv, L))
    inp = []
    for line in L:
        for v in raw_line_vectors(line):
            inp.append(pack(v, L))
    inp = sorted(set(inp) - {0})
    tv = sorted(set(tv) - {0})
    return dict(which=which, j=j, lines=list(L), r=4 * len(L),
                inputs=inp, targets=tv)


if __name__ == '__main__':
    print('forward worksets', FWD_WS)
    print('inverse worksets', INV_WS)
    print()
    print('%-4s %-2s %-22s %2s %3s %2s' % ('set', 'j', 'lines', 'r', 'm', 'T'))
    for which in ('fwd', 'inv'):
        for j in range(8):
            b = block(which, j)
            print('%-4s %-2d %-22s %2d %3d %2d' % (
                which, j, str(b['lines']), b['r'], len(b['inputs']), len(b['targets'])))
