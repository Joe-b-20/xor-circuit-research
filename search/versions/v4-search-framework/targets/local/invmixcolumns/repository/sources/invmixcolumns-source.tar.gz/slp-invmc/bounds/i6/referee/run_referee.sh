#!/bin/bash
# I6 referee — independent re-derivation and re-computation. One core, nice -n 19.
set -u
cd "$(dirname "$0")"
R=./ref_i6b
say(){ echo; echo "### $*"; }
say "0. matrix re-derived from the provenance header (GF(2^8)/0x11B, [14,11,13,9])"
python3 ref_derive.py
say "1. admissible keep-set census (Theorem A hypotheses), sizes 7/8/9, my own enumerator"
# (rerun with FORCE=1 to redo the 41.9M-subset enumeration; the layers are banked here)
if [ "${FORCE:-0}" = 1 ]; then
  $R ref_rows.txt admis 7 ref_admis_k7.txt
  $R ref_rows.txt admis 8 ref_admis_k8.txt
  $R ref_rows.txt admis 9 ref_admis_k9.txt
else
  echo "banked (FORCE=1 to redo):"
  echo "  size=7  subsets_scanned=3365856   admissible=$(wc -l < ref_admis_k7.txt)"
  echo "  size=8  subsets_scanned=10518300  admissible=$(wc -l < ref_admis_k8.txt)"
  echo "  size=9  subsets_scanned=28048800  admissible=$(wc -l < ref_admis_k9.txt)"
fi
echo "-- all three Theorem-A/B hypotheses on every keep-set that carries a claim:"
python3 ref_hypotheses.py
echo "diff against the author's layers:"
sort ref_admis_k8.txt | diff -q - <(sort ../../i5/runs/admissible_invmc_k8.txt) && echo "  k=8 layer IDENTICAL"
sort ref_admis_k9.txt | diff -q - <(sort ../runs/admissible_invmc_k9.txt) && echo "  k=9 layer IDENTICAL"
say "2. method cross-validation: dumb full-pool enumeration vs build-order DFS, random instances"
for c in 5 6; do nice -n 19 $R ref_rows.txt validate $c 400 $((c*2)) 3 | tail -1; done
nice -n 19 $R ref_rows.txt validate 7 120 14 3 | tail -1
nice -n 19 $R ref_rows.txt validate 8 12 16 3 | tail -1
echo "(the full runs -- c=7 x400 and c=8 x40 -- are quoted in REFEREE_REPORT.md 2.3;"
echo " ASAN build ref_i6_asan was clean on c=7 x60)"
say "3. Theorem B end-to-end vs EXACT minimum SLP size, and Lemma 3' projection (Python, raw model)"
nice -n 19 python3 ref_theoremB_stress.py
nice -n 19 python3 ref_lemma3p_stress.py
say "4. |K|=7 layer: minE for all 44 admissible sets"
nice -n 19 $R ref_rows.txt sweep 7 ref_admis_k7.txt 3 dfs
say "5. |K|=8 layer: minE for all 42388 admissible sets, by DUMB full-pool enumeration"
nice -n 19 $R ref_rows.txt sweep 8 ref_admis_k8.txt 2 bf ref_k8_minE_bf.txt
say "6. spot checks on |K|=8 sets with minE=2 (both methods; brute force exhausts |E|<=1)"
for k in 0,2,3,4,5,6,7,25 0,2,3,4,5,7,25,30 0,2,3,5,6,7,25,28 0,2,3,5,7,25,28,30 0,2,4,5,6,9,19,23 0,2,4,5,7,11,14,25 0,3,4,5,6,7,14,17; do
  nice -n 19 $R ref_rows.txt one 8 "$k" 2 both | grep -E "^K |brute-force. minE|dfs. *minE"
done
say "7. the two |K|=9 certificate keep-sets"
for k in 0,1,3,7,14,16,17,28,29 0,3,4,5,6,7,13,14,17; do
  nice -n 19 $R ref_rows.txt one 9 "$k" 3 bf
  nice -n 19 $R ref_rows.txt one 9 "$k" 4 dfs | grep dfs
done
say "8. positive control: an admissible 9-set whose minE is 3 must be FOUND at depth 3"
nice -n 19 $R ref_rows.txt one 9 0,1,2,3,5,9,22,23,29 3 both | grep -E "^K |brute-force. minE|dfs. *minE"
say "9. Lemma 3' on the real instances: add dead ambient inputs, minE must not drop"
for n in 9 10 11 12; do nice -n 19 $R ref_rows.txt ambient $n 0,1,3,7,14,16,17,28,29 4 dfs; done
for n in 9 10 11 12; do nice -n 19 $R ref_rows.txt ambient $n 0,3,4,5,6,7,13,14,17 4 dfs; done
say "10. sanity: the upper bounds, through the repo oracle"
cd ../../..
for c in circuits/invmc_alt_89_depth16.json circuits/invmc_walk_89_depth25.json circuits/invmc_yuan91.json; do
  echo "-- $c"; nice -n 19 python3 tools/verify_slp_generic.py --target spec/invmc_matrix.json "$c" | tail -2
done
say "11. my histogram vs the author's bank, all 42388 records"
python3 - <<'PY'
import json
bank={}
for line in open('bounds/i6/runs/sweep_k8_full.jsonl'):
    r=json.loads(line); bank[','.join(map(str,r['K']))]=r['minE']
mine={}
for line in open('bounds/i6/referee/ref_k8_minE_bf.txt'):
    a,b=line.split(); mine[a]=int(b.split('=')[1])
print("bank %d  mine %d  key-set equal %s  minE disagreements %d"%(
    len(bank),len(mine),set(bank)==set(mine),sum(1 for k in mine if bank[k]!=mine[k])))
PY
