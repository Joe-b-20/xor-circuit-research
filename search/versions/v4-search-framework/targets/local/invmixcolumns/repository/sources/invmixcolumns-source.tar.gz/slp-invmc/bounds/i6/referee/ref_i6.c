/* Independent referee re-implementation for the I6 "minE" claims.
   Written from the primary definitions only (Theorem A / Lemma 3 / Lemma 3' /
   Theorem B as restated in the referee report), not from the author's code.

   Model: XOR-SLP over GF(2), c inputs.  V = set of 32 distinct target masks of
   weight >= 2 over F2^c (the rows of M|_K re-indexed to the kept columns).
   G is "realizable" if it admits an order g_1..g_m with g_i = a^b,
   a,b in {e_1..e_c} u {g_1..g_{i-1}}.
   minE(V) = min{ |G \ V| : G realizable, distinct, all wt>=2, V subset of G }.

   KEY FACT used by both methods (proved in the report, section "closure"):
     exists realizable G with G\V subset of E   <=>   V subset of CL(E)
   where CL(E) is the greedy closure: start A = inputs u E, repeatedly add any
   v in V with v = a^b for a,b already in A.   [greedy closure is confluent and
   captures every build order, and any unused e in E can be dropped from G.]
   NOTE: this direction of the equivalence requires every e in E to be *usable*;
   the <= direction takes G = the set actually added, which is realizable and
   has G\V subset of E.  The => direction is monotonicity of closure.
   Hence:  minE(V) = min{ |E| : V subset of CL(E) }, E ranging over masks of
   weight >= 2.  <-- this is the definition BOTH methods below compute.

   METHOD 1 (bf): brute force.  Enumerate every E with |E| <= b over the full
   ambient pool of all weight->=2 masks.  No pruning, no heuristics.
   METHOD 2 (dfs): iterative-deepening DFS committing extras in build order,
   branching only on derivable candidates (pairsums of the current closure),
   with a last-level restriction and memoisation.  Used as a cross-check.

   Build: gcc -O2 -o ref_i6 ref_i6.c
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>

static int C, N, NW;          /* inputs, 1<<C, words */
static int V[64], NV;
typedef uint64_t BM;
#define GET(A,x) (((A)[(x)>>6]>>((x)&63))&1ULL)
#define SET(A,x) ((A)[(x)>>6]|=1ULL<<((x)&63))

/* ---- 32x32 matrix (read from rows file, one 32-char 0/1 string per line) ---- */
static char Mrows[32][40];

static void load_matrix(const char*path){
    FILE*f=fopen(path,"r"); if(!f){perror(path);exit(1);}
    for(int i=0;i<32;i++){ if(fscanf(f,"%39s",Mrows[i])!=1){fprintf(stderr,"bad rows\n");exit(1);} }
    fclose(f);
}
/* restrict M to sorted keep-set K (size c) -> rows as c-bit masks, bit i = column K[i] */
static int restrict_rows(const int*K,int c,int*out){
    for(int r=0;r<32;r++){ int m=0; for(int i=0;i<c;i++) if(Mrows[r][K[i]]=='1') m|=1<<i; out[r]=m; }
    return 32;
}
static int admissible(const int*rows){ /* 32 distinct, all weight>=2 */
    for(int r=0;r<32;r++){ int w=__builtin_popcount(rows[r]); if(w<2) return 0; }
    for(int a=0;a<32;a++) for(int b=a+1;b<32;b++) if(rows[a]==rows[b]) return 0;
    return 1;
}

/* ---------------- incremental closure ---------------- */
static BM A0[80]; static int pend0[64], npend0;
static BM Acur[80]; static int pend[64], npend;
static int queue_[4096];
static int curlist[400000]; static int ncur;      /* running list of members of Acur */
static int base_list[9000]; static int nbase;

/* add x to Acur and saturate over pending V elements. returns 1 if all V done */
static void cl_add(int x){
    int qh=0,qt=0;
    if(!GET(Acur,x)){ SET(Acur,x); curlist[ncur++]=x; queue_[qt++]=x; }
    while(qh<qt){
        int y=queue_[qh++];
        for(int i=0;i<npend;i++){
            int v=pend[i];
            if(!GET(Acur,v) && GET(Acur, v^y)){ SET(Acur,v); curlist[ncur++]=v; queue_[qt++]=v; }
        }
    }
    int k=0; for(int i=0;i<npend;i++) if(!GET(Acur,pend[i])) pend[k++]=pend[i];
    npend=k;
}
static void base_closure(void){
    memset(A0,0,sizeof(BM)*NW);
    for(int i=0;i<C;i++) SET(A0,1<<i);
    memcpy(Acur,A0,sizeof(BM)*NW);
    npend=0; for(int i=0;i<NV;i++) pend[npend++]=V[i];
    /* saturate from scratch */
    int changed=1;
    while(changed){ changed=0;
        for(int i=0;i<npend;i++){ int v=pend[i]; if(GET(Acur,v)) continue;
            for(int a=0;a<N;a++) if(GET(Acur,a) && GET(Acur,a^v)){ SET(Acur,v); changed=1; break; } }
        int k=0; for(int i=0;i<npend;i++) if(!GET(Acur,pend[i])) pend[k++]=pend[i]; npend=k;
    }
    memcpy(A0,Acur,sizeof(BM)*NW);
    npend0=npend; memcpy(pend0,pend,sizeof(int)*npend);
    nbase=0; for(int m=0;m<N;m++) if(GET(A0,m)) base_list[nbase++]=m;
}
static inline void reset_to_base(void){ memcpy(Acur,A0,sizeof(BM)*NW); npend=npend0; memcpy(pend,pend0,sizeof(int)*npend0);
    ncur=nbase; memcpy(curlist,base_list,sizeof(int)*nbase); }
/* is e derivable as a^b with a,b currently available? */
static inline int derivable(int e){ for(int i=0;i<ncur;i++) if(GET(Acur, e^curlist[i])) return 1; return 0; }
/* honest realizability test for G = V u E: start from inputs' closure, add an
   element of V u E only when it is the XOR of two ALREADY-AVAILABLE signals.
   Returns 1 iff every element of V gets built. */
static int realizable_with(const int*E,int b){
    reset_to_base();
    int used[8]; for(int i=0;i<b;i++) used[i]=0;
    int progress=1;
    while(progress && npend>0){
        progress=0;
        for(int i=0;i<b;i++){
            if(used[i]) continue;
            int e=E[i];
            if(GET(Acur,e)){ used[i]=1; continue; }
            if(derivable(e)){ used[i]=1; cl_add(e); progress=1; if(npend==0) break; }
        }
    }
    return npend==0;
}

/* ---------------- METHOD 1: brute force ---------------- */
static long long bf_tests;
static int pool[9000], npool;
static int bf_wit[8];
/* returns smallest b<=maxb with a witness, or -1 */
static int brute(int maxb){
    bf_tests=0;
    reset_to_base();
    if(npend==0) return 0;
    if(maxb<1) return -1;
    npool=0; for(int m=0;m<N;m++) if(__builtin_popcount(m)>=2) pool[npool++]=m;
    for(int b=1;b<=maxb;b++){
        int idx[8];
        for(int i=0;i<b;i++) idx[i]=i;
        while(1){
            int E[8]; for(int i=0;i<b;i++) E[i]=pool[idx[i]];
            bf_tests++;
            if(realizable_with(E,b)){ for(int i=0;i<b;i++) bf_wit[i]=E[i]; return b; }
            int p=b-1;
            while(p>=0 && idx[p]==npool-b+p) p--;
            if(p<0) break;
            idx[p]++; for(int i=p+1;i<b;i++) idx[i]=idx[i-1]+1;
        }
    }
    return -1;
}

/* ---------------- METHOD 2: build-order DFS ---------------- */
static long long dfs_nodes;
static int dfs_wit[8], dfs_depth_used;
/* memo: open hash on (A,budget) failures */
#define MEMOSZ (1<<22)
static uint64_t memokey[MEMOSZ]; static int8_t memobud[MEMOSZ];
static uint64_t hashA(const BM*A,int b){ uint64_t h=1469598103934665603ULL^(uint64_t)b;
    for(int i=0;i<NW;i++){ h^=A[i]; h*=1099511628211ULL; } if(!h)h=1; return h; }
static int memo_get(uint64_t h){ uint64_t i=h&(MEMOSZ-1); for(int k=0;k<8;k++){ if(memokey[i]==0) return 0; if(memokey[i]==h) return 1; i=(i+1)&(MEMOSZ-1);} return 0; }
static void memo_put(uint64_t h){ uint64_t i=h&(MEMOSZ-1); for(int k=0;k<8;k++){ if(memokey[i]==0||memokey[i]==h){memokey[i]=h;return;} i=(i+1)&(MEMOSZ-1);} memokey[h&(MEMOSZ-1)]=h; }

static int dfs(BM*A,int*pd,int npd,int budget,int depth){
    dfs_nodes++;
    if(npd==0) return 1;
    if(budget==0) return 0;
    uint64_t h=hashA(A,budget); if(memo_get(h)) return 0;
    /* candidate extras: derivable pairsums of A, weight>=2, not in A */
    int alist[9000];
    int na=0; for(int m=0;m<N;m++) if(GET(A,m)) alist[na++]=m;
    BM cand[80]; memset(cand,0,sizeof(BM)*NW);
    if(budget==1){
        /* last level: e must be v^a for some pending v and a in A, AND derivable */
        for(int i=0;i<npd;i++) for(int j=0;j<na;j++){ int e=pd[i]^alist[j];
            if(__builtin_popcount(e)>=2 && !GET(A,e)) SET(cand,e); }
        /* intersect with derivable */
        BM der[80]; memset(der,0,sizeof(BM)*NW);
        for(int i=0;i<na;i++) for(int j=i+1;j<na;j++){ int e=alist[i]^alist[j];
            if(__builtin_popcount(e)>=2 && !GET(A,e)) SET(der,e); }
        for(int w=0;w<NW;w++) cand[w]&=der[w];
    } else {
        for(int i=0;i<na;i++) for(int j=i+1;j<na;j++){ int e=alist[i]^alist[j];
            if(__builtin_popcount(e)>=2 && !GET(A,e)) SET(cand,e); }
    }
    BM savedA[80]; int savedp[64],savednp;
    for(int e=0;e<N;e++){
        if(!GET(cand,e)) continue;
        memcpy(savedA,A,sizeof(BM)*NW); memcpy(savedp,pd,sizeof(int)*npd); savednp=npd;
        memcpy(Acur,A,sizeof(BM)*NW); npend=npd; memcpy(pend,pd,sizeof(int)*npd);
        ncur=na; memcpy(curlist,alist,sizeof(int)*na);
        cl_add(e);
        BM A2[80]; int p2[64],np2; memcpy(A2,Acur,sizeof(BM)*NW); np2=npend; memcpy(p2,pend,sizeof(int)*npend);
        if(dfs(A2,p2,np2,budget-1,depth+1)){ dfs_wit[depth]=e; return 1; }
        memcpy(A,savedA,sizeof(BM)*NW); memcpy(pd,savedp,sizeof(int)*savednp); npd=savednp;
    }
    memo_put(h);
    return 0;
}
static int iddfs(int maxb){
    for(int b=0;b<=maxb;b++){
        memset(memokey,0,sizeof(memokey));
        reset_to_base();
        BM A[80]; int pd[64],npd; memcpy(A,Acur,sizeof(BM)*NW); npd=npend; memcpy(pd,pend,sizeof(int)*npend);
        dfs_nodes=0;
        if(dfs(A,pd,npd,b,0)){ dfs_depth_used=b; return b; }
    }
    return -1;
}

static void setup(const int*K,int c){
    C=c; N=1<<c; NW=(N+63)/64;
    int rows[32]; restrict_rows(K,c,rows);
    NV=0; for(int r=0;r<32;r++) V[NV++]=rows[r];
    base_closure();
}

int main(int argc,char**argv){
    load_matrix(argv[1]);
    const char*mode=argv[2];
    if(!strcmp(mode,"admis")){          /* admis <size> : count admissible keep-sets, dump them */
        int c=atoi(argv[3]);
        int K[80]; long long cnt=0,tot=0;
        int idx[80]; for(int i=0;i<c;i++) idx[i]=i;
        FILE*out=fopen(argv[4],"w");
        while(1){ tot++;
            for(int i=0;i<c;i++) K[i]=idx[i];
            int rows[32]; restrict_rows(K,c,rows);
            if(admissible(rows)){ cnt++;
                for(int i=0;i<c;i++) fprintf(out,"%d%c",K[i],i==c-1?'\n':','); }
            int p=c-1; while(p>=0 && idx[p]==32-c+p) p--;
            if(p<0) break; idx[p]++; for(int i=p+1;i<c;i++) idx[i]=idx[i-1]+1;
        }
        fclose(out);
        printf("size=%d  subsets_scanned=%lld  admissible=%lld\n",c,tot,cnt);
        return 0;
    }
    if(!strcmp(mode,"one")){            /* one <c> <k0,k1,...> <maxb> <method> */
        int c=atoi(argv[3]); int K[80]; { char*s=strdup(argv[4]); int i=0; for(char*t=strtok(s,",");t;t=strtok(NULL,",")) K[i++]=atoi(t); if(i!=c){fprintf(stderr,"c mismatch\n");return 1;} }
        int maxb=atoi(argv[5]); const char*meth=argv[6];
        int rows[32]; restrict_rows(K,c,rows);
        printf("K = %s  |K|=%d  admissible=%d\n",argv[4],c,admissible(rows));
        { int wmin=99,wmax=0; for(int r=0;r<32;r++){int w=__builtin_popcount(rows[r]); if(w<wmin)wmin=w; if(w>wmax)wmax=w;} printf("  restricted row weights %d..%d, distinct=%d\n",wmin,wmax,admissible(rows)); }
        printf("  V_K ="); for(int r=0;r<32;r++) printf(" %d",rows[r]); printf("\n");
        setup(K,c);
        { int na=0; for(int m=0;m<N;m++) if(GET(A0,m)) na++; printf("  |avail0|=%d  jam(|todo0|)=%d\n",na,npend0); }
        clock_t t0=clock();
        if(!strcmp(meth,"bf")||!strcmp(meth,"both")){
            int r=brute(maxb);
            double dt=(double)(clock()-t0)/CLOCKS_PER_SEC;
            printf("  [brute-force] pool=%d (all wt>=2 masks over %d inputs)  tests=%lld  %.3f CPU-s\n",npool,c,bf_tests,dt);
            if(r<0) printf("  [brute-force] NO witness with |E| <= %d  =>  minE >= %d\n",maxb,maxb+1);
            else { printf("  [brute-force] minE = %d  witness E = {",r); for(int i=0;i<r;i++)printf("%d%s",bf_wit[i],i<r-1?", ":""); printf("}\n"); }
        }
        if(!strcmp(meth,"dfs")||!strcmp(meth,"both")){
            clock_t t1=clock();
            int r=iddfs(maxb);
            double dt=(double)(clock()-t1)/CLOCKS_PER_SEC;
            if(r<0) printf("  [dfs]         NO witness with |E| <= %d (nodes=%lld, %.3f CPU-s) => minE >= %d\n",maxb,dfs_nodes,dt,maxb+1);
            else { printf("  [dfs]         minE = %d  witness (build order) = {",r); for(int i=0;i<r;i++)printf("%d%s",dfs_wit[i],i<r-1?", ":""); printf("}  nodes=%lld  %.3f CPU-s\n",dfs_nodes,dt); }
        }
        return 0;
    }
    if(!strcmp(mode,"ambient")){        /* ambient <n> <klist> <maxb> <method> : V from K, embedded in the low |K| bits of n>=|K| inputs.  Direct test of Lemma 3' on the real instances. */
        int n=atoi(argv[3]); int K[80],c=0; { char*s2=strdup(argv[4]); for(char*t=strtok(s2,",");t;t=strtok(NULL,",")) K[c++]=atoi(t); }
        int maxb=atoi(argv[5]); const char*meth=argv[6];
        int rows[32]; restrict_rows(K,c,rows);
        C=n; N=1<<n; NW=(N+63)/64;
        NV=0; for(int r=0;r<32;r++) V[NV++]=rows[r];   /* same integers, now over n inputs */
        base_closure();
        int na=0; for(int m=0;m<N;m++) if(GET(A0,m)) na++;
        printf("ambient n=%d  |K|=%d  K=%s  |avail0|=%d jam=%d\n",n,c,argv[4],na,npend0);
        clock_t t0=clock();
        if(!strcmp(meth,"bf")){ int r=brute(maxb); double dt=(double)(clock()-t0)/CLOCKS_PER_SEC;
            printf("  [brute-force] pool=%d tests=%lld %.3f CPU-s -> %s\n",npool,bf_tests,dt, r<0?"minE_n > maxb":"witness found");
            if(r>=0) printf("  minE_n = %d\n",r); else printf("  minE_n >= %d\n",maxb+1); }
        else { int r=iddfs(maxb); double dt=(double)(clock()-t0)/CLOCKS_PER_SEC;
            printf("  [dfs] nodes=%lld %.3f CPU-s  ",dfs_nodes,dt);
            if(r<0) printf("minE_n >= %d\n",maxb+1); else printf("minE_n = %d\n",r); }
        return 0;
    }
    if(!strcmp(mode,"sweep")){          /* sweep <c> <listfile> <maxb> <method> */
        int c=atoi(argv[3]); FILE*f=fopen(argv[4],"r"); int maxb=atoi(argv[5]); const char*meth=argv[6];
        char line[256]; long long hist[8]; memset(hist,0,sizeof(hist)); long long over=0,n=0;
        clock_t t0=clock();
        FILE*out = argc>7?fopen(argv[7],"w"):NULL;
        while(fgets(line,sizeof line,f)){
            int K[80],i=0; for(char*t=strtok(line,",\n");t;t=strtok(NULL,",\n")) K[i++]=atoi(t);
            if(i!=c) continue;
            setup(K,c); n++;
            int r = !strcmp(meth,"bf") ? brute(maxb) : iddfs(maxb);
            if(r<0) over++; else hist[r]++;
            if(out){ for(int j=0;j<c;j++) fprintf(out,"%d%c",K[j],j==c-1?' ':','); fprintf(out,"minE=%d\n",r); }
        }
        double dt=(double)(clock()-t0)/CLOCKS_PER_SEC;
        printf("swept %lld keep-sets (c=%d, method=%s, maxb=%d) in %.3f CPU-s\n",n,c,meth,maxb,dt);
        for(int b=0;b<=maxb;b++) printf("  minE=%d : %lld\n",b,hist[b]);
        printf("  minE>%d : %lld\n",maxb,over);
        if(out)fclose(out);
        return 0;
    }
    if(!strcmp(mode,"validate")){       /* validate <c> <ntrials> <nv> <maxb> : random V, compare bf vs dfs */
        int c=atoi(argv[3]); int nt=atoi(argv[4]); int nv=atoi(argv[5]); int maxb=atoi(argv[6]);
        srandom(12345);
        int bad=0; long long agree=0; long long hist[8]; memset(hist,0,sizeof(hist));
        for(int t=0;t<nt;t++){
            C=c;N=1<<c;NW=(N+63)/64;
            /* random distinct weight>=2 masks */
            int seen[4096]; memset(seen,0,sizeof(int)*N); NV=0;
            while(NV<nv){ int m=random()%N; if(__builtin_popcount(m)<2||seen[m])continue; seen[m]=1; V[NV++]=m; }
            base_closure();
            int r1=brute(maxb);
            int r2=iddfs(maxb);
            if(r1!=r2){ bad++; printf("MISMATCH trial %d: bf=%d dfs=%d  V=",t,r1,r2); for(int i=0;i<NV;i++)printf(" %d",V[i]); printf("\n"); }
            else { agree++; if(r1>=0) hist[r1]++; }
        }
        long long inh=0; for(int b=0;b<=maxb;b++) inh+=hist[b];
        printf("validate c=%d nv=%d trials=%d maxb=%d : agree=%lld mismatch=%d  depth hist:",c,nv,nt,maxb,agree,bad);
        for(int b=0;b<=maxb;b++) printf(" %d:%lld",b,hist[b]); printf("  (>maxb: %lld)\n", agree-inh);
        return bad!=0;
    }
    fprintf(stderr,"unknown mode\n"); return 1;
}
