#!/usr/bin/env python3
"""Referee: transcribe the published listings from my own pdftotext of the public PDFs, verify them against my
FIPS-197 implementation, measure depth, test in-place realisability of the g-XOR forward circuits (Jean 88, Sun 89),
and check the BKL16 reversal of Yuan's 91 (and Xiang's 92) gives InvMixColumns."""
import re, json, random, sys
sys.path.insert(0, "~/xor_ui/slp-invmc/referee_89")
S="<tmp>/work"
NEW="~/xor_ui/slp-invmc"
def xtime(a):
    a<<=1
    return (a^0x11b)&0xff if a&0x100 else a
def gmul(a,b):
    r=0
    while b:
        if b&1: r^=a
        a=xtime(a); b>>=1
    return r
def mixcol(c):
    s0,s1,s2,s3=c
    return [gmul(2,s0)^gmul(3,s1)^s2^s3, s0^gmul(2,s1)^gmul(3,s2)^s3, s0^s1^gmul(2,s2)^gmul(3,s3), gmul(3,s0)^s1^s2^gmul(2,s3)]
def invmixcol(c):
    s0,s1,s2,s3=c
    return [gmul(0xe,s0)^gmul(0xb,s1)^gmul(0xd,s2)^gmul(0x9,s3), gmul(0x9,s0)^gmul(0xe,s1)^gmul(0xb,s2)^gmul(0xd,s3),
            gmul(0xd,s0)^gmul(0x9,s1)^gmul(0xe,s2)^gmul(0xb,s3), gmul(0xb,s0)^gmul(0xd,s1)^gmul(0x9,s2)^gmul(0xe,s3)]
def rows_of(f, msb_first):
    idx=lambda byte,bit: 8*byte+(7-bit if msb_first else bit)
    rows=[0]*32
    for byte in range(4):
        for bit in range(8):
            c=[0,0,0,0]; c[byte]=1<<bit; out=f(c)
            for ob in range(4):
                for obit in range(8):
                    if (out[ob]>>obit)&1: rows[idx(ob,obit)] |= 1<<idx(byte,bit)
    return rows
TARGETS={("MC",False):rows_of(mixcol,False),("MC",True):rows_of(mixcol,True),("IMC",False):rows_of(invmixcol,False),("IMC",True):rows_of(invmixcol,True)}

def identify(final_masks):
    """final_masks: list of 32 masks (register contents or output gate masks). Return which target/convention matches as a set."""
    hits=[]
    for k,rows in TARGETS.items():
        if set(final_masks)==set(rows): hits.append(k)
    return hits

def sxor_unroll(prog, init=None):
    """prog: list of (i,j,label) meaning x[i]^=x[j]. Return g-XOR gates list, per-register signal, depths, and final masks.
    init: optional per-register initial variable index (input variable init[r] sits in register r)."""
    reg=list(range(32)); gates=[]; mask=[1<<(init[i] if init else i) for i in range(32)]; depth=[0]*32
    for i,j,_ in prog:
        gates.append((reg[i],reg[j])); mask.append(mask[reg[i]]^mask[reg[j]]); depth.append(max(depth[reg[i]],depth[reg[j]])+1)
        reg[i]=len(mask)-1
    return gates, reg, mask, depth
def gxor_eval(gates):
    mask=[1<<i for i in range(32)]; depth=[0]*32
    for a,b in gates: mask.append(mask[a]^mask[b]); depth.append(max(depth[a],depth[b])+1)
    return mask, depth
def inplace_test(gates, outsigs):
    """Same model as shrink_sxor.py: perfect kill-matching gate->own non-output operand + acyclic precedence."""
    n=len(gates); NS=32+n; OUT=set(outsigs)
    cons={s:[] for s in range(NS)}
    for k,(a,b) in enumerate(gates): cons[a].append(32+k); cons[b].append(32+k)
    opts={32+k:[x for x in gates[k] if x not in OUT] for k in range(n)}
    def acyclic(kill):
        adj={s:set() for s in range(NS)}
        for k in range(n):
            for x in gates[k]: adj[x].add(32+k)
        for g,s in kill.items():
            for c in cons[s]:
                if c!=g: adj[c].add(g)
        indeg={s:0 for s in range(NS)}
        for s in adj:
            for t in adj[s]: indeg[t]+=1
        st=[s for s in range(NS) if indeg[s]==0]; cnt=0
        while st:
            s=st.pop(); cnt+=1
            for t in adj[s]:
                indeg[t]-=1
                if indeg[t]==0: st.append(t)
        return cnt==NS
    found=[None]; nodes=[0]
    def bt(kill,killed,gl):
        nodes[0]+=1
        if found[0] or nodes[0]>2_000_000: return
        if not gl:
            if acyclic(kill): found[0]=dict(kill)
            return
        gl=sorted(gl,key=lambda g: len([x for x in opts[g] if x not in killed])); g=gl[0]
        for x in opts[g]:
            if x in killed: continue
            kill[g]=x; killed.add(x); bt(kill,killed,gl[1:]); del kill[g]; killed.discard(x)
    bt({},set(),list(range(32,NS)))
    both_out=[g for g,o in opts.items() if not o]
    return found[0] is not None, nodes[0], both_out

txt=lambda p: open(p,encoding="utf-8",errors="replace").read().replace("\x0c","\n").split("\n")
def after(lines, caption, n):
    i=[k for k,L in enumerate(lines) if caption in L]; assert len(i)==1, (caption,i); return lines[i[0]:i[0]+n]
# ---- Xiang 2020 Table 3 (MixColumns, x/y) and Table 4 (InvMixColumns, u/v), ePrint 2020/903 pp.16-17 ----
X=txt(f"{S}/xiang2020e.txt")
def parse_inplace(lines, v, y):
    pat=re.compile(r'(\d+)\s+%s(\d+)\s*=\s*%s(\d+)\s*\+\s*%s(\d+)(?:\s*\[\s*%s(\d+)\s*\])?'%(v,v,v,y))
    ops={}
    for L in lines:
        for m in pat.finditer(L):
            no,i,a,j,lab=m.groups(); assert i==a, L
            ops[int(no)]=(int(i),int(j),None if lab is None else int(lab))
    assert sorted(ops)==list(range(len(ops))), sorted(ops)
    return [ops[k] for k in range(len(ops))]
xi_mc=parse_inplace(after(X,'Table 3: An implementation of AES MixColumns with 92',40),'x','y'); xi_imc=parse_inplace(after(X,'Table 4: An implementation of AES inverse MixColumns with 92',40),'u','v')
# ---- Yuan 2024 Table 4 (MixColumn, 91) ----
Y=txt(f"{NEW}/papers/yuan2024.txt")
pat=re.compile(r'(\d+)\s+x\[(\d+)\] = x\[(\d+)\] \+ x\[(\d+)\](?: y\[(\d+)\])?')
ops={}
for L in after(Y,'Table 4: The implementation of AES MixColumn with 91 XORs',36):
    for m in pat.finditer(L):
        no,i,a,j,lab=m.groups(); assert i==a; ops[int(no)]=(int(i),int(j),None if lab is None else int(lab))
assert sorted(ops)==list(range(1,92)), sorted(ops)
yu_mc=[ops[k] for k in range(1,92)]
# ---- Sun-Yang-Li 2025 Table 4 (89 g-XOR) ----
Sn=txt(f"{S}/sun2025.txt")
pat=re.compile(r'b(\d+) = b(\d+) ⊕ b(\d+)(?:\s*\[t(\d+)\s*\])?')
ops={}
for L in after(Sn,'Table 4: An implementation of AES MixColumns matrix with 89 g-Xor',24):
    for m in pat.finditer(L):
        k,a,b,lab=m.groups(); ops[int(k)]=(int(a),int(b),None if lab is None else int(lab))
assert sorted(ops)==list(range(32,121)), (len(ops), sorted(ops)[:5])
sun_gates=[(ops[k][0],ops[k][1]) for k in range(32,121)]; sun_lab={32+i:ops[32+i][2] for i in range(89) if ops[32+i][2] is not None}
# ---- Jean 2026 Algorithm 1 (88 g-XOR) ----
Jn=txt(f"{S}/jean2026.txt")
pat=re.compile(r'(\d+):\s*([ty])(\d+)\s*←\s*([xty])(\d+)\s*⊕\s*([xty])(\d+)')
ops={}
for L in Jn:
    for m in pat.finditer(L):
        no,dk,di,ak,ai,bk,bi=m.groups(); ops[int(no)]=((dk,int(di)),(ak,int(ai)),(bk,int(bi)))
assert sorted(ops)==list(range(1,89)), sorted(ops)
sig={('x',i):i for i in range(32)}; jean_gates=[]; jean_lab={}
for no in range(1,89):
    d,a,b=ops[no]; jean_gates.append((sig[a],sig[b])); sig[d]=31+no
    if d[0]=='y': jean_lab[31+no]=d[1]
print("== parsed: Xiang T3 %d ops, Xiang T4 %d ops, Yuan T4 %d ops, Sun T4 %d gates, Jean Alg1 %d gates"%(len(xi_mc),len(xi_imc),len(yu_mc),len(sun_gates),len(jean_gates)))

def report_inplace(name, prog, expect, init=None):
    gates,reg,mask,depth=sxor_unroll(prog, init)
    final=[mask[reg[i]] for i in range(32)]
    hits=identify(final)
    # label check: register i annotated y_l must hold row l
    labok=None
    for k,rows in TARGETS.items():
        if k in hits:
            labok=all(mask[reg[i]]==rows[l] for (i,j,l) in prog if l is not None)
    D=max(depth[reg[i]] for i in range(32))
    print("   %-34s ops=%d  registers hold exactly: %s  labels consistent: %s  unrolled depth=%d"%(name,len(prog),hits,labok,D))
    assert any(h[0]==expect for h in hits), name
    return gates, [reg[i] for i in range(32)], D
def report_gxor(name, gates, lab, expect):
    mask,depth=gxor_eval(gates)
    for k,rows in TARGETS.items():
        if k[0]!=expect: continue
        holders={}
        for o in range(32):
            h=[s for s in range(len(mask)) if mask[s]==rows[o]]
            if len(h)!=1: break
            holders[o]=h[0]
        else:
            D=max(depth[holders[o]] for o in range(32))
            labok=all(holders[l]==s for s,l in lab.items())
            outs=[holders[o] for o in range(32)]
            print("   %-34s gates=%d  computes %s (conv msb_first=%s), all 32 outputs on distinct gates, labels consistent: %s, depth=%d"%(name,len(gates),k[0],k[1],labok,D))
            ok,nodes,both=inplace_test(gates,outs)
            print("      in-place (s-XOR, 32 regs, no temporaries) realisable as-is: %s   [gates with both operands outputs: %s; search nodes %d]"%(ok,both,nodes))
            # count non-output signals lacking a consumer (a second obstruction)
            NS=len(mask); OUT=set(outs); cons={s:0 for s in range(NS)}
            for a,b in gates: cons[a]+=1; cons[b]+=1
            noc=[s for s in range(NS) if s not in OUT and cons[s]==0]
            print("      non-output signals with no consumer:", noc)
            return
    print("   %-34s: DOES NOT compute %s in any tried convention"%(name,expect))

print("== published in-place (s-XOR) listings, run forward on 32 registers:")
xg,xo,_=report_inplace("Xiang T3 MixColumns (92)", xi_mc, "MC")
ig,io,Dx=report_inplace("Xiang T4 InvMixColumns (92)", xi_imc, "IMC")
yg,yo,_=report_inplace("Yuan T4 MixColumn (91)", yu_mc, "MC")
print("== BKL16 Cor.1: the same listings run in REVERSE order:")
rev=lambda prog:[(i,j,None) for (i,j,_) in reversed(prog)]
def perm(prog):   # forward program leaves output label l in register r  ->  reversed program must start with input l in register r
    init=[None]*32
    for i,j,l in prog:
        if l is not None: init[i]=l
    assert sorted(init)==list(range(32)); return init
print("   (inputs of the reversed program are placed by the forward program's output-register permutation)")
_,_,Dxr=report_inplace("reverse(Xiang T3) -> should be IMC", rev(xi_mc), "IMC", perm(xi_mc))
_,_,Dyr=report_inplace("reverse(Yuan T4)  -> should be IMC", rev(yu_mc), "IMC", perm(yu_mc))
_,_,Dir=report_inplace("reverse(Xiang T4) -> should be MC ", rev(xi_imc), "MC", perm(xi_imc))
print("   => a 91-gate 2-input XOR circuit for InvMixColumns (depth %d as unrolled) is supportable from Yuan Table 4 by reversal; Xiang T4 unrolls to depth %d"%(Dyr,Dx))
print("== published g-XOR forward circuits (do NOT transfer to InvMixColumns unless in-place realisable):")
report_gxor("Sun-Yang-Li 2025 Table 4 (89)", sun_gates, sun_lab, "MC")
report_gxor("Jean 2026 Alg.1 (88)", jean_gates, jean_lab, "MC")
print("== control: the in-place test applied to unrolled Xiang T4 / Yuan T4 (must be True):")
for nm,g,o in [("Xiang T4 unrolled",ig,io),("Yuan T4 unrolled",yg,yo)]:
    ok,nodes,both=inplace_test(g,o); print("   %s: %s"%(nm,ok))
# save transcriptions
json.dump({"xiang_T3_mc":xi_mc,"xiang_T4_imc":xi_imc,"yuan_T4_mc":yu_mc,"sun_T4_gates":sun_gates,"jean_alg1_gates":jean_gates},open(f"{NEW}/referee_89/literature_transcriptions.json","w"))
