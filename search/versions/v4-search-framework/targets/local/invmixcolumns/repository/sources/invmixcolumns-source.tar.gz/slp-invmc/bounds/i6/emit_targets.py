#!/usr/bin/env python3
"""emit_targets.py -- print the |K| restricted row masks of M|_K as a comma list,
for feeding to ./brute.  The matrix is loaded through i5_core, i.e. re-derived
from NEW/spec/*.json's declared mds_column and self-checked, exactly as in I5.

  python3 emit_targets.py --target invmc --K 0,3,4,5,6,7,14,17
"""
import argparse
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import i6_core as i6                                    # noqa: E402
core = i6.core

ap = argparse.ArgumentParser()
ap.add_argument('--target', default='invmc')
ap.add_argument('--K', required=True)
ap.add_argument('--verbose', action='store_true')
a = ap.parse_args()

say = print if a.verbose else (lambda *x, **k: None)
t = core.load(a.target)
core.rederive_and_compare(t, say=say)
core.selfcheck(t, say=say)
K = [int(x) for x in a.K.split(',')]
assert i6.admissible(t.rows, K, say=say if a.verbose else None), \
    'keep-set is NOT Theorem-A admissible'
V = i6.restrict(t.rows, K)
assert len(set(V)) == 32 and min(i6.popcount(v) for v in V) >= 2
print(','.join(str(v) for v in V))
