# REFEREE_L6: shared-nothing referee report on the e27 in-place 89 and the InvMixColumns 88 @ 19

Referee: Claude (Opus), 2026-09-26, 1 core. Nothing committed, and nothing written outside this directory.

**Independence.** I did not open any lane code (`L6_cnot/*.py`, `*.c`, `L1_matroid/*.py`) or anything in `MAIN_VERIFY/`. I did read the lane's record files: the listings, the JSON files, and the `.oracle.txt` one-liners, which I treated only as claims. From the lane's `lit/` folder I read only the papers' PDFs, never the notes. Everything below comes from code written in this directory, starting with my own FIPS-197 AES. Project documents I consulted: `slp-invmc/RESULT.md`, for the stated previous frontier, and `slp-invmc/PRIOR_ART_INVMC.md` plus the public repo's `PRIOR_ART.md`, as pointers only. I re-checked every fact they point to at its primary source.

## Verdicts

| Claim | Verdict |
|---|---|
| **1.** In-place AES MixColumns in **89** instructions `x[t] ^= x[c]` (32 registers, no ancilla, output permutation free) is a new record (published best: 91 Yuan et al., 92 Xiang et al.) | **CONFIRMED WITH CORRECTIONS** (C1–C3 below change framing only, not the verdict) |
| **1a.** `inplace89_D_depth27.txt` has CNOT depth **27**, beating Xiang 92 @ 28 (Zhu–Huang) and Yuan 91 @ 35 "as listed" | **CONFIRMED WITH CORRECTION C1**: Yuan's 91 reaches depth **28** under the same reordering Zhu–Huang used, so the lead is 27 vs 28, not 27 vs 35. D still beats both. |
| **1b.** Running the word backwards gives an **89**-instruction in-place InvMixColumns | **CONFIRMED** (all five 89s; reversed D has CNOT depth 27) |
| **2.** InvMixColumns 2-input-XOR SLP with **88 gates at depth 19**, a new Pareto point | **CONFIRMED** (6/6 files) |

No source I could find, published or posted up to 2026-09-26, has an in-place / s-XOR / ancilla-free MixColumns or InvMixColumns with ≤ 90 instructions. No third-party source has an InvMixColumns circuit with ≤ 88 gates in any model, at any depth. The only earlier ≤ 88 InvMixColumns circuits are this project's own 88s at depths 33–36.

---

## 1. Own reference (built from FIPS-197 only): `aes_ref.py`, `test_aes_ref.py` → `test_aes_ref.out`

GF(2⁸) uses 0x11B. The S-box is built from inversion plus the affine map. I implemented full AES-128 encryption and decryption. MixColumns uses coefficients 02 03 01 01 and InvMixColumns uses 0e 0b 0d 09, on column-major state.

| Test | Result |
|---|---|
| FIPS-197 App. C.1 (`000102…0f` / `00112233…ff` → `69c4e0d8…c55a`), encrypt + decrypt | PASS |
| FIPS-197 App. B (`2b7e1516…` / `3243f6a8…` → `3925841d…0b32`), encrypt + decrypt, and the round-1 column `d4bf5d30 → 046681e5` | PASS |
| Six standard MixColumns column vectors, both directions | PASS |
| 32×32 binary matrices vs the GF(2⁸) maps on 2,000 random columns; InvMC·MC = MC·InvMC = I; MC³ = InvMC | PASS |
| Densities: MC 184, InvMC 472 | as expected |

Bit convention: index `8·byte + k`, where k is the coefficient of xᵏ ("LSB"). This matches Xiang et al.'s note under Table 3 ("x0‖…‖x7 is the first byte with x7 the most significant bit"). Xiang's GitHub "Original Matrix" equals my matrix bit for bit (`lit_tables.out`).

## 2. Claim 1: mechanical verification (`verify.py`, `e2e_fips.py`, `removal_test.py`)

| Listing | n | Valid, outputs up to register permutation | `[y_r]` marks | Reverse ⇒ InvMC | FIPS-197 enc (forward) / dec (reversed) | CNOT depth, ASAP in listed order |
|---|---|---|---|---|---|---|
| inplace89_A | 89 | ✓ (8 fixed points) | 32/32 correct | ✓ | ✓ / ✓ | 38 |
| inplace89_B | 89 | ✓ | 32/32 | ✓ | ✓ / ✓ | 34 |
| inplace89_C_depth | 89 | ✓ | 32/32 | ✓ | ✓ / ✓ | 32 |
| **inplace89_D_depth27** | **89** | ✓ (7 fixed points) | 32/32 | ✓ | ✓ / ✓ | **27** |
| inplace89_X_xianglineage | 89 | ✓ | 32/32 | ✓ | ✓ / ✓ | 37 |
| inplace90_A | 90 | ✓ | 32/32 | ✓ | ✓ / ✓ | 49 |
| *control* Yuan 91 (`mixcolumns_yuan91.txt`) | 91 | ✓ (8 fixed points) | 32/32 | ✓ | ✓ / ✓ | **35** (as briefed) |
| *control* Xiang 92 (`mixcolumns_xiang92.txt`) | 92 | ✓ (5 fixed points) | 32/32 | ✓ | ✓ / ✓ | 30 |

- **Valid** means my mask simulator ends with exactly the 32 MixColumns rows, as a permutation of the registers. A value-level replay also passes: 200 random columns forward and back, and 5,000 random columns inside the FIPS-197 pipeline. Output placement there comes from the files' own `[y_r]` marks, so the marks are tested independently.
- Every listing also fails under the MSB-first convention, as the controls do, so the convention is identical to the published circuits'.
- **Negative control:** changing one control register in D breaks FIPS-197 encryption.
- The shipped `inplace89_A_invmixcolumns.txt` is exactly the reversed word of A. With its `R(o)` placement header, register i ends with InvMixColumns bit i. FIPS-197 decryption and 5,000 random columns pass.
- **No trivial slack:** in every claimed and published listing, deleting any 1 of the n instructions, or any pair of them, gives an invalid program. That is 0/89 and 0/3,916 for each 89; 0/91 and 0/4,095 for Yuan; 0/92 and 0/4,186 for Xiang.
- Transcriptions: the two comparator files equal the op sequences I parsed from the papers' own tables (Xiang Table 3, Yuan Table 4), and Yuan's GitHub `XOR/AES.txt`.

## 3. Convention: is the comparison like for like?

**Yes.** Both published programs use the same model as the 89s:

- **Listings:** every instruction is `x[t] ^= x[c]` with t, c in 0…31. No 33rd register appears, so there is no ancilla. The final register→output maps are non-identity permutations: 8 fixed points for Yuan, 5 for Xiang, 7 for D. Both published circuits rely on output-permutation freedom exactly as the 89s do.
- **Papers:**
  - Xiang et al. §1 define s-Xor as in-place operations x_i = x_i ⊕ x_j that turn the matrix into "identity (or a permutation) matrix".
  - Yuan et al. Def. 4: M = P·∏E³ₖ with P a permutation, and "the cost of permutation in the circuit is negligible".
  - Zhu–Huang Def. 1: A = P·∏E(c,t), rewiring free.
- **Inverse:** the reversed word needs its inputs placed according to the forward output map. Renaming registers turns this into natural inputs with permuted outputs, at no cost, which is the convention of Xiang's InvMC Table 4. I wrote that renamed version for D as `invmc_inplace89_depth27_from_D.txt` (89 instructions, depth 27, verified).

## 4. Depth metric (`depth_tools.py`, `depth_report.py`, `exact_exchange_depth.py`)

Zhu–Huang (ePrint 2023/165, §3) define three depths:

- **Seq D:** contiguous qubit-disjoint blocks of the listed order.
- **Move-eq D:** ASAP layering in listed order. This is what the Q# estimator reports, and it is the brief's metric.
- **Exchange-eq D:** the minimum over reorderings that swap commuting CNOTs only. CNOTs commute iff t₁≠c₂ and c₁≠t₂. Any such reordering preserves the map (it is a linear extension of the dependency order).

I computed the exchange optimum **exactly** with CP-SAT. Every optimal order was re-simulated and gives the identical final register state.

| Program | Seq D | ASAP (move-eq) | ZH Alg. 1 (my transcription) | **exact exchange-eq optimum** | lower bound (longest dependent chain) |
|---|---|---|---|---|---|
| Xiang 92 | **41** | **30** | **28** | **28** (OPTIMAL) | 26 |
| Yuan 91 | 48 | 35 | 28 | **28** (OPTIMAL) | 27 |
| Yuan Table 5 (98) | 13 | 13 | 13 | 13 | 13 |
| **D (89)** | 27 | **27** | 27 | **27** (OPTIMAL) | **27** |
| X (89) | 61 | 37 | 27 | 27 | 27 |
| A / B / C (89) | 65 / 63 / 32 | 38 / 34 / 32 | 35 / 33 / 32 | 35 / 33 / 32 | 34 / 32 / 32 |
| 90_A | 67 | 49 | 39 | 39 | 37 |

- **Zhu–Huang reproduced exactly.** Their Table 1 AES row is 92 / Seq 41 / Move-eq 30 / Exchange-eq 28, and so is mine. Their 28 is in fact optimal for that sequence.
- **Yuan Table 5 reproduced gate for gate:** my ASAP layer equals the printed depth label on all 98 operations.
- **Jang et al. reproduced:** their CiC 2025 Table 4 gives Xiang 92 → 30 and Yuan 91 → 35, both matching my ASAP.
- So the brief's "greedy ASAP in listed order" is the literature's move-equivalent / Q# depth. Zhu–Huang's 28 is the stricter exchange-equivalent depth.
- **D is optimal under both.** Its dependency graph has a chain of 27 non-commuting gates, so no map-preserving reordering of D goes below 27.
- Depth is symmetric under reversal. Reversed D (InvMC 89) has ASAP 27 and exchange optimum 27. For comparison, Xiang's Table 4 InvMC 92 as printed is 30 / 28, and Yuan 91 reversed is 35 / 28 (`invmc_inplace_depths.out`).

## 5. Claim 2: InvMixColumns SLPs (`verify.py`, `e2e_fips.py`, `save_reorders.py`)

| Check | Result for the 6 `*depth19.json` files |
|---|---|
| Gate count | 88 each; every gate reads only earlier signals; no self-XOR |
| All 32 InvMixColumns rows present | ✓, and the files' `provenance.outputs` maps are correct |
| FIPS-197 App. B + C.1 decryption with the SLP as InvMixColumns; 5,000 random columns | ✓ all 6 |
| Depth (longest input→output path) | **19** for all 6; the maximum over all signals is also 19 |
| Dead gates / duplicate masks / zero signals | 0 / 0 / 0 |
| Distinct circuits? | 6 distinct value sets, sharing 41–86 masks pairwise |

All 41 files in `invmc_from_mc/` are valid 88-gate SLPs, and each filename's depth equals the computed depth (minimum 19).

**Pareto status.**
- Previous frontier (`RESULT.md`): {(5,179), (6,149), (7,103), (8,101), (9,95), (14,91), (16,89), (33,88)}. All 729 previous 88s sat at depths 33–36.
- (19, 88) dominates (33, 88) and is not dominated by (16, 89). It is a new Pareto point.
- Published InvMixColumns points (§6) all have ≥ 91 gates, so none dominates it.

## 6. Novelty: literature sweep, 2019 to 2026-09-26 (plus pre-2019 baselines)

**Method.**
- Web search, including Chinese-language queries.
- IACR ePrint site search for "MixColumns", "MixColumn", "in-place" and "linear layers". ePrint abstract pages and PDFs *were* fetchable here, so ePrint items are READ at the primary source.
- arXiv API, three queries.
- ToSC tables of contents, 2024(3) to 2026(2).
- Semantic Scholar citation graph: every 2025+ paper citing Xiang 2020, Yuan 2024, Zhu–Huang, Shi–Feng, Liu et al. 2023 or Zhang et al. 2024, 74 rows in `lit/s2_cites_2025plus.txt`, each triaged by title.
- GitHub artifacts: Yuan, Xiang, Xu–Sun, HILL, and the user's public repo.

**Adversarial extra.** A free SLP is an in-place program of the same length iff each gate can overwrite an operand that is dead afterwards; I decided this exactly with CP-SAT (`slp_inplace.py`). My checker converts the Yuan 91, Xiang 92 and D listings back into valid in-place programs (positive control). It proves the following **not** in-place at their own length:
- Jean's 88 (ePrint 2026/1481);
- Sun–Yang–Li's 89 (ePrint 2025/1493, Table 4);
- all seven 88/89-gate SLPs in the user's public repo.

So no in-place ≤ 89 is hidden in any published SLP listing I could check.

"s" is s-XOR (in-place), "g" is g-XOR (free SLP, temporaries allowed), "CNOT@d" is an in-place quantum circuit at CNOT depth d.

| # | Source | AES MixColumns count (model) | InvMixColumns | Status |
|---|---|---|---|---|
| 1 | Kranz, Leander, Stoffelen, Wiemer, ToSC 2017(4) (ePrint 2017/1151) *[baseline]* | 97 g | — | READ |
| 2 | Grassl, Langenberg, Roetteler, Steinwandt, PQCrypto 2016 (arXiv 1512.04965) *[baseline]* | 277 CNOT@39 (LUP, in-place) | — | READ |
| 3 | Maximov, ePrint 2019/833 | 92 g, depth 6 | — | READ |
| 4 | Banik, Funabiki, Isobe, IWSEC 2019 (ePrint 2019/856) | 95 g | — | READ |
| 5 | Tan, Peyrin, TCHES 2020(1) (ePrint 2019/847) | 94 g, depth 6 | **152 g, depth 9** (Table 8) | READ |
| 6 | Li, Sun, Li, Wei, Hu, ToSC 2019(1) | 105 g @ 3 | — | SECONDARY (LZW23 and SFX23 tables) |
| 7 | Xiang, Zeng, Lin, Bao, Zhang, ToSC 2020(2) (ePrint 2020/903) | **92 s** (Table 3) | **92 s** (Table 4) | READ; both tables transcribed and verified |
| 8 | Jaques, Naehrig, Roetteler, Virdia, EUROCRYPT 2020 (arXiv 1910.01700) | 277/column CNOT, full depth 111 (in-place PLU); Maximov out-of-place | — | READ |
| 9 | Zou, Wei, Sun, Liu, Wu, ASIACRYPT 2020 | 277 CNOT@39 in-place (per Shi–Feng Table 2) | — | **UNREAD** (paywalled) |
| 10 | Langenberg, Pham, Steinwandt, IEEE TQE 2020 | ? | — | **UNREAD** |
| 11 | Lin, Xiang, Zeng, Zhang, CT-RSA 2021 | 91, depth 7. Labelled g by Yuan Table 2, SFX23 and Jang et al. (out-of-place 182 CNOT / 123 qubits); labelled s in the user's repo. Either way > 90. | — | **UNREAD** (paywalled) |
| 12 | de Brugière et al. 2021 | 128 CNOT@12 in-place (per Shi–Feng) | — | SECONDARY |
| 13 | Liu, Wang, Fan, Wu, Sun, Wang, ToSC 2022(1) (ePrint 2022/231) | 103 g @ 3 | — | SECONDARY |
| 14 | Liu, Wang, Sun, Fan, Wu, Wang, ToSC 2022(2) (ePrint 2022/747) | multi-input XOR; Jang et al. port to in-place 95–96 CNOT | — | SECONDARY |
| 15 | Huang, Sun, ASIACRYPT 2022 (ePrint 2022/620) | uses Xiang 92 in-place | — | READ |
| 16 | Zhu, Huang, Inscrypt 2022 (ePrint 2023/165) | 92 CNOT: Seq 41 / Move 30 / **Exchange 28** | — | READ; all three depths reproduced |
| 17 | Zhang, Feng, Xu, arXiv 2210.05184 | 92 (unconstrained), 159 on a 4×8 lattice | — | READ |
| 18 | Lin, Xiang, Xu, Zhang, Zeng, QIP 2023 (ePrint 2023/146) | uses Xiang 92 | — | READ |
| 19 | Liu, Zhao, Wang, CT-RSA 2023 (ePrint 2023/174) | 102 g @ 3 | — | READ |
| 20 | Liu, Preneel, Zhao, Wang, ASIACRYPT 2023 (ePrint 2023/1417) | **98 CNOT@16** in-place | — | READ |
| 21 | Shi, Feng, Xu, ToSC 2023(4) | 99 g @ 3 | — | READ |
| 22 | Frontiers in Physics 2023, "New record in the number of qubits…" | 4×92 = 368 (Xiang) | — | READ |
| 23 | **Yuan, Wu, Shi, Zhang, Zhang, ToSC 2024(2)** | **91 s** (Table 4; 35 as listed, 28 exchange-optimal, *computed here*); **98 CNOT@13** in-place (Table 5) | (implied by reversal: 91) | READ; both tables and GitHub verified; nothing below 91 in the repo |
| 24 | Osvik, Canright, ePrint 2024/1076 | 97 g @ 4, 94 g @ 5 | — | READ |
| 25 | Shi, Feng, ASIACRYPT 2024 (ePrint 2024/381) | **131 CNOT@10** in-place; Table 2 survey | — | READ |
| 26 | Zhang, Shi, Wu, Sui, IEEE TC 2024 | **105 CNOT@10** in-place | — | Abstract READ (Semantic Scholar); body **UNREAD** |
| 27 | Baksi et al., IEEE SOCC 2024 | 97 CNOT@17 in-place (per Jang et al. Table 4) | — | Abstract READ; body **UNREAD** |
| 28 | Pehlivanoğlu, Demir, PeerJ CS 2024 | 159 CNOT / 76 qubits (out-of-place) | — | SECONDARY |
| 29 | Jang, Baksi, Kim, Song, Seo, Chattopadhyay, IACR CiC 2025 (ePrint 2022/683) | adopts Yuan 91 in-place (depth 35); survey (lowest in-place is 91); own out-of-place 169@8 | — | READ |
| 30 | Huang, Zhang, Lin, EUROCRYPT 2025 (ePrint 2025/212) | S-box work, no new MixColumns | — | READ |
| 31 | Liao, Luo, ASIACRYPT 2025 (ePrint 2025/1494) | adopts Xiang 92 ("lowest to date") | — | READ |
| 32 | Sun, Yang, Li, ePrint 2025/1493 | **89 g** (depth 9 measured); **not** in-place-convertible | — | READ; CP-SAT |
| 33 | Jang, Baksi, Seo, ePrint 2025/1915 | reorders Jaques' in-place 277: depth 111 → 81 | — | READ |
| 34 | Frontiers in Physics 2025, "Constructing resource-efficient quantum circuits for AES" | uses Liu 98@16 | — | READ |
| 35 | Yu, Liu, ToSC 2025(2) (ePrint 2025/1960) | new linear-layer designs; no AES count | — | abstract |
| 36 | Li et al., HILL, ToSC 2026(1) | XOR2/XOR3, 270.4 GE @ 3 (out-of-place, not 2-input) | — | README + abstract |
| 37 | **Xu, Sun, ToSC 2026(2) / arXiv 2511.18226v2 (2026-05-24)** | 105–107 CNOT@10 in-place; its s-XOR table names **91 (Yuan) as state of the art** | — | READ, plus repo |
| 38 | Song, Seo, ePrint 2026/1412 (Jul 2026) | uses "the 91-CNOT pattern" | — | READ |
| 39 | **Jean, ePrint 2026/1481 (2026-07-20)** | **88 g** (depth 7 measured); **not** in-place-convertible | — | READ; CP-SAT |
| 40 | Chou, ePrint 2026/1798; Guo et al., ePrint 2026/1815 (Aug 2026) | greedy low-depth CNOT synthesis / SMT encoding; no AES MixColumns numbers | — | READ |
| 41 | Li, Guan, arXiv 2609.04160 (2026-09-03) | NP-hardness of s-XOR; no AES numbers | — | READ |
| 42 | Pandey, arXiv 2609.20873 (2026-09-16) | timeline: g record 88 (Jean); "91 … under the stricter s-XOR metric by Yuan" | — | READ |
| 43 | Banik, Bogdanov, Regazzoni, "Compact circuits for combined AES encryption/decryption" (JCEN 2019, doi 10.1007/s13389-017-0176-3) | 108-XOR forward circuit (hardware) | InvMC either with 193 XOR + 32-bit mux (an earlier design they cite) or as MC³ in 3 passes of the 108-XOR circuit: hardware area, not a 2-input SLP count | READ |
| 44 | Almazrooie et al. 2018; Li, Cai et al. SCPMA 2022; Wang, Wei, Long arXiv 2109.12354; Frontiers of Physics 2022 (AES "fewer qubits and gate operations") | in-place 275@200 (Almazrooie, per Jang et al.); others not stated | — | **UNREAD** / SECONDARY |
| 45 | User's public repo `aes-mixcolumns-xor-circuits` | 88–89 g (depths 5–10); none in-place-convertible | — | READ; CP-SAT |

**Result.**
- **In-place / s-XOR / CNOT, ≤ 90:** none. The published floor is **91** (Yuan 2024), and the literature still states it as the record as late as May, July and September 2026 (rows 37, 38, 42).
- **InvMixColumns with ≤ 88 gates in any 2-input-XOR-convertible model:** none. The published and implied points are 92 s (Xiang, explicit; classical depth 27), 91 (Yuan reversed; depth 27), 98 @ 13 (Yuan T5 reversed), 105 @ ≤10, 131 @ 10, and 152 g @ 9 (Tan–Peyrin). Nothing dominates 88 @ 19.

**Coverage limits.**
- Chinese-language journals (CNKI) cannot be searched from here.
- Paywalled primary sources (rows 9, 10, 11, 26 body, 27 body, 44) were checked only through secondary tables and abstracts. All of those report ≥ 91 or give no count.
- DBLP refused automated access.

## 7. Corrections

- **C1. Yuan comparator.** "Yuan's 91 at depth 35 as listed" is accurate for the listed order, and it is the published figure (Jang et al., CiC 2025, Table 4). But under Zhu–Huang's exchange-equivalence, the notion behind the 28 quoted for Xiang, the same 91 instructions reach **28**, and 28 is proven optimal by CP-SAT. The reordered, re-verified file is `yuan91_reordered_depth28.txt`. The fair statement is **89 @ 27 vs 91 @ 28 vs 92 @ 28**: D still strictly dominates both, but by one layer, not eight.
- **C2. Name the depth notion.** D's 27 is ASAP in listed order (move-equivalent). It is also its exchange optimum, because D's longest dependent chain is 27. Xiang's 28 is exchange-equivalent and likewise exactly optimal. Quote all three in the same notion.
- **C3. D is not a separate circuit.** D and X have the same instruction multiset, and every non-commuting pair appears in the same order, so D is X rescheduled (`lineage.out`). The five 89s form two lineages:
  - {A, B, C} share 72–74 of their 89 gate masks with Yuan's 91;
  - {X ≡ D} shares 67 with Xiang's 92;
  - each shares only about 40 with Jean's 88 or Sun–Yang–Li's 89 (`valueset_overlap.out`).
  
  Do not count X's listed depth 37 as a separate data point.
- **C4 (note, not an error).** The shipped InvMixColumns listing is the reversal of A, at CNOT depth 38. Reversing D instead gives InvMixColumns 89 at CNOT depth **27**, provided here with natural input placement: `invmc_inplace89_depth27_from_D.txt`.

No correction to Claim 2.

## 8. Reproduce (from this directory, ~40 s on 1 core)

```
export PYTHONDONTWRITEBYTECODE=1
python3 test_aes_ref.py            # FIPS-197 reference
python3 verify.py                  # claims 1, 1b, 2 + controls  -> verify_out.json
python3 lit_tables.py              # paper tables transcribed from the PDFs + verified
python3 e2e_fips.py                # AES-128 enc/dec with each circuit plugged in
python3 removal_test.py            # 1- and 2-deletion slack
python3 depth_report.py 300        # Seq / ASAP / ZH Alg.1 / lower bounds -> depth_report.json
python3 exact_exchange_depth.py    # exact exchange-equivalent optimum (CP-SAT)
python3 invmc_inplace_depths.py; python3 save_reorders.py; python3 invmc_relabel.py
python3 slp_inplace.py; python3 convert_controls.py; python3 userrepo_inplace.py   # SLP -> in-place (CP-SAT)
python3 lineage.py; python3 valueset_overlap.py; python3 classical_depth.py
```

`lit/` holds my own pdftotext extractions of every source marked READ, plus the PDFs I fetched in this session (ePrint, arXiv, DTU) and the GitHub files I checked. Papers already on disk were read from `slp-invmc/papers/`, `campaign_87/prior_basins/imported/papers/`, `campaign_87/e25_proof_to_search/literature/src/`, `campaign_87/agents/lit-88/`, and the PDFs, only, in `L6_cnot/lit/`.
