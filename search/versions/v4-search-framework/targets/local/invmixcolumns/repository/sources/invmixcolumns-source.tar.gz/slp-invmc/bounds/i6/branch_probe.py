#!/usr/bin/env python3
"""branch_probe.py -- I6 PRICING ONLY.  Emits no bound.

Measures the branching structure of the minE DFS (NOTEBOOK sec. 2b) at |K| = 8
on InvMixColumns, to depth 1, 2 and 3.  This is the measurement the I5 author
asked for: their estimate was first-level only (|pairsums| = 28 vs the
forward's 455) and they flagged "do not fund on this number; measure level 2
first".

Usage:
  python3 branch_probe.py --target invmc --layer ../i5/runs/admissible_invmc_k8.txt \
      --select jam32 --depth 3
  python3 branch_probe.py ... --select jam30 --sample 32 --seed 1 --depth 3
"""
import argparse
import os
import random
import statistics
import sys
import time
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import i6_core as i6                                    # noqa: E402
core = i6.core


def load_layer(path):
    return [[int(x) for x in l.split(',')] for l in open(path) if l.strip()]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--target', default='invmc')
    ap.add_argument('--layer', required=True)
    ap.add_argument('--select', default='jam32',
                    choices=['jam32', 'jam30', 'all', 'jampos'])
    ap.add_argument('--sample', type=int, default=0,
                    help='0 = every selected set; else a random sample of this size')
    ap.add_argument('--seed', type=int, default=1)
    ap.add_argument('--depth', type=int, default=2)
    a = ap.parse_args()

    t0 = time.process_time()
    t = core.load(a.target)
    core.rederive_and_compare(t)
    core.selfcheck(t)
    rows = t.rows
    t_load = time.process_time() - t0

    layer = load_layer(a.layer)
    print("\nlayer %s : %d keep-sets of size %d"
          % (os.path.basename(a.layer), len(layer), len(layer[0])))

    # --- jam census over the whole layer (re-measured here, not trusted) -----
    t1 = time.process_time()
    jams = []
    for K in layer:
        assert i6.admissible(rows, K), 'non-admissible keep-set in layer: %s' % K
        V = set(i6.restrict(rows, K))
        av, todo = i6.closure(set(1 << i for i in range(len(K))), V)
        jams.append((tuple(K), len(todo), len(av)))
    t_jam = time.process_time() - t1
    print("  jam distribution : %s" % dict(sorted(Counter(j for _, j, _ in jams).items())))
    print("  re-measured jam census over the full layer : %.3f CPU-s" % t_jam)

    if a.select == 'jam32':
        sel = [K for K, j, _ in jams if j == 32]
    elif a.select == 'jam30':
        sel = [K for K, j, _ in jams if j >= 30]
    elif a.select == 'jampos':
        sel = [K for K, j, _ in jams if j > 0]
    else:
        sel = [K for K, _, _ in jams]
    sel = [list(K) for K in sel]
    print("  selected '%s' : %d keep-sets" % (a.select, len(sel)))
    if a.sample and a.sample < len(sel):
        random.Random(a.seed).shuffle(sel)
        sel = sorted(sel[:a.sample])
        print("  random sample (seed %d) : %d keep-sets" % (a.seed, len(sel)))

    # --- branch profile ------------------------------------------------------
    print("\n%-30s %4s %6s %s" % ("K", "jam", "avail0", "  per-level: nodes  b(min/med/max)"))
    t2 = time.process_time()
    agg = {}
    for K in sel:
        p = i6.profile(rows, K, a.depth)
        line = "%-30s %4d %6d " % (','.join(str(x) for x in K), p['jam'], p['avail0'])
        for d in sorted(p['levels']):
            s = p['levels'][d]['sizes']
            s = [x for x in s if x or True]
            n = p['levels'][d]['nodes']
            line += " | L%d n=%-8d %d/%d/%d" % (
                d, n, min(s), int(statistics.median(s)), max(s))
            agg.setdefault(d, {'nodes': [], 'sizes': []})
            agg[d]['nodes'].append(n)
            agg[d]['sizes'].extend(s)
        print(line, flush=True)
    t_prof = time.process_time() - t2

    print("\nAGGREGATE over the %d measured keep-sets, depth %d, NO last-level pruning"
          % (len(sel), a.depth))
    print("%-6s %12s %12s %12s %10s %10s %10s" %
          ("level", "nodes_min", "nodes_med", "nodes_max", "b_min", "b_med", "b_max"))
    for d in sorted(agg):
        nn = sorted(agg[d]['nodes'])
        ss = sorted(agg[d]['sizes'])
        print("%-6d %12d %12d %12d %10d %10d %10d" %
              (d, nn[0], int(statistics.median(nn)), nn[-1],
               ss[0], int(statistics.median(ss)), ss[-1]))

    print("\ncpu_seconds load %.3f  jam_census %.3f  profile %.3f  total %.3f"
          % (t_load, t_jam, t_prof, time.process_time() - t0))
    return 0


if __name__ == '__main__':
    sys.exit(main())
